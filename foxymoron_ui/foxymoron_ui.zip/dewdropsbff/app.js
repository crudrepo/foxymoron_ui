"use strict";
/**
* Delcare Environments
*/
require('./app/helpers/module.alias').load();
const responseMsg = require('@service/response.message').ResponseMessage,
  rm = require('@service/require.module')({"type":"singleton"}),
  config = require('@helper/configuration');

/**
* Uncaught Exception event is fired.
*/
process.on('uncaughtException', error => {
    let resMsg = new responseMsg(rm.i18nConfig.defaultLocale, "handler", {});
    resMsg.errorRes(error, null, 'Internal Server Error', (err, data)=> {});
});

/**
* AppDynamics: API performance analyzer
*/
if(rm.productConfig.dd.AppDynamics.enabled){
  const appDynamics = require('./app/helpers/appdynamics')
  // Enable AppDynamics
  appDynamics.enableAppDynamics(rm.productConfig.dd.AppDynamics);
}

// Cluster Native Module
const isNotMaster = require('@helper/cluster').enableCluster(rm.settingConfig.isCluster);
if(isNotMaster) {

    /**
    * Module Dependencies.
    */
    const http = require('http'),
          express = require("./express"),
          server = http.createServer(express);

    // start server and listens on port no    
 		server.listen(config.port, (err)=>{
       if(!rm.lodash.isEmpty(err)){
         // log error whenever node server emits error 
         let resMsg = new responseMsg(rm.i18nConfig.defaultLocale, "handler", {});
         resMsg.errorRes(err, null, 'Internal Server Error', (err, data)=> {});
       }else{
         // log info whenever node server starts successful 
         rm.logger.debugger('Node Server is started and Listening on port '+ config.port +'...', true);
       }
		  
    });
    
    // log error whenever node server fails to start 
    server.on('error', (err)=>{
       if(!rm.lodash.isEmpty(err)){
         let resMsg = new responseMsg(rm.i18nConfig.defaultLocale, "handler", {});
         resMsg.errorRes(err, null, 'Internal Server Error', (err, data)=> {});
        }
    });     

}
