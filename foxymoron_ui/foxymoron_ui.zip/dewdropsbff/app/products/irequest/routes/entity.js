"use strict";

module.exports = { 
     /**
    * @swagger
    * /a/irequest/entities/list:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the entity list by pattern
    *     operationId: getListByPattern
    *     description: Fetch the entity list for request,allrequest,workbench,allworkbench,approval pages.
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the request list( Based on those options filter, sorting & pagination ).
    *         in: body
    *         required: true
    *         schema:
    *           allOf:
    *             - type: object
    *               properties:
    *                 type:
    *                   type: string
    *                   default: request
    *               required: [type]
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   getList: {
    pre: null,
    process: "entity.getList",
    post: null,
    method: 'POST'
    }
      
};
