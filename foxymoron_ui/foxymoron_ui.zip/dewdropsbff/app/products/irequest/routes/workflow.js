"use strict";

module.exports = { 
/**
    * @swagger
    * /a/irequest/workflows/predict:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Predict the Workflow
    *     operationId: predictWorkflow
    *     description: Predict the Workflow
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Predict the Workflow.
    *         in: body
    *         required: true
    *         schema:
    *             properties:  
    *               requestId:
    *                 type: string
    *               requestName:
    *                 type: string
    *               urgentRequirement:
    *                 type: boolean
    *               description:
    *                 type: string
    *               eformInstanceId:
    *                 type: string
    *               submitToWorkflow:
    *                 type: boolean
    *               behalfOfUserId:
    *                 type: string
    *               assignedToUserId:
    *                 type: string
    *               assignedToTypeId:
    *                 type: integer
    *               requestDefinitionId:
    *                 type: string
    *               attachmentIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               draft:
    *                 type: boolean
    *               mode:
    *                 type: boolean
    *               formInstance:
    *                 type: string
    *               buyerTenantId:
    *                 type: string
    *               supplierRequestFlag:
    *                 type: boolean
    *               editMode:
    *                 type: boolean
    *               cwfIntegration:
    *                 type: boolean
    *     responses:
    *       200:
    *         description: successful operation
    */
    predict: {
        pre: null,
        process: "workflow.predict",
        post: null,
        method: 'POST'
    }

}
