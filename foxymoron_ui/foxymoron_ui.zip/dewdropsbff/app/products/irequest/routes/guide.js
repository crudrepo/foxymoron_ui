"use strict";

module.exports = { 
   
    /**
    * @swagger
    * /a/irequest/guides/getGuideDetails:
    *   get:
    *     tags:
    *       - iRequest API
    *     summary: Get Guide Me Details
    *     operationId: getGuideDetails
    *     description: Fetch Guide Me Details
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
   getGuideDetails: {
        pre: null,
        process: "guide.getGuideDetails",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/irequest/guides/getGuideNext:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Submit the current Guide Me answer and get next question
    *     operationId: getGuideNext
    *     description: Submit Guide Me answer and get next question
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Answer Option Code
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               optionCode:
    *                 type: string
    *           required: [optionCode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getGuideNext: {
        pre: null,
        process: "guide.getGuideNext",
        post: null,
        method: 'POST'
    }

}