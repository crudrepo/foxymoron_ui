"use strict";

module.exports = { 
     
  /**
    * @swagger
    * /a/irequest/policies/list:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the list of Policies
    *     operationId: getPolicies
    *     description: Get the list of policies
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the list of policies ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "policy.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/policies/getTypes:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the list of Policy Types
    *     operationId: getPolicyTypes
    *     description: Get the list of policy types
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the list of policy types ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getTypes: {
        pre: null,
        process: "policy.getTypes",
        post: null,
        method: 'POST'
    },

     /**
    * @swagger
    * /a/irequest/policies/getPolicyWithTypes:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the list of Policy and PolicyTypes
    *     operationId: getPolicyWithTypes
    *     description: Get the list of policy and policytypes
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the list of policy with types ( Based on those options sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getPolicyWithTypes: {
        pre: null,
        process: "policy.getPolicyWithTypes",
        post: null,
        method: 'POST'
    }
};
