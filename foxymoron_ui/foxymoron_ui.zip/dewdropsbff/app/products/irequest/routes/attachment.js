"use strict";

module.exports = {    
    /**
    * @swagger
    * /a/irequest/attachments/fileDownload/{filePath}:
    *   get:
    *     tags:
    *       - iRequest API
    *     summary: Download Attachment File
    *     operationId: downloadAttachmentFile
    *     description: Download Attachment File
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: filePath
    *         description: Provide the file path.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */

    /*getDetails: {
        pre: null,
        process: null,
        post: null
    }*/

    /**
    * @swagger
    * /a/irequest/attachments/{filePath}/download:
    *   get:
    *     tags:
    *       - iRequest API
    *     summary: Download an Attachment File
    *     operationId: downloadAnAttachmentFile
    *     description: Download Attachment File
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: filePath
    *         description: Provide the encoded file path.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */

    download: {
        pre: null,
        process: "attachment.download",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/irequest/attachments:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Attach & Upload the files
    *     operationId: attachFiles
    *     consumes:
    *       - multipart/form-data
    *     parameters:
    *         - in: formData
    *           name: file
    *           type: file
    *           description: Attach & Upload the files to the SFTP server
    *           required: true
    *         - in: header
    *           name: modulename
    *           type: string
    *     responses:
    *       200:
    *         description: successful operation
    */  

    create: {
        pre: null,
        process: "attachment.create",
        post: null,
        method: 'POST'
    }
    
};