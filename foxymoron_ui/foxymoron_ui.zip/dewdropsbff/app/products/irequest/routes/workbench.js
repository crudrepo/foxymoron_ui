"use strict";

module.exports = {


     /**
    * @swagger
    * /a/irequest/workbenchs/getCount:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Count of the RequestManager.
    *     operationId: getmyWorkbenchCount
    *     description: Get the (total/pending) count value of the Request Manager.
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the request list which is with RM( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - type: object
    *               properties:
    *                 type:
    *                   type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getCount:{
        pre: null,
        process: "workbench.getCount",
        post: null,
        method: 'POST'
    },

     /**
    * @swagger
    * /a/irequest/workbenchs/getList:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the request list which is with RM
    *     operationId: getRequestListWithRM
    *     description: Fetch the request list which is with RM
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch all PreviouslyUsed/favourites/All worlbench list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - type: object
    *               properties:
    *                 rmType:
    *                   type: string
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "workbench.getList",
        post: null,
        method: 'POST'
    },


    /**
    * @swagger
    * /a/irequest/workbenchs/getDetails:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: View the RM request
    *     operationId: viewRMRequest
    *     description: View the Rm request
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide those fileds to apply/submit the apporval action.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               requestId:
    *                 type: string
    *               rmType:
    *                 type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
   getDetails: {
        pre: null,
        process: "workbench.getDetails",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/irequest/workbenchs/markRequestCompleted:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Approval Action
    *     operationId: markRequestCompleted
    *     description: markRequestCompleted 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide those fileds to apply/submit the apporval action.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               requestDefinitionId:
    *                 type: string
    *               submittedToWorkflow:
    *                type: boolean
    *               eformInstanceId:
    *                type: string
    *               action:
    *                 type: integer
    *               requestComments:
    *                 type: string
    *               description:
    *                 type: string
    *               urgentRequirementDesc:
    *                 type: string
    *               requestName:
    *                 type: string
    *               urgentRequirement:
    *                 type: boolean
    *               assignedToTypeId:
    *                 type: integer
    *               assignedToUserId:
    *                 type: string
    *               behalfOfUserId:
    *                 type: string
    *               attachmentIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               requestId:
    *                 type: string
    *               eformId:
    *                 type: string
    *               formInstance:
    *                  type: string
    *               checkForSecurity:
    *                 type: boolean
    *               supplierRequestFlag:
    *                 type: boolean
    *               quickSave:
    *                  type: boolean
    *               requestMaster:
    *                  type: boolean
    *                  default: false
    *             required: [ requestComments]
    *     responses:
    *       200:
    *         description: successful operation
    */
    markComplete: {
        pre: null,
        process: "workbench.markComplete",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/irequest/workbenchs/markRequestReturned:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Approval Action 
    *     operationId: markRequestReturned
    *     description: markRequestReturned Action
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide those fileds to apply/submit the apporval action.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               requestDefinitionId:
    *                 type: string
    *               submittedToWorkflow:
    *                type: boolean
    *               eformInstanceId:
    *                type: string
    *               action:
    *                 type: integer
    *               requestComments:
    *                 type: string
    *               description:
    *                 type: string
    *               urgentRequirementDesc:
    *                 type: string
    *               requestName:
    *                 type: string
    *               urgentRequirement:
    *                 type: boolean
    *               assignedToTypeId:
    *                 type: integer
    *               assignedToUserId:
    *                 type: string
    *               behalfOfUserId:
    *                 type: string
    *               attachmentIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               requestId:
    *                 type: string
    *               eformId:
    *                 type: string
    *               formInstance:
    *                  type: string
    *               checkForSecurity:
    *                 type: boolean
    *               supplierRequestFlag:
    *                 type: boolean
    *               quickSave:
    *                  type: boolean
    *               requestMaster:
    *                  type: boolean
    *                  default: false
    *             required: [ requestComments]
    *     responses:
    *       200:
    *         description: successful operation
    */
    markRequestReturned: {
        pre: null,
        process: "workbench.markRequestReturned",
        post: null,
        method: 'POST'
    },

     /**
    * @swagger
    * /a/irequest/workbenchs/save:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: workbench save
    *     operationId: approvalAction
    *     description: Approval Action
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide those fileds to savethe workbench request.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               requestApprovalId:
    *                 type: string
    *               action:
    *                 type: integer
    *               requestComments:
    *                 type: string
    *               description:
    *                 type: string
    *               urgentRequirementDesc:
    *                 type: string
    *               requestName:
    *                 type: string
    *               urgentRequirement:
    *                 type: boolean
    *               assignedToTypeId:
    *                 type: integer
    *               assignedToUserId:
    *                 type: string
    *               behalfOfUserId:
    *                 type: string
    *               attachmentIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               requestId:
    *                 type: string
    *               eformId:
    *                 type: string
    *               formInstance:
    *                  type: string
    *               checkForSecurity:
    *                 type: boolean
    *               supplierRequestFlag:
    *                 type: boolean
    *               quickSave:
    *                  type: boolean
    *               submittedToWorkflow:
    *                 type: boolean
    *               requestDefinitionId:
    *                  type: string
    *               eformInstanceId:
    *                type: string
    *               requestMaster:
    *                  type: boolean
    *                  default: false
    *     responses:
    *       200:
    *         description: successful operation
    */
   save: {
    pre: null,
    process: "workbench.save",
    post: null,
    method: 'POST'
},
    
};
