/**
 * Attachment Controller
 *
 * @description :: Provides attachment related operations
 */
const upload = require('@service/upload')

module.exports = (parentClass) => {

    class Attachment extends parentClass {

        /*
         * Create Method
         * Add attachment files.
         */
        create(request, input, callback) {
            try {
                let productSetting = super.productSetting(request);
                let modules = Object.keys(productSetting['modules']);
                let validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "modulename": "joi.any().required().valid(" + JSON.stringify(modules) + ").label('irequest-lable-23__')"
                };
                validationUtility.addInternalSchema(schema);
                const moduleName = request.headers.modulename;
                const result = validationUtility.validate({ "modulename": moduleName });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const moduleOptions = productSetting['modules'][moduleName]['attachment'];
                    const options = { productName: request.productName };
                    const uploadService = new (upload)(super.lodash.merge(moduleOptions, options));
                    super.async.waterfall([
                        (callback) => {
                            //This metbod to upload file into tmp path of node server.
                            uploadService.fileUploadToServer(request, (error, result) => {
                                if (error) {
                                    return callback(error, result);
                                } else if (result) {
                                    return callback(null, result);
                                }
                            });
                        },
                        (result, callback) => {
                            //This metbod to make an entry into the attachment table by Product API call.
                            const output = { errors: result.errors, files: result.files }, input = [];
                            if (super.lodash.isEmpty(result.files) === false) {
                                result.files.forEach((file) => {
                                    if (file.status === true) {
                                        input.push({ "module": moduleName.toUpperCase(), "encoding": "UTF-8", "name": file.name, "fileSize": file.size });
                                    }
                                });
                                if (super.lodash.isEmpty(input) === false) {
                                    const irequest = new (super.iRequestHook({request: request}))();
                                    irequest.addAttachment(request, input, (error, request, response) => {
                                        if (error) {
                                            return callback(error, output);
                                        } else if (response) {
                                            if (super.lodash.isEmpty(response.data) === false) {
                                                result.files.map((item) => {
                                                    const fileDetails = (super.lodash.isArray(response.data)) ? super.lodash.find(response.data, { "info2": item.name }) : ((item.name === response.data.info2) ? response.data : {});
                                                    if (super.lodash.isEmpty(fileDetails) === false) {
                                                        super.lodash.merge(item, fileDetails);
                                                    } else {
                                                        super.lodash.merge(item, { status: false });
                                                    }
                                                });
                                            }
                                            if (super.lodash.isEmpty(response.errors) === false) {
                                                response.errors.forEach((error) => {
                                                    output.errors.push({ "description": error });
                                                });
                                            }
                                            return callback(null, output);
                                        }
                                    });
                                } else {
                                    return callback(null, output);
                                }
                            } else {
                                return callback(null, output);
                            }
                        },
                        (result, callback) => {
                            //This metbod to upload file from tmp folder to sftp server.
                            const output = { records: [], errors: result.errors, message: [], files: result.files };
                            if (super.lodash.isEmpty(result.files) === false) {
                                super.async.eachSeries(result.files, (file, callback1) => {
                                    if (file.status === true) {
                                        let data = file;
                                        let input = {
                                            remoteFilePath: data.info1,
                                            localFilePath: data.path,
                                        };
                                        //Upload file to the sftp server
                                        uploadService.save(input, (error, response) => {
                                            if (error) {
                                                output.errors.push({ "description": error });
                                            } else if (response) {
                                                const filePath = data.info1 + '~' + data.name;
                                                let filePathEncode = super.utils.encrypt(filePath, request.tokenId, true);
                                                let replaceSlash = filePathEncode.replace(/\//g, "@");
                                                let record = {
                                                    "id": data.id,
                                                    "name": data.name,
                                                    "path": replaceSlash,
                                                    "size": data.size,
                                                    "type": data.type,
                                                    "modifiedBy": data.modifiedBy,
                                                    "modifiedOn": data.modifiedOn
                                                };
                                                output.records.push(record);
                                                output.message.push({ description: data.name + ' was upload successfully.' });
                                            }
                                            callback1();
                                        });
                                    }else{
                                        callback1();
                                    }
                                }, () => {
                                    return callback(null, output);
                                });
                            } else {
                                return callback(null, output);
                            }
                        }
                    ],
                        (err, results) => { //final method to provides the output details here.
                            //Delete file from tmp folder
                            if (super.lodash.isEmpty(results.files) === false) {
                                results.files.forEach((file) => {
                                    uploadService.unlink(file.path, () => { });
                                });
                            }

                            if (err) {
                                return callback(err, null);
                            }

                            if (results.errors.length && results.records.length == 0) {
                                return callback(results.errors, null);
                            }

                            let output = {
                                data: {
                                    records: (results.records.length) ? results.records : undefined
                                },
                                message: (results.message.length) ? results.message : undefined,
                                errors: (results.errors.length) ? results.errors : undefined
                            };
                            return callback(null, request, output);
                        }
                    );
                }
            } catch (error) {
                callback(error, null);
            }
        };

        download(request, input, callback) {
            try {
                const ddHook = new (super.ddHook({ request: request }))();
                ddHook.getFileStream(request, input, (error, response) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        return callback(null, request, { data: response });
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }

    };

    return Attachment;

};