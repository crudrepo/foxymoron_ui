"use strict";
module.exports = {
    /**
     * @swagger
     * /a/icontract/contracts/list:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get the list of contracts from authoring module
     *     operationId: Contract List
     *     description: Get the list of contracts from authoring module
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch the list of contracts from authoring module (based on filter, sorting & pagination options).
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    getList: {
        pre: null,
        process: "contract.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete the contract
    *     operationId: deleteContract
    *     description: Delete the contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the contract ID(s) to delete. Allowed value for mode (Single,Bulk)
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *               comment:
    *                   type: string                       
    *               mode:
    *                   type: string                       
    *     required: [ids,mode] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "contract.destroy",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/contracts/cloningContract:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get Template Version For Cloning Contract
    *     operationId: cloningContract
    *     description: Get Template Version For Cloning Contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the contract ID(s) to Cloning the Contract.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string
    *               amendment:
    *                   type: boolean                       
    *     required: [ids,amendment] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    cloningContract: {
        pre: null,
        process: "contract.cloningContract",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contract/checkLineItemsPermissions:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Permission to bulk download of Line Items (for multiple contracts) API
    *     operationId: checkLineItemsPermissions
    *     description: Permission to bulk download of Line Items (for multiple contracts) API
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Permission to bulk download of Line Items (for multiple contracts) API
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    checkLineItemsPermissions: {
        pre: null,
        process: "contract.checkLineItemsPermissions",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/checkDocumentPermissions:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Bulk Contract documents permission API 
    *     operationId: checkDocumentPermission
    *     description: Bulk Contract documents permission API [Allowed Value for module (Authoring,Repository) ]
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Bulk Contract documents permission API 
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             module:
    *               type: string
    *           required: [ids,module]
    *     responses:
    *       200:
    *         description: successful operation
    */
    checkDocumentPermissions: {
        pre: null,
        process: "contract.checkDocumentPermissions",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getContractList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get the list of contracts
    *     operationId: getContractList
    *     description: Get the list of contracts
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the list of contracts
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - type: object
    *               properties:
    *                 vendorId:
    *                   type: string
    *                 type:
    *                   type: string
    *                 subType:
    *                   type: string
    *                 categoryDesc:
    *                   type: string
    *                 BUDesc:
    *                   type: string 
    *     responses:
    *       200:
    *         description: successful operation
    */
    getContractList: {
        pre: null,
        process: "contract.getContractList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getFilterData:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get All Filter Parameters with Values for given module
    *     operationId: getFilterData
    *     description: Get All Filter Parameters with Values for given module
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get All Filter Parameters with Values for given module
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             module:
    *                 type: string
    *           required: [module]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getFilterData: {
        pre: null,
        process: "contract.getFilterData",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/getCustomMasters:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get enumeration values for a given custom master field
     *     operationId: Custom Master List
     *     description: Get enumeration values for a given custom master field
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Get enumeration values for a given custom master field
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    getCustomMasters: {
        pre: null,
        process: "contract.getCustomMasters",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getTypes:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get all contract types and sub types
    *     operationId: getTypeSubType
    *     description: Get all contract types and sub types
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getTypes: {
        pre: null,
        process: "contract.getTypes",
        post: null,
        method: 'GET'
    },
    /**
     * @swagger
     * /a/icontract/contracts/getConfiguration:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get Product Configuration for Contract Outline Document 
     *     operationId: getConfiguration
     *     description: Get Product Configuration for Contract Outline Document 
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Get Product Configuration for Contract Outline Document 
     *         in: body
     *         required: true
     *         schema:
     *           properties:
     *             subTypeId:
     *                 type: string
     *           required: [subTypeId]
     *     responses:
     *       200:
     *         description: successful operation
     */
    getConfiguration: {
        pre: null,
        process: "contract.getConfiguration",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getTitle:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get 'auto-title' base on "type and subtype ", contract Category or region
    *     operationId: getContractAutoTitle
    *     description: Get 'auto-title' base on "type and subtype ", contract Category or region
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get 'auto-title' base on "type and subtype ", contract Category or region
    *         in: body
    *         schema:
    *             properties:
    *               type:
    *                 type: string
    *               subType:
    *                   type: string                       
    *               contractCategory:
    *                   type: string                       
    *               region:
    *                   type: string                       
    *     responses:
    *       200:
    *         description: successful operation
    */
    getTitle: {
        pre: null,
        process: "contract.getTitle",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getBUList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get list of business units
    *     operationId: Bu List
    *     description: Get list of business units
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get list of business units
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getBUList: {
        pre: null,
        process: "contract.getBUList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getMetaData:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get Filtered MetaData By BaseType 
    *     operationId: getMetaData
    *     description: Get Filtered MetaData By BaseType 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Filtered MetaData By BaseType 
    *         in: body
    *         schema:
    *           properties:
    *             subtypeId:
    *                 type: string
    *             contractId:
    *                 type: string
    *             commonContractId:
    *                 type: string
    *             contractModule:
    *                 type: string
    *             contractCloning:
    *                 type: boolean
    *             metaDataClone:
    *                 type: boolean
    *     responses:
    *       200:
    *         description: successful operation
    */
    getMetaData: {
        pre: null,
        process: "contract.getMetaData",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/{contract_Id}/getFlexiFormDetails:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get get Flexi Form Details for given contract id
    *     operationId: getFlexiFormDetails
    *     description: Get get Flexi Form Details for given contract id
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contract_Id
    *         description: Provide a contract ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Get get Flexi Form Details for given contract id
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             eFormId:
    *                 type: string
    *             iseFormClone:
    *                 type: string
    *           required: [iseFormClone]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getFlexiFormDetails: {
        pre: null,
        process: "contract.getFlexiFormDetails",
        post: null,
        method: 'POST'
    }
};