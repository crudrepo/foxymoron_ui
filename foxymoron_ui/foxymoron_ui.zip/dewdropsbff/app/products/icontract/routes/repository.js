"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/repositories/getLabels:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get UI labels for repository contract
    *     operationId: getLabels
    *     description: Get UI Labels for Repository Contract
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getLabels: {
        pre: null,
        process: "repository.getLabels",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/repositories/list:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get the list of contracts from repository module
    *     operationId: repositoryList
    *     description: Get the list of contracts from repository module
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the list of contracts from repository module (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "repository.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/{contract_Id}/getContractHierarchy:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Fetch/Get a Contract Hierarchy Details
    *     operationId: getContractDetails
    *     description: Fetch/Get a Contract Hierarchy Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contract_Id
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getContractHierarchy: {
        pre: null,
        process: "repository.getContractHierarchy",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/repositories/downloadLineItem:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Download line items
    *     operationId: downloadLineItem
    *     description: Download line items [Mode should be single or bulk]
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Download line items
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadLineItem: {
        pre: null,
        process: "repository.downloadLineItem",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/downloadDocuments:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Download All Documents 
    *     operationId: downloadDocuments
    *     description: Download All Documents 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the multiple Documents
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadDocuments: {
        pre: null,
        process: "repository.downloadDocuments",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/canDelete:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Check whether the contract is deletable or not
    *     operationId: canDelete
    *     description: Check whether the contract is deletable or not. Allowed Value for mode (Single,Bulk)
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Check whether the contract is deletable or not.Allowed Value for mode (Single,Bulk)
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *             comment:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    canDelete: {
        pre: null,
        process: "repository.canDelete",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/deleteContract:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete the contract
    *     operationId: deleteContract
    *     description: Delete the contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the contract ID(s) to delete.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *               comment:
    *                   type: string                       
    *               mode:
    *                   type: string                       
    *     required: [ids,mode] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    deleteContract: {
        pre: null,
        process: "repository.deleteContract",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/repositories/getAllowedAction:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get get allowed action for contract ID
    *     operationId: getAllowedActionByContract
    *     description: Get get allowed action for contract ID
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get get allowed action for contract ID
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAllowedAction: {
        pre: null,
        process: "repository.getAllowedAction",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/delegateAmendment:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Delete the contract
    *     operationId: deleteContract
    *     description: Delete the contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the contract ID(s) to delete.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                   type: string  
    *               delegateUsersEmailIds:
    *                 type: array
    *                 items:
    *                   type: string                     
    *     required: [contractId,delegateUsersEmailIds] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    delegateAmendment: {
        pre: null,
        process: "repository.delegateAmendment",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/suggestedAction:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get suggested action
    *     operationId: suggestedaction
    *     description: Get the suggestedaction details for contract ID's
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the suggestedaction details for contract ID's
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    suggestedAction: {
        pre: null,
        process: "repository.suggestedAction",
        post: null,
        method: 'POST'
    }
};