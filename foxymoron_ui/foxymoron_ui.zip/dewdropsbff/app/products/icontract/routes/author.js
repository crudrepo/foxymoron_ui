"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/authors/getDelegateAmendmentUserList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get the delegate amendment user list
    *     operationId: getDelegateAmendmentUserList
    *     description: Get the delegate amendment user list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the delegate amendment user list
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDelegateAmendmentUserList: {
        pre: null,
        process: "author.getDelegateAmendmentUserList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/icontract/authors/downloadLineItem:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Download line items
    *     operationId: downloadLineItem
    *     description: Download line items
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Download line items [Mode should be single or bulk]
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadLineItem: {
        pre: null,
        process: "author.downloadLineItem",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/authors/downloadDocuments:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Download All Documents 
    *     operationId: downloadDocuments
    *     description: Download All Documents 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the multiple Documents
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadDocuments: {
        pre: null,
        process: "author.downloadDocuments",
        post: null,
        method: 'POST'
    },
    
    /**
    * @swagger
    * /a/icontract/authors/getAllowedAction:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get get allowed action for contract ID
    *     operationId: getAllowedActionByContract
    *     description: Get get allowed action for contract ID
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get get allowed action for contract ID
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAllowedAction: {
        pre: null,
        process: "author.getAllowedAction",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/authors/suggestedAction:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get suggested action
    *     operationId: suggestedaction
    *     description: Get the suggestedaction details for contract ID's
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the suggestedaction details for contract ID's
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    suggestedAction: {
        pre: null,
        process: "author.suggestedAction",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/authors/canDelete:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Check whether the contract is deletable or not
    *     operationId: canDelete
    *     description: Check whether the contract is deletable or not
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Check whether the contract is deletable or not
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    canDelete: {
        pre: null,
        process: "author.canDelete",
        post: null,
        method: 'POST'
    }
};