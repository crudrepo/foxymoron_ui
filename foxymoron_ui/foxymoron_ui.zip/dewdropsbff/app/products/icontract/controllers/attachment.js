/**
 * Attachment Controller
 *
 * @description :: Provides attachment related operations
 */
const upload = require('@service/upload'),
    fs = require('fs');

module.exports = (parentClass) => {
    class Attachment extends parentClass {
        /*
        * Create Method
        * Add attachment files.
        */
        create(request, input, callback) {
            try {
                const productSetting = super.productSetting(request),
                    modules = Object.keys(productSetting['modules']),
                    validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "module": "joi.string().valid(" + JSON.stringify(modules) + ").required().insensitive().label('icontract-lable-8__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "module": request.headers.module });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const moduleOptions = productSetting['modules'][request.headers.module]['attachment'],
                        options = { "productName": request.productName },
                        uploadService = new (upload)(super.lodash.merge(moduleOptions, options));
                    super.async.waterfall([
                        (callback) => {
                            uploadService.fileUploadToServer(request, callback);
                        }, (result, callback) => {
                            if (super.lodash.isEmpty(result.errors)) {
                                this.getFileInfo(result, callback)
                            }
                            else {
                                callback(result.errors, null);
                            }
                        },
                        (result, callback) => {
                            this.sendRequest(request, result, callback);
                        }
                    ],
                        (error, request, results) => {
                            if (error) {
                                callback(error, null);
                            }
                            else {
                                callback(null, request, results)
                            }
                        });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /*
        * Getting Info from temp Folder 
        * After That Removing Files from Temp Folder
        */
        getFileInfo(result, callback) {
            try {

                fs.readFile(result.files[0].path, { encoding: 'base64' }, (error, content) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        let fileName = result.files[0].name,
                            contentType = result.files[0].type;
                        if (super.lodash.isEmpty(result.files) === false) {
                            result.files.forEach((file) => {
                                fs.unlink(file.path, (error) => {
                                    if (error) super.rm.logger.log({ level: "error", data: error });
                                });
                            });
                        }
                        return callback(null, { content, fileName, contentType });
                    }
                });
            }
            catch (error) {
                return callback(error, null);
            }
        }
        /*
        * Sending File To BK API
        */
        sendRequest(request, result, callback) {
            try {
                request.body = super.lodash.merge(request.body, result, { "module": request.headers.module });
                const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                    url = `${request.productsURL.iContract["soa"]}/contract/uploaddocument`;
                http.post(url, 'uploadDocument', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }
    }
    return Attachment;
};