/**
 * Author Controller
 * @description :: Author action related operations
 */
module.exports = (parentClass) => {
    class Author extends parentClass {
        /**
        * @Method Name : getAllowedAction
        * @Description : Get the allowed action for given contract id
        * @return object / Throw Error
        */
        getAllowedAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/authoring/getAllowedActionByContract`;
                    http.post(url, 'getSuggestedAction', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : getDelegateAmendmentUserList
        * @Description : Get delegate amendment user list
        * @return object / Throw Error
        */
        getDelegateAmendmentUserList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/authoring/getDelegateAmendmentUserList`;
                    http.post(url, 'getDelegateAmendmentUserList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "users": { "type": "array", "properties": { "id": { "type": "string" }, "name": { "type": "string" }, "email": { "type": "string" } } }, "delegateAmendentUsers": { "type": "array", "properties": { "id": { "type": "string" }, "name": { "type": "string" }, "email": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : downloadLineItem
        * @Description : Get the line items for given contract id's
        * @return object / Throw Error
        */
        downloadLineItem(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')"

                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contract/downloadlineitem`;
                    http.post(url, 'downloadLineItem', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(result.errors, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "contractIds": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : downloadDocuments
        * @Description : Get the multiple Attachment for given contract id's
        * @return object / Throw Error
        */
        downloadDocuments(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')",
                        "module": "joi.string().required().valid('Authoring','Repository').insensitive().label('icontract-lable-8__')"
                    };

                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "module": "Authoring" }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contract/downloaddocuments`;
                    http.post(url, 'downloadDocuments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(result.errors, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : suggestedAction
        * @Description : Get the suggested action for given contract id's
        * @return object / Throw Error
        */
        suggestedAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/authoring/suggestedaction`;
                    http.post(url, 'getSuggestedAction', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : canDelete
        * @Description : Check whether the contract is deletable or not
        * @return object / Throw Error
        */
        canDelete(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/authoring/candeletecontract`;
                    http.post(url, 'canDelete', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contractsAllowedToDelete": { "type": "none" }, "failureCount": { "type": "number" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    }

    return Author;
};