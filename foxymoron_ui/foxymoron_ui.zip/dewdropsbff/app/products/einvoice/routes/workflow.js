module.exports = {
    /**
    * @swagger
    * /a/einvoice/workflows/{workflow_Id}:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: Get workflow Details
    *     operationId: getWorkflowDetails
    *     description:  Get workflow Details by workflow_Id
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: workflow_Id
    *         description: Get workflow Details
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "workflow.getDetails",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/einvoice/workflows/{workflow_Id}/scopeDetails:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: Get workflow Scope Details
    *     operationId: getScopeDetails
    *     description:  Get workflow Scope Details by workflow_Id
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: workflow_Id
    *         description: Get workflow Scope Details by workflow_Id
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    scopeDetails: {
        pre: null,
        process: "workflow.scopeDetails",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    *  /a/einvoice/workflows/{workflow_Id}/workflowTrail:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the workflow trail
    *     operationId: getWorkflowTrail
    *     description: Get the workflow trail
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: workflow_Id
    *         description: Provide a workflow ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Get the workflow trail
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           workflowInstanceId:
    *            type: string
    *          required: [workflowInstanceId]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    workflowTrail: {
        pre: null,
        process: "workflow.workflowTrail",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/einvoice/workflows/evaluate:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Evaluate the wokflow for the data passed
    *     operationId: Evaluate the wokflow for the data passed
    *     description: Evaluate the wokflow for the data passed
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Evaluate the wokflow for the data passed
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               processCode:                   
    *                 type: string                     
    *               requestUserId:
    *                 type: string                     
    *               currency:
    *                 type: string                     
    *               itemSource:
    *                 type: string                     
    *               supplierId:
    *                 type: string                     
    *               cbl:
    *                 type: object                                                 
    *                 $ref: '#/definitions/cbl'
    *               noTaxAmount:                     
    *                 type: boolean           
    *               neverExpires:                     
    *                 type: boolean           
    *               selfAssessedAmt:                     
    *                 type: boolean           
    *               shipToLocationDifference:                     
    *                 type: boolean           
    *               headerCOAEnabled:                     
    *                 type: boolean           
    *               hasNegativeTaxByByuer:                     
    *                 type: boolean           
    *               hasNegativeTax:                     
    *                 type: boolean           
    *               coaFlexiFormInstanceIds:                     
    *                 type: array           
    *                 items:            
    *                     type: string            
    *               costCenterUniqueCodes:                     
    *                 type: array  
    *                 items:            
    *                     type: string          
    *               glAccountCodes:                     
    *                 type: array  
    *                 items:            
    *                     type: string 
    *               accountTypeCodes:                     
    *                 type: array  
    *                 items:            
    *                     type: string          
    *               coaFlexiFormId:                     
    *                 type: string           
    *               totalAmount:                     
    *                 type: number           
    *               purchaseType:                     
    *                 type: string           
    *               requisitionIds:                     
    *                 type: array  
    *                 items:            
    *                     type: string                   
    *               referenceType:                     
    *                 type: string           
    *               paymentTerms:                     
    *                 type: string           
    *               buyerId:                     
    *                 type: string           
    *               requesterId:                     
    *                 type: string           
    *               invoiceId:                     
    *                 type: string           
    *               invoiceType:                     
    *                 type: string           
    *               paymentMethod:                     
    *                 type: string           
    *               invoiceMatchingStatus:                     
    *                 type: string           
    *               invoiceMatchResult:                     
    *                 type: object           
    *                 properties:
    *                   infoList:
    *                       type: array
    *                       items:
    *                           type: object
    *                           properties:
    *                             field:
    *                                 type: string
    *                             type:
    *                                 type: number
    *                             value:
    *                                 type: object
    *                             lineItemId:
    *                                 type: string
    *                   warningList:
    *                       type: array
    *                       items:
    *                           type: object
    *                           properties:
    *                             field:
    *                                 type: string
    *                             type:
    *                                 type: number
    *                             value:
    *                                 type: object
    *                             lineItemId:
    *                                 type: string
    *                   errorList:
    *                       type: array
    *                       items:
    *                           type: object
    *                           properties:
    *                             field:
    *                                 type: string
    *                             type:
    *                                 type: number
    *                             value:
    *                                 type: object
    *                             lineItemId:
    *                                 type: string
    *                   duplicateInvoices:
    *                       type: array
    *                       items:
    *                           type: string
    *                   validDueDate:
    *                       type: boolean
    *               receiptRequiredForItemMap:                     
    *                 type: object                     
    *               requesterForItemsMap:                     
    *                 type: object           
    *               templateId:                     
    *                 type: string           
    *               contractOwner:                     
    *                 type: string           
    *               invoiceTemplate:                     
    *                 type: object           
    *                 properties:
    *                   tenantId:
    *                       type: string
    *                   createdBy:
    *                       type: string
    *                   createdOn:
    *                       type: string
    *                   status:
    *                       type: number
    *                   statusComments:
    *                       type: string
    *                   archive:
    *                       type: boolean
    *                   error:
    *                       type: boolean
    *                   errorReasons:
    *                       type: object              
    *                   modifiedBy:
    *                       type: string              
    *                   modifiedOn:
    *                       type: string              
    *                   version:
    *                       type: number              
    *                   templateId:
    *                       type: string              
    *                   templateUniqueId:
    *                       type: string              
    *                   templateOwner:
    *                       type: string              
    *                   templateName:
    *                       type: string              
    *                   buyer:
    *                       type: string              
    *                   requester:
    *                       type: string              
    *                   autoInvoiceNo:
    *                       type: string              
    *                   sequence:
    *                       type: number              
    *                   purchaseType:
    *                       type: string             
    *                   purchaseTypeCode:
    *                       type: string             
    *                   visibilityRule:
    *                       type: string             
    *                   visibilityRuleStatus:
    *                       type: boolean             
    *                   description:
    *                       type: string             
    *                   notes:
    *                       type: string             
    *                   releaseScheduleId:
    *                       type: string             
    *                   lastExecutionTime:
    *                       type: string             
    *                   nextExecutionTime:
    *                       type: string                         
    *                   templateDate:
    *                       type: string             
    *                   supplierId:
    *                       type: string             
    *                   supplierName:
    *                       type: string             
    *                   suppAddressId:
    *                       type: string             
    *                   suppRemitToAddressId:
    *                       type: string             
    *                   suppCurrency:
    *                       type: string                         
    *                   suppContact:
    *                       type: string             
    *                   suppAddress:
    *                       type: string             
    *                   supplierAddress:
    *                       type: object       
    *                       $ref: '#/definitions/Address'
    *                   supplierAddressRemit:
    *                       type: object      
    *                       $ref: '#/definitions/Address'
    *                   suppAddressRemit:
    *                       type: string                    
    *                   customerReferenceId:
    *                       type: string                    
    *                   extraCharges:
    *                       type: number                    
    *                   freightCharges:
    *                       type: number                    
    *                   insuranceCharges:
    *                       type: number                    
    *                   exciseDuties:
    *                       type: number                    
    *                   totalAmount:
    *                       type: number                    
    *                   grossTotalAmount:
    *                       type: number                    
    *                   taxAmount:
    *                       type: number                                      
    *                   invoicedAmount:
    *                       type: number                    
    *                   submittedOn:
    *                       type: string                    
    *                   approvedOn:
    *                       type: string                    
    *                   closedOn:
    *                       type: string                    
    *                   baseCurrency:
    *                       type: string                    
    *                   baseExchangeRate:
    *                       type: number                    
    *                   baseTotal:
    *                       type: number                    
    *                   docType:
    *                       type: number                    
    *                   companyCode:
    *                       type: string                    
    *                   referenceValue:
    *                       type: string                    
    *                   referenceType:
    *                       type: number                    
    *                   splitCostingLevel:
    *                       type: number                    
    *                   splitCostingType:
    *                       type: number                    
    *                   origin:
    *                       type: number                    
    *                   suppErpid:
    *                       type: string                    
    *                   suppAddrErpid:
    *                       type: string                    
    *                   workflowId:
    *                       type: string                    
    *                   externalId:
    *                       type: string                    
    *                   erpId:
    *                       type: string                    
    *                   workflowInstanceId:
    *                       type: string                    
    *                   projectSettingStatus:
    *                       type: string                    
    *                   contractId:
    *                       type: string                    
    *                   contractNumber:
    *                       type: string                    
    *                   contractType:
    *                       type: number                    
    *                   suppPaymentTermId:
    *                       type: string                    
    *                   businessUnitCode:
    *                       type: string                    
    *                   locationCode:
    *                       type: string                    
    *                   billToCode:
    *                       type: string                    
    *                   invoiceToCode:
    *                       type: string                    
    *                   supplierRemitAddErpId:
    *                       type: string                    
    *                   shipToCodeType:
    *                       type: number                    
    *                   shipToCode:
    *                       type: string                    
    *                   shipToLocation:
    *                       type: string                    
    *                   purchaseTypeSetting:
    *                       type: boolean                    
    *                   ptGLAccountSetting:
    *                       type: boolean                    
    *                   assignProject:
    *                       type: boolean                    
    *                   supplierTaxExempt:
    *                       type: string                    
    *                   discountLevel:
    *                       type: number                    
    *                   discountType:
    *                       type: number                    
    *                   discountValue:
    *                       type: number                    
    *                   applyNoTaxes:
    *                       type: boolean                    
    *                   processEformId:
    *                       type: string                    
    *                   dynamicFormId:
    *                       type: string                    
    *                   dynamicInstanceId:
    *                       type: string                    
    *                   validationResult:
    *                       type: object                    
    *                       properties:
    *                         errorList:
    *                             type: array
    *                             items:
    *                                 type: object
    *                                 properties:
    *                                   fieldName:
    *                                       type: string
    *                                   errorCode:
    *                                       type: string
    *                                   errorMessage:
    *                                       type: string
    *                                   errorParameters:
    *                                       type: array
    *                                       items:
    *                                           type: object
    *                         warningList:
    *                             type: array
    *                             items:
    *                                 type: object
    *                                 properties:
    *                                   fieldName:
    *                                       type: string
    *                                   errorCode:
    *                                       type: string
    *                                   errorMessage:
    *                                       type: string
    *                                   errorParameters:
    *                                       type: array
    *                                       items:
    *                                           type: object
    *                   attachments:
    *                       type: array                    
    *                       items:
    *                           type: object
    *                           properties:
    *                             tenantId:
    *                                 type: string
    *                             createdBy:
    *                                 type: string
    *                             createdOn:
    *                                 type: string
    *                             status:
    *                                 type: number
    *                             statusComments:
    *                                 type: string
    *                             archive:
    *                                 type: boolean
    *                             error:
    *                                 type: boolean
    *                             errorReasons:
    *                                 type: object
    *                             attachmentId:
    *                                 type: string
    *                             referenceAttachmentId:
    *                                 type: string
    *                             name:
    *                                 type: string
    *                             encoding:
    *                                 type: string
    *                             fileSize:
    *                                 type: number
    *                             path:
    *                                 type: string
    *                             type:
    *                                 type: number
    *                             visibility:
    *                                 type: string
    *                             comments:
    *                                 type: string
    *                             displayName:
    *                                 type: string
    *                             supplierId:
    *                                 type: string
    *                             supplierName:
    *                                 type: string
    *                             consumerId:
    *                                 type: string
    *                             origin:
    *                                 type: number
    *                             alreadyInvoiced:
    *                                 type: boolean
    *                             ocrParsedContent:
    *                                 type: string
    *                             ocrDocumentJson:
    *                                 type: string
    *                             ocrExtractedFieldsJson:
    *                                 type: string
    *                             documentMappings:
    *                                 type: array
    *                                 items:
    *                                     type: object
    *                                     properties:
    *                                       tenantId:
    *                                           type: string
    *                                       attachmentId:
    *                                           type: string
    *                                       documentId:
    *                                           type: string
    *                                       docType:
    *                                           type: number
    *                                       status:
    *                                           type: string
    *                                       invoice:
    *                                           type: object
    *                                           properties:
    *                                             tenantId:
    *                                                 type: string
    *                                             createdBy:
    *                                                 type: string
    *                                             createdOn:
    *                                                 type: string
    *                                             status:
    *                                                 type: number
    *                                             statusComments:
    *                                                 type: string
    *                                             archive:
    *                                                 type: boolean
    *                                             error:
    *                                                 type: boolean
    *                                             errorReasons:
    *                                                 type: object
    *                                             modifiedBy:
    *                                                 type: string
    *                                             modifiedOn:
    *                                                 type: string
    *                                             version:
    *                                                 type: number
    *                                             invoiceId:
    *                                                 type: string
    *                                             invoiceUniqueId:
    *                                                 type: string
    *                                             comments:
    *                                                 type: string
    *                                             invoiceNumber:
    *                                                 type: string
    *                                             invoiceDate:
    *                                                 type: string
    *                                             description:
    *                                                 type: string
    *                                             purchaseOrderNumber:
    *                                                 type: string
    *                                             buyer:
    *                                                 type: string
    *                                             supplierId:
    *                                                 type: string
    *                                             supplierName:
    *                                                 type: string
    *                                             supplierAddressId:
    *                                                 type: string
    *                                             suppAddress:
    *                                                 type: object
    *                                                 $ref: '#/definitions/Address'
    *                                             supplierAddressIdRemit:
    *                                                 type: string
    *                                             suppAddressRemit:
    *                                                 type: object
    *                                                 $ref: '#/definitions/Address'
    *                                             supplierCurrency:
    *                                                 type: string
    *                                             supplierContact:
    *                                                 type: string
    *                                             discountLevel:
    *                                                 type: number
    *                                             discountType:
    *                                                 type: number
    *                                             discountValue:
    *                                                 type: number
    *                                             extraCharges:
    *                                                 type: number
    *                                             freightCharges:
    *                                                 type: number
    *                                             insuranceCharges:
    *                                                 type: number
    *                                             exciseDuties:
    *                                                 type: number
    *                                             totalAmount:
    *                                                 type: number
    *                                             grossTotalAmount:
    *                                                 type: number
    *                                             submittedOn:
    *                                                 type: string
    *                                             approvedOn:
    *                                                 type: string
    *                                             closedOn:
    *                                                 type: string
    *                                             resubmitionCount:
    *                                                 type: number
    *                                             applyNoTaxes:
    *                                                 type: boolean
    *                                             baseCurrency:
    *                                                 type: string
    *                                             baseExchangeRate:
    *                                                 type: number
    *                                             baseTotal:
    *                                                 type: number
    *                                             taxAmount:
    *                                                 type: number
    *                                             chargedAmount:
    *                                                 type: number
    *                                             chargedTaxAmount:
    *                                                 type: number
    *                                             batchProcessing:
    *                                                 type: boolean
    *                                             docType:
    *                                                 type: number
    *                                             docTypeDesc:
    *                                                 type: string
    *                                             purchaseType:
    *                                                 type: string
    *                                             purchaseTypeCode:
    *                                                 type: string
    *                                             pending:
    *                                                 type: boolean
    *                                             companyCode:
    *                                                 type: string
    *                                             referenceValue:
    *                                                 type: string
    *                                             attachmentIds:
    *                                                 type: array
    *                                                 items:
    *                                                     type: string
    *                                             externalId:
    *                                                 type: string
    *                                             splitCostingLevel:
    *                                                 type: number
    *                                             splitCostingType:
    *                                                 type: number
    *                                             referenceType:
    *                                                 type: number
    *                                             paymentMethod:
    *                                                 type: number
    *                                             origin:
    *                                                 type: number
    *                                             purchaseTypeSetting:
    *                                                 type: boolean
    *                                             ptGLAccountSetting:
    *                                                 type: boolean
    *                                             supplierERPId:
    *                                                 type: string
    *                                             supplierAddressERPId:
    *                                                 type: string
    *                                             erpId:
    *                                                 type: string
    *                                             workflowId:
    *                                                 type: string
    *                                             workflowInstanceId:
    *                                                 type: string
    *                                             processEformId:
    *                                                 type: string
    *                                             dynamicFormId:
    *                                                 type: string
    *                                             dynamicInstanceId:
    *                                                 type: string
    *                                             assignProject:
    *                                                 type: boolean
    *                                             projectSettingStatus:
    *                                                 type: string
    *                                             customerReferenceId:
    *                                                 type: string
    *                                             contractNumber:
    *                                                 type: string
    *                                             contractId:
    *                                                 type: string
    *                                             contractType:
    *                                                 type: number
    *                                             paymentTermId:
    *                                                 type: string
    *                                             businessUnitCode:
    *                                                 type: string
    *                                             locationCode:
    *                                                 type: string
    *                                             billToCode:
    *                                                 type: string
    *                                             invoiceToCode:
    *                                                 type: string
    *                                             attachmentsStr:
    *                                                 type: string
    *                                             requestEdit:
    *                                                 type: boolean
    *                                             epDiscountDueDate:
    *                                                 type: string
    *                                             epDiscountedAmount:
    *                                                 type: number
    *                                             invoiceDateGMT:
    *                                                 type: string
    *                                             prePOAllowDays:
    *                                                 type: number
    *                                             suppLocationStr:
    *                                                 type: string
    *                                             defaultSupplierRemitTOAddress:
    *                                                 type: object
    *                                                 $ref: '#/definitions/Address'
    *                                             supplierTaxExampt:
    *                                                 type: string
    *                                             transactionId:
    *                                                 type: string
    *                                             getzsnInvoiceCreator:
    *                                                 type: string
    *                                             getzsnInvoiceCreatorEmailId:
    *                                                 type: string
    *                                             supplierRemitAddressERPId:
    *                                                 type: string
    *                                             shipToCodeType:
    *                                                 type: number
    *                                             shipToCode:
    *                                                 type: string
    *                                             shipToLocation:
    *                                                 type: string
    *                                             selfAssessedAmt:
    *                                                 type: number
    *                                             useTaxApplicable:
    *                                                 type: boolean
    *                                             newGrossTotalAmount:
    *                                                 type: number
    *                                             applyTaxOnGrossTotal:
    *                                                 type: boolean
    *                                             newTotalTaxAmount:
    *                                                 type: number
    *                                             supplierBankingDetailsId:
    *                                                 type: string
    *                                             supplierBankingDetails:
    *                                                 type: object
    *                                                 $ref: '#/definitions/BankingDetails'
    *                                             visibilityRule:
    *                                                 type: string
    *                                             entitySettings:
    *                                                 type: object
    *                                             supplierAddressJSON:
    *                                                 type: string
    *                                             coaflexiFormId:
    *                                                 type: string
    *                                             coaflexiFormInstanceVersion:
    *                                                 type: number
    *                                             supplierAddressRemitJSON:
    *                                                 type: string
    *                                             coaflexiFormInstanceId:
    *                                                 type: string
    *                                             supplierBankingDetailsJSON:
    *                                                 type: string
    *                                             defaultSupplierRemitTOAddressJSON:
    *                                                 type: string
    *                                             persistObject:
    *                                                 type: boolean
    *                                             errorReasonsStr:
    *                                                 type: string
    *                                       ocrProcessed:
    *                                           type: boolean
    *                             statusDetails:
    *                                 type: number
    *                             checksum:
    *                                 type: string
    *                             data:
    *                                 type: string
    *                             version:
    *                                 type: string
    *                             additionalInfo:
    *                                 type: string
    *                             productid:
    *                                 type: string
    *                             refId:
    *                                 type: string
    *                             serviceCode:
    *                                 type: string
    *                             serviceProviderCode:
    *                                 type: string
    *                             callBackEndPoints:
    *                                 type: string
    *                             tpiDoc:
    *                                 type: string
    *                             tpiStatusComments:
    *                                 type: string
    *                             serviceRequestTrackingId:
    *                                 type: string
    *                             requestAccepted:
    *                                 type: boolean
    *                             tpiResponse:
    *                                 type: string
    *                             isExtract:
    *                                 type: string
    *                             kofaxResponse:
    *                                 type: string
    *                             attachmentErpId:
    *                                 type: string
    *                             errorReasonsStr:
    *                                 type: string
    *                   taxes: 
    *                       type: array 
    *                       items:
    *                           type: object
    *                           properties:
    *                             templateId:
    *                                 type: string
    *                             position:
    *                                 type: number
    *                             tenantId:
    *                                 type: string
    *                             taxType:
    *                                 type: string
    *                             taxName:
    *                                 type: string
    *                             taxRate:
    *                                 type: number
    *                             compound:
    *                                 type: boolean
    *                             applicableFor:
    *                                 type: number
    *                             taxableAmount:
    *                                 type: number
    *                             taxAmount:
    *                                 type: number
    *                             useTax:
    *                                 type: boolean
    *                             borneByBuyerTaxAmount:
    *                                 type: number
    *                   costings: 
    *                       type: array 
    *                       items:
    *                           type: object
    *                           properties:
    *                             templateId:
    *                                 type: string
    *                             lineItemId:
    *                                 type: string
    *                             position:
    *                                 type: number
    *                             tenantId:
    *                                 type: string
    *                             budgetId:
    *                                 type: string
    *                             budgetLineId:
    *                                 type: string
    *                             budgetLineTransactionId:
    *                                 type: string
    *                             budgetBaseValue:
    *                                 type: number
    *                             businessUnitCode:
    *                                 type: string
    *                             costCenterCode:
    *                                 type: string
    *                             costingValue:
    *                                 type: number
    *                             projectCode:
    *                                 type: string
    *                             splitValue:
    *                                 type: number
    *                             unique:
    *                                 type: string
    *                   items: 
    *                       type: array 
    *                       items:
    *                           type: object
    *                           properties:
    *                             lineItemId:
    *                                 type: string
    *                             templateId:
    *                                 type: string
    *                             position:
    *                                 type: number
    *                             tenantId:
    *                                 type: string
    *                             lineNo:
    *                                 type: string
    *                             splitCostingType:
    *                                 type: number
    *                             itemId:
    *                                 type: string
    *                             invoicedQuantity:
    *                                 type: number
    *                             marketPrice:
    *                                 type: number
    *                             discountType:
    *                                 type: number
    *                             discountValue:
    *                                 type: number
    *                             discountedPrice:
    *                                 type: number
    *                             discountAmount:
    *                                 type: number
    *                             applyNoTaxes:
    *                                 type: boolean
    *                             itemPrice:
    *                                 type: number
    *                             itemTaxPrice:
    *                                 type: number
    *                             itemTotalPrice:
    *                                 type: number                                    
    *                             attachments:
    *                                 type: array                    
    *                                 items:
    *                                     type: object
    *                                     properties:
    *                                       tenantId:
    *                                           type: string
    *                                       createdBy:
    *                                           type: string
    *                                       createdOn:
    *                                           type: string
    *                                       status:
    *                                           type: number
    *                                       statusComments:
    *                                           type: string
    *                                       archive:
    *                                           type: boolean
    *                                       error:
    *                                           type: boolean
    *                                       errorReasons:
    *                                           type: object
    *                                       attachmentId:
    *                                           type: string
    *                                       referenceAttachmentId:
    *                                           type: string
    *                                       name:
    *                                           type: string
    *                                       encoding:
    *                                           type: string
    *                                       fileSize:
    *                                           type: number
    *                                       path:
    *                                           type: string
    *                                       type:
    *                                           type: number
    *                                       visibility:
    *                                           type: string
    *                                       comments:
    *                                           type: string
    *                                       displayName:
    *                                           type: string
    *                                       supplierId:
    *                                           type: string
    *                                       supplierName:
    *                                           type: string
    *                                       consumerId:
    *                                           type: string
    *                                       origin:
    *                                           type: number
    *                                       alreadyInvoiced:
    *                                           type: boolean
    *                                       ocrParsedContent:
    *                                           type: string
    *                                       ocrDocumentJson:
    *                                           type: string
    *                                       ocrExtractedFieldsJson:
    *                                           type: string
    *                                       documentMappings:
    *                                           type: array
    *                                           items:
    *                                               type: object
    *                                               properties:
    *                                                 tenantId:
    *                                                     type: string
    *                                                 attachmentId:
    *                                                     type: string
    *                                                 documentId:
    *                                                     type: string
    *                                                 docType:
    *                                                     type: number
    *                                                 status:
    *                                                     type: string  
    *                                                 invoice:
    *                                                     type: object  
    *                                                     properties:
    *                                                       tenantId:
    *                                                           type: string
    *                                                       createdBy:
    *                                                           type: string
    *                                                       createdOn:
    *                                                           type: string
    *                                                       status:
    *                                                           type: number
    *                                                       statusComments:
    *                                                           type: string
    *                                                       archive:
    *                                                           type: boolean
    *                                                       error:
    *                                                           type: boolean
    *                                                       errorReasons:
    *                                                           type: object
    *                                                       modifiedBy:
    *                                                           type: string
    *                                                       modifiedOn:
    *                                                           type: string
    *                                                       version:
    *                                                           type: number
    *                                                       invoiceId:
    *                                                           type: string
    *                                                       invoiceUniqueId:
    *                                                           type: string
    *                                                       comments:
    *                                                           type: string
    *                                                       invoiceNumber:
    *                                                           type: string
    *                                                       invoiceDate:
    *                                                           type: string
    *                                                       description:
    *                                                           type: string
    *                                                       purchaseOrderNumber:
    *                                                           type: string
    *                                                       buyer:
    *                                                           type: string
    *                                                       supplierId:
    *                                                           type: string
    *                                                       supplierName:
    *                                                           type: string
    *                                                       supplierAddressId:
    *                                                           type: string
    *                                                       suppAddress:
    *                                                           type: object
    *                                                           $ref: '#/definitions/Address'
    *                                                       supplierAddressIdRemit:
    *                                                           type: string
    *                                                       suppAddressRemit:
    *                                                           type: object
    *                                                           $ref: '#/definitions/Address'
    *                                                       supplierCurrency:
    *                                                           type: string
    *                                                       supplierContact:
    *                                                           type: string
    *                                                       discountLevel:
    *                                                           type: number
    *                                                       discountType:
    *                                                           type: number
    *                                                       discountValue:
    *                                                           type: number
    *                                                       extraCharges:
    *                                                           type: number
    *                                                       freightCharges:
    *                                                           type: number
    *                                                       insuranceCharges:
    *                                                           type: number
    *                                                       exciseDuties:
    *                                                           type: number
    *                                                       totalAmount:
    *                                                           type: number
    *                                                       grossTotalAmount:
    *                                                           type: number
    *                                                       submittedOn:
    *                                                           type: string
    *                                                       approvedOn:
    *                                                           type: string
    *                                                       closedOn:
    *                                                           type: string
    *                                                       resubmitionCount:
    *                                                           type: number
    *                                                       applyNoTaxes:
    *                                                           type: boolean
    *                                                       baseCurrency:
    *                                                           type: string
    *                                                       baseExchangeRate:
    *                                                           type: number
    *                                                       baseTotal:
    *                                                           type: number
    *                                                       taxAmount:
    *                                                           type: number
    *                                                       chargedAmount:
    *                                                           type: number
    *                                                       chargedTaxAmount:
    *                                                           type: number
    *                                                       batchProcessing:
    *                                                           type: boolean
    *                                                       docType:
    *                                                           type: number
    *                                                       docTypeDesc:
    *                                                           type: string
    *                                                       purchaseType:
    *                                                           type: string
    *                                                       purchaseTypeCode:
    *                                                           type: string
    *                                                       pending:
    *                                                           type: boolean
    *                                                       companyCode:
    *                                                           type: string
    *                                                       referenceValue:
    *                                                           type: string
    *                                                       attachmentIds:
    *                                                           type: array
    *                                                           items:
    *                                                               type: string
    *                                                       externalId:
    *                                                           type: string
    *                                                       splitCostingLevel:
    *                                                           type: number
    *                                                       splitCostingType:
    *                                                           type: number
    *                                                       referenceType:
    *                                                           type: number
    *                                                       paymentMethod:
    *                                                           type: number
    *                                                       origin:
    *                                                           type: number
    *                                                       purchaseTypeSetting:
    *                                                           type: boolean
    *                                                       ptGLAccountSetting:
    *                                                           type: boolean
    *                                                       supplierERPId:
    *                                                           type: string
    *                                                       supplierAddressERPId:
    *                                                           type: string
    *                                                       erpId:
    *                                                           type: string
    *                                                       workflowId:
    *                                                           type: string
    *                                                       workflowInstanceId:
    *                                                           type: string
    *                                                       processEformId:
    *                                                           type: string
    *                                                       dynamicFormId:
    *                                                           type: string
    *                                                       dynamicInstanceId:
    *                                                           type: string
    *                                                       assignProject:
    *                                                           type: boolean
    *                                                       projectSettingStatus:
    *                                                           type: string
    *                                                       customerReferenceId:
    *                                                           type: string
    *                                                       contractNumber:
    *                                                           type: string
    *                                                       contractId:
    *                                                           type: string
    *                                                       contractType:
    *                                                           type: number
    *                                                       paymentTermId:
    *                                                           type: string
    *                                                       businessUnitCode:
    *                                                           type: string
    *                                                       locationCode:
    *                                                           type: string
    *                                                       billToCode:
    *                                                           type: string
    *                                                       invoiceToCode:
    *                                                           type: string
    *                                                       attachmentsStr:
    *                                                           type: string
    *                                                       requestEdit:
    *                                                           type: boolean
    *                                                       epDiscountDueDate:
    *                                                           type: string
    *                                                       epDiscountedAmount:
    *                                                           type: number
    *                                                       invoiceDateGMT:
    *                                                           type: string
    *                                                       prePOAllowDays:
    *                                                           type: number
    *                                                       suppLocationStr:
    *                                                           type: string
    *                                                       defaultSupplierRemitTOAddress:
    *                                                           type: object
    *                                                           $ref: '#/definitions/Address'
    *                                                       supplierTaxExampt:
    *                                                           type: string
    *                                                       transactionId:
    *                                                           type: string
    *                                                       getzsnInvoiceCreator:
    *                                                           type: string
    *                                                       getzsnInvoiceCreatorEmailId:
    *                                                           type: string
    *                                                       supplierRemitAddressERPId:
    *                                                           type: string
    *                                                       shipToCodeType:
    *                                                           type: number
    *                                                       shipToCode:
    *                                                           type: string
    *                                                       shipToLocation:
    *                                                           type: string
    *                                                       selfAssessedAmt:
    *                                                           type: number
    *                                                       useTaxApplicable:
    *                                                           type: boolean
    *                                                       newGrossTotalAmount:
    *                                                           type: number
    *                                                       applyTaxOnGrossTotal:
    *                                                           type: boolean
    *                                                       newTotalTaxAmount:
    *                                                           type: number
    *                                                       supplierBankingDetailsId:
    *                                                           type: string
    *                                                       supplierBankingDetails:
    *                                                           type: object
    *                                                           $ref: '#/definitions/BankingDetails'
    *                                                       visibilityRule:
    *                                                           type: string
    *                                                       entitySettings:
    *                                                           type: object
    *                                                       supplierAddressJSON:
    *                                                           type: string
    *                                                       coaflexiFormId:
    *                                                           type: string
    *                                                       coaflexiFormInstanceVersion:
    *                                                           type: number
    *                                                       supplierAddressRemitJSON:
    *                                                           type: string
    *                                                       coaflexiFormInstanceId:
    *                                                           type: string
    *                                                       supplierBankingDetailsJSON:
    *                                                           type: string
    *                                                       defaultSupplierRemitTOAddressJSON:
    *                                                           type: string
    *                                                       persistObject:
    *                                                           type: boolean
    *                                                       errorReasonsStr:
    *                                                           type: string
    *                                                 ocrProcessed: 
    *                                                     type: boolean 
    *                                       statusDetails:  
    *                                           type: number  
    *                                       checksum:  
    *                                           type: string  
    *                                       data:  
    *                                           type: string  
    *                                       version:  
    *                                           type: string  
    *                                       additionalInfo:  
    *                                           type: string  
    *                                       productid:  
    *                                           type: string  
    *                                       refId:  
    *                                           type: string  
    *                                       serviceCode:  
    *                                           type: string  
    *                                       serviceProviderCode:  
    *                                           type: string  
    *                                       callBackEndPoints:  
    *                                           type: string  
    *                                       tpiDoc:  
    *                                           type: string  
    *                                       tpiStatusComments:  
    *                                           type: string  
    *                                       serviceRequestTrackingId:  
    *                                           type: string  
    *                                       requestAccepted:  
    *                                           type: boolean  
    *                                       tpiResponse:  
    *                                           type: string  
    *                                       isExtract:  
    *                                           type: string  
    *                                       kofaxResponse:  
    *                                           type: string  
    *                                       attachmentErpId:  
    *                                           type: string  
    *                                       errorReasonsStr:  
    *                                           type: string  
    *                             comments:   
    *                                 type: string   
    *                             contractNo:   
    *                                 type: string   
    *                             contractId:   
    *                                 type: string   
    *                             contractType:   
    *                                 type: number   
    *                             chargedLineAmount:   
    *                                 type: number   
    *                             chargedLineTaxAmount:   
    *                                 type: number   
    *                             chargedQuantity:   
    *                                 type: number   
    *                             assetCode:   
    *                                 type: string   
    *                             adjustedQuantity:   
    *                                 type: number   
    *                             assetCodeType:   
    *                                 type: number   
    *                             requesterId:   
    *                                 type: string   
    *                             requesterName:   
    *                                 type: string   
    *                             shipToCodeType:   
    *                                 type: number   
    *                             shipToCode:   
    *                                 type: string   
    *                             shipToLocation:   
    *                                 type: string   
    *                             deliverToType:   
    *                                 type: number   
    *                             deliverTo:   
    *                                 type: string   
    *                             deliveryUpto:   
    *                                 type: string   
    *                             deliveryOn:   
    *                                 type: string   
    *                             catlogItem:   
    *                                 type: object   
    *                                 properties:
    *                                   scopeId:
    *                                       type: string
    *                                   catalogId:
    *                                       type: string
    *                                   catalogItemId:
    *                                       type: number
    *                                   catalogVersion:
    *                                       type: number
    *                                   itemId:
    *                                       type: string
    *                                   supplierId:
    *                                       type: string
    *                                   supplierName:
    *                                       type: string
    *                                   supplierPartId:
    *                                       type: string
    *                                   supplierAuxPartId:
    *                                       type: string
    *                                   supplierAddressId:
    *                                       type: string
    *                                   supplierAddress:
    *                                       type: string
    *                                   manufacturerPartId:
    *                                       type: string
    *                                   manufacturerName:
    *                                       type: string
    *                                   name:
    *                                       type: string
    *                                   description:
    *                                       type: string
    *                                   uom:
    *                                       type: string
    *                                   currency:
    *                                       type: string
    *                                   price:
    *                                       type: number
    *                                   marketPrice:
    *                                       type: number
    *                                   leadTime:
    *                                       type: number
    *                                   categoryCode:
    *                                       type: string
    *                                   categoryName:
    *                                       type: string
    *                                   unsspscCode:
    *                                       type: string
    *                                   unsspscName:
    *                                       type: string
    *                                   supplierProductURL:
    *                                       type: string
    *                                   manufacturerProductURL:
    *                                       type: string
    *                                   imageURL:
    *                                       type: string
    *                                   thumbnailURL:
    *                                       type: string
    *                                   sourceRefNo:
    *                                       type: string
    *                                   contractNo:
    *                                       type: string
    *                                   contractId:
    *                                       type: string
    *                                   sourceType:
    *                                       type: number
    *                                   itemType:
    *                                       type: number
    *                                   receiptType:
    *                                       type: number
    *                                   contractType:
    *                                       type: number
    *                                   error:
    *                                       type: boolean
    *                                   active:
    *                                       type: boolean
    *                                   hidden:
    *                                       type: boolean
    *                                   activity:
    *                                       type: number
    *                                   greenItem:
    *                                       type: boolean
    *                                   preferredItem:
    *                                       type: boolean
    *                                   validFrom:
    *                                       type: string
    *                                   validTo:
    *                                       type: string
    *                                   publishedOn:
    *                                       type: string
    *                                   attachments:
    *                                       type: array
    *                                       items:
    *                                           type: string
    *                                   outOfStock:
    *                                       type: boolean
    *                                   systemAttributes:
    *                                       type: object
    *                                   itemAttributes:
    *                                       type: object
    *                                   itemErrors:
    *                                       type: object
    *                                   sourcingStatus:
    *                                       type: number
    *                                   externalId:
    *                                       type: string
    *                                   origin:
    *                                       type: number
    *                             taxes:
    *                                 type: array
    *                                 items:
    *                                     type: object
    *                                     properties:
    *                                       templateId:
    *                                           type: string
    *                                       lineItemId:
    *                                           type: string
    *                                       position:
    *                                           type: number
    *                                       tenantId:
    *                                           type: string
    *                                       taxType:
    *                                           type: string
    *                                       taxName:
    *                                           type: string
    *                                       taxRate:
    *                                           type: number
    *                                       compound:
    *                                           type: boolean
    *                                       taxableAmount:
    *                                           type: number
    *                                       taxAmount:
    *                                           type: number
    *                                       useTax:
    *                                           type: boolean
    *                             accountings:
    *                                 type: array
    *                                 items:
    *                                     type: object
    *                                     properties:
    *                                       templateId:
    *                                           type: string
    *                                       lineItemId:
    *                                           type: string
    *                                       position:
    *                                           type: number
    *                                       tenantId:
    *                                           type: string
    *                                       accountTypeCode:
    *                                           type: string
    *                                       generalLedgerCode:
    *                                           type: string
    *                                       accountingValue:
    *                                           type: number
    *                                       purchaseType:
    *                                           type: string
    *                                       purchaseTypeCode:
    *                                           type: string
    *                                       purchaseTypeTemp:
    *                                           type: string
    *                                       visibilityRule:
    *                                           type: string
    *                                       visibilityRuleStatus:
    *                                           type: boolean
    *                             costings:
    *                                 type: array
    *                                 items:
    *                                     type: object
    *                                     properties:
    *                                       templateId:
    *                                           type: string
    *                                       lineItemId:
    *                                           type: string
    *                                       position:
    *                                           type: number
    *                                       tenantId:
    *                                           type: string
    *                                       budgetId:
    *                                           type: string
    *                                       budgetLineId:
    *                                           type: string
    *                                       budgetLineTransactionId:
    *                                           type: string    
    *                                       budgetBaseValue:
    *                                           type: numebr
    *                                       businessUnitCode:
    *                                           type: string
    *                                       costCenterCode:
    *                                           type: string
    *                                       costingValue:
    *                                           type: numebr
    *                                       projectCode:
    *                                           type: string
    *                                       splitValue:
    *                                           type: number
    *                                       unique:
    *                                           type: string
    *                             attachmentIds:
    *                                 type: array
    *                                 items:
    *                                     type: string
    *                             itemQuantity:
    *                                 type: number
    *                             processEformId:
    *                                 type: string
    *                             dynamicFormId:
    *                                 type: string
    *                             dynamicInstanceId:
    *                                 type: string
    *                             dynamicInstanceVersion:
    *                                 type: numebr
    *                             coaflexiFormId:
    *                                 type: string
    *                             coaflexiFormInstanceVersion:
    *                                 type: number
    *                             coaflexiFormInstanceId:
    *                                 type: string
    *                             attachmentsStr:
    *                                 type: string
    *                   recurringSchedule:
    *                       type: object
    *                       properties: 
    *                         schedulerId:
    *                             type: string
    *                         templateId:
    *                             type: string
    *                         frequencyBy:
    *                             type: string
    *                         recurrancesOn:
    *                             type: number
    *                         interval:
    *                             type: number
    *                         startFrom:
    *                             type: string
    *                         endTo:
    *                             type: string
    *                         neverExpire:
    *                             type: boolean
    *                         previousFireTime:
    *                             type: string
    *                         nextFireTime:
    *                             type: string
    *                         finalFireTime:
    *                             type: string
    *                         recurranceMonthForYear:
    *                             type: number
    *                         activeFrom:
    *                             type: string
    *                         activeTill:
    *                             type: string
    *                   attachmentIds:
    *                       type: array
    *                       items:
    *                           type: string
    *                   neverExpire:
    *                       type: boolean
    *                   selfAssessedAmt:
    *                       type: number
    *                   useTaxApplicable:
    *                       type: boolean
    *                   supplierBankId:
    *                       type: string
    *                   suppBankingDetails:
    *                       type: string
    *                   supplierBankingDetails:
    *                       type: object
    *                       $ref: '#/definitions/BankingDetails'
    *                   newGrossTotalAmount:
    *                       type: number
    *                   applyTaxOnGrossTotal:
    *                       type: boolean
    *                   newTotalTaxAmount:
    *                       type: number
    *                   entitySettings:
    *                       type: object
    *                   grossContractTotalAmount:
    *                       type: number
    *                   result:
    *                       type: object
    *                       properties:
    *                         errorList:
    *                             type: array
    *                             items:
    *                                 type: object  
    *                                 properties:
    *                                   fieldName:
    *                                       type: string
    *                                   errorCode:
    *                                       type: string
    *                                   errorMessage:
    *                                       type: string
    *                                   errorParameters:
    *                                       type: array
    *                                       items:
    *                                           type: object
    *                         warningList:
    *                             type: array
    *                             items:
    *                                 type: object  
    *                                 properties:
    *                                   fieldName:
    *                                       type: string
    *                                   errorCode:
    *                                       type: string
    *                                   errorMessage:
    *                                       type: string
    *                                   errorParameters:
    *                                       type: array
    *                                       items:
    *                                           type: object
    *                   invoiceAccountings: 
    *                       type: array
    *                       items:
    *                           type: object
    *                           properties:
    *                             templateId:
    *                                 type: string
    *                             lineItemId:
    *                                 type: string
    *                             position:
    *                                 type: number
    *                             tenantId:
    *                                 type: string
    *                             accountTypeCode:
    *                                 type: string
    *                             generalLedgerCode:
    *                                 type: string
    *                             accountingValue:
    *                                 type: number
    *                             purchaseType:
    *                                 type: string
    *                             purchaseTypeCode:
    *                                 type: string
    *                             purchaseTypeTemp:
    *                                 type: string
    *                             visibilityRule:
    *                                 type: string
    *                             visibilityRuleStatus:
    *                                 type: boolean
    *                   allTemplateCostings: 
    *                       type: array
    *                       items:
    *                           type: object
    *                           properties:
    *                             templateId:
    *                                 type: string
    *                             lineItemId:
    *                                 type: string
    *                             position:
    *                                 type: number
    *                             tenantId:
    *                                 type: string
    *                             budgetId:
    *                                 type: string
    *                             budgetLineId:
    *                                 type: string
    *                             budgetLineTransactionId:
    *                                 type: string
    *                             budgetBaseValue:
    *                                 type: number
    *                             businessUnitCode:
    *                                 type: string
    *                             costCenterCode:
    *                                 type: string
    *                             costingValue:
    *                                 type: number
    *                             projectCode:
    *                                 type: string
    *                             splitValue:
    *                                 type: number
    *                             unique:
    *                                 type: string
    *                   validationResults: 
    *                       type: string
    *                   attachmentsStr: 
    *                       type: string
    *                   errorReasonsStr: 
    *                       type: string
    *             required: [processCode,requestUserId,currency,cbl,supplierId,COAFlexiFormInstanceIds,COAFlexiFormId,costCenterUniqueCodes,glAccountCodes,accountTypeCodes,totalAmount,itemSource,requisitionIds,referenceType,paymentTerms,buyerId,requesterId,invoiceId,invoiceType,paymentMethod,invoiceMatchingStatus,invoiceMatchResult,contractOwner,templateId,invoiceTemplate] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    evaluate: {
        pre: null,
        process: "workflow.evaluate",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * definitions:
    *   cbl:
    *     required : [companyCode,businessUnitCode,locationCode]
    *     properties:
    *       companyCode:
    *         type: string
    *       businessUnitCode:
    *         type: string
    *       locationCode:
    *         type: string
    */
    /**
    * @swagger
    * definitions:
    *   Address:
    *     properties:
    *       tenantId:
    *         type: string
    *       addressId:
    *         type: string
    *       street1:
    *         type: string
    *       street2:
    *         type: string
    *       street3:
    *         type: string
    *       city:
    *         type: string
    *       state:
    *         type: string
    *       country:
    *         type: string
    *       zip:
    *         type: string
    *       poBox:
    *         type: string
    *       phone:
    *         type: string
    *       fax:
    *         type: string
    *       headQuarter:
    *         type: boolean
    *       order:
    *         type: boolean
    *       remitt:
    *         type: boolean
    *       addressAccountGroupId:
    *         type: string         
    */
    /**
    * @swagger
    * definitions:
    *   BankingDetails:
    *     properties:
    *       tenantId:
    *         type: string     
    *       bankingDetailsID:
    *         type: string     
    *       bankRecordLabel:
    *         type: string     
    *       bankRecordERPId:
    *         type: string     
    *       bankCountry:
    *         type: string     
    *       bankName:
    *         type: string     
    *       branchName:
    *         type: string     
    *       bankId:
    *         type: string     
    *       bankBeneficiaryName:
    *         type: string     
    *       bankAccountType:
    *         type: string     
    *       bankAccountNo:
    *         type: string     
    *       bankIdQualifier:
    *         type: string     
    *       bankSwiftQualifierCode:
    *         type: string     
    *       bankIBANNo:
    *         type: string     
    *       bankSwiftCode:
    *         type: string     
    *       bankSortCode:
    *         type: string     
    *       bankRoutingNo:
    *         type: string     
    *       bankRoutingKey:
    *         type: string     
    *       bankBranchId:
    *         type: string     
    *       bankAccountSeqNumber:
    *         type: string     
    *       bankDescription:
    *         type: string     
    *       isDefault:
    *         type: boolean     
    */


    /**
      * @swagger
      *  /a/einvoice/workflows/remindAction:
      *   put:
      *     tags:
      *       - eInvoice API
      *     summary: To remind the workflow approval
      *     operationId: remindWorkflowApproval
      *     description: To remind the workflow approval
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: body
      *         description: To remind the workflow approval
      *         in: body
      *         required: true
      *         schema:
      *          properties:
      *           workflowInstanceId:
      *            type: string
      *           approvalLastModifiedOn:
      *            type: string
      *           approvalId:
      *            type: string   
      *          required: [workflowInstanceId,approvalId]     
      *     responses:
      *       200:
      *         description: successful operation
      */
     remindAction: {
        pre: null,
        process: "workflow.remindAction",
        post: null,
        method: 'PUT'
    },


    /**
    * @swagger
    *  /a/einvoice/workflows/approveAction:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: To Approve the workflow with Approval Id and Amount
    *     operationId: approverWorkflowApproval
    *     description: To Approve the workflow with Approval Id and Amount
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Do Workflow approve action
    *         in: body
    *         required: true
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             properties:
    *               roletype:
    *                   type: string
    *               approvedAmount:
    *                   type: string
    *               approvalLastModifiedOn:
    *                   type: string
    *               adminRequestedAction:
    *                   type: string
    *               comments:
    *                   type: string
    *               approvalId:
    *                   type: string
    *             required: [approvalId, approvedAmount]
    *     responses:
    *       200:
    *         description: successful operation
    */
    approveAction: {
        pre: null,
        process: "workflow.approveAction",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * /a/einvoice/workflows/getApprovals:
     *   post:
     *     tags:
     *       - eInvoice API
     *     summary: get Workflow Approvals Details
     *     operationId: get Workflow Approvals Details
     *     description: getWorkflowApprovalsDetails
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: approvalIds
     *         description: get Workflow Approvals
     *         in: body
     *         required: true
     *         schema:
     *          properties:
     *           approvalId:
     *             type: string   
     *     responses:
     *       200:
     *         description: successful operation
     */
    
    getApprovals: {
        pre: null,
        process: "workflow.getApprovals",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/einvoice/workflows/approvalList:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the Workflows Approval List by Page Name
    *     operationId: workflowsList
    *     description: Get the Workflows Approval List by Page Name
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Workflows Approval List (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *             - type: object
    *               properties:      
    *                 pageName:
    *                    type: string
    *               required: [pageName ]
    *     responses:
    *       200:
    *         description: successful operation
    */
    approvalList: {
        pre: null,
        process: "workflow.approvalList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    *  /a/einvoice/workflows/rejectAction:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: To Reject the workflow approval with Approval Id
    *     operationId: rejectWorkflowApproval
    *     description: To Reject the workflow approval with Approval Id
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: To Reject the workflow Approval
    *         in: body
    *         required: true
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             properties:
    *               roletype:
    *                   type: string
    *               approvalLastModifiedOn:
    *                   type: string
    *               adminRequestedAction:
    *                   type: string
    *               comments:
    *                   type: string
    *               approvalId:
    *                   type: string  
    *             required: [approvalId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    rejectAction: {
        pre: null,
        process: "workflow.rejectAction",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    *  /a/einvoice/workflows/delegateAction:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Delegate the workflow approval to new user
    *     operationId: delegateWorkflowApproval
    *     description: Delegate the workflow approval to new user
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Delegate the workflow approval to new user
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               adminRequestedAction:
    *                 type: boolean
    *               roletype:
    *                 type: string
    *               approvalLastModifiedOn:
    *                 type: number
    *               comments:
    *                 type: string   
    *               delegatedUserId:
    *                 type: string
    *               approvalId:
    *                 type: string
    *             required: [roletype,delegatedUserId,approvalId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    delegateAction: {
        pre: null,
        process: "workflow.delegateAction",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    *  /a/einvoice/workflows/validateDynamicApprover:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Validate Dynamic Approver already exists or not
    *     operationId: validateDynamicApprover
    *     description: Validate Dynamic Approver already exists or not
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Validate Dynamic Approver already exists or not
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               newUserId:
    *                 type: string
    *               workflowId:
    *                 type: string
    *               workflowInstanceId:
    *                 type: string
    *               parentNodeId:
    *                 type: string   
    *               action:
    *                 type: string
    *               entityId:
    *                 type: string
    *               activityId:
    *                 type: string
    *               processCode:
    *                 type: string
    *               lastModifiedLong:
    *                 type: number
    *             required: [newUserId,workflowId,workflowInstanceId,parentNodeId,action,entityId,processCode]  
    *     responses:
    *       200:
    *         description: successful operation
    */
    validateDynamicApprover: {
        pre: null,
        process: "workflow.validateDynamicApprover",
        post: null,
        method: 'POST'
    },

    /**
      * @swagger
      *  /a/einvoice/workflows/{workflowInstance_Id}/updateInstance:
      *   put:
      *     tags:
      *       - eInvoice API
      *     summary: Update the workflow instance
      *     operationId: updateWorkflowInstance
      *     description: Update the workflow instance
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: workflowInstance_Id
      *         description: Provide a Instance ID.
      *         in: path
      *         required: true
      *         type: string
      *       - name: body
      *         description: Update the workflow instance based on workflow Instance Id and approval Id
      *         in: body
      *         required: true
      *         schema:
      *          properties:
      *           workflowNodeId:
      *            type: string
      *           parentNodeId:
      *            type: string
      *           parentUserId:
      *            type: string
      *           approvalId:
      *            type: string   
      *           nodeId:
      *            type: string
      *           approverUserId:
      *            type: string
      *           action:
      *            type: string  
      *           entityId:
      *            type: string
      *           processCode:
      *            type: string 
      *           roleType:
      *            type: string
      *           lastModifiedLong:
      *            type: number 
      *          required: [workflowNodeId,parentNodeId,parentUserId,approvalId,nodeId,approverUserId,action,entityId,processCode,roleType]   
      *     responses:
      *       200:
      *         description: successful operation
      */
     updateInstance: {
        pre: null,
        process: "workflow.updateInstance",
        post: null,
        method: 'PUT'
    }

}