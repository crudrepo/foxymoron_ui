"use strict";

module.exports = {

    /**
    * @swagger
    * /a/einvoice/invoices/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the invoice list
    *     operationId: invoiceList
    *     description: Get the invoice list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the invoice (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "invoice.getList",
        post: null,
        method: 'POST'
    },

      /**
    * @swagger
    * /a/einvoice/invoices/{invoice_Id}/callAction:
    *   put:
    *     tags:
    *       - eInvoice API
    *     summary: Update the Invoice based on actionName
    *     operationId: updateInvoiceBasedOnAction
    *     description: Update the Invoice based on actionName
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: invoice_Id
    *         description: Provide a Invoice Id
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: Update the invoice based on actionName (voidInvoice, closeInvoice, returnInvoice, 
    *           recallInvoice, remindPendingReceipt, confirmAndMatch, releaseHold, restrictPayment) with comments.
    *         type: string
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               actionName:
    *                 type: string
    *               comments:
    *                 type: string
    *               approvedAmount:
    *                 type: string
    *             required: [actionName ]
    *     responses:
    *       200:
    *         description: successful operation
    */
    callAction: {
        pre: null,
        process: "invoice.updateAction",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/einvoice/invoices/{invoice_Id}/getDetails:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Fetch/Get a Invoice Details
    *     operationId: getInvoiceDetails
    *     description: Fetch/Get a Invoice Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: invoice_Id
    *         description: Provide a invoice ID.
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: View Invoice Details.
    *         in: body
    *         schema: 
    *             properties:
    *               version:
    *                 type: integer
    *             required: [version]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "invoice.getInvoiceDetails",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/einvoice/invoices/isExistsInvoiceNumber:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Fetch/Get a Invoice Details if Invoice Number Exists
    *     operationId: getInvoiceDetails if Invoice Number Exists
    *     description: Fetch/Get a Invoice Details if Invoice Number Exists
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: View Invoice Details if Invoice Number Exists
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               invoiceNumber:
    *                 type: string
    *               supplierId:
    *                 type: string
    *               invoiceId:
    *                 type: string
    *             required: [invoiceNumber,supplierId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    isExistsInvoiceNumber: {
        pre: null,
        process: "invoice.isExistsInvoiceNumber",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/einvoice/invoices/{invoice_Id}/adjustCreditMemo:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get Adjust Credit Memo By Invoice Id and Amount
    *     operationId: getInvoiceAdjustCreditMemo
    *     description: Get Adjust Credit Memo By Invoice Id and Amount
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: invoice_Id
    *         description: Provide a invoice ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Get Adjust Credit Memo By Invoice Id and Amount
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               approvedAmount:
    *                 type: string
    *             required: [approvedAmount ]
    *     responses:
    *       200:
    *         description: successful operation
    */
    adjustCreditMemo: {
        pre: null,
        process: "invoice.adjustCreditMemo",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/einvoice/invoices/{id}/auditTrail:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Fetch/Get Audit Trail Details by Id and Type
    *     operationId: getAuditTrailDetails
    *     description: Fetch/Get Audit Trail Details by Id and Type
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: id
    *         description: Provide Invoice_Id/CM_Id/PO_Id.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Get Audit Trail Details(pass the entityType as EINVOICE/CREDIT_MEMO/PURCHASE_ORDER with respetive Id).
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               entityType:
    *                 type: string
    *             required: [entityType ]
    *     responses:
    *       200:
    *         description: successful operation
    */
    auditTrail: {
        pre: null,
        process: "invoice.auditTrail",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/einvoice/invoices/{invoice_Id}/submitForCoding:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Invoice To SubmitForCoding By Invoice Id and User Id
    *     operationId: SubmitForCoding
    *     description: Invoice To SubmitForCoding By Invoice Id and User Id
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: invoice_Id
    *         description: Provide Invoice_ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Invoice To SubmitForCoding By Invoice Id and User Id
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               reAssignUserId:
    *                 type: string
    *               version:
    *                 type: integer
    *             required: [reAssignUserId, version]
    *     responses:
    *       200:
    *         description: successful operation
    */
    submitForCoding: {
        pre: null,
        process: "invoice.submitForCoding",
        post: null,
        method: 'POST'
    },   
     
    /**
    * @swagger
    * /a/einvoice/invoices/{invoice_Id}/adjustCredit:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Adjust Credit By Invoice Id and Comments.
    *     operationId: InvoiceAdjustCredit
    *     description: Adjust Credit By Invoice Id and Comments.
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: invoice_Id
    *         description: Provide Invoice ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Adjust Credit By Invoice Id and Comments.
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               comments:
    *                 type: string
    *               creditMemoIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               apportionedAmount:
    *                 type: array
    *                 items:
    *                   type: string
    *               adjustedAmount:
    *                 type: string
    *             required: [comments, creditMemoIds, adjustedAmount]
    *     responses:
    *       200:
    *         description: successful operation
    */
    adjustCredit: {
        pre: null,
        process: "invoice.adjustCredit",
        post: null,
        method: 'POST'
    }
}