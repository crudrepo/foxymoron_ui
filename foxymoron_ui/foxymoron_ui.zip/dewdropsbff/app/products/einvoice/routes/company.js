"use strict";

module.exports = {

    /**
    * @swagger
    * /a/einvoice/companies/allowedList:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the allowed company list
    *     operationId: companyList
    *     description: Get the allowed company list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the company list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   allowedList: {
        pre: null,
        process: "company.allowedList",
        post: null,
        method: 'POST'
    }

}