"use strict";
const rm = require('@service/require.module')();

/**
 * Einvoice Hook
 *
 * @description :: Create common methods & used it throught out application.
 */

 class Einvoice {

   /*
     * Add Attachment Method
     * This method to create an entry into the attachment table.
    */
   addAttachment(request, input, callback) {
    try {
        const http = new (rm.httpService)(request);
        const einvoiceURL = request.productsURL.eInvoice;
        const url = `${einvoiceURL}/attachment/${request.headers.modulename.toUpperCase()}/add`;
        http.post(url, 'addAttachment', input[0], (error, result) => {
            if (error) {
                return callback(error, null);
            } else if (result) {
                return callback(null, request, result);
            }
        });
    } catch (error) {
        return callback(error, null);
    }
}

}

module.exports = Einvoice;