/**
 * Contract Controller
 *
 * @description :: Provides Contract related CRUD operation.
 */

module.exports = (parentClass) => {

    class Contract extends parentClass {

        /**
        * @Name :: getContractDetails
        *
        * @Description :: Fetch/Get Contract Details
        * 
        * @return/object/Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('einvoice-lable-22__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.contract_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/component/iContract/' + request.params.contract_Id;
                    http.get(url, 'getContractDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object", "properties": {"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"string"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"object"},"contractId":{"type":"string"},"contractNumber":{"type":"string"},"title":{"type":"string"},"expiryDate":{"type":"string"},"startDate":{"type":"number"},"contractOwnerId":{"type":"string"},"contractOwnerName":{"type":"string"},"supplierId":{"type":"string"},"category":{"type":"string"},"businessUnit":{"type":"string"},"version":{"type":"number"},"viewUrl":{"type":"string"},"totalAmount":{"type":"number"},"utilizedAmount":{"type":"number"},"paymentTerm":{"type":"string"},"currency":{"type":"string"},"contractStatus":{"type":"string"},"contractItemSet":{"type":"array", "properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"string"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"object"},"contractLineItemId":{"type":"string"}, "contractId":{"type":"string"},"contractNumber":{"type":"string"},"lineItemNumber":{"type":"string"},"lineItemName":{"type":"string"},"price":{"type":"number"},"vendorId":{"type":"string"},"vendorContactPersonId":{"type":"string"},"vendorName":{"type":"string"},"quantity":{"type":"number"},"unitOfMeasurement":{"type":"string"},"currency":{"type":"string"},"category":{"type":"string"},"description":{"type":"string"},"categoryName":{"type":"string"},"errorReasonsStr":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        
    }

    return Contract;
}