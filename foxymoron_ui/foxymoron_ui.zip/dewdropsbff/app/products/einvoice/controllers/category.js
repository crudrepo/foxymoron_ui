/**
 * category Filter Controller
 * @description :: Provides category filter view related CRUD operation.
 */
module.exports = (parentClass) => {
    class Category extends parentClass {
        /**
         * @Method Name : getList
         *
         * @Description : Get the list of category 
         * @return object / Throw Error
         */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.eInvoice}/master/categories/filter`;
                    http.post(url, 'getCategoryList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "categoryCode": { "type": "string" }, "name": { "type": "string" }, "parentCategoryCode": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "categoryType": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());

                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    }
    return Category;
};
