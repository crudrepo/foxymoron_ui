/**
 * Company Controller
 *
 * @description :: Provides Company related CRUD operation.
 */

module.exports = (parentClass) => {
    
    class Company extends parentClass {
        
        /**
        * @name :: allowedList
        *
        * @description :: provides the allowed companies list
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback companies details
        */
        allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/CBL/company/'+ request.user.userId +'/filter';
                    http.post(url, 'AllowedCompanyList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "code": { "type": "string" }, "name": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }

                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return Company;
}