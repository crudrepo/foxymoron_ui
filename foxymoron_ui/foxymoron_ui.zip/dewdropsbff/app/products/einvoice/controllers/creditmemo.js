/**
 * CreditMemo Controller
 *
 * @description :: Provides CreditMemo related CRUD operation.
 */

module.exports = (parentClass) => {

    class CreditMemo extends parentClass {

        /**
        * @name :: getList
        *
        * @description :: It gives the list of Credit Memos
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback response details
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/creditMemo/filter';
                    http.post(url, 'creditMemoFilterList', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                output = {},
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'].records : [],
                                pagination = (!super.lodash.isEmpty(result['data'])) ? result['data'].pagination : {},
                                responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"statusComments":{"type":"string"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"status":{"type":"number"},"invoiceId":{"type":"string"},"invoiceUniqueId":{"type":"string"},"comments":{"type":"string"},"invoiceNumber":{"type":"string"},"invoiceDate":{"type":"none"},"description":{"type":"string"}, "purchaseType":{"type":"string"},"purchaseOrderNumber":{"type":"string"},"grossTotalAmount":{"type":"none"},"paymentTermId":{"type":"string"},"invoiceType":{"type":"number"},"requester":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"newGrossTotalAmount":{"type":"none"},"supplierCurrency":{"type":"string"},"origin":{"type":"string"},"submittedOn":{"type":"none"},"companyCode":{"type":"none","key":"company"},"businessUnitCode":{"type":"none","key":"businessUnit"},"locationCode":{"type":"none","key":"location"},"epDiscountDueDate":{"type":"none","key":"discountDueDate"},"epDiscountedAmount":{"type":"none","key":"discountAmount"},"transactionId":{"type":"string"},"dueDate":{"type":"none","key":"invoiceDueDate"},"matchedOn":{"type":"none"},"paymentStatus":{"type":"number"}}}}};
                            let companyCodes = [],
                                businessUnitCodes = [],
                                locationCodes = [];
                            if(!lodash.isEmpty(records) && lodash.isArray(records)) {  
                                records.forEach(item => {
                                    if(item.companyCode) companyCodes.push(item.companyCode);
                                    if(item.businessUnitCode) businessUnitCodes.push( item.businessUnitCode);
                                    if(item.locationCode) locationCodes.push( item.locationCode);
                                });
                                companyCodes = lodash.uniq(companyCodes);
                                businessUnitCodes = lodash.uniq(businessUnitCodes);
                                locationCodes = lodash.uniq(locationCodes);
                            }
                            else{
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('pagination', output.responseSchema.properties);
                                return callback(null, request, output.execute());
                            }
                            const cmd = new (super.cmdHook({request: request}))(),
                                tasks = [
                                    (methodCallback) => {
                                        if (lodash.isEmpty(companyCodes)) return methodCallback(request, {});
                                        //Step 1 : Fetch company details 
                                        const reqData = { "codes": companyCodes, "pageNo":1 , "perPageRecords":companyCodes.length };
                                        cmd.getCompany(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.companyDetails = input.data.result || [];
                                        if (lodash.isEmpty(businessUnitCodes)) return methodCallback(request, {});
                                        //Step 2 : Fetch BusinessUnit details 
                                        const reqData = { "codes": businessUnitCodes,"pageNo":1 , "perPageRecords":businessUnitCodes.length  };
                                        cmd.getBusinessUnit(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.businessUnitDetails = input.data.result || [];
                                        if (lodash.isEmpty(locationCodes)) return methodCallback(request, {});
                                        //Step 3 : Fetch Location details 
                                        const reqData = { "codes": locationCodes, "pageNo":1 , "perPageRecords":locationCodes.length  };
                                        cmd.getLocation(request, reqData, methodCallback);
                                    },                                    
                                    (request, input, methodCallback) => {
                                        output.locationDetails = input.data.result || [];    
                                        output.records = [];
                                        output.pagination = pagination;
                                        //Step 4 : Merge OU details to the response       
                                        //a) Company
                                        if (!lodash.isEmpty(output.companyDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.companyDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(records, extractProps, ["companyCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //b) Business Unit
                                         if (!lodash.isEmpty(output.businessUnitDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.businessUnitDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["businessUnitCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //c) Location
                                        if (!lodash.isEmpty(output.locationDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.locationDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["locationCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        return methodCallback(null, request, {"data": output});
                                    }, 
                                ];

                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {                                  
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }        
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @name :: updateAction
        *
        * @description :: It Updates the Credit Memo status based on actionName with Comments
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback response details
        */
       updateAction(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "actionName": "joi.string().required().valid('voidCreditMemo','returnCreditMemo', 'removeCreditMemo').label('einvoice-lable-12__')",
                    "comments": "joi.string().when('actionName', { is: joi.string().valid('voidCreditMemo', 'returnCreditMemo'), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-13__')",
                    "cmStatus": "joi.string().when('actionName', { is: joi.string().valid('voidCreditMemo'), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-16__')",
                    "doVoid": "joi.boolean().when('actionName', { is: joi.string().valid('voidCreditMemo'), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-17__')",
                    "creditMemoId": "joi.string().required().label('einvoice-lable-15__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(super.lodash.merge(request.body, { "creditMemoId": request.params.creditmemo_Id }));
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    einvoiceURL = request.productsURL.eInvoice,
                    actionName = request.body.actionName,
                    url = einvoiceURL + '/creditMemo/' + request.params.creditmemo_Id + '/action/' + actionName,
                    requestBody = {};
                if (actionName == "voidCreditMemo") {
                    requestBody.comments = request.body.comments;
                    requestBody.cmStatus = request.body.cmStatus;
                    requestBody.doVoid = request.body.doVoid;
                } else if(actionName == "returnCreditMemo"){
                    requestBody.comments = request.body.comments;
                }
                http.post(url, 'creditAction', requestBody, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Name :: get Credit Memo Details
    *
    * @Description :: Fetch/Get Credit Memo Details
    * 
    * @return/object/Throw Error
    */
    getCreditMemoDetails(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "creditMemoId": "joi.string().required().label('einvoice-lable-15__')",
                    "version": "joi.number().integer().label('einvoice-lable-18__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(super.lodash.merge(request.body, { "creditMemoId": request.params.creditmemo_Id }));
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    einvoiceURL = request.productsURL.eInvoice,
                    version = request.body.version,
                    url = einvoiceURL + '/creditMemo/' + request.params.creditmemo_Id + '/' + version;

                http.get(url, 'creditMemoDetails', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const utils = super.utils,
                            lodash = super.lodash,
                            records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [],                            
                            responseSchema = { "type": "array", "properties": { "creditMemo": { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "purchaseType": { "type": "string" }, "epDiscountDueDate": { "type": "number" }, "epDiscountedAmount": { "type": "number" }, "invoiceDate": { "type": "none" }, "dueDate": { "type": "none" }, "version": { "type": "number" }, "invoiceId": { "type": "string" }, "invoiceUniqueId": { "type": "string" }, "erpId": { "type": "string" }, "workflowId": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "attachmentIds": { "type": "none" }, "supplierCurrency": { "type": "string" }, "discountValue": { "type": "number" }, "extraCharges": { "type": "number" }, "insuranceCharges": { "type": "number" }, "grossTotalAmount": { "type": "number" }, "purchaseOrderNumber": { "type": "number" }, "contractNumber": { "type": "string" }, "totalAmount": { "type": "number" }, "discountLevel": { "type": "number" }, "exciseDuties": { "type": "number" }, "companyCode": { "type": "string" }, "businessUnitCode": { "type": "string" }, "locationCode": { "type": "string" }, "billToCode": { "type": "string" }, "invoiceToCode": { "type": "string" }, "freightCharges": { "type": "number" }, "splitCostingLevel": { "type": "number" }, "splitCostingType": { "type": "number" }, "origin": { "type": "number" }, "newGrossTotalAmount": { "type": "number" }, "assignProject": { "type": "boolean" }, "supplierId": { "type": "string" }, "baseCurrency": { "type": "string" }, "baseExchangeRate": { "type": "number" }, "customerReferenceId": { "type": "string" }, "supplierContact": { "type": "string" }, "supplierAddressId": { "type": "string" }, "supplierAddressIdRemit": { "type": "string" }, "invoiceTaxes": { "type": "string" }, "supplierERPId": { "type": "string" }, "paymentTermId": { "type": "string" }, "supplierTaxExampt": { "type": "string" }, "supplierName": { "type": "string" }, "suppAddress": { "type": "object", "properties": { "tenantId": { "type": "string" }, "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } }, "suppAddressRemit": { "type": "object", "properties": { "tenantId": { "type": "string" }, "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } }, "comments": { "type": "string" }, "description": { "type": "string" }, "invoiceNumber": { "type": "string" }, "buyer": { "type": "none", "key": "buyerInfo" }, "requester": { "type": "none", "key": "requesterInfo" } } }, "creditMemoItems": { "type": "array", "properties": { "receipttype": { "type": "string" }, "itemTotalPrice": { "type": "number" }, "lineItemId": { "type": "string" }, "invoiceId": { "type": "string" }, "itemId": { "type": "string" }, "attachmentIds": { "type": "none" }, "lineNo": { "type": "string" }, "itemTaxes": { "type": "array", "properties": { "tenantId": { "type": "string" }, "crMemoItemTaxId": { "type": "string" }, "lineItemId": { "type": "string" }, "type": { "type": "string" }, "name": { "type": "string" }, "rate": { "type": "number" }, "compound": { "type": "boolean" }, "creditMemoId": { "type": "string" }, "taxAmount": { "type": "number" }, "useTax": { "type": "boolean" } } }, "marketPrice": { "type": "number" }, "itemQuantity": { "type": "number" }, "splitCostingType": { "type": "number" }, "assetCodeType": { "type": "number" }, "assetCode": { "type": "string" }, "itemComment": { "type": "string" }, "purchaseOrderId": { "type": "none" }, "contractNo": { "type": "string" }, "contractType": { "type": "number" }, "discountType": { "type": "number" }, "discountValue": { "type": "number" }, "coaflexiFormId": { "type": "string" }, "coaflexiFormInstanceId": { "type": "string" }, "coaflexiFormInstanceVersion": { "type": "number" } } }, "creditMemoTaxes": { "type": "array", "properties": { "tenantId": { "type": "string" }, "invoiceId": { "type": "string" }, "type": { "type": "string" }, "name": { "type": "string" }, "rate": { "type": "number" }, "taxableAmount": { "type": "number" }, "taxAmount": { "type": "number" }, "applicableFor": { "type": "number" }, "compound": { "type": "boolean" }, "useTax": { "type": "boolean" }, "borneByBuyerTaxAmount": { "type": "number" } } }, "creditMemoCostings": { "type": "array", "properties": { "lineItemId": { "type": "string" }, "invoiceId": { "type": "string" }, "budgetId": { "type": "string" }, "budgetLineId": { "type": "string" }, "budgetLineTransactionId": { "type": "string" }, "businessUnitCode": { "type": "string" }, "costCenterCode": { "type": "string" }, "projectCode": { "type": "string" }, "splitValue": { "type": "number" }, "value": { "type": "number" } } }, "creditMemoAccountings": { "type": "array", "properties": { "generalLedgerCode": { "type": "string" }, "tenantId": { "type": "string" }, "crMemoAccountingId": { "type": "none" }, "value": { "type": "number" }, "lineItemId": { "type": "string" }, "invoiceId": { "type": "string" }, "purchaseType": { "type": "string" }, "purchaseTypeCode": { "type": "string" }, "creditMemoId": { "type": "string" }, "visibilityRule": { "type": "none" }, "accountTypeCode": { "type": "string" } } }, "cmCatLogItems": { "type": "none" }, "invoiceMatchResult": { "type": "none" }, "supportObjects": { "type": "object", "properties": { "attachments": { "type": "array", "properties": {} }, "items": { "type": "none" }, "ocrAttachmentId": { "type": "string" } } }, "cmAdjustmentBo": { "type": "string" } } };
                        let userDetails = [];
                        if (!lodash.isEmpty(records)) {
                            if (records.creditMemo) {
                                if (records.creditMemo.buyer) userDetails.push(records.creditMemo.buyer);
                                if (records.creditMemo.requester) userDetails.push(records.creditMemo.requester);
                            }
                            if (records.supportObjects && records.supportObjects.attachments) {
                                records.supportObjects.attachments.forEach(item => {
                                    userDetails.push(item.createdBy);
                                });
                            }
                            userDetails = lodash.uniq(userDetails);
                        } else {
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                        if (lodash.isEmpty(userDetails)) {
                            let output1 = [];
                            output1.push(records);
                            const output = (new (super.responseHandler)(request, { "data": output1 }, responseSchema));
                            return callback(null, request, output.execute());
                        }

                        const tms = new (super.tmsHook({ request: request }))(),
                            tasks = [
                                (methodCallback) => {
                                    if (lodash.isEmpty(userDetails)) return methodCallback(request, {});
                                    const reqData = { "ids": userDetails };
                                    tms.getUsersDetails(request, reqData, methodCallback);
                                },
                                (request, input, methodCallback) => {
                                    let data = [];
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]);
                                            utils.mergeObject(records.creditMemo, extractProps, ["buyer", "id"]);
                                            utils.mergeObject(records.creditMemo, extractProps, ["requester", "id"]);
                                            utils.mergeArray(records.supportObjects.attachments, extractProps, ["createdBy", "id"]);
                                            data.push(records);
                                        }
                                        return methodCallback(null, request, { data });
                                }
                            ];
                        super.async.waterfall(tasks, (error, request, result) => {
                            if (error) {
                                return callback(error, null);
                            } else {
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('attachments', output.responseSchema.properties.supportObjects.properties.attachments.properties);
                                return callback(null, request, output.execute());
                            }
                        });
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };



    }

    return CreditMemo;
}