/**
 * Invoice Controller
 *
 * @description :: Provides invoice related CRUD operation.
 */

module.exports = (parentClass) => {

    class Invoice extends parentClass {

        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/filter';
                    http.post(url, 'invoiceFilterList', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                output = {},
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'].records : [],
                                pagination = (!super.lodash.isEmpty(result['data'])) ? result['data'].pagination : {},
                                responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"}, "paymentInApproval":{"type":"number"}, "adjustedAmount":{"type":"number"}, "approvedGrossTotalAmount":{"type":"number"}, "useTaxApplicable":{"type":"boolean"}, "selfAssessedAmt":{"type":"number"}, "useTaxAdjustedAmount":{"type":"number"}, "bbAdjustedAmount":{"type":"number"}, "statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"status":{"type":"number"},"version":{"type":"number"},"invoiceId":{"type":"string"},"invoiceUniqueId":{"type":"string"},"comments":{"type":"string"},"invoiceNumber":{"type":"string"},"invoiceDate":{"type":"none"},"description":{"type":"string"}, "docType":{"type":"none"},"docTypeDesc":{"type":"string"}, "purchaseType":{"type":"string"},"purchaseOrderNumber":{"type":"string","key":"orderNumber"},"buyer":{"type":"string"},"attachmentsStr":{"type":"array"},"grossTotalAmount":{"type":"none"},"paymentTermId":{"type":"string"},"invoiceType":{"type":"number"},"requester":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"newGrossTotalAmount":{"type":"none","key":"invoiceAmount"},"requestEdit":{"type":"boolean"},"supplierCurrency":{"type":"string","key":"invoiceCurrency"},"origin":{"type":"string","key":"invoiceOrigin"},"submittedOn":{"type":"none"},"approvedOn":{"type":"none"},"closedOn":{"type":"none"},"resubmitionCount":{"type":"number"},"attachmentIds":{"type":"none"},"companyCode":{"type":"none","key":"company"},"businessUnitCode":{"type":"none","key":"businessUnit"},"locationCode":{"type":"none","key":"location"},"epDiscountDueDate":{"type":"none","key":"discountDueDate"},"epDiscountedAmount":{"type":"none","key":"discountAmount"},"transactionId":{"type":"string"},"zsnInvoiceCreator":{"type":"string"},"zsnInvoiceCreatorEmailId":{"type":"string"},"dueDate":{"type":"none","key":"invoiceDueDate"},"paidAmount":{"type":"none"},"matchedOn":{"type":"none"},"paidOn":{"type":"none"},"paymentApprovedOn":{"type":"none"},"confirmStatus":{"type":"number"},"paymentStatus":{"type":"number"},"autoMatched":{"type":"boolean"},"onHold":{"type":"boolean"}}}}};
                            let companyCodes = [],
                                businessUnitCodes = [],
                                locationCodes = [];
                            if(!lodash.isEmpty(records) && lodash.isArray(records)) {  
                                records.forEach(item => {
                                    if(item.companyCode) companyCodes.push(item.companyCode);
                                    if(item.businessUnitCode) businessUnitCodes.push( item.businessUnitCode);
                                    if(item.locationCode) locationCodes.push( item.locationCode);
                                });
                                companyCodes = lodash.uniq(companyCodes);
                                businessUnitCodes = lodash.uniq(businessUnitCodes);
                                locationCodes = lodash.uniq(locationCodes);
                            }
                            else{
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('pagination', output.responseSchema.properties);
                                return callback(null, request, output.execute());
                            }
                            const cmd = new (super.cmdHook({request: request}))(),
                                tasks = [
                                    (methodCallback) => {
                                        if (lodash.isEmpty(companyCodes)) return methodCallback(request, {});
                                        //Step 1 : Fetch company details 
                                        const reqData = { "codes": companyCodes, "pageNo":1 , "perPageRecords":companyCodes.length };
                                        cmd.getCompany(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.companyDetails = input.data.result || [];
                                        if (lodash.isEmpty(businessUnitCodes)) return methodCallback(request, {});
                                        //Step 2 : Fetch BusinessUnit details 
                                        const reqData = { "codes": businessUnitCodes,"pageNo":1 , "perPageRecords":businessUnitCodes.length  };
                                        cmd.getBusinessUnit(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.businessUnitDetails = input.data.result || [];
                                        if (lodash.isEmpty(locationCodes)) return methodCallback(request, {});
                                        //Step 3 : Fetch Location details 
                                        const reqData = { "codes": locationCodes, "pageNo":1 , "perPageRecords":locationCodes.length  };
                                        cmd.getLocation(request, reqData, methodCallback);
                                    },                                    
                                    (request, input, methodCallback) => {
                                        output.locationDetails = input.data.result || [];    
                                        output.records = [];
                                        output.pagination = pagination;
                                        //Step 4 : Merge OU details to the response       
                                        //a) Company
                                        if (!lodash.isEmpty(output.companyDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.companyDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(records, extractProps, ["companyCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //b) Business Unit
                                         if (!lodash.isEmpty(output.businessUnitDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.businessUnitDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["businessUnitCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //c) Location
                                        if (!lodash.isEmpty(output.locationDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.locationDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["locationCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        return methodCallback(null, request, {"data": output});
                                    }, 
                                ];

                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {                                  
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }        
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

       /**
        * @name :: updateAction
        *
        * @description :: It Updates the Invoice based on actionName with Comments
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback response details
        */
        updateAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "actionName": "joi.string().required().valid('voidInvoice','closeInvoice','returnInvoice','recallInvoice','remindPendingReceipt','confirmAndMatch','releaseHold','restrictPayment').label('einvoice-lable-12__')",
                        "comments": "joi.string().when('actionName', { is: joi.string().valid('voidInvoice', 'releaseHold', 'closeInvoice', 'returnInvoice', 'restrictPayment'), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-13__')",
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "approvedAmount": "joi.string().when('actionName', { is: joi.string().valid('restrictPayment'), then: joi.required(), otherwise : joi.optional().allow('')}).label('einvoice-lable-65__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id}));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        actionName = request.body.actionName,
                        url = einvoiceURL + '/invoice/' +  request.params.invoice_Id + '/action/' + actionName,
                        requestBody = {comments: request.body.comments};                     
                    http.post(url, 'invoiceAction', requestBody, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: getDetails
        *
        * @Description :: Fetch/Get a Invoice Details
        * 
        * @return/object/Throw Error
        */
        getInvoiceDetails(request, input, callback){
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {                        
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "version": "joi.number().integer().label('einvoice-lable-18__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id}));              
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),                   
                        einvoiceURL = request.productsURL.eInvoice,
                        version = request.body.version,
                        url = einvoiceURL + '/invoice/' + request.params.invoice_Id + '/' + version;

                    http.get(url, 'invoiceDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [],
                                responseSchema = { "type": "array", "properties": { "invoice": { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "paymentStatus": { "type": "number" }, "approvedGrossTotalAmount": { "type": "number" }, "useTaxApplicable": { "type": "boolean" }, "selfAssessedAmt": { "type": "number" }, "useTaxAdjustedAmount": { "type": "number" }, "bbAdjustedAmount": { "type": "number" }, "integrationStatus": { "type": "number" }, "paymentInApproval": { "type": "number" }, "cmAdjusted": { "type": "boolean" }, "submitForCodingUserId": { "type": "none", "key": "submitForCodingUserInfo" }, "purchaseType": { "type": "string" }, "epDiscountDueDate": { "type": "number" }, "epDiscountedAmount": { "type": "number" }, "invoiceDate": { "type": "none" }, "dueDate": { "type": "none" }, "version": { "type": "number" }, "invoiceId": { "type": "string" }, "invoiceUniqueId": { "type": "string" }, "erpId": { "type": "string" }, "workflowId": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "attachmentIds": { "type": "none" }, "supplierCurrency": { "type": "string" }, "discountValue": { "type": "number" }, "extraCharges": { "type": "number" }, "insuranceCharges": { "type": "number" }, "totalAmount": { "type": "number" }, "grossTotalAmount": { "type": "number" }, "discountLevel": { "type": "number" }, "exciseDuties": { "type": "number" }, "companyCode": { "type": "string" }, "businessUnitCode": { "type": "string" }, "locationCode": { "type": "string" }, "billToCode": { "type": "string" }, "invoiceToCode": { "type": "string" }, "freightCharges": { "type": "number" }, "splitCostingLevel": { "type": "number" }, "splitCostingType": { "type": "number" }, "origin": { "type": "number" }, "newGrossTotalAmount": { "type": "number" }, "assignProject": { "type": "boolean" }, "supplierId": { "type": "string" }, "baseCurrency": { "type": "string" }, "baseExchangeRate": { "type": "number" }, "customerReferenceId": { "type": "string" }, "supplierContact": { "type": "string" }, "supplierAddressId": { "type": "string" }, "supplierAddressIdRemit": { "type": "string" }, "invoiceTaxes": { "type": "string" }, "supplierERPId": { "type": "string" }, "paymentTermId": { "type": "string" }, "supplierTaxExampt": { "type": "string" }, "supplierName": { "type": "string" }, "suppAddress": { "type": "object", "properties": { "tenantId": { "type": "string" }, "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } }, "suppAddressRemit": { "type": "object", "properties": { "tenantId": { "type": "string" }, "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } }, "purchaseOrderNumber": { "type": "string" }, "submittedOn": { "type": "number" }, "supplierBankingDetails": { "type": "object", "properties": { "bankRecordLabel": { "type": "string" }, "bankDescription": { "type": "string" }, "bankRecordERPId": { "type": "string" }, "bankCountry": { "type": "string" }, "bankName": { "type": "string" }, "bankId": { "type": "string" }, "branchName": { "type": "string" }, "bankBranchId": { "type": "string" }, "bankAccountType": { "type": "string" }, "bankAccountNo": { "type": "string" }, "bankAccountSeqNumber": { "type": "string" }, "bankBeneficiaryName": { "type": "string" }, "bankSwiftQualifierCode": { "type": "string" }, "bankSwiftCode": { "type": "string" }, "bankSortCode": { "type": "string" }, "bankIBANNo": { "type": "string" }, "bankIdQualifier": { "type": "string" }, "bankRoutingNo": { "type": "string" }, "bankRoutingKey": { "type": "string" } } }, "comments": { "type": "string" }, "description": { "type": "string" }, "invoiceNumber": { "type": "string" }, "buyer": { "type": "none", "key": "buyerInfo" }, "requester": { "type": "none", "key": "requesterInfo" } } }, "invoiceItems": { "type": "array", "properties": { "lineItemId": { "type": "string" }, "invoiceId": { "type": "string" }, "itemId": { "type": "string" }, "attachmentIds": { "type": "none" }, "lineNo": { "type": "string" }, "itemTaxes": { "type": "array", "properties": { "tenantId": { "type": "string" }, "compound": { "type": "boolean" }, "useTax": { "type": "boolean" }, "type": { "type": "string" }, "name": { "type": "string" }, "rate": { "type": "number" }, "taxAmount": { "type": "number" }, "taxableAmount": { "type": "number" } } }, "marketPrice": { "type": "number" }, "itemQuantity": { "type": "number" }, "splitCostingType": { "type": "number" }, "assetCodeType": { "type": "number" }, "assetCode": { "type": "string" }, "itemComment": { "type": "string" }, "purchaseOrderId": { "type": "none" }, "contractNo": { "type": "string" }, "contractType": { "type": "number" }, "discountType": { "type": "number" }, "discountValue": { "type": "number" }, "coaflexiFormId": { "type": "string" }, "coaflexiFormInstanceId": { "type": "string" }, "coaflexiFormInstanceVersion": { "type": "number" }, "itemTotalPrice": { "type": "number" } } }, "invoiceTaxes": { "type": "array", "properties": { "tenantId": { "type": "string" }, "invoiceId": { "type": "string" }, "type": { "type": "string" }, "name": { "type": "string" }, "rate": { "type": "number" }, "taxableAmount": { "type": "number" }, "taxAmount": { "type": "number" }, "applicableFor": { "type": "number" }, "compound": { "type": "boolean" }, "useTax": { "type": "boolean" }, "borneByBuyerTaxAmount": { "type": "number" } } }, "invoiceCostings": { "type": "array", "properties": { "lineItemId": { "type": "string" }, "invoiceId": { "type": "string" }, "budgetId": { "type": "string" }, "budgetLineId": { "type": "string" }, "budgetLineTransactionId": { "type": "string" }, "businessUnitCode": { "type": "string" }, "costCenterCode": { "type": "string" }, "projectCode": { "type": "string" }, "splitValue": { "type": "number" }, "value": { "type": "number" } } }, "invoiceAccountings": { "type": "array", "properties": { "generalLedgerCode": { "type": "string" }, "tenantId": { "type": "string" }, "lineItemId": { "type": "string" }, "invoiceId": { "type": "string" }, "purchaseType": { "type": "string" }, "purchaseTypeCode": { "type": "string" }, "value": { "type": "number" }, "visibilityRule": { "type": "none" }, "accountTypeCode": { "type": "string" } } }, "invoiceMatchResult": { "type": "none" }, "supportObjects": { "type": "object", "properties": { "attachments": { "type": "array", "properties": {} }, "items": { "type": "none" }, "ocrAttachmentId": { "type": "string" }, "supplier": { "type": "none" } } } } };
                            let userDetails = [];
                            if (!lodash.isEmpty(records)) {
                                if(records.invoice){
                                    if(records.invoice.buyer) userDetails.push(records.invoice.buyer);
                                    if(records.invoice.requester) userDetails.push(records.invoice.requester);
                                    if(records.invoice.submitForCodingUserId) userDetails.push(records.invoice.submitForCodingUserId);                       
                                }
                                if(records.supportObjects && records.supportObjects.attachments){
                                    records.supportObjects.attachments.forEach(item =>{
                                        userDetails.push(item.createdBy);
                                    });
                                }
                                userDetails = lodash.uniq(userDetails);
                            } else {
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                return callback(null, request, output.execute());
                            }
                            if (lodash.isEmpty(userDetails)) {
                                let output1 = [];
                                output1.push(records);
                                const output = (new (super.responseHandler)(request, { "data": output1 }, responseSchema));
                                return callback(null, request, output.execute());
                            }

                            const tms = new (super.tmsHook({ request: request }))(),
                                tasks = [                                                                       
                                    (methodCallback) => {
                                        if (lodash.isEmpty(userDetails)) return methodCallback(request, {});
                                        const reqData = { "ids": userDetails };
                                        tms.getUsersDetails(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        let data = [];
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]);
                                            utils.mergeObject(records.invoice, extractProps, ["buyer", "id"]);
                                            utils.mergeObject(records.invoice, extractProps, ["requester", "id"]);
                                            utils.mergeObject(records.invoice, extractProps, ["submitForCodingUserId", "id"]);
                                            utils.mergeArray(records.supportObjects.attachments, extractProps, ["createdBy", "id"]);
                                            data.push(records);                                            
                                        }
                                        return methodCallback(null, request, { data });
                                    }
                                ];
                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('attachments', output.responseSchema.properties.supportObjects.properties.attachments.properties);
                                    return callback(null, request, output.execute());
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: get Invoice Details if Invoice Number Exists
        *
        * @Description :: Fetch/Get Invoice Details if Invoice Number Exists
        * 
        * @return/object/Throw Error
        */
        isExistsInvoiceNumber(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "invoiceNumber": "joi.string().required().label('einvoice-lable-23__')",
                        "supplierId": "joi.string().required().label('einvoice-lable-19__')",
                        "invoiceId": "joi.string().label('einvoice-lable-14__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/' + 'isExistsInvoiceNumber';
                    http.post(url, 'isInvoiceNumberExists', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Invoice Adjust Credit Memo by Id and Amount
        *
        * @Description :: Invoice Adjust Credit Memo by Id and Amount
        * 
        * @return/object/Throw Error
        */
        adjustCreditMemo(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {  
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "approvedAmount": "joi.string().required().label('einvoice-lable-65__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id}));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/' + 'creditMemoAdjustmentDetails';
                    http.post(url, 'adjustCredit', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "ToBeApportionedCMList": { "type": "none" }, "BB_TAX": { "type": "number" }, "TOTAL_TAX": { "type": "string" }, "prevAdjustedAmount": { "type": "number" }, "NEGATIVE_TAX": { "type": "number" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));                        
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Audit Trail By Id and Type
        *
        * @Description :: Audit Trail By Id and Type
        * 
        * @return/object/Throw Error
        */
        auditTrail(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "Id": "joi.string().required().label('einvoice-lable-66__')",
                        "entityType": "joi.string().required().label('einvoice-lable-67__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "Id": request.params.invoice_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        entityType = request.body.entityType,
                        url = einvoiceURL + '/invoice/' + request.params.invoice_Id + '/auditTrail/' + entityType;
                    http.get(url, 'auditTrail', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "autoId": { "type": "number" }, "auditTrailId": { "type": "string" }, "parentAuditTrailId":{"type":"string"}, "entityType":{"type":"string"}, "entityId":{"type":"string"}, "version":{"type":"number"}, "event":{"type":"string"}, "comments":{"type":"string"}, "attachmentIds":{"type":"none"}, "role":{"type":"string"}, "auditVariables":{"type":"none"}, "auditVariablesStr":{"type":"string"}, "attachmentsStr":{"type":"string"} } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        
        /**
        * @Name :: Submit For Coding By Invoice Id and User Id
        *
        * @Description :: Submit For Coding By Invoice Id and User Id
        * 
        * @return/object/Throw Error
        */
        submitForCoding(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "version": "joi.number().required().label('einvoice-lable-18__')",
                        "reAssignUserId": "joi.string().required().label('einvoice-lable-68__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/' + request.params.invoice_Id + '/action/submitForCoding/' + request.body.reAssignUserId,
                        reqBody = {};
                        reqBody.version = request.body.version;
                    http.post(url, 'SubmitForCoding', reqBody, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Adjust Credit, Against Invoice
        *
        * @Description :: Adjust Credit, Against Invoice
        * 
        * @return/object/Throw Error
        */
        adjustCredit(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "comments": "joi.string().required().label('einvoice-lable-13__')",
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "creditMemoIds": "joi.array().items(joi.string().min(1).required().label('einvoice-lable-15__')).unique().label('einvoice-lable-15__')",
                        "apportionedAmount": "joi.array().items(joi.string().allow('').label('einvoice-lable-69__')).label('einvoice-lable-69__')",
                        "adjustedAmount": "joi.string().required().label('einvoice-lable-70__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/' + request.params.invoice_Id + '/action/creditMemoAdjustmentAgainstInvoice/adjustCredit',
                        requestBody = {};
                    requestBody.comments = request.body.comments;
                    requestBody.creditMemoId = request.body.creditMemoIds;
                    requestBody.apportionedAmount = request.body.apportionedAmount;
                    requestBody.adjustedAmount = request.body.adjustedAmount;
                    http.post(url, 'adjustCredit', requestBody, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    }

    return Invoice;
};
