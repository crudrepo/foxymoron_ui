/**
 * Invoice Filter Controller
 *
 * @description :: Provides invoice filter view related CRUD operation.
 */

module.exports = (parentClass) => {

    class InvoiceFilter extends parentClass {

        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "pageName": "joi.string().required().label('einvoice-lable-2__')",
                        "filterName": "joi.string().required().label('einvoice-lable-3__')",
                        "isDefault": "joi.boolean().required().label('einvoice-lable-4__')",
                        "advancedFilters": "joi.string().allow(['', null]).required().label('einvoice-lable-5__')",
                        "filters": "joi.string().allow(['', null]).required().label('einvoice-lable-6__')",
                        "sortColumn": "joi.number().integer().required().label('einvoice-lable-7__')",
                        "sortType": "joi.string().allow(['', null]).required().label('einvoice-lable-8__')",
                        "displayRecords": "joi.number().integer().required().label('einvoice-lable-9__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const reqData = request.body;
                    reqData.tenantId = request.user.tenantId;
                    reqData.userId = request.user.userId;
                    reqData.createdOn = Date.now();
                    reqData.filterId = "";
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/filter/create';
                    http.post(url, 'createFilter', reqData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        update(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "filterId": "joi.string().required().label('einvoice-lable-10__')",
                        "pageName": "joi.string().invalid(['', null]).label('einvoice-lable-2__')",
                        "filterName": "joi.string().invalid(['', null]).label('einvoice-lable-3__')",
                        "isDefault": "joi.boolean().label('einvoice-lable-4__')",
                        "advancedFilters": "joi.string().allow(['', null]).label('einvoice-lable-5__')",
                        "filters": "joi.string().allow(['', null]).label('einvoice-lable-6__')",
                        "sortColumn": "joi.number().integer().label('einvoice-lable-7__')",
                        "sortType": "joi.string().allow(['', null]).label('einvoice-lable-8__')",
                        "displayRecords": "joi.number().positive().label('einvoice-lable-9__')"
                    };
                validationUtility.addInternalSchema(schema);
                request.body.filterId = request.params.invoicefilter_Id.toString();
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const reqData = request.body;
                    reqData.tenantId = request.user.tenantId;
                    reqData.userId = request.user.userId;
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/filter/update';
                    http.post(url, 'updateFilter', reqData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" }, "info1":{"type":"string"} } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        destroy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "filterId": "joi.string().required().label('einvoice-lable-10__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "filterId": request.params.invoicefilter_Id.toString() });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/filter/' + request.params.invoicefilter_Id + "/delete";
                    http.delete(url, 'deleteFilter', (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" }, "info1":{"type":"string"} } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "pageName": "joi.string().required().label('einvoice-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/filter/getUserFilters/' + request.body.pageName;
                    http.get(url, 'getInvoiceFilterList', (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "filterId": { "type": "string" }, "advancedFilters": { "type": "string" }, "displayRecords": { "type": "number" }, "filterName": { "type": "string" }, "filters": { "type": "string" }, "isDefault": { "type": "boolean" }, "pageName": { "type": "string" }, "sortColumn": { "type": "number" }, "sortType": { "type": "string" }, "tenantId": { "type": "string" }, "userId": { "type": "string" }, "createdOn": { "type": "date" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

      getDetails(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),                    
            schema = {
                "filterId": "joi.string().required().label('einvoice-lable-10__')"
            };
            validationUtility.addInternalSchema(schema);    
            const result = validationUtility.validate({ "filterId": request.params.invoicefilter_Id.toString() });
            if (result) {
              const errorMsg = new (super.customError)(result, 'ValidationError', 3);
              callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    einvoiceURL = request.productsURL.eInvoice,
                    url = einvoiceURL + '/invoice/filter/' + request.params.invoicefilter_Id;
                http.get(url, 'getInvoiceFilterDetails', (error, result) => {
                  if(error){
                      return callback(error, null);
                  }else{                          
                      const responseSchema = { "type": "object", "properties": { "filterId": { "type": "string" }, "advancedFilters": { "type": "string" }, "displayRecords": { "type": "number" }, "filterName": { "type": "string" }, "filters": { "type": "string" }, "isDefault": { "type": "boolean" }, "pageName": { "type": "string" }, "sortColumn": { "type": "number" }, "sortType": { "type": "string" }, "tenantId": { "type": "string" }, "userId": { "type": "string" }, "createdOn": { "type": "date" } } },
                          output =  (new (super.responseHandler)(request, result, responseSchema));
                      return callback(null, request, output.execute());        
                  }
                });
            }
        } catch (error) {
          callback(error, null);
        }
    };
    }

    return InvoiceFilter;
};
