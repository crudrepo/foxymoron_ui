/**
 * CNS Controller
 *
 * @description :: Provides CNS related operations
 */

"use strict";
module.exports = (parentClass) => {
    class Service extends parentClass {

        /**
         * @Method Name : notificationRequest
         *
         * @Description : Get the notification
         * @return object / Throw Error
         */
        notificationRequest(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "productName":   "joi.string().required().label('cns-lable-1__')",
                    "type":   "joi.number().integer().valid(0,1).required().label('cns-lable-2__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new(super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let action = 'GET_USER_NOTIFICATIONS',
                        append = '&action=GET_USER_NOTIFICATIONS&callback=jsonpCallback';
                    if (request.body.type == 1) {
                        action = '';
                        append = '&cancelNotPopUpForTheSession=true';
                    }
                    const http = new(super.httpTmsService)(request),
                        cnsURL = request.productsURL.cns,
                        url = cnsURL + '/serviceClientRequests.cns' +
                        '?action=' + action +
                        '&locale=' + request.user.userSettings.locale +
                        '&userId=' + request.user.userId +
                        '&timeZone=' + request.user.userSettings.timeZone +
                        '&companyId=' + request.user.tenantId +
                        '&productName=' + request.body.productName +
                        '&tenantId=' + request.user.tenantId +
                        '&userId=' + request.user.userId +
                        '&tokenId=' + request.tokenId +
                        '&emailAddress=' + request.user.emailId +
                        '&locale=' + request.user.userSettings.locale + append +
                        '&timestamp=' + new Date().getTime();
                    http.post(url, 'notificationRequest', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const output = {"html": result.toString() || null};
                            return callback(null, request, {data: output});
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
    };
    return Service;
};