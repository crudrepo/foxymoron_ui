"use strict";
module.exports = {   
    /**
        * @swagger
        * /a/dd/ui/getConfig:
        *   get:
        *     tags:
        *       - Dewdrops API
        *     summary: Get the app Configurations
        *     operationId: getConfig
        *     description: Get the app Configurations
        *     produces:
        *       - application/json
        *     responses:
        *       200:
        *         description: successful operation
    */
    getConfig: {
        pre: null,
        process: "ui.getConfig",
        post: null,
        method: 'GET'
    }
};