/**
   * Project Route
   * Provides this Route for project relate operation.
*/

"use strict";

module.exports = {
  /**
   * @swagger
   * /a/cmd/projects/list:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Get Project List
   *     operationId: getProjectList
   *     description: Fetch the Project List
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the Project List(based on name and code).
   *         in: body
   *         schema:
   *           properties:
   *             name:
   *               type: string
   *             code:
   *               type: string
   *             codes:
   *               type: array
   *               items:
   *                 type: string
   *             isActive:
   *               type: boolean
   *             projectNo:
   *               type: string
   *             perPageRecords:
   *               type: integer
   *             pageNo:
   *               type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList: {
    pre: null,
    process: "project.getList",
    post: null,
    method: 'POST'
  },

  /**
   * @swagger
   * /a/cmd/projects/allowedList:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Search Allowed Project
   *     operationId: searchAllowedProject
   *     description: Search Allowed Project
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the Project based on those inputs(pagination, sorting & filter).
   *         in: body
   *         required: true 
   *         schema:
   *             allOf:
   *                - $ref: '#/definitions/pagination'
   *                - $ref: '#/definitions/cmdSort'
   *                - type: object
   *                  properties:      
   *                    companyCode:
   *                      type: string
   *                    bUCCMap:
   *                      type: string
   *                    projectNameOrCode:
   *                      type: string
   *                    userId:
   *                      type: string    
   *                  required: [companyCode, bUCCMap]    
   *     responses:
   *       200:
   *         description: successful operation
   */

  allowedList: {
    pre: null,
    process: "project.allowedList",
    post: null,
    method: 'POST'
  },

    /**
   * @swagger
   * /a/cmd/projects/searchProject:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Search Project
   *     operationId: searchProject
   *     description: Search Project
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the Project based on those inputs(pagination, filter).
   *         in: body
   *         required: true 
   *         schema:
   *             allOf:
   *                - $ref: '#/definitions/pagination'
   *                - type: object
   *                  properties:      
   *                    companyCode:
   *                      type: string
   *                    bUCode:
   *                      type: string
   *                    CCCode:
   *                      type: string
   *                    projectName:
   *                      type: string    
   *                  required: [companyCode, bUCode, CCCode]    
   *     responses:
   *       200:
   *         description: successful operation
   */

  searchProject: {
    pre: null,
    process: "project.searchProject",
    post: null,
    method: 'POST'
  }
}