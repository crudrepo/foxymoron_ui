"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/cmd/businessunits/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Business Unit  List
    *     operationId: getBusinessUnit List
    *     description: Get Business Unit  List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Business Unit List(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties:  
    *               name:
    *                 type: string
    *               codes:
    *                  type: array
    *                  items:
    *                    type: string
    *               isActive:
    *                 type: boolean
    *               parentCode:
    *                 type: string
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "businessunit.getList",
        post: null,
        method: 'POST'
    },
    
       /**
     * @swagger
     * /a/cmd/businessunits/allowedList:
     *   post:
     *     tags:
     *       - CMD API
     *     summary: Search Allowed Business Unit
     *     operationId: searchAllowedBusinessUnit
     *     description: Search Allowed Business Unit
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Find the Business Unit based on those inputs(pagination, sorting & filter).
     *         in: body
     *         schema:
     *             allOf:
     *                - $ref: '#/definitions/pagination'
     *                - $ref: '#/definitions/cmdSort'
     *                - type: object
     *                  properties:  
     *                    companyCode:
     *                      type: string
     *                    name:
     *                      type: string    
     *                    userId:
     *                      type: string    
     *                  required: [businessUnitCode]
     *     responses:
     *       200:
     *         description: successful operation
     */

    allowedList: {
        pre: null,
        process: "businessunit.allowedList",
        post: null,
        method: 'POST'
    }
};