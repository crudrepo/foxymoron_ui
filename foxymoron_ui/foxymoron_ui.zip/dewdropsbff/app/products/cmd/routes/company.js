"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/cmd/companies/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Company  List
    *     operationId: geCompany List
    *     description: Get Company  List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Company  List(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties: 
    *               name:
    *                 type: string
    *               code:
    *                 type: string
    *               codes:
    *                 type: array
    *                 items:
    *                   type: string
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *               isActive:
    *                 type: boolean
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "company.getList",
        post: null,
        method: 'POST'
    },
    
    /**
     * @swagger
     * /a/cmd/companies/allowedList:
     *   post:
     *     tags:
     *       - CMD API
     *     summary: Search Allowed Companies
     *     operationId: searchAllowedCompanies
     *     description: Search Allowed Companies
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Find the Companies based on those inputs(pagination, sorting & filter).
     *         in: body      
     *         schema:
     *             allOf:
     *                - $ref: '#/definitions/pagination'
     *                - $ref: '#/definitions/cmdSort'
     *                - type: object
     *                  properties:      
     *                    name:
     *                      type: string
     *                    userId:
     *                      type: string            
     *     responses:
     *       200:
     *         description: successful operation
     */

    allowedList: {
        pre: null,
        process: "company.allowedList",
        post: null,
        method: 'POST'
    } 
};