"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/cmd/categories/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Category List
    *     operationId: getCategoryList
    *     description: Get Category List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Category List(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties:  
    *               name:
    *                 type: string
    *               code:
    *                 type: string
    *               parentCategoryName:
    *                 type: string
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "category.getList",
        post: null,
        method: 'POST'
    },
    
  /**
   * @swagger
   * /a/cmd/categories:
   *   get:
   *     tags:
   *       - CMD API
   *     summary: Get Category List
   *     operationId: getCategoryList
   *     description: Fetch all the Category List
   *     produces:
   *       - application/json
   *     responses:
   *       200:
   *         description: successful operation
   */

  getRecords:{
    pre: null,
    process: "category.getRecords",
    post: null,
    method: 'GET'
  }

};