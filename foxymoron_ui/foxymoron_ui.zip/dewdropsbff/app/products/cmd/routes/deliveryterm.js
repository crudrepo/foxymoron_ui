"use strict";

module.exports = {

  /**
   * @swagger
   * /a/cmd/deliveryterms/list :
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Get DeliveryTerms list
   *     operationId: getDeliveryTermsList
   *     description: Fetch all the DeliveryTerms List
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Fetch the DeliveryTerms list(based on those options name, code).
   *         in: body
   *         schema:
   *           properties:
   *             name: 
   *               type: string
   *             code: 
   *               type: string
   *             perPageRecords:
   *               type: integer
   *             pageNo:
   *               type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList:{
    pre: null,
    process: "deliveryterm.getList",
    post: null,
    method: 'POST'
  }
}