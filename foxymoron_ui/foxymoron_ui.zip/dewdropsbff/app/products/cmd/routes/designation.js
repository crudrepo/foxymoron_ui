/**
   * Designation Controller
   * It is used for handling designation related operations.
*/

"use strict";

module.exports = {

  /**
   * @swagger
   * /a/cmd/designations/list:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Get Designation List
   *     operationId: getDesignation
   *     description: Get Designation List
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Get Designation List based on Codes and Pagination.
   *         in: body
   *         schema:
   *             allOf:
   *                - $ref: '#/definitions/pagination'
   *                - type: object
   *                  properties:
   *                    codes:
   *                      type: array
   *                      items:
   *                        type: string
   *     responses:
   *       200:
   *         description: successful operation
   */
    getList: {
        pre: null,
        process: "designation.getList",
        post: null,
        method: 'POST'
    }

}