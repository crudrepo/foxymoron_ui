"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/cmd/regions/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Region List
    *     operationId: getRegionList
    *     description: Get Region List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Region List(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties:  
    *               name:
    *                 type: string
    *               code:
    *                 type: string
    *               codes:
    *                 type: array
    *                 items:
    *                   type: string
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "region.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/cmd/regions/allowedList:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Region Allowed List
    *     operationId: getRegionAllowedList
    *     description: Get Region Allowed List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Region Allowed List(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties:  
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */  
    allowedList: {
        pre: null,
        process: "region.allowedList",
        post: null,
        method: 'POST'
    }
};