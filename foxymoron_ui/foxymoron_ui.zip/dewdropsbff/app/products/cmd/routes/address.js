"use strict";

module.exports = {
    /**
    * @swagger
    * /a/cmd/addresses/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Search Address List
    *     operationId: addressList
    *     description: Fetch the address list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch all addresses(based on search criteria & pagination).
    *         type: string
    *         in: body
    *         schema:
    *             properties:
    *               name:
    *                 type: string
    *               codes:
    *                 type: array
    *                 items:
    *                   type: string
    *               isActive:
    *                 type: boolean    
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */

    getList: {
        pre: null,
        process: "address.getList",
        post: null,
        method: 'POST'
    },


    /**
    * @swagger
    * /a/cmd/addresses:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Add Address
    *     operationId: addAddress
    *     description: Add a new address
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add address with address data
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               name:
    *                 type: string
    *               street1:
    *                 type: string
    *               street2:
    *                 type: string
    *               street3:
    *                 type: string
    *               street4:
    *                 type: string
    *               city:
    *                 type: string
    *               county:
    *                 type: string
    *               state:
    *                 type: object
    *                 properties:  
    *                   code:
    *                       type: string
    *                 required: [code]
    *               postal:
    *                 type: string
    *               country:
    *                 type: object
    *                 properties:  
    *                   code:
    *                       type: string
    *                 required: [code]
    *               shipTo:
    *                 type: boolean
    *               billTo:
    *                 type: boolean
    *               invoiceTo:
    *                 type: boolean
    *               oneTime:
    *                 type: boolean
    *               custom:
    *                 type: boolean
    *             required: [name, street1, street2, country, state, shipTo, billTo, invoiceTo]
    *     responses:
    *       200:
    *         description: successful operation
    */

    create: {
        pre: null,
        process: "address.create",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/cmd/addresses:
    *   put:
    *     tags:
    *       - CMD API
    *     summary: Update Address
    *     operationId: updateAddress
    *     description: Update address
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update address with address data
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               name:
    *                 type: string
    *               code:
    *                 type: string
    *               street1:
    *                 type: string
    *               street2:
    *                 type: string
    *               street3:
    *                 type: string
    *               street4:
    *                 type: string
    *               city:
    *                 type: string
    *               county:
    *                 type: string
    *               state:
    *                 type: object
    *                 properties:  
    *                   code:
    *                       type: string
    *                 required: [code]
    *               postal:
    *                 type: string
    *               country:
    *                 type: object
    *                 properties:  
    *                   code:
    *                       type: string
    *                 required: [code]
    *               shipTo:
    *                 type: boolean
    *               billTo:
    *                 type: boolean
    *               invoiceTo:
    *                 type: boolean
    *               oneTime:
    *                 type: boolean
    *               custom:
    *                 type: boolean
    *             required: [name, code, street1, street2, country, state, shipTo, billTo, invoiceTo]
    *     responses:
    *       200:
    *         description: successful operation
    */

    update: {
        pre: null,
        process: "address.update",
        post: null,
        method: 'PUT'
    },

    /**
     * @swagger
     * /a/cmd/addresses/allowedList:
     *   post:
     *     tags:
     *       - CMD API
     *     summary: Search Allowed Address
     *     operationId: searchAllowedAddress
     *     description: Search Allowed Address
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Find the Address based on those inputs(pagination, sorting & filter).
     *         in: body
     *         required: true 
     *         schema:
     *             allOf:
     *                - $ref: '#/definitions/pagination'
     *                - $ref: '#/definitions/cmdSort'
     *                - type: object
     *                  properties:      
     *                    name:
     *                      type: string
     *                    companyCode:
     *                      type: string
     *                    businessUnitCode:
     *                      type: string
     *                    userId:
     *                      type: string 
     *                    codes:
     *                      type: array
     *                      items:
     *                        type: string
     *                    isActive:
     *                      type: boolean
     *                  required: [companyCode, businessUnitCode]    
     *     responses:
     *       200:
     *         description: successful operation
     */

    allowedList: {
        pre: null,
        process: "address.allowedList",
        post: null,
        method: 'POST'
    }
}