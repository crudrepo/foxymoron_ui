/**
   * State Controller
   * Provides this controller to get the state list and details.
*/

"use strict";

module.exports = {

  /**
   * @swagger
   * /a/cmd/purchasetypes/list :
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Get PurchaseTypes list
   *     operationId: getPurchaseTypesList
   *     description: Fetch all the PurchaseTypes List
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Fetch the PurchaseTypes list(based on those options filter, pagination).
   *         in: body
   *         schema:
   *           properties:
   *             name: 
   *               type: string
   *             code: 
   *               type: string
   *             perPageRecords:
   *               type: integer
   *             pageNo:
   *               type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList:{
    pre: null,
    process: "purchasetype.getList",
    post: null,
    method: 'POST'
  }
}