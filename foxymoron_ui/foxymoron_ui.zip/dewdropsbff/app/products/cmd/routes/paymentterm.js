"use strict";

module.exports = {

  /**
   * @swagger
   * /a/cmd/paymentterms/list :
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Get PaymentTerms list
   *     operationId: getPaymentTermsList
   *     description: Fetch all the PaymentTerms List
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Fetch the PaymentTerms list(based on those options name, code).
   *         in: body
   *         schema:
   *           properties:
   *             name: 
   *               type: string
   *             code: 
   *               type: string
   *             perPageRecords:
   *               type: integer
   *             pageNo:
   *               type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList:{
    pre: null,
    process: "paymentterm.getList",
    post: null,
    method: 'POST'
  }
}