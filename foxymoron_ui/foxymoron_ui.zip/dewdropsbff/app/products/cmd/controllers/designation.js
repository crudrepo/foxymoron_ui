/**
   * Designation Controller
   * @Description : It is used for handling Designation related operations.
*/

"use strict";

module.exports = (parentClass) => {

    class Department extends parentClass {

        /**
        * @Method Name : getDesignationList
        *
        * @Description : Search the Designation List by Codes
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "codes": "joi.array().items(joi.string().allow('').label('cmd-lable-20__')).unique().label('cmd-lable-20__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmdURL = request.productsURL.cmd,
                        http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                        url = cmdURL + '/organization/searchDesignation?tenantId=' + request.user.tenantId + '&code=ROOT_NODE' + '&locale=' + request.user.userSettings.locale;
                    http.post(url, 'designationList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "name": { "type": "string" }, "code": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "level": { "type": "number" }, "description": { "type": "string" }, "auditStatus": { "type": "string" }, "erpId": { "type": "string" }, "actionVia": { "type": "string" }, "modifiedBy": { "type": "none" }, "modifiedOn": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    }

    return Department;
}