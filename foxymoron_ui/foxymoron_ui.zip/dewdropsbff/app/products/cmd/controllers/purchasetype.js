/**
   * purchaseType Controller
   * Provides this controller to get the purchaseType list and details.
*/

"use strict";

module.exports = (parentClass)=> {
  
  class PurchaseType extends parentClass {

    /**
    * @Method Name : getList
    *
    * @Description : Display the state lists
    * @return object / Throw Error
    */
    getList(request, input, callback){
        try {
          const validationUtility = super.utils.validationUtility(request);
          const schema = {
              "name" : "joi.string().max(30).label('cmd-lable-1__')",
              "code" : "joi.string().max(30).label('cmd-lable-10__')"
          };                      
          validationUtility.addInternalSchema(schema);
          validationUtility.addCommonSchema('pagination'); 
          const result = validationUtility.validate(request.body);
          if(result){
              const errorMsg = new (super.customError)(result, 'ValidationError', 3);
              callback(errorMsg, null);
          }else{
            const conditions = [];
            const http =  new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch);
            const name = request.body.name;
            const code = request.body.code;
            const erpid = request.body.erpid;

            if(!super.lodash.isEmpty(code)){
              conditions.push({"column":"SEARCH_BY_CODE","value":code});              
            }

            if(!super.lodash.isEmpty(name)){
              conditions.push({"column":"SEARCH_BY_NAME","value":name});
            } 

            if(!super.lodash.isEmpty(erpid)){
              conditions.push({"column":"SEARCH_BY_ERP_ID", "value":erpid});
            }

            const requestData = {
              "mode":0,
              "conditions":conditions,
              "noOfRecords": request.body.perPageRecords || super.settingConfig.perPageRecords,  
              "startIndex": (request.body.pageNo || super.settingConfig.pageNo) - 1,
              "ascending":false,
              "searchCondition":""
            }
            const cmdURL = request.productsURL.cmd;
            const url = cmdURL+'/component/searchPurchaseTypes?tenantId='+request.user.tenantId+'&locale='+request.user.userSettings.locale;
            http.post(url, 'stateList', requestData, (error, result) => {
               if(error){
                 callback(error, null);
               }else if(result){
                if(super.lodash.isEmpty(result.data)==false){
                  result.data.noOfRecords = requestData.noOfRecords;
                  result.data.startIndex = requestData.startIndex+1;
                }
                const responseSchema = {"type":"object","properties":{"totalCount":{"type":"number","key":"totalRecords"},"noOfRecords":{"type":"number","key":"perPageRecords"},"startIndex":{"type":"number","key":"pageNo"},"result":{"type":"array","key":"records","properties":{"code":{"type":"string"},"name":{"type":"string"},"erpId":{"type":"string"},"active":{"type":"boolean","key":"status"},"id":{"type":"number"},"createdOn":{"type":"none"}}}}};
                const output =  (new (super.responseHandler)(request, result, responseSchema)).execute();
                return callback(null, request, output);
               }
             });
          }         
        } catch (error) {
          callback(error, null);
        }
    }
}
return PurchaseType;
}