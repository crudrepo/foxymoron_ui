/**
   * Cost center Controller
   * Provides this controller to search the cost centers.
*/

"use strict";

module.exports = (parentClass) => {

  class CostCenter extends parentClass {

    /**
    * @Method Name : getList
    *
    * @Description : Search the cost centers
    * @return object / Throw Error
    */
    getList(request, input, callback) {
      try {
        let validationUtility = super.utils.validationUtility(request);
        let schema = {
          "name": "joi.string().max(30).label('cmd-lable-1__')",
          "code": "joi.string().max(30).label('cmd-lable-18__')",
          "codes": "joi.array().items(joi.string().allow('').label('cmd-lable-20__')).unique().label('cmd-lable-20__')",
          "isActive": "joi.boolean().allow('').label('cmd-lable-39__')"
        };
        validationUtility.addInternalSchema(schema);
        validationUtility.addCommonSchema('pagination');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const cmdURL = request.productsURL.cmd;
          const http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch);
          const url = cmdURL + '/costing/getCostCenters?tenantId=' + request.user.tenantId + '&locale='+request.user.userSettings.locale;
          http.post(url, 'costCenterList', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result) {
              let responseSchema = { "type": "object", "properties": { "totalCount": { "type": "number", "key": "totalRecords" }, "noOfRecords": { "type": "number", "key": "perPageRecords" }, "startIndex": { "type": "number", "key": "pageNo" }, "result": { "type": "array", "key": "records", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "active": { "type": "boolean" }, "id": { "type": "string" }, "costCenterCode": { "type": "string" }, "categoryCode": { "type": "string" }, "parentCategoryName": { "type": "string" }, "parentCategoryCode": { "type": "string" }, "description": { "type": "string" }, "createdOn": { "type": "date" }, "modifiedOn": { "type": "date" }, "costCenterOwners": { "type": "array", "properties": { "tenantId": { "type": "string" }, "costCenterCode": { "type": "string" }, "costCenterOwner": { "type": "string" }, "currency": { "type": "string" } } } } } } };
              let output = (new (super.responseHandler)(request, result, responseSchema));
              output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }


    /**
    * @Method Name : allowedList
    *
    * @Description : Search Allowed CostCenters
    * @return object / Throw Error
    */
    allowedList(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
        schema = {
          "companyCode": "joi.string().required().label('cmd-lable-27__')",
          "businessUnitCode": "joi.string().required().label('cmd-lable-28__')",
          "name": "joi.string().max(30).label('cmd-lable-1__')",
          "code": "joi.string().max(30).label('cmd-lable-18__')"          
        };
        validationUtility.addInternalSchema(schema);
        validationUtility.addCommonSchema('pagination');
        validationUtility.addCommonSchema('cmdSort');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const cmdURL = request.productsURL.cmd,
                searchParams = JSON.stringify([{"ORST_ORG_LVL_1":[request.body.companyCode], "ORST_ORG_LVL_2":[request.body.businessUnitCode]}]),
                http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                url = cmdURL + '/costing/searchAllowedCostCenters?tenantId='+ request.user.tenantId +'&userId=' + request.user.userId +'&searchParams='+ searchParams +'&fetchOnlyCodes=false&locale='+request.user.userSettings.locale,
                input = super.lodash.merge({}, {"ascending": true, "sortColumn": "SORT_BY_NAME"}, request.body);
          http.post(url, 'allowedCostCenterList', input, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result) {
              const responseSchema = {"type":"object","properties":{"totalCount":{"type":"number","key":"totalRecords"},"noOfRecords":{"type":"number","key":"perPageRecords"},"startIndex":{"type":"number","key":"pageNo"},"result":{"type":"array","key":"records","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"name":{"type":"string"},"code":{"type":"string"},"active":{"type":"boolean"},"id":{"type":"string"},"costCenterCode":{"type":"string"},"description":{"type":"string"},"scopeGroupCode":{"type":"string"},"erpId":{"type":"string"},"createdOn":{"type":"none"},"modifiedOn":{"type":"none"},"costCenterOwners":{"type":"array","properties":{"tenantId":{"type":"string"},"costCenterCode":{"type":"string"},"costCenterOwner":{"type":"string"},"currency":{"type":"string"}}}}}}},
                    output = (new (super.responseHandler)(request, result, responseSchema));
              output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

  }

  return CostCenter;
}