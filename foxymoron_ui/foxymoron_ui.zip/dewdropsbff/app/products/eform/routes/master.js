"use strict";
module.exports = {

   /**
   * @swagger
   * definitions:
   *   params:
   *     properties:
   *       masterType:
   *         type: string
   *       masterInfo:
   *          type: string
   */

   /**
     * @swagger
     * /a/eform/masters/list:
     *   post:
     *     tags:
     *       - Eform API
     *     summary: Get master data list
     *     operationId: getMasterData
     *     description: Get master data list
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch the list of master data(based on those options filter, sorting & pagination)
     *         in: body
     *         schema:
     *             allOf:
     *                - $ref: '#/definitions/params'
     *                - $ref: '#/definitions/pagination'
     *                - $ref: '#/definitions/criteriaGroup'
     *                - $ref: '#/definitions/sort'
     *                  required: [masterType, masterInfo]
     *     responses:
     *       200:
     *         description: successful operation
     */
    getList: {
        pre: null,
        process: "master.getList",
        post: null,
        method: 'POST'
    },
}

