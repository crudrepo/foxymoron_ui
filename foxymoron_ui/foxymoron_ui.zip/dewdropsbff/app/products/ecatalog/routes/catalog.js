"use strict";

module.exports = {    
    
    /**
    * @swagger
    * /a/ecatalog/catalogs/list:
    *   post:
    *     tags:
    *       - Ecatalog API
    *     summary: Get the catalog list
    *     operationId: getCatalogList
    *     description: Get the catalog list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the catalog list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "catalog.getList",
        post: null,
        method: 'POST'
    } 
};