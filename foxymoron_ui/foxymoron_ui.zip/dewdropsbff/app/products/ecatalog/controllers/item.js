/**
 * eCatalog Controller
 *
 * @description :: It's used to get the Ecatalog Items list.
 */

"use strict";
module.exports = (parentClass)=> {
  class Item extends parentClass {
     /**
       * Get the eCatalog items list.
     */ 
      getList(request, input, callback) {
            try {                
                let validationUtility = super.utils.validationUtility(request);         
                validationUtility.addCommonSchema('pagination'); 
                validationUtility.addCommonSchema('sort');              
                validationUtility.addCommonSchema('criteriaGroup');    
                let result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const eCatalog = request.productsURL.eCatalog;
                    let http =  new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    let url = eCatalog+'/items/filter';                                          
                    http.post(url, 'getCatalog', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else if(result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{}}}},
                            output =  (new (super.responseHandler)(request, result, responseSchema)); 
                            output.addCommonSchema('ecatalog-item', output.responseSchema.properties.records.properties);
                            output.addCommonSchema('pagination', output.responseSchema.properties);                               
                            const schemaRes = output.execute();                           
                            if(schemaRes.data) {
                                schemaRes.data.facetResult = result.data.facetResult;
                                schemaRes.data.statResult = result.data.statResult;
                            }                            
                            return callback(null, request, schemaRes);                            
                        }
                    });
                }                
            } catch (error) {               
                return callback(error, null);
            }
        }

  }
  return Item;
};

