"use strict";

module.exports = { 

     /**
     * @swagger
     * definitions:
     *   stringArray:
     *     schema:
     *       type: array
     *       items:
     *         type: string
     */

     /**
     * @swagger
     * definitions:
     *   numberArray:
     *     schema:
     *       type: array
     *       items:
     *         type: number
     */
     
    /**
     * @swagger
     * definitions:
     *   evaluate:
     *     required: [flexibleAccountingFormId,buyerId, totalAmount, itemSource,purchaseOrderId, supplier, categoryCodes, costCenterCodes, accountTypeCodes, glAccountCodes, companyCode, businessUnitCode, locationCode, regionCode]
     *     properties:
     *       status:
     *          type: integer
     *       statusComments:
     *          type: string
     *       archive:
     *          type: boolean
     *       error:
     *          type: boolean
     *       errorReasons:
     *          type: object
     *       version:
     *          type: integer
     *       workflowId:
     *          type: string
     *       name:
     *          type: string
     *       defaultWorkflow:
     *          type: boolean
     *       description:
     *          type: string
     *       processCode:
     *          type: string
     *       definitionId:
     *          type: string
     *       definitionType:
     *          type: boolean
     *       currency:
     *          type: string
     *       updated:
     *          type: boolean
     *       parentWorkflowId:
     *          type: string
     *       preventMultiApprovals:
     *          type: boolean
     *       skipInitiator:
     *          type: boolean
     *       subprocessKey:
     *          type: string
     *       newWorkflow:
     *          type: boolean
     *       costCenterApproverType:
     *          type: integer
     *       requestUserId:
     *          type: string
     *       companyCode:
     *          type: string
     *       businessUnitCode:
     *          type: string
     *       locationCode:
     *          type: string
     *       regionCode:
     *          type: string 
     *       categoryCodes:
     *          schema:
     *           $ref: '#/definitions/stringArray'
     *       roleType:
     *          type: string
     *       flexibleAccountingInstanceId:
     *          schema:
     *           $ref: '#/definitions/stringArray'    
     *       flexibleAccountingVersion:
     *          schema:
     *           $ref: '#/definitions/numberArray'
     *       flexibleAccountingFormId:
     *          type: string
     *       costCenterCodes:
     *          schema:
     *           $ref: '#/definitions/stringArray'
     *       accountTypeCodes:
     *          schema:
     *           $ref: '#/definitions/stringArray'    
     *       glAccountCodes:
     *          schema:
     *           $ref: '#/definitions/stringArray'               
     *       totalAmount:
     *          type: integer
     *       itemSource:
     *          schema:
     *           $ref: '#/definitions/stringArray'
     *       purchaseType:
     *          type: string   
     *       utilizeBudget:
     *          type: boolean 
     *       purchaseOrderId:
     *          type: string 
     *       referenceType:
     *          type: string  
     *       paymentMethod:
     *          type: string   
     *       supplier:
     *          type: string  
     *       buyerId:
     *          type: string 
     *       budgetLineIds:
     *          schema:
     *           $ref: '#/definitions/stringArray' 
     *       statusText:
     *          type: string 
     *       reqInventory:
     *          type: boolean 
     *       contracted:
     *          type: boolean 
     *       customShipAddress:
     *          type: boolean 
     *       errorReasonsStr:
     *          type: string 
     *       requisitionIds:
     *          schema:
     *           $ref: '#/definitions/stringArray' 
     *       purchaseOrderType:
     *          type: string   
     *       paymentTerms:
     *          type: string  
     *       poItemType:
     *          type: string 
     *       receiptRequired:
     *          type: boolean  
     *       costingValues:
     *          schema:
     *           $ref: '#/definitions/numberArray'
     *       orderValue:
     *          type: integer 
     *       blanketPurchaseOrderType:
     *          type: string                  
     */
    
    /**
    * @swagger
    * /a/eproc/workflows/evaluate:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Evaluate the Workflow before its aproval
    *     operationId: evaluateWorkflow
    *     description: Evaluate the Workflow before its aproval
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide the request object for evaluating a workflow.
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/evaluate'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    evaluate: {
        pre: null,
        process: "workflow.evaluate",
        post: null,
        method: 'POST'
    }, 
    
    /**
     * @swagger
     * definitions:
     *   remindAprroval:
     *     type: object
     *     properties:
     *       approvalId: 
     *         type: string
     *       workflowInstanceId: 
     *         type: string
     *       approvalLastModifiedOn: 
     *         type: string
     *       requisitionId: 
     *         type: string
     */

    /**
     * @swagger
     * /a/eproc/workflows/remind:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Reminds approver to approve the requisition
     *     operationId:  remindApproval
     *     description:  Reminds approver to approve the requisition
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch the  Past Requisitions items(based on filter, sorting & pagination)..
     *         type: string
     *         in: body
     *         required: true
     *         schema: 
    *            $ref: '#/definitions/remindAprroval'
     */
    remind: {
        pre: null,
        process: "workflow.remind",
        post: null,
        method: 'POST'
    },

        /**
    * @swagger
    *  /a/eproc/workflows/getworkflowTrail:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: getworkflowTrail
    *     operationId: getworkflowTrail
    *     description: getworkflowTrail
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: recall a requisition
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           processCode:
    *            type: string
    *           workflowId:
    *            type: string
    *           workflowInstanceId:
    *            type: string
    *           entityId:
    *            type: string
    *          required: [processCode, workflowId, entityId]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    getworkflowTrail: {
        pre: null,
        process: "workflow.getworkflowTrail",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * /a/eproc/workflows/getWorkflowApprovals:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: get Workflow Approvals Details
     *     operationId: get Workflow Approvals Details
     *     description: getWorkflowApprovalsDetails
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: approvalIds
     *         description: get Workflow Approvals
     *         in: body
     *         required: true
     *         schema:
     *          properties:
     *           approvalIds:
     *            type: array
     *            items:
     *             type: string   
     *     responses:
     *       200:
     *         description: successful operation
     */
    
    getWorkflowApprovals: {
        pre: null,
        process: "workflow.getWorkflowApprovals",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    *  /a/eproc/workflows/{workflow_Id}/getpredictworkflowTrail:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: getpredictworkflowTrail
    *     operationId: getpredictworkflowTrail
    *     description: getpredictworkflowTrail
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: workflow_Id
    *         description: Provide a workflow ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: get predict workflowTrail
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           processCode:
    *            type: string
    *           workflowId:
    *            type: string
    *           workflowInstanceId:
    *            type: string
    *           entityId:
    *            type: string
    *           groupId:
    *            type: string
    *           entityVersion:
    *            type: number
    *          required: [processCode, workflowId, entityId, groupId, entityVersion]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    getpredictworkflowTrail: {
        pre: null,
        process: "workflow.getpredictworkflowTrail",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    *  /a/eproc/workflows/{workflow_Id}/updateWorkflowInstance:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: updateWorkflowInstance
    *     operationId: updateWorkflowInstance
    *     description: updateWorkflowInstance
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: workflow_Id
    *         description: Provide a workflowInstance ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: update workflow instance
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           workflowInstanceId:
    *            type: string
    *           entityId:
    *            type: string
    *           entityVersion:
    *            type: number
    *           lastModifiedLong:
    *            type: string
    *           lastUpdatedOn:
    *            type: string
    *           nodeId:
    *            type: string
    *           workflowNodeId:
    *            type: string
    *           parentNodeId:
    *            type: string
    *           parentUserId:
    *            type: string
    *           approverUserId:
    *            type: string
    *           action:
    *            type: string
    *           approvalId:
    *            type: string
    *           roleType:
    *            type: string
    *           isAmend:
    *            type: boolean
    *           processCode:
    *            type: string
    *           groupId:
    *            type: string
    *          required: [entityId, entityVersion, nodeId, action, roleType, processCode, groupId]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateWorkflowInstance: {
        pre: null,
        process: "workflow.updateWorkflowInstance",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    *  /a/eproc/workflows/{workflow_Id}/updateSelectableUserWorkflowInstance:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: updateSelectableUserWorkflowInstance
    *     operationId: updateSelectableUserWorkflowInstance
    *     description: updateSelectableUserWorkflowInstance
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: workflow_Id
    *         description: Provide a workflowInstance ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: update workflow instance
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           workflowId:
    *            type: string
    *           workflowInstanceId:
    *            type: string
    *           entityId:
    *            type: string
    *           nodeId:
    *            type: string
    *           processCode:
    *            type: string
    *           groupId:
    *            type: string
    *           selectableUserId:
    *            type: string
    *          required: [workflowId, entityId, nodeId, processCode, groupId]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateSelectableUserWorkflowInstance: {
        pre: null,
        process: "workflow.updateSelectableUserWorkflowInstance",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    *  /a/eproc/workflows/{workflowInstance_Id}/updateRequisitionItemGroup:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update the requisition item group
    *     operationId: updateRequisitionItemGroup
    *     description: Update the requisition item group
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: workflowInstance_Id
    *         description: Provide a workflowInstance ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Get the update Requisition item group
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           requisitionId:
    *            type: string
    *           groupId:
    *            type: string
    *          required: [requisitionId, groupId]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateRequisitionItemGroup: {
        pre: null,
        process: "workflow.updateRequisitionItemGroup",
        post: null,
        method: "PUT"
    },

      /**
    * @swagger
    *  /a/eproc/workflows/validateDynamicApprover:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Validating Approver 
    *     operationId: validateDynamicApprover
    *     description: Validating Approver 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Validating Approver
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           selectableUserId:
    *            type: string
    *           workflowId:
    *            type: string
    *           workflowInstanceId:
    *            type: string
    *           parentNodeId:
    *            type: string
    *           action:
    *            type: string
    *           entityId:
    *            type: string
    *           activityId:
    *            type: string
    *           processCode:
    *            type: string
    *           lastModifiedLong:
    *            type: number
    *           groupId:
    *            type: string
    *           documentScope:
    *            type: array
    *            items:
    *             type: string
    
    *          required: [selectableUserId,workflowId,workflowInstanceId,parentNodeId,action,entityId,processCode]     
    *     responses:
    *       200:
    *         description: successful operation
    */
   validateDynamicApprover : {
    pre: null,
    process:"workflow.validateDynamicApprover",
    post:null,
    method:"POST"
},

 /**
     * @swagger
     * /a/eproc/workflows/addUpdateWorkflowNodeApprover:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Add Update Workflow Node App Approver
     *     operationId: add_update_workflow_node_Approver
     *     description: add Update Workflow Node Approver
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: add update workflow Node Aprover
     *         in: body
     *         required: true
     *         schema:
     *          properties:
     *           entityId:
     *            type: string
     *           entityType:
     *            type: string
     *           workflowInstanceId:
     *            type: string
     *           nodeId:
     *            type: string
     *           costCenterCodeList:
     *            type: array
     *            items:
     *             type: string  
     *           costCenterApproverList:
     *            type: array
     *            items:
     *             type: string
     *    
     *          required: [entityId,entityType,nodeId,costCenterCodeList,costCenterApproverList]
     *     responses:
     *       200:
     *         description: successful operation
     */
    addUpdateWorkflowNodeApprover : {
        pre: null,
        process:"workflow.addUpdateWorkflowNodeApprover",
        post:null,
        method:"POST"
    },

    /**
     * @swagger
     * /a/eproc/workflows/getWorkflowNodeApprovers:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get the Workflow Node Approvers
     *     operationId: get_workflow_node_Approvers
     *     description: Get the Workflow Node Approvers
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Get the Workflow Node Approvers
     *         in: body
     *         required: true
     *         schema:
     *          properties:
     *           entityId:
     *            type: string
     *           entityType:
     *            type: string
     *           workflowInstanceId:
     *            type: string
     *          required: [entityId,entityType,workflowInstanceId]
     *     responses:
     *       200:
     *         description: successful operation
     */
    getWorkflowNodeApprovers : {
        pre: null,
        process: "workflow.getWorkflowNodeApprovers",
        post: null,
        method:"POST"
    },

    /**
    * @swagger
    * /a/eproc/workflows/getApprovalList:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the workflow approvals list
    *     operationId: getWorkflowApprovalsList
    *     description: Get the workflow approvals list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the workflow approvals(based on those options filter, sorting & pagination).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getApprovalList: {
        pre: null,
        process: "workflow.getApprovalList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/workflows/approveAction:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Do Workflow approve action
    *     operationId: doWorkflowApproveAction
    *     description: Do Workflow approve action
    *     produces:
    *       - application/json
     *     parameters:
     *       - name: body
     *         description: Do Workflow approve action
     *         in: body
     *         required: true
     *         schema:
     *          properties:
     *           roleType:
     *            type: string
     *           approvalId:
     *            type: string
     *           approvalLastModifiedOn:
     *            type: number
     *           adminRequestedAction:
     *            type: boolean
     *           comments:
     *            type: string
     *          required: [roleType, approvalId, approvalLastModifiedOn]
    *     responses:
    *       200:
    *         description: successful operation
    */   
    approveAction: {
        pre: null,
        process: "workflow.approveAction",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/workflows/rejectAction:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Do Workflow reject action
    *     operationId: doWorkflowRejectAction
    *     description: Do Workflow reject action
    *     produces:
    *       - application/json
     *     parameters:
     *       - name: body
     *         description: Do Workflow reject action
     *         in: body
     *         required: true
     *         schema:
     *          properties:
     *           roleType:
     *            type: string
     *           approvalId:
     *            type: string
     *           approvalLastModifiedOn:
     *            type: number
     *           adminRequestedAction:
     *            type: boolean
     *           comments:
     *            type: string
     *          required: [roleType, approvalId, approvalLastModifiedOn]
    *     responses:
    *       200:
    *         description: successful operation
    */   
    rejectAction: {
        pre: null,
        process: "workflow.rejectAction",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/workflows/doDelegateWorkflowApproval:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Do Workflow delegate approval
    *     operationId: doDelegateWorkflowApproval
    *     description: Do Workflow delegate approval
    *     produces:
    *       - application/json
     *     parameters:
     *       - name: body
     *         description: Do Workflow delegate approval
     *         in: body
     *         required: true
     *         schema:
     *          properties:
     *           approvalId:
     *            type: string
     *           delegatedUserId:
     *            type: string
     *           roleType:
     *            type: string
     *           comments:
     *            type: string
     *           adminRequestedAction:
     *            type: boolean
     *           documentScope:
     *            type: array
     *            items:
     *             type: string
     *           approvalLastModifiedOn:
     *            type: number
     *          required: [approvalId, delegatedUserId, roleType, approvalLastModifiedOn]
    *     responses:
    *       200:
    *         description: successful operation
    */   
    doDelegateWorkflowApproval: {
        pre: null,
        process: "workflow.doDelegateWorkflowApproval",
        post: null,
        method: 'POST'
    }
};