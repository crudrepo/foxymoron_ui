"use strict";

module.exports = {
    /**
     * @swagger
     * /a/eproc/contracts/list:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get Contract List
     *     operationId: contractList
     *     description: Get Contract List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Search for contracts ( Based on those options filter, sorting & pagination ).
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - type: object
     *               properties:      
     *                 isMapUserInfo:
     *                    type: boolean
     *               required: []    
     *     responses:
     *       200:
     *         description: successful operation
     */
    getList: {
        pre: null,
        process: "contract.getList",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * /a/eproc/contracts/{contract_Id}:
     *   get:
     *     tags:
     *       - Eproc API
     *     summary: Fetch/Get a Contract Details
     *     operationId: getContractDetails
     *     description: Fetch/Get a Contract Details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: contract_Id
     *         description: Provide a Contract ID.
     *         in: path
     *         required: true
     *         type: integer
     *     responses:
     *       200:
     *         description: successful operation
     */
    getDetails: {
        pre: null,
        process: "contract.getDetails",
        post: null,
        method: 'GET'
    }

};