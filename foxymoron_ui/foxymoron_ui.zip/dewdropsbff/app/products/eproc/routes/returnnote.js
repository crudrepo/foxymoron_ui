"use strict";

module.exports = {
    /**
        * @swagger
        * /a/eproc/returnnotes/{returnNote_Id}:
        *   get:
        *     tags:
        *       - Eproc API
        *     summary: Get Return Note Details
        *     operationId: getReturnNoteDetails
        *     description: Fetch a Return Note Details
        *     produces:
        *       - application/json
        *     parameters:
        *       - name: returnNote_Id
        *         description: Find a Return Note Details.
        *         in: path
        *         required: true
        *         type: integer
        *     responses:
        *       200:
        *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "returnnote.getReturnNoteDetails",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/returnnotes/{returnnote_Id}:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary: Delete ReturnNotes
    *     operationId: deleteReturnNotes
    *     description: Delete ReturnNotes
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: returnnote_Id
    *         description: Provide the returnnoteId to delete
    *         required: true
    *         type: integer
    *         in: path
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy : {  
        pre: null,
        process : "returnnote.destroy",
        post: null,
        method: 'DELETE'
    },

    /**
    * @swagger
    * /a/eproc/returnnotes/getReturnNoteAttachment :
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Return Note Attachment
    *     operationId: getReturnNoteAttachment
    *     description: Get Return Note Attachment
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Return Note Attachment
    *         type: string
    *         in: body
    *         schema: 
    *          properties:
    *           returnNoteId:
    *            type: string
    *           requisitionId:
    *            type: string
    *          required: [returnNoteId]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    getReturnNoteAttachment: {
        pre: null,
        process: "returnnote.getReturnNoteAttachment",
        post: null,
        method: 'POST'
    },
}