"use strict";

module.exports = { 

	/**
    * @swagger
    * definitions:
    *   formInstance:
    *       type: object
    *       properties:
    *          formInstanceId:
    *             type: string
    *          formDefinitionId:
    *             type: string
    *          sectionInstances:
    *             type: array
    *             items:
    *               type: object
    *               $ref: '#/definitions/sectionInstances'
    *       required: [formInstanceId,formDefinitionId,sectionInstances,formInstance]
    */

    /**
    * @swagger
    * definitions:
    *   sectionInstances:
    *       properties:
	*         sectionInstanceId:
    *           type: string
	*         sectionDefinitionId:
    *           type: string
    *         fieldInstances:
    *           type: array
    *           items:
    *             type: object
    *             properties:
	*              fieldInstanceId:
	*               type: string
	*              fieldDefinitionId:
    *               type: string
    *              value:
    *               type: array
    *               items: 
    *                type: string
    *              referenceValue:
    *               type: array
    *               items: 
    *                type: string
    */

    /**
    * @swagger
    * /a/eproc/dynamicforms/{dynamicForm_Id}:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update a dynamic form
    *     operationId: updateDynamicform
    *     description: Update a dynamic form
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: dynamicForm_Id
    *         description: Provide a Form ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Update a dynamic form
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           dynamicInstanceId:
    *            type: string
    *           processCode:
    *            type: string
    *           type:
    *            type: integer
    *           formInstance:
    *             $ref: '#/definitions/formInstance'
    *           extraParams:
    *            type: object
    *          required: [dynamicInstanceId,processCode,type,formInstance,extraParams]
    *               
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "dynamicform.update",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/eproc/dynamicforms/getForm:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the Dynamicform Instance
    *     operationId: getDynamicForm
    *     description: Get the Dynamicform Instance
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the Dynamicform Instance.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               dynamicFormId:
    *                 type: string
    *               dynamicInstanceId:
    *                 type: string
    *             required: [dynamicFormId, dynamicFormId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    getForm: {
        pre: null,
        process: "Dynamicform.getForm",
        post: null,
        method: 'POST'
    }    
};