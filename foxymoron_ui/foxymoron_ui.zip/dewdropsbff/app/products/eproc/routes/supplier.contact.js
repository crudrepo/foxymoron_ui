"use strict";

module.exports = {
    /**
    * @swagger
    * /a/eproc/suppliers/{supplier_Id}/contacts/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Supplier's Contact List
    *     operationId: getSupplierContactDetails
    *     description: Fetch a Supplier's Contact List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: supplier_Id
    *         description: Provide a Supplier ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Fetch a Supplier's Contact List.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               addressId:
    *                 type: string
    *               referConfig:
    *                 type: boolean
    *               contactType:
    *                 type: string
    *             required: [referConfig]
    *     responses:
    *       200:
    *         description: successful operation
    */
   getList: {
        pre: null,
        process: "supplierContact.getList",
        post: null,
        method: 'POST'
    }
}