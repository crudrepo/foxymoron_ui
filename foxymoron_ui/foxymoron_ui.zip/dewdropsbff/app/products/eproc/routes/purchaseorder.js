"use strict";

module.exports = {
    /**
     * @swagger
     * /a/eproc/purchaseorders/list:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get Purchase Order List
     *     operationId: purchaseorderList
     *     description: Get Purchase Order List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Provide the purchaseOrder Number.
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *             - type: object
     *               properties:      
     *                 isMapUserInfo:
     *                    type: boolean
     *               required: []    
     *     responses:
     *       200:
     *         description: successful operation
     */
    getList: {
        pre: null,
        process: "purchaseorder.getList",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * /a/eproc/purchaseorders/getAmendList:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get Amended Purchase Order List
     *     operationId: purchaseorderList
     *     description: Get Amended Purchase Order List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Provide the amended purchaseOrders.
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *               required: []    
     *     responses:
     *       200:
     *         description: successful operation
     */
    getAmendList: {
        pre: null,
        process: "purchaseorder.getAmendList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/openpoCount:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Open Purchase Order List
    *     operationId: openpurchaseorderList
    *     description: Get Open Purchase Order List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide the purchaseOrder Number.
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */    
    openpoCount: {
        pre: null,
        process: "purchaseorder.openpoCount",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * /a/eproc/purchaseorders/getPurchaseTypes:
     *   get:
     *     tags:
     *       - Eproc API
     *     summary: Get Purchase Types
     *     operationId: purchaseTypes
     *     description: Get details for purchase types
     *     produces:
     *       - application/json
     *     responses:
     *       200:
     *         description: successful operation
     */
    getPurchaseTypes: {
        pre: null,
        process: "purchaseorder.getPurchaseTypes",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/{purchaseorder_Id}:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get Item Details
    *     operationId: downloadPO
    *     description: Fetch an Item Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: purchaseorder_Id
    *         description: Provide an Item ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "purchaseorder.downloadPurchaseOrder",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/getPONumbers:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the Purchase Order Numbers
    *     operationId: getPONumbers
    *     description: Get the Purchase Order Numbers
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the Purchase Order Numbers.
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *           required: [ids]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    getPONumbers: {
        pre: null,
        process: "purchaseorder.getPONumbers",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/{purchaseorder_Id}/getOrderDetails:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Purchase Order Details
    *     operationId: getPurchaseOrderDetails
    *     description: Fetch Purchase Order Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: purchaseorder_Id
    *         description: Find a Purchase Order Details.
    *         required: true
    *         type: integer
    *         in: path
    *       - name: body
    *         description: Get Requisition Details
    *         in: body
    *         required: true
    *         schema:
    *           required: [entityType, version, requireDependent, requireScopeValidation]
    *           properties:
    *             entityType:
    *               type: string
    *             version:
    *               type: string
    *             useSnapshot:
    *               type: boolean
    *             view:
    *               type: boolean
    *             requireDependent:
    *               type: boolean
    *             requireScopeValidation:
    *               type: boolean
    *             validateByScopeOnly:
    *               type: boolean
    *             buyerDesk:
    *               type: boolean
    *     responses:
    *       200:
    *         description: successful operation
    */
    getOrderDetails: {
        pre: null,
        process: "purchaseorder.getPurchaseOrderDetails",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/getSuggestedPurchaseOrders:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get suggested Purchase Orders
    *     operationId: getSuggestedPurchaseOrders
    *     description: Get suggested Purchase Orders
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get suggested Purchase Orders
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             requisitionIds:
    *               type: array
    *               items:
    *                 type: string
    *             lineItemIds:
    *               type: array
    *               items:
    *                 type: string
    *           required: [requisitionIds, lineItemIds]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    getSuggestedPurchaseOrders: {
        pre: null,
        process: "purchaseorder.getSuggestedPurchaseOrders",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/convertRequisitionToPurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Convert the Requisition to PurchaseOrder
    *     operationId: convertRequisitionToPurchaseOrder
    *     description: Convert the Requisition to PurchaseOrder
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Convert the Requisition to PurchaseOrder
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             doSubmit:
    *               type: boolean
    *             purchaseOrder:
    *               type: array
    *               items:
    *                 type: object
    *                 properties:
    *                   lineItemId:
    *                     type: string
    *                   requisitionId:
    *                     type: string
    *                   modifiedOn:
    *                     type: number
    *                   attachmentId:
    *                     type: array
    *                     items:
    *                       type: string
    *                   attachmentComments:
    *                     type: array
    *                     items:
    *                       type: string
    *                   attachmentVisibility:
    *                     type: array
    *                     items:
    *                       type: string
    *                   notes:
    *                     type: string
    *                   baseCurrency:
    *                     type: string
    *                   baseExchangeRate:
    *                     type: number
    *                   receiptRequiredStatus:
    *                     type: number
    *           required: [doSubmit, purchaseOrder]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    convertRequisitionToPurchaseOrder: {
        pre: null,
        process: "purchaseorder.convertRequisitionToPurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/validatePurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Do validate existing purchase order
    *     operationId: validateExistingPurchaseOrder
    *     description: Do validate existing purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Do validate existing purchase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderId:
    *               type: string
    *             isAmend:
    *               type: boolean
    *           required: [purchaseOrderId]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    validatePurchaseOrder: {
        pre: null,
        process: "purchaseorder.validatePurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/recallPO:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Recall purchase order
    *     operationId: recallPurchaseOrder
    *     description: Recall purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Recall purchase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderId:
    *               type: string
    *             comments:
    *               type: string
    *           required: [purchaseOrderId,comments]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    recallPO: {
        pre: null,
        process: "purchaseorder.recallPO",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/updateEstimatedDeliveryDate:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Update estimated delivery date
    *     operationId: updateEstimatedDeliveryDate
    *     description: Update estimated delivery date of purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update estimated delivery date of purchase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderId:
    *               type: string
    *             estimatedeliveryDate:
    *               type: number
    *             comments:
    *               type: string
    *           required: [purchaseOrderId,estimatedeliveryDate]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    updateEstimatedDeliveryDate: {
        pre: null,
        process: "purchaseorder.updateEstimatedDeliveryDate",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/remindApprover:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Remind purchase order approver
    *     operationId: remindApprover
    *     description: Remind purchase order approver
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Remind purchase order approver
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             approvalId:
    *               type: string
    *             workflowInstanceId:
    *               type: string
    *             approvalLastModifiedOn:
    *               type: string
    *           required: [workflowInstanceId]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    remindApprover: {
        pre: null,
        process: "purchaseorder.remindApprover",
        post: null,
        method: 'POST'
    },

    
    /**
    * @swagger
    * /a/eproc/purchaseorders/{purchaseOrderId}:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Download path and name of purchase order
    *     operationId: download
    *     description: Fetch purchase order file path and name
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: purchaseOrderId
    *         description: provide purchase order ID
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    download: {
        pre: null,
        process: "purchaseorder.download",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/doCancelPurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Cancel purchase order
    *     operationId: doCancelPurchaseOrder
    *     description: Cancel purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Cancel purchase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderId:
    *               type: string
    *             comments:
    *               type: string
    *           required: [purchaseOrderId, comments]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    doCancelPurchaseOrder: {
        pre: null,
        process: "purchaseorder.doCancelPurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/doClosePurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Close purchase order
    *     operationId: doClosePurchaseOrder
    *     description: Close purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Close purchase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderId:
    *               type: string
    *             comments:
    *               type: string
    *             allowInvoice:
    *               type: boolean
    *             blockPayment:
    *               type: boolean
    *           required: [purchaseOrderId]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    doClosePurchaseOrder: {
        pre: null,
        process: "purchaseorder.doClosePurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/{purchaseOrderId}/doDelete:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary: Delete Purchase order
    *     operationId: doDelete
    *     description: Delete Purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: purchaseOrderId
    *         description: Provide the purchaseOrderId to delete
    *         required: true
    *         type: integer
    *         in: path
    *     responses:
    *       200:
    *         description: successful operation
    */
    doDelete : {
        pre: null,
        process : "purchaseorder.doDelete",
        post: null,
        method: 'DELETE'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/doRecallAmendedPurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Recall amended purchase order
    *     operationId: doRecallAmendedPurchaseOrder
    *     description: Recall amended purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Recall amended purchase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderId:
    *               type: string
    *             comments:
    *               type: string
    *           required: [purchaseOrderId, comments]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    doRecallAmendedPurchaseOrder: {
        pre: null,
        process: "purchaseorder.doRecallAmendedPurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/doReleasePurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Release purchase order
    *     operationId: doReleasePurchaseOrder
    *     description: Release purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Release purchase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderId:
    *               type: string
    *           required: [purchaseOrderId]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    doReleasePurchaseOrder: {
        pre: null,
        process: "purchaseorder.doReleasePurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * definitions:
    *   purchaseOrder:
    *    type: object
    *    properties:
    *      purchaseOrderId:
    *        type: string
    *      parentPurchaseOrderId:
    *        type: string
    *      name:
    *        type: string
    *      purchaseOrderNumber:
    *        type: string
    *      type:
    *        type: number
    *      notes:
    *        type: string
    *      companyCode:
    *        type: string
    *      businessUnitCode:
    *        type: string
    *      locationCode:
    *        type: string
    *      billToCode:
    *        type: string
    *      invoiceToCode:
    *        type: string
    *      baseCurrency:
    *        type: string
    *      baseExchangeRate:
    *        type: number
    *      purchaseType:
    *        type: string
    *      purchaseTypeCode:
    *        type: string
    *      splitCostingLevel:
    *        type: number
    *      splitCostingType:
    *        type: number
    *      shipToCodeType:
    *        type: number
    *      shipToCode:
    *        type: string
    *      shipToLocation:
    *        type: string
    *      deliverToType:
    *        type: number
    *      deliveryTo:
    *        type: string
    *      project:
    *        type: string
    *      requireReceipt:
    *        type: boolean
    *      statusComments:
    *        type: string
    *      assignProject:
    *        type: boolean
    *      projectSettingStatus:
    *        type: string
    *      assetCodeSetting:
    *        type: boolean
    *      purchaseTypeSetting:
    *        type: boolean
    *      purchaseTypeAtLineLevel:
    *        type: boolean
    *      ptGLAccountSetting:
    *        type: boolean
    *      receiptRequiredLevel:
    *        type: number
    *      receiptRequiredStatus:
    *        type: number
    *      releaseNumber:
    *        type: number
    *      invoiceUntilDate:
    *        type: number
    *      orderAuthorizationType:
    *        type: string
    *      totalOrderValue:
    *        type: number
    *      consumedOrderValue:
    *        type: number
    *      validityFrom:
    *        type: number
    *      validityTo:
    *        type: number
    *      sendPOToSupplier:
    *        type: boolean
    *      hideBpoValueSettingUserDecide:
    *        type: boolean
    *      autoUpdate:
    *        type: boolean
    *      settingsMapString:
    *        type: string
    *      applyNoTaxes:
    *        type: boolean
    *      supplierId:
    *        type: string
    *      suppAddressId:
    *        type: string
    *      suppCurrency:
    *        type: string
    *      paymentTermId:
    *        type: string
    *      suppPOContact:
    *        type: string
    *      suppPOContactEmail:
    *        type: string
    *      supplierPOContactType:
    *        type: number
    *      deliveryTermCode:
    *        type: string
    *      supplierName:
    *        type: string
    *      supplierERPId:
    *        type: string
    *      quotationNo:
    *        type: string
    *      discountLevel:
    *        type: number
    *      discountType:
    *        type: number
    *      discountValue:
    *        type: number
    *      freightCharges:
    *        type: number
    *      checkoutBuyer:
    *        type: string
    *      termsAndConditions:
    *        type: string
    *      requester:
    *        type: string
    *      requesterEmailId:
    *        type: string
    *      workflowId:
    *        type: string
    *      workflowInstanceId:
    *        type: string
    *      deliverOn:
    *        type: number
    *      utilizeBudget:
    *        type: boolean
    *      attachmentIds:
    *        type: array
    *        items:
    *          type: string
    *      processEformId:
    *        type: string
    *      dynamicFormId:
    *        type: string
    *      dynamicInstanceId:
    *        type: string
    *      flexibleAccountingFormId:
    *        type: string
    *      flexibleAccountingInstanceId:
    *        type: string
    *      flexibleAccountingVersion:
    *        type: number
    *      paymentMethod:
    *        type: number
    *      paymentId:
    *        type: string
    *      paymentTransactionId:
    *        type: string
    *      retrospectivePurchase:
    *        type: boolean
    *      retrospectiveSendPOSupplier:
    *        type: boolean
    *      retrospectiveLetUserDecide:
    *        type: boolean
    *      allowedBackdateDays:
    *        type: number
    *      sendToReadyForApproval:
    *        type: boolean
    *      version:
    *        type: number
    *      totalAmount:
    *        type: number
    *      freightTaxAmount:
    *        type: number
    *      supplierComments:
    *        type: string
    *      taxAmount:
    *        type: number
    *      modifiedOn:
    *        type: number
    */

    /**
    * @swagger
    * definitions:
    *   purchaseOrderItems:
    *    type: array
    *    items:
    *     type: object
    *     properties:
    *      lineNo:
    *        type: number
    *      lineItemId:
    *        type: string
    *      parentLineItemId:
    *        type: string
    *      itemSource:
    *        type: number
    *      itemType:
    *        type: number
    *      attachmentIds:
    *        type: array
    *        items:
    *         type: string  
    *      itemId:
    *        type: string
    *      itemQuantity:
    *        type: number
    *      marketPrice:
    *        type: number
    *      discountType:
    *        type: number
    *      discountValue:
    *        type: number
    *      itemPrice:
    *        type: number
    *      itemTaxes:
    *        type: array
    *        items:
    *          type: object 
    *          properties:
    *           type:
    *             type: string
    *           name:
    *             type: string
    *           rate:
    *             type: number
    *           compound:
    *             type: boolean
    *      itemTaxPrice:
    *        type: number
    *      itemTotalPrice:
    *        type: number
    *      requisitionId:
    *        type: string
    *      requisitionLineNo:
    *        type: number
    *      internalComment:
    *        type: string
    *      supplierComment:
    *        type: string
    *      splitCostingType:
    *        type: number
    *      purchaseType:
    *        type: string
    *      purchaseTypeCode:
    *        type: string
    *      consumedTotalPrice:
    *        type: number
    *      consumedQuantity:
    *        type: number
    *      allowedTotalPrice:
    *        type: number
    *      maxUnitPrice:
    *        type: number
    *      allowedTotalQuantity:
    *        type: number
    *      deliveryOn:
    *        type: number
    *      deliveryUpto:
    *        type: number
    *      assetCode:
    *        type: string
    *      assetCodeType:
    *        type: number
    *      applyNoTaxes:
    *        type: boolean
    *      contractNo:
    *        type: string
    *      contractId:
    *        type: string
    *      contractType:
    *        type: number
    *      processEformId:
    *        type: string
    *      dynamicInstanceId:
    *        type: string
    *      dynamicInstanceVersion:
    *        type: number
    *      flexibleAccountingFormId:
    *        type: string
    *      flexibleAccountingInstanceId:
    *        type: string
    *      flexibleAccountingVersion:
    *        type: number
    *      requester:
    *        type: string
    *      receiptRequiredStatus:
    *        type: number
    *      addedOn:
    *        type: number
    *      deliverToType:
    *        type: number
    *      deliverTo:
    *        type: string
    *      shipToCodeType:
    *        type: number
    *      shipToCode:
    *        type: string
    *      shipToLocation:
    *        type: string
    */

    /**
    * @swagger
    * definitions:
    *   PoItems:
    *    type: array
    *    items:
    *     type: object
    *     properties:
    *      supplierPartId:
    *        type: string
    *      name:
    *        type: string
    *      itemId:
    *        type: string
    *      uom:
    *        type: string
    *      itemType:
    *        type: number
    *      receiptType:
    *        type: number
    *      description:
    *        type: string
    *      currency:
    *        type: string
    *      price:
    *        type: number
    *      marketPrice:
    *        type: number
    *      manufacturerName:
    *        type: string
    *      manufacturerProductURL:
    *        type: string
    *      manufacturerPartId:
    *        type: string
    *      supplierProductURL:
    *        type: string
    *      imageURL:
    *        type: string
    *      categoryCode:
    *        type: string
    *      categoryName:
    *        type: string
    *      unsspscCode:
    *        type: string
    *      unsspscName:
    *        type: string
    *      greenItem:
    *        type: boolean
    *      preferredItem:
    *        type: boolean
    *      attachments:
    *        type: array
    *        items:
    *         type: string
    *      itemAttributes:
    *        type: object
    *      contractNo:
    *        type: string
    *      contractId:
    *        type: string
    *      externalId:
    *        type: string
    *      supplierId:
    *        type: string
    */

    /**
    * @swagger
    * definitions:
    *   purchaseOrderCostings:
    *    type: array
    *    items:
    *     type: object
    *     properties:
    *      lineItemId:
    *        type: string
    *      businessUnitCode:
    *        type: string
    *      costCenterCode:
    *        type: string
    *      value:
    *        type: number
    *      budgetId:
    *        type: string
    *      budgetLineId:
    *        type: string
    *      budgetLineTransactionId:
    *        type: string
    *      projectCode:
    *        type: string
    *      splitValue:
    *        type: number
    *      purchaseOrderId:
    *        type: string
    */

    /**
    * @swagger
    * definitions:
    *   purchaseOrderAccountings:
    *    type: array
    *    items:
    *     type: object
    *     properties:
    *      lineItemId:
    *        type: string
    *      accountTypeCode:
    *        type: string
    *      generalLedgerCode:
    *        type: string
    *      value:
    *        type: number
    */

    /**
    * @swagger
    * definitions:
    *   purchaseOrderTaxes:
    *    type: array
    *    items:
    *     type: object
    *     properties:
    *      type:
    *        type: string
    *      name:
    *        type: string
    *      rate:
    *        type: number
    *      compound:
    *        type: boolean
    *      applicableFor:
    *        type: number
    */

    /**
    * @swagger
    * definitions:
    *   attachmentsDetails:
    *    type: array
    *    items:
    *     type: object
    *     properties:
    *      attachmentId:
    *        type: string
    *      comments:
    *        type: string
    *      visibility:
    *        type: number
    */

    /**
    * @swagger
    * /a/eproc/purchaseorders/updatePurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Update purchase order details
    *     operationId: updatePurchaseOrderDetails
    *     description: Update the purchase order details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update the purchase order details
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             submit:
    *               type: boolean
    *             purchaseOrder:
    *               $ref: '#/definitions/purchaseOrder'
    *             purchaseOrderItems:
    *               $ref: '#/definitions/purchaseOrderItems'
    *             items:
    *               $ref: '#/definitions/PoItems'
    *             purchaseOrderCostings:
    *               $ref: '#/definitions/purchaseOrderCostings'
    *             purchaseOrderAccountings:
    *               $ref: '#/definitions/purchaseOrderAccountings'
    *             purchaseOrderTaxes:
    *               $ref: '#/definitions/purchaseOrderTaxes'
    *             attachmentsDetails:
    *               $ref: '#/definitions/attachmentsDetails'
    *           required: [submit, purchaseOrder, purchaseOrderItems, items, purchaseOrderAccountings, purchaseOrderTaxes]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    updatePurchaseOrder: {
        pre: null,
        process: "purchaseorder.updatePurchaseOrder",
        post: null,
        method: 'POST'
    },

     /**
    * @swagger
    * /a/eproc/purchaseorders/doReopenPurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Reopen purchase order
    *     operationId: doReopenPurchaseOrder
    *     description: Reopen the closed purchase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Reopen the closed purchase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderId:
    *               type: string
    *             comments:
    *               type: string
    *           required: [purchaseOrderId]
    *     responses:
    *       200:
    *         description: successful operation
    */    
   doReopenPurchaseOrder: {
        pre: null,
        process: "purchaseorder.doReopenPurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/purchaseorders/doValidatePurchaseOrderDetails:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Validate purchase order details
    *     operationId: doValidatePurchaseOrderDetails
    *     description: Validate the purchase order details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Validate the purchase order details
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             purchaseOrderDetails:
    *               type: object
    *               properties:
    *                 submit:
    *                   type: boolean
    *                 isAmend:
    *                   type: boolean
    *                 purchaseOrder:
    *                   $ref: '#/definitions/purchaseOrder'
    *                 purchaseOrderItems:
    *                   $ref: '#/definitions/purchaseOrderItems'
    *                 purchaseOrderCostings:
    *                   $ref: '#/definitions/purchaseOrderCostings'
    *                 purchaseOrderAccountings:
    *                   $ref: '#/definitions/purchaseOrderAccountings'
    *                 purchaseOrderTaxes:
    *                   $ref: '#/definitions/purchaseOrderTaxes'
    *                 items:
    *                   $ref: '#/definitions/PoItems'
    *                 attachmentsDetails:
    *                   $ref: '#/definitions/attachmentsDetails'
    *                 supportObjects:
    *                   type: object
    *                   properties:
    *                     items:
    *                      type: object
    *     responses:
    *       200:
    *         description: successful operation
    */    
    doValidatePurchaseOrderDetails: {
        pre: null,
        process: "purchaseorder.doValidatePurchaseOrderDetails",
        post: null,
        method: 'POST'
    },

    /**                     
    * @swagger
    * /a/eproc/purchaseorders/doEmailPurchaseOrderToSupplier:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      EmailPurchaseOrder to the Supplier
    *     operationId:  emailPurchaseOrderToSupplier
    *     description:  EmailPurchaseOrder to the Supplier
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: EmailPurchaseOrder to the Supplier
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           purchaseOrderId:
    *            type: string
    *           roleType:
    *            type: string
    *           comments:
    *            type: string
    *          required: [purchaseOrderId, roleType]
    *     responses:
    *       200:
    *         description: successful operation
    */
    doEmailPurchaseOrderToSupplier: {
        pre: null,
        process: "purchaseorder.doEmailPurchaseOrderToSupplier",
        post: null,
        method: 'POST'
    },

    /**                     
    * @swagger
    * /a/eproc/purchaseorders/doEmailPurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      EmailPurchaseOrder 
    *     operationId:  emailPurchaseOrder
    *     description:  EmailPurchaseOrder 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: EmailPurchaseOrder 
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           purchaseOrderId:
    *            type: string
    *           message:
    *            type: string
    *           requireCopy:
    *            type: boolean
    *           to:
    *            type: array
    *            items:
    *             type: string
    *           requireAttachment:
    *            type: boolean
    *           attachmentIds:
    *            type: array
    *            items:
    *             type: string
    *           attachmentNames:
    *            type: array
    *            items:
    *             type: string
    *          required: [purchaseOrderId, message, to]
    *     responses:
    *       200:
    *         description: successful operation
    */
    doEmailPurchaseOrder: {
        pre: null,
        process: "purchaseorder.doEmailPurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**                     
    * @swagger
    * /a/eproc/purchaseorders/isPOEmailToSupplierActionAllowed:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      Email to supplier Action allowed
    *     operationId:  isPOEmailToSupplierActionAllowed
    *     description:  Email to supplier Action allowed
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Email to supplier Action allowed
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           purchaseOrderId:
    *            type: string
    *           roleType:
    *            type: string
    *          required: [purchaseOrderId, roleType]
    *     responses:
    *       200:
    *         description: successful operation
    */
   isPOEmailToSupplierActionAllowed: {
        pre: null,
        process: "purchaseorder.isPOEmailToSupplierActionAllowed",
        post: null,
        method: 'POST'
   },

   /**                     
    * @swagger
    * /a/eproc/purchaseorders/{purchaseOrder_Id}/isPurchaseOrderAmendable:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary:      Purchase Order Amendable 
    *     operationId:  isPurchaseOrderAmendable
    *     description:  Purchase Order Amendable 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: purchaseOrder_Id
    *         description: Provide the purchase order id
    *         required: true
    *         type: string
    *         in: path
    *       
    *     responses:
    *       200:
    *         description: successful operation
    */
   isPurchaseOrderAmendable: {
        pre: null,
        process: "purchaseorder.isPurchaseOrderAmendable",
        post: null,
        method: 'GET'
    },

    //TODO: we will update swagger request defination for preview purchase order.
    /**
    * @swagger
    * /a/eproc/purchaseorders/previewPurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get purchase order preview
    *     operationId: previewPurchaseOrder
    *     description: Get purchase order preview
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get purchase order preview
    *         type: string
    *         in: body
    *         schema: 
    *     responses:
    *       200:
    *         description: successful operation
    */
   previewPurchaseOrder: {
        pre: null,
        process: "purchaseorder.previewPurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**                     
    * @swagger
    * /a/eproc/purchaseorders/getTransactionHistoryForItem:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      Transaction history for item
    *     operationId:  getTransactionHistoryForItem
    *     description:  Transaction history for item
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Transaction history for item
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           purchaseOrderId:
    *            type: string
    *           lineItemId:
    *            type: string
    *           inventoryOrderExternalId:
    *            type: string
    *          required: [lineItemId]
    *     responses:
    *       200:
    *         description: successful operation
    */
   getTransactionHistoryForItem: {
        pre: null,
        process: "purchaseorder.getTransactionHistoryForItem",
        post: null,
        method: 'POST'
   },

       /**                     
    * @swagger
    * /a/eproc/purchaseorders/getAmendPODetails:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      Get purchaseOrder details for Amend
    *     operationId:  getAmendPODetails
    *     description:  Get purchaseOrder details for Amend
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get purchaseOrder details for Amend
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           entityType:
    *            type: string
    *           entityId:
    *            type: string
    *           version:
    *            type: number
    *           requireDependent:
    *            type: boolean
    *           useSnapshot:
    *            type: boolean
    *           view:
    *            type: boolean
    *           requireScopeValidation:
    *            type: boolean
    *           emailAddress:
    *            type: string
    *          required: [entityType, entityId]
    *     responses:
    *       200:
    *         description: successful operation
    */
   getAmendPODetails: {
        pre: null,
        process: "purchaseorder.getAmendPODetails",
        post: null,
        method: 'POST'
   },

    /**                     
    * @swagger
    * /a/eproc/purchaseorders/{purchaseorder_Id}/isAmendPurchaseOrderWorkflowRequired:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      Check whether AmendPO required workflow or not
    *     operationId:  isAmendPurchaseOrderWorkflowRequired
    *     description:  Check whether AmendPO required workflow or not
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: purchaseorder_Id
    *         description: Provide a Purchase Order Id.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Check whether AmendPO required workflow or not
    *         in: body
    *         required: true
    *         schema:
    *          properties:   
    *           amendedGrossTotalAmount:
    *            type: number
    *           amendedSupplierCurrency:
    *            type: string
    *          required: [amendedGrossTotalAmount, amendedSupplierCurrency]
    *     responses:
    *       200:
    *         description: successful operation
    */
   isAmendPurchaseOrderWorkflowRequired: {
    pre: null,
    process: "purchaseorder.isAmendPurchaseOrderWorkflowRequired",
    post: null,
    method: 'POST'
   },

   /**
    * @swagger
    * /a/eproc/purchaseorders/doAmendPurchaseOrderDetails:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Amend purhcase order
    *     operationId: doAmendPurchaseOrderDetails
    *     description: Amend purhcase order
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Amend purhcase order
    *         type: string
    *         in: body
    *         schema: 
    *           properties:
    *             submit:
    *               type: boolean
    *             amend:
    *               type: boolean
    *             purchaseOrderDetails:
    *               type: object
    *               properties:
    *                 purchaseOrder:
    *                   $ref: '#/definitions/purchaseOrder'
    *                 purchaseOrderItems:
    *                   $ref: '#/definitions/purchaseOrderItems'
    *                 items:
    *                   $ref: '#/definitions/PoItems'
    *                 purchaseOrderCostings:
    *                   $ref: '#/definitions/purchaseOrderCostings'
    *                 purchaseOrderAccountings:
    *                   $ref: '#/definitions/purchaseOrderAccountings'
    *                 purchaseOrderTaxes:
    *                   $ref: '#/definitions/purchaseOrderTaxes'
    *                 attachmentsDetails:
    *                   $ref: '#/definitions/attachmentsDetails'
    *                 submit:
    *                   type: boolean
    *           required: [submit, purchaseOrder, purchaseOrderItems, items, purchaseOrderAccountings, purchaseOrderTaxes]
    *     responses:
    *       200:
    *         description: successful operation
    */    
   doAmendPurchaseOrderDetails: {
    pre: null,
    process: "purchaseorder.doAmendPurchaseOrderDetails",
    post: null,
    method: 'POST'
   },
   
   /**                     
    * @swagger
    * /a/eproc/purchaseorders/removeEntitySnapshot:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary:      Remove Entity Snapshot
    *     operationId:  removeEntitySnapshot
    *     description:  Remove Entity Snapshot
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Remove Entity Snapshot
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           entityId:
    *            type: string
    *           entityType:
    *            type: string
    *          required: [entityId, entityType]
    *     responses:
    *       200:
    *         description: successful operation
    */
   removeEntitySnapshot: {
    pre: null,
    process: "purchaseorder.removeEntitySnapshot",
    post: null,
    method: 'DELETE'
   },

      /**                     
    * @swagger
    * /a/eproc/purchaseorders/addReqItemsToPOAmendment:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      add Requisition Items To PO Amendment
    *     operationId:  addReqItemsToPOAmendment
    *     description:  add Requisition Items To PO Amendment
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: add Requisition Items To PO Amendment
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           emailAddress:
    *            type: string
    *           groupId:
    *            type: string
    *           requisitionId:
    *            type: string
    *          required: [requisitionId]
    *     responses:
    *       200:
    *         description: successful operation
    */
   addReqItemsToPOAmendment: {
    pre: null,
    process: "purchaseorder.addReqItemsToPOAmendment",
    post: null,
    method: 'POST'
   },
    /**                     
    * @swagger
    * /a/eproc/purchaseOrder/doSubmitPurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      Submit PurchaseOrder
    *     operationId:  doSubmitPurchaseOrder
    *     description:  Submit PO by purchaseOrderId
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Submit PO by purchaseOrderId
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           purchaseOrderId:
    *            type: string
    *          required: [purchaseOrderId]
    *     responses:
    *       200:
    *         description: successful operation
    */
   doSubmitPurchaseOrder: {
        pre: null,
        process: "purchaseorder.doSubmitPurchaseOrder",
        post: null,
        method: 'POST'
    },

    /**                     
    * @swagger
    * /a/eproc/purchaseOrder/doModifyPurchaseOrder:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary:      Modify PurchaseOrder
    *     operationId:  doModifyPurchaseOrder
    *     description:  Modify PurchaseOrder with workflwoInstanceId
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Modify PurchaseOrder with workflwoInstanceId
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           purchaseOrderId:
    *            type: string
    *           workflowInstanceId:
    *            type: string
    *          required: [purchaseOrderId,workflowInstanceId]
    *     responses:
    *       200:
    *         description: successful operation
    */
   doModifyPurchaseOrder: {
    pre: null,
    process: "purchaseorder.doModifyPurchaseOrder",
    post: null,
    method: 'POST'
}
};