"use strict";

module.exports = {
    /**
    * @swagger
    * /a/eproc/baskets/{basket_Id}/items:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update Basket Item
    *     operationId: updateBasketItem
    *     description: Update Basket Item
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: basket_Id 
    *         description: Provide a Basket Id.
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: Update Basket Item
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               itemQuantityList:
    *                 type: array
    *                 items:
    *                   type: object
    *                   properties:
    *                       itemId:
    *                           type: string
    *                       itemQuantity:
    *                           type: number
    *               removingItemIDs:
    *                 type: array 
    *                 items:
    *                   type: string
    *     required: [basketId, addingItemIDs, itemQuantity, removingItemIDs] 
    *     responses:
    *       200:
    *         description: successful operation
    */

    update:{
        pre: null,
        process: "basketItem.update",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/eproc/baskets/{basket_Id}/items:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary: Delete the Basket items
    *     operationId: deleteBasketItems
    *     description: Delete the Basket items
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: basket_Id
    *         description: Provide the basketId
    *         required: true
    *         type: integer
    *         in: path
    *       - name: body
    *         description: Post the item ID(s).
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               itemIds:
    *                 type: array
    *                 items:
    *                   type: string
    *           required: [itemIds]
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy : {  
        pre: null,
        process : "basketItem.delBasketItems",
        post: null,
        method: 'DELETE'
    }
}