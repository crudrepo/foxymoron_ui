"use strict";

module.exports = {

    /**
    * @swagger
    * /a/eproc/buyers/assignBuyers:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: search users
    *     operationId: searchUsers
    *     description: Sarch users(buyers) to assign
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the users(based on name or emailId).
    *         in: body
    *         schema:
    *           properties:
    *             name: 
    *               type: string
    *             perPageRecords:
    *               type: integer
    *             pageNo:
    *               type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    assignBuyers: {
        pre: null,
        process: "buyer.assignBuyers",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/buyers/assignBuyerGroups:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: search users groups
    *     operationId: searchUserGroups
    *     description: Sarch userGroups(buyerGroups) to assign
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the userGroups(based on name or emailId).
    *         in: body
    *         schema:
    *           properties:
    *             name: 
    *               type: string
    *             perPageRecords:
    *               type: integer
    *             pageNo:
    *               type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    assignBuyerGroups: {
        pre: null,
        process: "buyer.assignBuyerGroups",
        post: null,
        method: 'POST'
    }

}