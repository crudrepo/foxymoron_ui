
"use strict";

module.exports = {    
    // /**
    //  * @swagger
    //  * /a/eproc/suppliers/websitesList:
    //  *   post:
    //  *     tags:
    //  *       - Eproc API
    //  *     summary: Get Suppliers Websites
    //  *     operationId: getWebsitesList
    //  *     description: Fetch all Websites of Suppliers
    //  *     produces:
    //  *       - application/json
    //  *     parameters:
    //  *       - name: body
    //  *         description: Find name or Provide page no to get records.
    //  *         in: body
    //  *         schema:
    //  *           $ref: '#/definitions/findRecord'
    //  *     responses:
    //  *       200:
    //  *         description: successful operation
    //  */
   /* websitesList: {
        pre: null,
        process: "supplier.getWebsitesList",
        post: null
    } */  
    
        /**
    * @swagger
    * /a/eproc/suppliers/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Search suppliers
    *     operationId: searchSuppliers
    *     description: Search suppliers
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search for suppliers ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "supplier.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/suppliers/addUpdateSuggestedSupplier:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add or Update suppliers
    *     operationId: addupdateSuppliers
    *     description: Add or Update suppliers
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add or Update suppliers.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               suggestedSupplierId:
    *                 type: string
    *               name:
    *                 type: string
    *             required: [name]
    *     responses:
    *       200:
    *         description: successful operation
    */
    addUpdateSuggestedSupplier: {
        pre: null,
        process: "supplier.addUpdateSuggestedSupplier",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/suppliers/updatedSuppliers:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get list of Updated Suppliers
    *     operationId: updatedSuppliers
    *     description: Get list of Updated Suppliers
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: This api is use to get Updated Suppliers.
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *           required: [ids]
    *     responses:
    *       200:
    *         description: successful operation
    */
   updatedSuppliers: {
    pre: null,
    process: "supplier.updatedSuppliers",
    post: null,
    method: 'POST'
  }
};