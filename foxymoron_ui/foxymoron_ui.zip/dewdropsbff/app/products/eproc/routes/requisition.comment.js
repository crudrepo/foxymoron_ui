"use strict";
module.exports = { 
    /**
    * @swagger
    * /a/eproc/requisitions/{requisition_Id}/comments:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Fetch the requisition comments
    *     operationId: getRequisitionComment
    *     description: Fetch the requisition comments
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requisition_Id
    *         description: Provide requisition ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getRecords: {
        pre: null,
        process: "requisitionComment.fetchComments",
        post: null,
        method: 'GET'
    },

    /**
     * @swagger
     * definitions:
     *   postComments:
     *     required : [comment]
     *     properties:
     *       comment:
     *         type: string
     */

    /**
    * @swagger
    * /a/eproc/requisitions/{requisition_Id}/comments:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Create a Comment
    *     operationId: createRequisitionComment
    *     description: Post the comment for a requisition.
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requisition_Id
    *         description: Provide requisition ID.
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: Post a requisition comments.
    *         in: body
    *         required: true
    *         schema:
    *           type: object
    *           $ref: '#/definitions/postComments'
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "requisitionComment.createComment",
        post: null,
        method: 'POST'
    }    
};