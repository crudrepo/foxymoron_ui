/**
 * User Controller
 *
 * @description :: Provides user related crud operations
 */

"use strict";

module.exports = (parentClass) => {
    class User extends parentClass {
        /**
        * @Name : getDeliveryUsers
        * @Description : It is used for fetching deliveryTo user list
        * @param1 : request
        * @param2 : input
        * @param3 : callback  
        * @return : object / Throw Error
        */

        getDeliveryUsers(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                        http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = eProcURL + '/user/deliveryScope/filter';

                    http.post(url, 'getDeliveryUsers', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "userId": { "type": "string" }, "type": { "type": "number" }, "emailId": { "type": "string" }, "displayName": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "designation": { "type": "string" }, "department": { "type": "string" }, "currency": { "type": "currency" }, "numberFormat": { "type": "string" }, "fomattedNumberFormat": { "type": "string" }, "dateFormat": { "type": "string" }, "timeFormat": { "type": "string" }, "salutation": { "type": "string" }, "locale": { "type": "string" }, "timeZone": { "type": "string" }, "decimalPrecision": { "type": "number" }, "reportingManagerId": { "type": "string" }, "active": { "type": "boolean" }, "erpId": { "type": "string" } } } } };

                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : getDetails
        *
        * @Description : Display the deliveryTo user Details
        * @return object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                    "user_Id": "joi.string().required().label('eproc-lable-22__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({ "user_Id": request.params.user_Id });
                if (result) {
                    let errorMsg = new (super.customError)(result, 'ValidationError', 6);
                    callback(errorMsg, null);
                } else {
                    const tms = new (super.tmsHook({request: request}))();
                    tms.getUsers(request, request.params.user_Id, (error, request, response) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            if (response.length === 0) {
                                return callback(null, request, { data: {}, message: "eproc-error-9" });
                            } else {
                                const responseSchema = { "type": "object", "properties": { "userId": { "type": "string" }, "emailId": { "type": "string" }, "displayName": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "designation": { "type": "string" }, "department": { "type": "string" }, "active": { "type": "boolean" }, "tenantId": { "type": "string" }, "erpId": { "type": "string" } } };
                                const output = (new (super.responseHandler)(request, { "data": response[0] }, responseSchema));
                                return callback(null, request, output.execute());
                            }
                        }
                    });
                    /*const eProcURL = request.productsURL.eProc["web"]
                    const http = new (super.httpTmsService)(request);
                    const url = eProcURL +
                        '?responseType=json' +
                        '&tenantId=' + request.user.tenantId +
                        '&scopeName=eProcjQuery' +
                        '&userName=' + request.user.displayName +
                        '&userId=' + request.params.user_Id +
                        '&tokenId=' + request.tokenId +
                        '&emailAddress=' + request.user.emailId +
                        '&method=master.authority.user.getUsers' +
                        '&tenantUserId=' + request.params.user_Id +
                        '&requireUserPreferences=1';
                    http.get(url, 'deliveryToUserDetails', (error, response) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const keyName = (Object.keys(response.result).length == 1) ? Object.keys(response.result)[0] : null;
                            if (super.lodash.isEmpty(keyName)) {
                                return callback(null, request, { data: {}, message: "eproc-error-9" });
                            }
                            const responseSchema = { "type": "object", "properties": { "userId": { "type": "string" }, "emailId": { "type": "string" }, "displayName": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "designation": { "type": "string" }, "department": { "type": "string" }, "active": { "type": "boolean" }, "tenantId": { "type": "string" }, "erpId": { "type": "string" } } };
                            const output = (new (super.responseHandler)(request, { "data": response.result[keyName] }, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });*/
                }
            } catch (error) {
                callback(error, null);
            }
        };


        /**
        * @Method Name : getScope
        * @Description : Get the user scope details
        * @return object / Throw Error
        */
        getScope(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                    "user_Id": "joi.required().label('eproc-lable-212__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({ "user_Id": request.params.user_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const eprocHook = new (super.eprocHook({request: request}))();
                    eprocHook.getUserScope(request, input, (error, request, response) => {
                        if (error) {
                            return callback(error, null);
                        } else if (response) {
                            return callback(null, request, response);
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };



        /**
         * Function to fetch buying units information based on user prefrence
         * @param {*} request 
         * @param {*} input 
         * @param {*} callback 
         */
        getBuyingUnit(request, input, callback) {
            try {
                let userScope = {};
                let output = {
                    company: {},
                    businessUnit: {},
                    location: {}
                };
                const cmd = new (super.cmdHook({request: request}))();
                const tasks = [
                    (callback) => {
                        //Step 1 : Call TMS Get Prefrence API
                        const eprocHook = new (super.eprocHook({request: request}))();
                        eprocHook.getUserScope(request, null, callback);
                    },
                    (request, input, callback) => {
                        //Step 2 : Filter User Scope Data        
                        userScope = super.lodash.pick(input.data, 'companyCode', 'businessUnitCode', 'locationCode');
                        //Step 3(a): If location code is not avaibale, move to next task
                        if (super.lodash.isEmpty(userScope.locationCode)) return callback(null, { data: { result: [] } });
                        //Step 3(b): Get Location info from CMD API                        
                        const requestData = {
                            "code": userScope.locationCode,
                            "isActive": ""
                        };
                        cmd.getLocation(request, requestData, callback);
                    },
                    (request, input, callback) => {
                        //Step 4 : Filter out location data
                        if (!super.lodash.isEmpty(input.data.result) && super.lodash.isArray(input.data.result)) {
                            output.location = super.lodash.pick(input.data.result[0], 'name', 'code', 'active', 'shipToCode', 'billToCode', 'invoiceToCode');
                            output.location.status = output.location.active;
                            delete output.location.active;
                        }
                        //Step 5(a): If location code is not avaibale, move to next task
                        if (super.lodash.isEmpty(userScope.companyCode)) return callback(null, { data: { result: [] } });
                        //Step 5(b) : Get Company info from CMD API
                        const requestData = {
                            "code": userScope.companyCode,
                            "isActive": ""
                        };
                        cmd.getCompany(request, requestData, callback);
                    },
                    (request, input, callback) => {
                        //Step 6 : Filter out Company data
                        if (!super.lodash.isEmpty(input.data.result) && super.lodash.isArray(input.data.result)) {
                            output.company = super.lodash.pick(input.data.result[0], 'name', 'code', 'active');
                            output.company.status = output.company.active;
                            delete output.company.active;
                        }
                        //Step 7(a): If location code is not avaibale, move to next task
                        if (super.lodash.isEmpty(userScope.businessUnitCode)) return callback(null, { data: { result: [] } });
                        //Step 7(b) : Get Business Unit info from CMD API
                        const requestData = {
                            "code": userScope.businessUnitCode,
                            "isActive": ""
                        };
                        cmd.getBusinessUnit(request, requestData, callback);
                    }
                ];
                super.async.waterfall(tasks, (err, req, response) => {
                    if (err) {
                        return callback(err, null);
                    }
                    else {
                        //Step 8 : Filter out Business Unit info
                        if (!super.lodash.isEmpty(response.data.result) && super.lodash.isArray(response.data.result)) {
                            output.businessUnit = super.lodash.pick(response.data.result[0], 'name', 'code', 'active');
                            output.businessUnit.status = output.businessUnit.active;
                            delete output.businessUnit.active;
                        }
                        //Step 9 : Send response to callback
                        return callback(null, req, { "data": output });
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }


        /**
        * @Name : getDefaultAddress
        * @Description : It is used for fetching default address list
        * @param1 locationCode  
        * @return : object
        */
        getDefaultAddress(request, input, callback) {
            try {
                const tasks = [
                    (methodCallback) => {
                        //Step 1 : Call TMS getUserScope API to get location code.
                        const eprocHook = new (super.eprocHook({request: request}))();
                        eprocHook.getUserScope(request, {}, methodCallback);
                    },
                    (request, input, methodCallback) => {
                        //Step 2: check if location code is available                          
                        if (!super.lodash.isEmpty(input.data) && input.data.locationCode !== "") {
                            const data = { "code": input.data.locationCode, "isActive": "" },
                                cmd = new (super.cmdHook({request: request}))();
                            //Step 3: Call getLocation method from CMD API                      
                            cmd.getLocation(request, data, methodCallback);
                        } else {
                            return methodCallback(null, request, null);
                        }
                    },
                    (request, input, methodCallback) => {
                        //Step 4: check if input is not empty                                                                                                                   
                        if (!super.lodash.isEmpty(input) && super.lodash.isObject(input)) {
                            const result = input.data.result[0],
                                data = {
                                    "shipToCode": result.shipToCode,
                                    "billToCode": result.billToCode,
                                    "invoiceToCode": result.invoiceToCode
                                },
                                cmd = new (super.cmdHook({request: request}))();
                            //Step 5 : Call getAllAddress method from CMD API
                            cmd.getAllAddress(request, data, methodCallback);
                        } else {
                            return methodCallback(null, request, { data: null });
                        }
                    }
                ];
                super.async.waterfall(tasks, (err, request, response) => {
                    if (err) {
                        return callback(err, null);
                    } else {
                        //Step 6 : Filter out get address data                           
                        if (!super.lodash.isEmpty(response.data) && super.lodash.isObject(response.data) && !super.lodash.isEmpty(response.data.result)) {
                            const responseSchema = { "type": "object", "properties": { "shipToCode": { "type": "object", "properties": { "code": { "type": "string" }, "name": { "type": "string" }, "line1": { "type": "string", "key": "street1" }, "line2": { "type": "string", "key": "street2" }, "city": { "type": "string" }, "county": { "type": "string" }, "state": { "type": "object", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "isoCode": { "type": "string" } } }, "zip": { "type": "string" }, "country": { "type": "object", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "isoCode": { "type": "string" } } }, "phone": { "type": "string" }, "fax": { "type": "string" }, "email": { "type": "string" }, "warehouseAddress": { "type": "string" }, "shipTo": { "type": "boolean" }, "billTo": { "type": "boolean" }, "invoiceTo": { "type": "boolean" }, "oneTime": { "type": "boolean" }, "createdOn": { "type": "date" } } }, "billToCode": { "type": "object", "properties": { "code": { "type": "string" }, "name": { "type": "string" }, "line1": { "type": "string", "key": "street1" }, "line2": { "type": "string", "key": "street2" }, "city": { "type": "string" }, "county": { "type": "string" }, "state": { "type": "object", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "isoCode": { "type": "string" } } }, "zip": { "type": "string" }, "country": { "type": "object", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "isoCode": { "type": "string" } } }, "phone": { "type": "string" }, "fax": { "type": "string" }, "email": { "type": "string" }, "warehouseAddress": { "type": "string" }, "shipTo": { "type": "boolean" }, "billTo": { "type": "boolean" }, "invoiceTo": { "type": "boolean" }, "oneTime": { "type": "boolean" }, "createdOn": { "type": "date" } } }, "invoiceToCode": { "type": "object", "properties": { "code": { "type": "string" }, "name": { "type": "string" }, "line1": { "type": "string", "key": "street1" }, "line2": { "type": "string", "key": "street2" }, "city": { "type": "string" }, "county": { "type": "string" }, "state": { "type": "object", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "isoCode": { "type": "string" } } }, "zip": { "type": "string" }, "country": { "type": "object", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "isoCode": { "type": "string" } } }, "phone": { "type": "string" }, "fax": { "type": "string" }, "email": { "type": "string" }, "warehouseAddress": { "type": "string" }, "shipTo": { "type": "boolean" }, "billTo": { "type": "boolean" }, "invoiceTo": { "type": "boolean" }, "oneTime": { "type": "boolean" }, "createdOn": { "type": "date" } } } } },
                                output = (new (super.responseHandler)(request, { data: response.data.result[0] }, responseSchema)).execute();
                            return callback(null, request, output);
                        } else {
                            const error = new (super.customError)("dd-common-error-1", "AppError");
                            return callback(null, request, { "errors": error, "data": {} });
                        }
                    }
                });

            } catch (error) {
                return callback(error, null);
            }
        }


        /**
        * @Name : getBehalfUsers
        * @Description : It is used for fetching behalf user list
        * @param1 : request
        * @param2 : input
        * @param3 : callback  
        * @return : object / Throw Error
        */

        getBehalfUsers(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                        http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = eProcURL + '/user/searchBehalfUsers';

                    http.post(url, 'getBehalfUsers', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"type":{"type":"number"},"emailId":{"type":"string"},"displayName":{"type":"string"},"firstName":{"type":"string"},"lastName":{"type":"string"},"designation":{"type":"string"},"department":{"type":"string"},"currency":{"type":"string"},"numberFormat":{"type":"string"},"fomattedNumberFormat":{"type":"string"},"dateFormat":{"type":"string"},"timeFormat":{"type":"string"},"salutation":{"type":"string"},"locale":{"type":"string"},"timeZone":{"type":"string"},"decimalPrecision":{"type":"number"},"reportingManagerId":{"type":"string"},"active":{"type":"boolean"},"erpId":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Method Name : getDetailsByIds
        * @Description : It is used to get the user list
        * @return object / Throw Error
        */
        getDetailsByIds(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                    "userIds" :  "joi.array().items(joi.string().label('eproc-lable-212__')).min(1).unique().required().label('eproc-lable-212__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate(request.body);
                if (result) {
                    let errorMsg = new (super.customError)(result, 'ValidationError', 6);
                    callback(errorMsg, null);
                } else {
                    const tms = new (super.tmsHook({request: request}))();
                    tms.getUsers(request, request.body.userIds, (error, request, response) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            if (response.length === 0) {
                                return callback(null, request, { data: {}, message: "eproc-error-9" });
                            } else {
                                let result = {}
                                result.records = response
                                const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "userId": { "type": "string" }, "emailId": { "type": "string" }, "displayName": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "designation": { "type": "string" }, "department": { "type": "string" }, "active": { "type": "boolean" }, "tenantId": { "type": "string" }, "erpId": { "type": "string" } } } } };
                                const output = (new (super.responseHandler)(request, { "data": result }, responseSchema));
                                return callback(null, request, output.execute());
                            }
                        }
                    })
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : getList
        * @Description : It is used to get the user list
        * @return : object
        */
        getList(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const eProcURL = request.productsURL.eProc["soa"];
                    let url = eProcURL + '/user/filter';

                    http.post(url, 'getUserList', request.body, (error, response) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "userId": { "type": "string" }, "emailId": { "type": "string" }, "displayName": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "designation": { "type": "string" }, "department": { "type": "string" }, "active": { "type": "boolean" }, "tenantId": { "type": "string" }, "erpId": { "type": "string" } } } } };
                            let output = (new (super.responseHandler)(request, response, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name : selectableUser
        * @Description : It is used to get the selectable User list
        * @return : object
        */
        selectableUser(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/user/selectableUser/filter';
                    http.post(url, 'selectableUserList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"requestUserId":{"type":"string"},"emailAddress":{"type":"string"},"salutation":{"type":"string"},"firstName":{"type":"string"},"lastName":{"type":"string"},"name":{"type":"string"},"controlCurrency":{"type":"string"},"spendLimit":{"type":"string"},"approvalLimit":{"type":"string"},"invoiceApprovalLimit":{"type":"string"},"companyCode":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"costCenterCode":{"type":"string"},"purchasingScopeCode":{"type":"string"},"reportingManagerId":{"type":"string"},"designation":{"type":"string"},"department":{"type":"string"},"deliveryScope":{"type":"string"},"behalfScope":{"type":"string"},"active":{"type":"string"},"erpId":{"type":"string"},"procurementScopes":{"type":"none"},"userScopeDefault":{"type":"none"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };




        getEprocUserConfig(request, input, callback){
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                  "configTenantId" : "joi.string().label('eproc-lable-382__').required()",
                  "configUserId" : "joi.string().label('eproc-lable-212__').required()",
                  "configKeys" :  "joi.array().items(joi.string().label('eproc-lable-53__')).required().label('eproc-lable-212__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate(request.body);
                if (result) {
                    let errorMsg = new (super.customError)(result, 'ValidationError', 6);
                    callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    let url = eProcURL + '/workflowapproval/getApprovalDelegationConfig';



                    http.post(url, 'getEprocUserConfig', request.body, (error, response) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request,response);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        
        };

        updateEprocUserConfig(request, input, callback){
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                  "configUserId":"joi.string().label('eproc-lable-212__')",
                  "reassignPending":"joi.boolean().label('eproc-lable-463__').optional()",
                  "EPROC_APPROVAL_DELEGATION":"joi.string().label('eproc-lable-462__').allow('').optional()",

                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate(request.body);
                if (result) {
                    let errorMsg = new (super.customError)(result, 'ValidationError', 6);
                    callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    let url = eProcURL + '/workflowapproval/updateApprovalDelegationConfiguration';



                    http.post(url, 'updateEprocUserConfig', request.body, (error, response) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request,response);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        
        };
    


    };
    return User
        
}