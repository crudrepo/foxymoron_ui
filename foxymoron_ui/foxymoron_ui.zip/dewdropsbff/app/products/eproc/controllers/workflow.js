/**
 * Workflow Controller
 *
 * @description :: It deals with Workflow related actions.
 */
"use strict";
module.exports = (parentClass)=> {
  class Workflow extends parentClass { 
      /**
      * Evaluate the workflow before approval
      */    
      evaluate(request, input, callback){
          try {            
              const validationUtility = super.utils.validationUtility(request); 
              const schema = {
                    "status": "joi.number().integer().label('eproc-lable-76__')",
                    "statusComments": "joi.string().allow('').label('eproc-lable-360__')",
                    "archive": "joi.boolean().label('eproc-lable-361__')",
                    "error": "joi.boolean().label('eproc-lable-155__')",
                    "errorReasons": "joi.object({}).label('eproc-lable-362__')",
                    "version": "joi.number().integer().label('eproc-lable-72__')",
                    "workflowId": "joi.string().allow('').label('eproc-lable-363__')",
                    "name": "joi.string().allow('').label('eproc-lable-73__')",
                    "defaultWorkflow": "joi.boolean().label('eproc-lable-364__')",
                    "description": "joi.string().allow('').label('eproc-lable-136__')",
                    "processCode": "joi.string().allow('').label('eproc-lable-201__')",
                    "definitionId": "joi.string().allow('').label('eproc-lable-74__')",
                    "definitionType": "joi.boolean().label('eproc-lable-365__')",
                    "currency": "joi.string().allow('').label('eproc-lable-75__')",
                    "updated": "joi.boolean().label('eproc-lable-175__')",
                    "parentWorkflowId": "joi.string().allow('').label('eproc-lable-366__')",
                    "preventMultiApprovals": "joi.boolean().label('eproc-lable-367__')",
                    "skipInitiator": "joi.boolean().label('eproc-lable-368__')",
                    "subprocessKey": "joi.string().allow('').label('eproc-lable-369__')",

                    "newWorkflow": "joi.boolean().label('eproc-lable-370__')",
                    "costCenterApproverType": "joi.number().integer().label('eproc-lable-371__')",
                    "requestUserId": "joi.string().label('eproc-lable-372__')",
                    "companyCode": "joi.string().allow('').required().label('eproc-lable-63__')",
                    "businessUnitCode": "joi.string().allow('').required().label('eproc-lable-64__')",
                    "locationCode": "joi.string().allow('').required().label('eproc-lable-65__')",
                    "regionCode": "joi.string().allow('').required().label('eproc-lable-66__')",
                    "categoryCodes": "joi.array().items(joi.string().allow('').label('eproc-lable-59__')).unique().required().label('eproc-lable-59__')",
                    "roleType": "joi.string().allow('').label('eproc-lable-373__')",
                    "flexibleAccountingInstanceId": "joi.array().items(joi.string().allow('').label('eproc-lable-374__')).unique().label('eproc-lable-374__')",
                    "flexibleAccountingVersion": "joi.array().items(joi.number().integer().label('eproc-lable-375__')).label('eproc-lable-375__')",
                    "flexibleAccountingFormId": "joi.string().allow('').required().label('eproc-lable-376__')",
                    "costCenterCodes": "joi.array().items(joi.string().allow('').label('eproc-lable-60__')).unique().required().label('eproc-lable-60__')",
                    "accountTypeCodes": "joi.array().items(joi.string().allow('').label('eproc-lable-61__')).unique().required().label('eproc-lable-61__')",
                    "glAccountCodes": "joi.array().items(joi.string().allow('').label('eproc-lable-62__')).unique().required().label('eproc-lable-62__')",
                    "totalAmount": "joi.number().required().label('eproc-lable-68__')",
                    "itemSource": "joi.array().items(joi.string().allow('').label('eproc-lable-69__')).unique().required().label('eproc-lable-69__')",
                    "purchaseType": "joi.string().allow('').label('eproc-lable-199__')",
                    "utilizeBudget": "joi.boolean().label('eproc-lable-377__')",

                    "purchaseOrderId": "joi.string().allow('').label('eproc-lable-70__')",
                    "referenceType": "joi.string().allow('').label('eproc-lable-378__')",
                    "paymentMethod": "joi.string().allow('').label('eproc-lable-379__')",
                    "supplier": "joi.string().allow('').label('eproc-lable-77__')",                    
                    "buyerId": "joi.string().allow('').label('eproc-lable-71__')",
                    "budgetLineIds": "joi.array().items(joi.string().allow('').label('eproc-lable-380__')).unique().label('eproc-lable-380__')",
                    "statusText": "joi.string().allow('').label('eproc-lable-381__')",
                    "reqInventory": "joi.boolean().label('eproc-lable-382__')",
                    "contracted": "joi.boolean().label('eproc-lable-173__')",
                    "customShipAddress": "joi.boolean().label('eproc-lable-383__')",
                    "errorReasonsStr": "joi.string().allow('').label('eproc-lable-384__')",
                    
                    "requisitionIds": "joi.array().items(joi.string().allow('').label('eproc-lable-385__')).unique().label('eproc-lable-385__')",
                    "purchaseOrderType": "joi.string().allow('').label('eproc-lable-386__')",
                    "paymentTerms": "joi.string().allow('').label('eproc-lable-387__')",
                    "poItemType": "joi.string().allow('').label('eproc-lable-388__')",
                    "receiptRequired": "joi.boolean().label('eproc-lable-389__')",
                    "costingValues": "joi.array().items(joi.number().label('eproc-lable-390__')).unique().label('eproc-lable-390__')",
                    "orderValue": "joi.number().label('eproc-lable-391__')",
                    "blanketPurchaseOrderType": "joi.string().allow('').label('eproc-lable-392__')"
              };
              validationUtility.addInternalSchema(schema);    
              const result = validationUtility.validate(request.body);
              if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
              } else {
                  request.body.requestUserId = request.body.requestUserId || request.user.userId;
                  const http =  new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                  url = eProcURL + '/workflowapproval/doEvaluateWorkflow';
                  http.post(url, 'evaluateWorkflow', request.body, (error, result) => {
                    if(error){
                      callback(error, null);
                    }else {
                      const responseSchema = {"type":"object","properties":{"workflowEvaluated":{"type":"boolean"},"workflowWithAdditionalDetails":{"type":"object","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none","pattern":"DD MMM YYYY - HH: mm: ss"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"string"},"errorReasons":{"type":"object"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none","pattern":"DD MMM YYYY - HH: mm: ss"},"version":{"type":"number"},"workflowId":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"defaultWorkflow":{"type":"boolean"},"processCode":{"type":"string"},"definitionId":{"type":"string"},"definitionType":{"type":"number"},"updated":{"type":"boolean"},"currency":{"type":"string"},"parentWorkflowId":{"type":"string"},"preventMultiApprovals":{"type":"boolean"},"statusText":{"type":"string"},"newWorkflow":{"type":"boolean"},"skipInitiator":{"type":"boolean"},"subprocessKey":{"type":"string"},"costCenterApproverType":{"type":"number"},"ccownerIncluded":{"type":"boolean"},"userWithDefaultCCIncluded":{"type":"boolean"},"rmwithNonZeroApprovalLimitIncluded":{"type":"boolean"},"errorReasonsStr":{"type":"object"}}},"instanceActivities":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none","pattern":"DD MMM YYYY - HH: mm: ss"},"status":{"type":"number"},"autoId":{"type":"number"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none","pattern":"DD MMM YYYY - HH: mm: ss"},"predictedActivityId":{"type":"string"},"activityId":{"type":"string"},"workflowNodeId":{"type":"string"},"nodeId":{"type":"string"},"userType":{"type":"string"},"displayName":{"type":"string"},"receivedOn":{"type":"none","pattern":"DD MMM YYYY - HH: mm: ss"},"delegated":{"type":"boolean"},"endCustomNode":{"type":"boolean"},"activityType":{"type":"number"},"activityValue":{"type":"string"},"approvalId":{"type":"string"},"comments":{"type":"string"},"actionBy":{"type":"string"},"actionOn":{"type":"none","pattern":"DD MMM YYYY - HH: mm: ss"},"customNode":{"type":"boolean"},"instanceId":{"type":"string"},"executionId":{"type":"string"},"instanceActivityUsers":{"type":"none"},"instanceActivityDelegates":{"type":"array"},"subProcessInstanceIds":{"type":"array"},"subInstanceActivities":{"type":"array"},"multiSubInstanceActivities":{"type":"array"},"multiSubProcessInstanceIds":{"type":"array"},"forkMetaMap":{"type":"array"},"userTypeStr":{"type":"string"},"subProcessInstanceIdsStr":{"type":"string"},"multiSubProcessInstanceIdsStr":{"type":"string"},"forkMetaMapStr":{"type":"string"}}}}};
                      const output =  (new (super.responseHandler)(request, result, responseSchema)).execute();
                      return callback(null, request, output);
                    }
                  });
              }
          } catch (error) {
            callback(error, null);
          }
      }

      remind(request, input, callback) {
        try {
          const validationUtility = super.utils.validationUtility(request);
          validationUtility.addInternalSchema({
            "approvalId": "joi.string().allow('').allow(null).label('eproc-lable-361__')",
            "workflowInstanceId": "joi.string().allow('').allow(null).label('eproc-lable-362__')",
            "approvalLastModifiedOn": "joi.string().allow('').allow(null).label('eproc-lable-363__')",
            "requisitionId": "joi.string().label('eproc-lable-372__').allow('').allow(null)"
          });
          const validationErrors = validationUtility.validate(request.body);
          if (validationErrors) {
            const errorMsg = new(super.customError)(validationErrors, 'ValidationError', 3);
            callback(errorMsg, null);
          } else {
            const http = new(super.httpService)(request),
              eProcURL = request.productsURL.eProc["soa"],
              url = `${eProcURL}/workflowapproval/remindApprover`;

            http.post(url, 'remindApproval', request.body, (error, result) => {
              if (error) {
                callback(error, null);
              } else {
                const responseSchema = {"type":"object","properties":{"remindApproval":{"type":"boolean"}}};
                callback(null, request, (new(super.responseHandler)(request, {data: result.data}, responseSchema)).execute());
              }
            });
          }
        } catch (error) {
          callback(error, null);
        }
      }

      /**
    * Function to get workflowTrail
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    getworkflowTrail(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {            
            "processCode": "joi.string().required().label('eproc-lable-201__')",
            "workflowId": "joi.string().required().label('eproc-lable-266__')",
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "workflowInstanceId": "joi.string().label('eproc-lable-267__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/getWorkflowTrail';
          http.post(url, 'getWorkflowTrail', request.body, (error, result) => {           
            if (error) {
              return callback(error, null);
            } else if (result) {
                const responseSchema = {"type":"object","properties":{"lastModifiedOn":{"type":"none"},"instanceActivities":{"type":"array","properties":{"activityId":{"type":"string"},"subProcessInstanceIds":{"type":"none"},"subInstanceActivities":{"type":"none"},"predictedActivityId":{"type":"string"},"workflowNodeId":{"type":"string"},"nodeId":{"type":"string"},"userType":{"type":"string"},"displayName":{"type":"string"},"receivedOn":{"type":"none"},"status":{"type":"number"},"delegated":{"type":"boolean"},"endCustomNode":{"type":"boolean"},"activityType":{"type":"number"},"activityValue":{"type":"string"},"approvalId":{"type":"string"},"comments":{"type":"string"},"actionBy":{"type":"number"},"actionOn":{"type":"none"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"customNode":{"type":"boolean"},"instanceId":{"type":"string"},"executionId":{"type":"string"},"instanceActivityUsers":{"type":"array","properties":{"userId":{"type":"string"},"status":{"type":"number"},"comments":{"type":"string"},"actionOn":{"type":"none"}}},"instanceActivityDelegates":{"type":"object","properties":{"userId":{"type":"string"},"status":{"type":"number"},"comments":{"type":"string"},"actionOn":{"type":"none"}}}}}}};
                const output = (new (super.responseHandler)(request, result, responseSchema));
                return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

      /**
    * Function to get getWorkflowApprovals
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    getWorkflowApprovals(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {            
            "approvalIds": "joi.array().items(joi.string().allow('').label('eproc-lable-361__')).unique().label('eproc-lable-361__')"
          };
        validationUtility.addInternalSchema(schema);    
        let result = validationUtility.validate(request.body);  
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/getWorkflowApprovals';            
          http.post(url, 'getWorkflowApprovals', request.body, (error, result) => {             
            if (error) {
              return callback(error, null);
            } else if (result) {
                const responseSchema = {"type":"object","properties":{"workflowApprovals":{"type":"array","properties":{"tenantId":{"type":"string"},"autoId":{"type":"number"},"approvalId":{"type":"string"},"receivedOn":{"type":"none"},"status":{"type":"number"},"entityId":{"type":"string"},"version":{"type":"number"},"entityNumber":{"type":"string"},"entityName":{"type":"string"},"entityCompanyCode":{"type":"string"},"entityBusinessUnitCode":{"type":"string"},"entityLocationCode":{"type":"string"},"entityCreatedBy":{"type":"string"},"entityInitiator":{"type":"string"},"entityCurrency":{"type":"string"},"entityAmount":{"type":"number"},"entityUrgent":{"type":"boolean"},"approvalType":{"type":"number"},"approvalValue":{"type":"string"},"displayName":{"type":"string"},"comments":{"type":"string"},"actionBy":{"type":"string"},"actionOn":{"type":"none"},"workflowId":{"type":"string"},"processCode":{"type":"string"},"workflowInstanceId":{"type":"string"},"workflowExecutionId":{"type":"string"},"delegated":{"type":"boolean"},"adminAction":{"type":"boolean"},"workflowApprovalUsers":{"type":"none"},"workflowApprovalDelegates":{"type":"none"},"modifiedOn":{"type":"none"},"systemAction":{"type":"boolean"},"processingStatus":{"type":"number"},"processType":{"type":"string"},"autoAction":{"type":"boolean"},"archive":{"type":"boolean"},"supplierId":{"type":"string"},"totalCount":{"type":"number"},"itemIds":{"type":"none"},"groupId":{"type":"string"},"pending":{"type":"boolean"},"processTypeStr":{"type":"string"}}}}},
                      output = (new (super.responseHandler)(request, result, responseSchema));
                return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * Function to get predictworkflowTrail
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    getpredictworkflowTrail(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {            
            "processCode": "joi.string().required().label('eproc-lable-201__')",
            "workflowId": "joi.string().required().label('eproc-lable-266__')",
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "groupId": "joi.string().required().label('eproc-lable-332__')",
            "entityVersion": "joi.number().integer().required().label('eproc-lable-394__')",
            "workflowInstanceId": "joi.string().allow('', null).label('eproc-lable-267__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(super.lodash.merge(request.body, {"workflowId": request.params.workflow_Id}));
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/predictedWorkflowTrail';
          http.post(url, 'getPredictworkflowTrail', request.body, (error, result) => {           
            if (error) {
              return callback(error, null);
            } else if (result) {
                const responseSchema = {"type":"object","properties":{"lastModifiedOn":{"type":"none"},"instanceActivities":{"type":"array","properties":{"activityId":{"type":"string"},"predictedActivityId":{"type":"string"},"workflowNodeId":{"type":"string"},"nodeId":{"type":"string"},"userType":{"type":"string"},"displayName":{"type":"string"},"receivedOn":{"type":"none"},"status":{"type":"number"},"delegated":{"type":"boolean"},"endCustomNode":{"type":"boolean"},"activityType":{"type":"number"},"activityValue":{"type":"string"},"approvalId":{"type":"string"},"comments":{"type":"string"},"actionBy":{"type":"number"},"actionOn":{"type":"none"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"customNode":{"type":"boolean"},"instanceId":{"type":"string"},"executionId":{"type":"string"},"instanceActivityUsers":{"type":"array","properties":{"userId":{"type":"string"},"status":{"type":"number"},"comments":{"type":"string"},"actionOn":{"type":"none"}}},"instanceActivityDelegates":{"type":"object","properties":{"userId":{"type":"string"},"status":{"type":"number"},"comments":{"type":"string"},"actionOn":{"type":"none"}}},"tenantId":{"type":"string"},"autoId":{"type":"number"},"subProcessInstanceIds":{"type":"none"},"subInstanceActivities":{"type":"none"},"multiSubInstanceActivities":{"type":"none"},"multiSubProcessInstanceIds":{"type":"none"},"forkMetaMap":{"type":"none"},"userTypeStr":{"type":"string"},"subProcessInstanceIdsStr":{"type":"string"},"multiSubProcessInstanceIdsStr":{"type":"string"},"forkMetaMapStr":{"type":"string"}}},"newWorkflow":{"type":"boolean"},"skipInitiator":{"type":"boolean"},"workflowName":{"type":"string"}}},
                output = (new (super.responseHandler)(request, result, responseSchema));
                return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * Function to update workflowInstance
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    updateWorkflowInstance(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = { 
            "workflowInstanceId": "joi.string().allow('', null).label('eproc-lable-267__')",
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "entityVersion": "joi.number().integer().label('eproc-lable-394__')",

            "lastModifiedLong": "joi.string().allow('', null).label('eproc-lable-431__')",
            "lastUpdatedOn": "joi.string().allow('', null).label('eproc-lable-432__')",
            "nodeId": "joi.string().required().label('eproc-lable-433__')",
            "workflowNodeId": "joi.string().required().label('eproc-lable-434__')",
            "parentNodeId": "joi.string().allow('', null).label('eproc-lable-435__')",
            "parentUserId": "joi.string().allow('', null).label('eproc-lable-436__')",
            "approverUserId": "joi.string().allow('', null).label('eproc-lable-437__')",
            "action": "joi.string().required().label('eproc-lable-50__')",
            "approvalId": "joi.string().allow('', null).label('eproc-lable-438__')",
            "roleType": "joi.string().required().label('eproc-lable-367__')",
            "isAmend": "joi.boolean().label('eproc-lable-439__')",
            
            "processCode": "joi.string().required().label('eproc-lable-201__')",
            "groupId": "joi.string().required().label('eproc-lable-332__')",
            
            
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(super.lodash.merge(request.body, {"workflowInstanceId": request.params.workflow_Id}));
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/updateWorkflowInstance';
          http.post(url, 'updateWorkflowInstance', request.body, (error, result) => {           
            if (error) {
              return callback(error, null);
            } else if (result) {
                const responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"info1":{"type":"string"},"info2":{"type":"string"}}},
                  output = (new (super.responseHandler)(request, result, responseSchema));
                return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

/**
    * Function to update updateSelectableUserWorkflowInstance
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    updateSelectableUserWorkflowInstance(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {            
            "processCode": "joi.string().required().label('eproc-lable-201__')",
            "workflowId": "joi.string().required().label('eproc-lable-266__')",
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "groupId": "joi.string().required().label('eproc-lable-332__')",
            "nodeId": "joi.string().required().label('eproc-lable-433__')",
            "workflowInstanceId": "joi.string().allow('', null).label('eproc-lable-267__')",
            "selectableUserId": "joi.string().allow('', null).label('eproc-lable-443__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(super.lodash.merge(request.body, {"workflowInstanceId": request.params.workflow_Id}));
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/updateSelectableUserWorkflowInstance';
          http.post(url, 'updateSelectableUserWorkflowInstance', request.body, (error, result) => {           
            if (error) {
              return callback(error, null);
            } else if (result) {
                const responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"info1":{"type":"string"},"info2":{"type":"string"}}},
                  output = (new (super.responseHandler)(request, result, responseSchema));
                return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

	/**
    * Function to update addUpdateWorkflowNodeApprover
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    addUpdateWorkflowNodeApprover(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {          
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "entityType": "joi.string().required().label('eproc-lable-356__')",
            "workflowInstanceId": "joi.string().allow('', null).label('eproc-lable-267__')",
            "nodeId": "joi.string().required().label('eproc-lable-433__')",
            "costCenterCodeList": "joi.array().items(joi.string().label('eproc-lable-60__')).min(1).required().unique().label('eproc-lable-60__')",
            "costCenterApproverList": "joi.array().items(joi.string().label('eproc-lable-444__')).min(1).required().unique().label('eproc-lable-444__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(super.lodash.merge(request.body, {"workflowInstanceId": request.params.workflow_Id}));
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/addUpdateWorkflowNodeApprover';
          http.post(url, 'addUpdateWorkflowNodeApprover', request.body, (error, result) => {           
            if (error) {
              return callback(error, null);
            } else if (result) {
                const responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"info1":{"type":"string"},"info2":{"type":"string"}}},
                  output = (new (super.responseHandler)(request, result, responseSchema));
                return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * Function to updateRequisitionItemGroup
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    updateRequisitionItemGroup(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {   
            "requisitionId": "joi.string().required().label('eproc-lable-6__')",
            "groupId": "joi.string().required().label('eproc-lable-332__')",
            "workflowInstanceId": "joi.string().required().label('eproc-lable-267__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(super.lodash.merge(request.body, {"workflowInstanceId": request.params.workflow_Id}));
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/modifyRequisitionItemGroup';
          http.post(url, 'updateRequisitionItemGroup', request.body, (error, result) => {        
            if (error) {
              return callback(error, null);
            } else {
                const responseSchema = {"type":"object","properties":{"requisitionStatus":{"type":"number"}}},
                  output = (new (super.responseHandler)(request, result, responseSchema));
                return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    
   /**
    * @name ::validateDynamicApprover
    *
    * @description :: Function to Ability to change the approver of the doucment
    * @param {object} request
    *        @param {string} selectableUserId
    *        @param {string} workflowId
    *        @param {string} workflowInstanceId
    *        @param {string} parentNodeId
    *        @param {string} action
    *        @param {string} entityId
    *        @param {string} activityId
    *        @param {string} processCode
    *        @param {number} lastModifiedLong
    * @return :: acknowledgement that change has been approved or not.
    */
    validateDynamicApprover(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "selectableUserId": "joi.string().required().label('eproc-lable-449__')",
            "workflowId": "joi.string().required().label('eproc-lable-450__')",
            "workflowInstanceId": "joi.string().required().label('eproc-lable-267__')",
            "parentNodeId": "joi.string().required().label('eproc-lable-435__')",
            "action": "joi.string().required().label('eproc-lable-50__')",
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "activityId": "joi.string().allow('',null).label('eproc-lable-451__')",
            "processCode": "joi.string().required().label('eproc-lable-201__')",
            "lastModifiedLong": "joi.number().label('eproc-lable-431__')",
            "isAmend": "joi.boolean().label('eproc-lable-439__')",
            "groupId": "joi.string().required().label('eproc-lable-332__')",
            "amend": "joi.boolean().label('eproc-lable-452__')",
            "documentScope": "joi.array().items(joi.string().allow('').label('eproc-lable-453__')).unique().required().label('eproc-lable-453__')"

          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/validateDynamicApprover';
          http.post(url, 'ValidateDynamicApprover', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result && result.data.id) {
              const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            } else {
              return callback(null, request, result);
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * @name ::getWorkflowNodeApprover
    *
    * @description :: Function to Ability to get the workflow node approvers
    * @param {object} request
    *        @param {string} entityId
    *        @param {string} entityType
    *        @param {string} workflowInstanceId
    * @return :: return the workflow node approvers.
    */
    getWorkflowNodeApprovers(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "entityType": "joi.string().required().label('eproc-lable-356__')",
            "workflowInstanceId": "joi.string().required().label('eproc-lable-267__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/nodeApprovers';
          http.post(url, 'getWorkflowNodeApprovers', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = { "type": "object", "properties": { "approverNodes": { "type": "none" } } },
              output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * @name ::getApprovalList
    *
    * @description :: Function to Ability to get the workflow approvals list
    * @param {object} request
    *        @param {number} perPageRecords
    *        @param {number} pageNo
    *        @param {array}  sort
    *        @param {object} criteriaGroup
    * @return :: return the workflow approvals list.
    */

    getApprovalList(request, input, callback) {
      try {                
          const validationUtility = super.utils.validationUtility(request);         
          validationUtility.addCommonSchema('pagination'); 
          validationUtility.addCommonSchema('sort');              
          validationUtility.addCommonSchema('criteriaGroup');
          const result = validationUtility.validate(request.body);
          if(result){
              const errorMsg = new (super.customError)(result, 'ValidationError', 3);
              return callback(errorMsg, null);
          }else{
              const eProcURL = request.productsURL.eProc["soa"];
              const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter); 
              const url = eProcURL+'/workflowapproval/filter';       
              http.post(url, 'getWorkflowApprovals', request.body, (error, result) => {
                  if(error) {
                      return callback(error, null);
                  } else {
                    let utils = super.utils,
                      lodash = super.lodash,
                      userIds = [];
                      
                      if(lodash.isArray(result['data'].records)) {
                          // Get the unique user ID(S)
                          userIds = result['data'].records.map((user)=> { return user.entityInitiator;}).filter((elem, index, self)=> {
                              return index == self.indexOf(elem);
                          });
                      }

                      const tasks = [
                          // Pass the userIds and Collect the user datas
                          (methodCallback) => {
                              if(!lodash.isEmpty(userIds)) {
                                  const tms = new (super.tmsHook({request: request}))();
                                  tms.getUsers(request, userIds, methodCallback);
                              }else{
                                  return methodCallback(null, request, []);
                              }
                          },
                          // Merge the user datas and Product results
                          (request, input, methodCallback) => {                                   
                              if(!lodash.isEmpty(input)) {
                                  let extractProps = utils.extractObjPropsFromArray(input, ["firstName","lastName","displayName","userId"]);
                                  let utilsMerge = utils.mergeArray(result['data'].records, extractProps, ['entityInitiator','userId']);
                                  result['data'].records = utilsMerge; 
                              }
                              return methodCallback(null, request, result);
                          }
                      ];

                      super.async.waterfall(tasks, (error, request, result) => {
                          if (error) {
                              return callback(error, null);
                          } else {
                              const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"autoId":{"type":"number"},"approvalId":{"type":"string"},"receivedOn":{"type":"none"},"status":{"type":"number"},"entityId":{"type":"string"},"version":{"type":"number"},"entityNumber":{"type":"string"},"entityName":{"type":"string"},"entityCompanyCode":{"type":"string"},"entityBusinessUnitCode":{"type":"string"},"entityLocationCode":{"type":"string"},"entityCreatedBy":{"type":"string"},"entityInitiator":{"type":"none"},"entityCurrency":{"type":"string"},"entityAmount":{"type":"number"},"entityUrgent":{"type":"boolean"},"approvalType":{"type":"number"},"approvalValue":{"type":"string"},"displayName":{"type":"string"},"comments":{"type":"string"},"actionBy":{"type":"string"},"actionOn":{"type":"number"},"workflowId":{"type":"string"},"processCode":{"type":"string"},"workflowInstanceId":{"type":"string"},"workflowExecutionId":{"type":"string"},"delegated":{"type":"boolean"},"adminAction":{"type":"boolean"},"workflowApprovalUsers":{"type":"none"},"workflowApprovalDelegates":{"type":"none"},"modifiedOn":{"type":"none"},"systemAction":{"type":"boolean"},"processingStatus":{"type":"number"},"processType":{"type":"string"},"processKey":{"type":"none"},"autoAction":{"type":"boolean"},"archive":{"type":"boolean"},"supplierId":{"type":"string"},"totalCount":{"type":"number"},"itemIds":{"type":"none"},"groupId":{"type":"string"},"pending":{"type":"boolean"},"processTypeStr":{"type":"string"},"pendingIds":{"type":"none"},"delegatedOnTimeStamp":{"type":"none"},"delegatedOn":{"type":"none"},"pendingWith":{"type":"string"},"allowAction":{"type":"boolean"},"delegatedByMe":{"type":"boolean"}}}}},
                              output =  (new (super.responseHandler)(request, result, responseSchema));
                              output.addCommonSchema('pagination', output.responseSchema.properties);
                              return callback(null, request, output.execute());
                          }        
                      });                          
                  }
              });
          }                
      } catch (error) {
          return callback(error, null);
      }
    }

    /**
    * @name ::approveAction
    *
    * @description :: do workflows approve Action
    * @param {object} request
    *        @param {string} entityId
    *        @param {string} entityType
    *        @param {string} workflowInstanceId
    * @return :: return the workflow approve action details.
    */
    approveAction(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "roleType": "joi.string().required().label('eproc-lable-367__')",
            "approvalId": "joi.string().required().label('eproc-lable-361__')",
            "approvalLastModifiedOn": "joi.number().required().label('eproc-lable-363__')",
            "adminRequestedAction": "joi.boolean().label('eproc-lable-450__')",
            "comments": "joi.string().allow('', null).label('eproc-lable-196__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/approveAction';
          http.post(url, 'workflowApproveAction', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
              output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * @name ::rejectAction
    *
    * @description :: do workflows reject Action
    * @param {object} request
    *        @param {string} entityId
    *        @param {string} entityType
    *        @param {string} workflowInstanceId
    * @return :: return the workflow reject action details.
    */
    rejectAction(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "roleType": "joi.string().required().label('eproc-lable-367__')",
            "approvalId": "joi.string().required().label('eproc-lable-361__')",
            "approvalLastModifiedOn": "joi.number().required().label('eproc-lable-363__')",
            "adminRequestedAction": "joi.boolean().label('eproc-lable-450__')",
            "comments": "joi.string().allow('', null).label('eproc-lable-196__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/rejectAction';
          http.post(url, 'workflowRejectAction', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
              output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * @name ::doDelegateWorkflowApproval
    *
    * @description :: do workflows reject Action
    * @param {object} request
    *        @param {string} approvalId
    *        @param {string} delegatedUserId
    *        @param {string} roleType
    *        @param {string} comments
    *        @param {boolean} adminRequestedAction
    *        @param {number} approvalLastModifiedOn
    *        @param {array} documentScope
    * @return :: return the workflow approval id.
    */
    doDelegateWorkflowApproval(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "approvalId": "joi.string().required().label('eproc-lable-361__')",
            "delegatedUserId": "joi.string().required().label('eproc-lable-460__')",
            "roleType": "joi.string().required().label('eproc-lable-367__')",
            "comments": "joi.string().allow('', null).label('eproc-lable-196__')",
            "adminRequestedAction": "joi.boolean().label('eproc-lable-450__')",
            "documentScope": "joi.array().items(joi.string().allow('').label('eproc-lable-453__')).unique().required().label('eproc-lable-453__')",
            "approvalLastModifiedOn": "joi.number().required().label('eproc-lable-363__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/workflowapproval/doDelegateWorkflowApproval';
          http.post(url, 'workflowdoDelegateWorkflowApproval', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = { "type": "object", "properties": { "approvalId": { "type": "string" } } },
              output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

  }
  return Workflow;
};