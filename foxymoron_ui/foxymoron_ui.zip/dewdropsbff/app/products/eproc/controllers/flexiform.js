"use strict";
/**
 * FlexiForm Controller
 *
 * @description :: Provides flexiform related operations
 */

module.exports = (parentClass)=> {
  class FlexiForm extends parentClass {

    /**
    * @Name : updateDynamicInstanceCOA
    * @Description : It is used to update the Dynamic Instances COA
    * @return : object / Throw Error
    */
    updateDynamicInstanceCOA(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
            schema = {
                "dynamicFormId": "joi.string().required().label('eproc-lable-79__')",
                "processCode": "joi.string().label('eproc-lable-80__')",
                "formInstance": "joi.object().required().label('eproc-lable-394__')",
                "extraParams": "joi.object().required().label('eproc-lable-83__')",
                //"extraParams": "joi.object().keys({quantity:joi.number().integer().label('eproc-lable-1__'),totalAmount:joi.number().label('eproc-lable-179__'),purchaseType:joi.string().label('eproc-lable-199__'),company:joi.string().label('eproc-lable-395__'),businessUnit:joi.string().label('eproc-lable-397__'),location:joi.string().label('eproc-lable-237__'),category:joi.string().label('eproc-lable-396__'),userId:joi.string().label('eproc-lable-212__'),scopeType:joi.string().label('eproc-lable-34__'),scopeId:joi.string().label('eproc-lable-193__')}).label('eproc-lable-83__')",
                "dynamicInstanceId": "joi.string().allow('').label('eproc-lable-84__')",
                "skipValidation": "joi.boolean().label('eproc-lable-393__')"
            };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(super.lodash.merge(request.body, {"dynamicFormId": request.params.flexiform_Id}));
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            } else {
                const eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/flexiForm/updateDynamicInstanceCOA',
                http =  new (super.httpService)(request),
                requestData = super.lodash.merge(request.body, {"dynamicFormId": request.params.flexiform_Id});
                
                http.post(url, 'updateDynamicInstanceCOA', requestData, (error, result) => {
                    if(error){
                        return callback(error, null);
                    }else if(result) {
                        const message = {description: "eproc-msg-23"};
                        if(!super.lodash.isEmpty(result.data.dynamicInstanceId)){
                            result.message = [message];              
                        }
                        const responseSchema = {"type":"object","properties":{"dynamicInstanceId":{"type":"string"},"dynamicInstanceVersion":{"type":"number"}}},
                        output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());                    
                    }
                });
            }
        }
        catch (error) {
            callback(error, null);
        }
    };

    /**
    * @Name : updateDynamicInstance
    * @Description : It is used to update the Dynamic Instances
    * @return : object / Throw Error
    */
    updateDynamicInstance(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
            schema = {
                "dynamicFormId": "joi.string().required().label('eproc-lable-79__')",
                "processCode": "joi.string().required().label('eproc-lable-80__')",
                "formInstance": "joi.object().required().label('eproc-lable-394__')",
                "dynamicInstanceId": "joi.string().allow('').label('eproc-lable-84__')"
            };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(super.lodash.merge(request.body, {"dynamicFormId": request.params.flexiform_Id}));
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            } else {
                const eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/flexiForm/updateDynamicInstance',
                http =  new (super.httpService)(request),
                requestData = super.lodash.merge(request.body, {"dynamicFormId": request.params.flexiform_Id});
                
                http.post(url, 'updateDynamicInstance', requestData, (error, result) => {
                    if(error){
                        return callback(error, null);
                    }else if(result) {
                        const message = {description: "eproc-msg-24"};
                        if(!super.lodash.isEmpty(result.data.dynamicInstanceId)){
                            result.message = [message];              
                        }
                        const responseSchema = {"type":"object","properties":{"dynamicInstanceId":{"type":"string"},"dynamicInstanceVersion":{"type":"number"}}},
                        output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());                    
                    }
                });
            }
        }
        catch (error) {
            callback(error, null);
        }
    };
     
  };

  return FlexiForm;
};