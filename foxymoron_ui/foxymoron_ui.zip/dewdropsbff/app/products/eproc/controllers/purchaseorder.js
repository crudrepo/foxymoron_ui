"use strict";
module.exports = (parentClass)=> {
    class PurchaseOrder extends parentClass{
        getPurchaseTypes(request, input, callback) {
            try {
                const http =  new (super.httpService)(request);
                const eProcURL = request.productsURL.eProc["soa"];
                const url = eProcURL+'/purchaseorder/getPurchaseTypes';
                http.get(url, 'getPurchaseTypes', (error, result) => {
                    if(error){
                        callback(error, null);
                    }else if(result){
                        callback(null, request, { "data": super.utils.formatResponse(result)});
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : getList
        *
        * @Description : Filter the purchase order List
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "isMapUserInfo": "joi.boolean().label('eproc-lable-441__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                validationUtility.addCommonSchema('sort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eprocHook = new (super.eprocHook({request: request}))();
                    if(!request.body.isMapUserInfo){
                        return eprocHook.getpurchseOrderList(request, request.body, callback);
                    }
                    const utils = super.utils,
                        lodash = super.lodash,
                        result = { poList: {}};
                    let userIds = [];

                    const tasks = [
                        (methodCallback) => {
                            eprocHook.getpurchseOrderList(request, request.body, methodCallback)
                        },
                        (request, input, methodCallback) => {
                            result.poList = input;
                            if(lodash.isArray(result.poList['data'].records)) {
                                result.poList['data'].records.forEach((user) => {
                                     userIds.push(user.createdBy, user.checkoutBuyer);
                                });
                                userIds = lodash.uniq(userIds);
                            }
                            // Pass the userIds and Collect the user datas
                            if(!lodash.isEmpty(userIds)) {
                                const tms = new (super.tmsHook({request: request}))();
                                tms.getUsers(request, userIds, methodCallback);
                            }else{
                                return methodCallback(null, request, []);
                            }
                        },
                        // Merge the user datas and Product results
                        (request, input, methodCallback) => {
                           if(!lodash.isEmpty(input)) {
                                const extractProps = utils.extractObjPropsFromArray(input, ["firstName","lastName","displayName","userId"]),
                                // Step : 1 merge utils created By user
                                utilsMerge1 = utils.mergeArray(result.poList['data'].records, extractProps, ['createdBy','userId']),
                                // Step : 2 merge utils checkout buyer user
                                utilsMerge2 = utils.mergeArray(utilsMerge1, extractProps, ['checkoutBuyer','userId']);
                                result.poList['data'].records = utilsMerge2;
                           }
                           return methodCallback(null, request, result);
                        }
                    ];

                    super.async.waterfall(tasks, (error, request, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result.poList);
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }

         /**
        * @Method Name : getAmendList
        *
        * @Description : Filter the purchase order List
        * @return object / Throw Error
        */
       getAmendList(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                };
            validationUtility.addInternalSchema(schema);
            validationUtility.addCommonSchema('pagination');
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const eprocHook = new (super.eprocHook({request: request}))();
                return eprocHook.getAmendPurchseOrderList(request, request.body, callback);
            }
        } catch (error) {
            callback(error, null);
        }
    }

        /**
        * @Method Name : openpoCount
        *
        * @Description : Filter the purchase order List
        * @return object / Throw Error
        */
        openpoCount(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                validationUtility.addCommonSchema('sort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let finalResult = {};
                    const eprocHook = new (super.eprocHook({request: request}))();
                    super.async.parallel([
                        function(callback1) {
                            eprocHook.getpurchseOrderList(request, input, (error, request, response) => {
                                if (error) {
                                    return callback(error, null);
                                } else if (response) {
                                    if(response.data.records.length > 0){
                                        finalResult.poLists = response.data;
                                    }else{
                                        finalResult.poLists = {};
                                        finalResult.poLists.records = [];
                                    }
                                    callback1(null,finalResult);
                                }
                            });
                        },
                        function(callback1) {
                            request.body.criteriaGroup = {};
                            request.body.criteriaGroup.logicalOperator =  "AND",
                            request.body.criteriaGroup.criteria = [];
                            request.body.criteriaGroup.criteria.push({
                                    "fieldName": "createdBy",
                                    "operation": "EQUALS",
                                    "value": request.user.userId
                                },
                                {
                                    "fieldName": "referenceType",
                                    "operation": "EQUALS",
                                    "value": "1"
                                },
                                {
                                    "fieldName": "archive",
                                    "operation": "EQUALS",
                                    "value": "false"
                                },
                                {"fieldName": "allStatus",
                                "operation": "IN",
                                "multivalue": ["STATUS_RECEIPT_NA","STATUS_RECEIPT_PARTIAL"]
                            });
                            eprocHook.getpurchseOrderList(request, input, (error, request, response) => {
                                if (error) {
                                    return callback(error, null);
                                } else if (response) {
                                    if(response.data.totalRecords > 0){
                                        finalResult.openpoCount = response.data.totalRecords;
                                    }else{
                                        finalResult.openpoCount = 0;
                                    }
                                    callback1(null,finalResult);
                                }
                            });
                        }
                    ],
                    function(err, results) {
                        return callback(null, request, {data: finalResult});
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }

        /**
         * @Method Name : downloadPurchaseOrder
         *
         * @Description : Get download path for purchase order
         * @return object / Throw Error
         */
        downloadPurchaseOrder(request, input, callback) {
            try {
                const http = new(super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = `${eProcURL}/purchaseOrder/download/${request.params.purchaseorder_Id}`;

                http.get(url, 'downloadPO', (error, result) => {
                    if (error) {
                        callback(error, null);
                    } else {
                        const responseSchema = {"type": "object","properties": {"path": {"type": "filePathEncode"},"name": {"type": "string"}}};
                        return callback(null, request, (new(super.responseHandler)(request, result, responseSchema)).execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        }

        /**
        * @Method Name : getPONumbers
        * @Description : Get the PO Numbers
        * @return object / Throw Error
        */
        getPONumbers(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required().label('eproc-lable-15__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/getPurchaseOrderNumbers';
                    http.post(url, 'getPONumbers', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
         * @Method Name : getPurchaseOrderDetails
         *
         * @Description : Get details of particular purchase order
         * @return object / Throw Error
         */
        getPurchaseOrderDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "entityType": "joi.string().required().label('eproc-lable-356__')",
                        "entityId": "joi.string().required().label('eproc-lable-357__')",
                        "emailAddress": "joi.string().allow('', null)",
                        "version": "joi.number().required().label('eproc-lable-72__')",
                        "useSnapshot": "joi.boolean().allow('', null).label('eproc-lable-373__')",
                        "view": "joi.boolean().allow('', null).label('eproc-lable-374__')",
                        "requireDependent": "joi.boolean().required().label('eproc-lable-375__')",
                        "requireScopeValidation": "joi.boolean().required().label('eproc-lable-376__')",
                        "validateByScopeOnly": "joi.boolean().allow('', null).label('eproc-lable-377__')",
                        "buyerDesk": "joi.boolean().allow('', null).label('eproc-lable-378__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "entityId": request.params.purchaseorder_Id, "emailAddress": null }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    request.body.emailAddress = request.user.emailId;
                    const http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL + '/purchaseOrder/view';
                    http.post(url, 'getPurchaseOrderDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            for (const key in result.data.objects.attachments) {
                                const attachment = result.data.objects.attachments[key];
                                if (attachment) {
                                    result.data.objects.attachments[key].path = super.utils
                                        .encrypt(attachment.path + '~' + attachment.name, request.tokenId, true)
                                        .replace(/\//g, "@");
                                }
                            }
                            return callback(null, request, { data: result });
                        }
                    });
                }
            }  catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : getSuggestedPurchaseOrders
        * @Description : Get the PO Numbers
        * @return object / Throw Error
        */
        getSuggestedPurchaseOrders(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "requisitionIds": "joi.array().items(joi.string().required().label('eproc-lable-6__')).unique().required().label('eproc-lable-6__')",
                         "lineItemIds": "joi.array().items(joi.string().label('eproc-lable-417__')).unique().required().label('eproc-lable-417__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/getSuggestedPurchaseOrders';
                    http.post(url, 'getSuggestedPurchaseOrders', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type": "object","properties": {"failedGeneratedPurchaseOrders": {"type": "none"} ,"suggestedPurchaseOrders": {"type": "none"}, "free-text": {"type": "none"}, "previouslyGeneratedPurchaseOrders": {"type": "none"}, "supportObjects": {"type": "none"}}};
                            return callback(null, request, (new(super.responseHandler)(request, result, responseSchema)).execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : convertRequisitionToPurchaseOrder
        * @Description : Get the PO Numbers
        * @return object / Throw Error
        */
        convertRequisitionToPurchaseOrder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "doSubmit": "joi.boolean().required().label('eproc-lable-455__')",
                        "purchaseOrder": "joi.array().items(joi.object({lineItemId: joi.string().required().label('eproc-lable-417__'),requisitionId: joi.string().required().label('eproc-lable-417__'),modifiedOn: joi.number().required().label('eproc-lable-417__'),attachmentId: joi.array().items(joi.string().allow('')).unique().required().label('eproc-lable-417__'),attachmentComments: joi.array().items(joi.string().allow('')).required().label('eproc-lable-453__'),attachmentVisibility: joi.array().items(joi.string().allow('')).required().label('eproc-lable-417__'),notes: joi.string().allow('').required().label('eproc-lable-230__'),baseCurrency: joi.string().required().label('eproc-lable-251__'),baseExchangeRate: joi.number().required().label('eproc-lable-252__'),receiptRequiredStatus: joi.number().required().label('eproc-lable-287__')})).required().label('eproc-lable-454__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/convertRequisitionToPurchaseOrder';
                    http.post(url, 'doCconvertRequisitionToPurchaseOrder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : validatePurchaseOrder
        * @Description : Do validate purchase order
        * @return object / Throw Error
        */
        validatePurchaseOrder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required().label('eproc-lable-70__')",
                        "isAmend": "joi.boolean().label('eproc-lable-439__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/doValidateExistingPurchaseOrderDetails ';
                    http.post(url, 'doValidateEPurchaseOrder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type": "object","properties": {"isValid": {"type": "boolean"}}};
                            return callback(null, request, (new(super.responseHandler)(request, result, responseSchema)).execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : recallPO
        * @Description : Recall purchase order
        * @return object / Throw Error
        */
        recallPO(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required()",
                        "comments": "joi.string().required()"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/doRecallPurchaseOrder';
                    http.post(url, 'doRecallPurchaseOrder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : updateEstimatedDeliveryDate
        * @Description : Update estimated delivery date of purchase order
        * @return object / Throw Error
        */
        updateEstimatedDeliveryDate(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required()",
                        "estimatedeliveryDate": "joi.number().required()",
                        "comments": "joi.string()"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/updateEstimatedDeliveryDate';
                    http.post(url, 'updateEstimatedDeliveryDate', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Method Name : remindApprover
        * @Description : Remind purchase order approver
        * @return object / Throw Error
        */
        remindApprover(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "approvalId": "joi.string()",
                        "workflowInstanceId": "joi.string().required()",
                        "approvalLastModifiedOn": "joi.string()"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/remindApprover';
                    http.post(url, 'remindApprover', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
         * @Method Name : download
         * @Description : Get download path and name for purchase order
         * @return object / Throw Error
         */
        download(request, input, callback) {
            try {
                const http = new(super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = `${eProcURL}/purchaseOrder/download/${request.params.purchaseOrderId}`;

                http.get(url, 'download', (error, result) => {
                    if (error) {
                        callback(error, null);
                    } else {
                        const responseSchema = {"type": "object","properties": {"path": {"type": "filePathEncode"},"name": {"type": "string"}}};
                        return callback(null, request, (new(super.responseHandler)(request, result, responseSchema)).execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        }


        /**
        * @Method Name : doCancelPurchaseOrder
        * @Description : Cancel purchase order
        * @return object / Throw Error
        */
        doCancelPurchaseOrder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required()",
                        "comments": "joi.string().required()"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/doCancelPurchaseOrder';
                    http.post(url, 'doCancelPurchaseOrder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Method Name : doClosePurchaseOrder
        * @Description : Close purchase order
        * @return object / Throw Error
        */
        doClosePurchaseOrder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required().label('eproc-lable-70__')",
                        "comments": "joi.string().allow('', null).label('eproc-lable-196__')",
                        "allowInvoice": "joi.boolean().label('eproc-lable-407__')",
                        "blockPayment": "joi.boolean().label('eproc-lable-461__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/doClosePurchaseOrder';
                    http.post(url, 'doClosePurchaseOrder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Method Name : doDelete
        * @Description : Delete purchase order
        * @return object / Throw Error
        */
        doDelete(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required()"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "purchaseOrderId": request.params.purchaseorder_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL + '/purchaseOrder/' + request.params.purchaseorder_Id + '/doDelete';
                    http.delete(url, 'doDelete', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Method Name : doRecallAmendedPurchaseOrder
        * @Description : Recall amended purchase order
        * @return object / Throw Error
        */
        doRecallAmendedPurchaseOrder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required()",
                        "comments": "joi.string().required()"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/doRecallAmendedPurchaseOrder';
                    http.post(url, 'doRecallAmendedPurchaseOrder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : doReleasePurchaseOrder
        * @Description : Release purchase order
        * @return object / Throw Error
        */
        doReleasePurchaseOrder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required()"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/doReleasePurchaseOrder';
                    http.post(url, 'doReleasePurchaseOrder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : updatePurchaseOrder
        * @Description : Update purchase order details
        * @return object / Throw Error
        */
        updatePurchaseOrder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "submit": "joi.boolean().required().label('eproc-lable-214__')",
                        "purchaseOrder": "joi.object().required().label('eproc-lable-452__')",
                        "purchaseOrderItems": "joi.array().items(joi.object()).required().label('eproc-lable-456__')",
                        "items": "joi.array().items(joi.object()).required().label('eproc-lable-208__')",
                        "purchaseOrderCostings": "joi.array().items(joi.object()).required().label('eproc-lable-457__')",
                        "purchaseOrderAccountings": "joi.array().items(joi.object()).required().label('eproc-lable-458__')",
                        "purchaseOrderTaxes": "joi.array().items(joi.object()).required().label('eproc-lable-459__')",
                        "attachmentsDetails": "joi.array().items(joi.object()).label('eproc-lable-412__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/updatePurchaseOrderDetails';
                    http.post(url, 'updatePurchaseOrderDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    /**
        * @Method Name : doReopenPurchaseOrder
        * @Description : Reopen purchase order
        * @return object / Throw Error
        */
       doReopenPurchaseOrder(request, input, callback) {
        try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required()",
                        "comments": "joi.string()"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/doReopenPurchaseOrder';
                    http.post(url, 'doReopenPurchaseOrder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : doValidatePurchaseOrderDetails
        * @Description : Update purchase order details
        * @return object / Throw Error
        */
        doValidatePurchaseOrderDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderDetails": "joi.object().required().label('eproc-lable-447__')",
                        "isAmend": "joi.boolean().label('eproc-lable-439__')",
                        "submit": "joi.boolean().label('eproc-lable-214__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/purchaseOrder/doValidatePurchaseOrderDetails';
                    http.post(url, 'doValidatePurchaseOrderDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : doEmailPurchaseOrderToSupplier
        * @Description : Email purchase order details to supplier
        * @return object / Throw Error
        */
       doEmailPurchaseOrderToSupplier(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "purchaseOrderId": "joi.string().required()",
                    "roleType": "joi.string().required()",
                    "comments": "joi.string()",
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/purchaseOrder/emailPurchaseOrderToSupplier';
                http.post(url, 'emailPurchaseOrderToSupplier', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        return callback(null, request, result);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };
    /**
        * @Method Name : doEmailPurchaseOrder
        * @Description : Email purchase order details to supplier
        * @return object / Throw Error
        */
       doEmailPurchaseOrder(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "purchaseOrderId": "joi.string().required()",
                    "message": "joi.string().required()",
                    "to": "joi.array().required()",
                    "requireCopy": "joi.boolean()",
                    "requireAttachment": "joi.boolean()",
                    "attachmentIds": "joi.array()",
                    "attachmentNames": "joi.array()"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/purchaseOrder/emailPurchaseOrder';
                http.post(url, 'emailPurchaseOrder', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        return callback(null, request, result);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Method Name : isPOEmailToSupplierActionAllowed
    * @Description : Email to supplier Action allowed
    * @return object / Throw Error
    */
   isPOEmailToSupplierActionAllowed(request, input, callback) {
    try {
        const validationUtility = super.utils.validationUtility(request),
            schema = {
                "purchaseOrderId": "joi.string().required()",
                "roleType": "joi.string().required()"
            };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
            const http = new (super.httpService)(request),
                eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/purchaseOrder/isPOEmailToSupplierActionAllowed';
            http.post(url, 'isPOEmailToSupplierActionAllowed', request.body, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Method Name : isPurchaseOrderAmendable
    * @Description : To get purchase amendable
    * @return object / Throw Error
    */
    isPurchaseOrderAmendable(request, input, callback) {
    try {
        const validationUtility = super.utils.validationUtility(request),
            schema = {
                "purchaseOrder_Id": "joi.string().required()"
            };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate({"purchaseOrder_Id": request.params.purchaseorder_Id});
        if (result) {
            const errorMsg = new (super.customError)(result, 'ValidationError', 3);
            return callback(errorMsg, null);
        } else {
            const http = new (super.httpService)(request),
                eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/purchaseOrder/isPurchaseOrderAmendable/'+request.params.purchaseorder_Id;
            http.get(url, 'isPurchaseOrderAmendable', (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
        }
     } catch (error) {
            return callback(error, null);
     }
    };

    /**
        * @Method Name : previewPurchaseOrder
        * @Description : to Preview the PurchaseOrder
        * @return object / Throw Error
        */
       previewPurchaseOrder(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                    schema = {};
                validationUtility.addInternalSchema(schema);
                const result = false;
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/purchaseOrder/previewPurchaseOrder';
                http.post(url, 'previewPurchaseOrder', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        return callback(null, request, result);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };
    /**
    * @Method Name : getTransactionHistoryForItem
    * @Description : Transaction history for item
    * @return object / Throw Error
    */
   getTransactionHistoryForItem(request, input, callback) {
    try {
        const validationUtility = super.utils.validationUtility(request),
            schema = {
                "purchaseOrderId": "joi.string()",
                "lineItemId": "joi.string().required()",
                "inventoryOrderExternalId": "joi.string()"
            };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
            const http = new (super.httpService)(request),
                eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/purchaseOrder/transactionHistoryForItem';
            http.post(url, 'getTransactionHistoryForItem', request.body, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Method Name : doSubmitPurchaseOrder
    * @Description : Submit PO by purchaseOrderId
    * @return object / Throw Error
    */
   doSubmitPurchaseOrder(request, input, callback) {
    try {
        const validationUtility = super.utils.validationUtility(request),
            schema = {
                "purchaseOrderId": "joi.string().required()"
            };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
            const http = new (super.httpService)(request),
                eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/purchaseOrder/doSubmitPurchaseOrder';
            http.post(url, 'doSubmitPurchaseOrder', request.body, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Method Name : doModifyPurchaseOrder
    * @Description : Modify PurchaseOrder with workflwoInstanceId
    * @return object / Throw Error
    */
   doModifyPurchaseOrder(request, input, callback) {
    try {
        const validationUtility = super.utils.validationUtility(request),
            schema = {
                "purchaseOrderId": "joi.string().required()",
                "workflowInstanceId": "joi.string().required()"
            };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
            const http = new (super.httpService)(request),
                eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/purchaseOrder/doModifyPurchaseOrder';
            http.post(url, 'doModifyPurchaseOrder', request.body, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Method Name : getAmendPurchaseOrderDetails
    * @Description : To get purchase order details for amendment
    * @return object / Throw Error
    */
       getAmendPODetails(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "entityType": "joi.string().required().label('eproc-lable-447__')",
                        "entityId": "joi.string().required().label('eproc-lable-448__')",
                        "version": "joi.number().label('eproc-lable-449__')",
                        "requireDependent": "joi.boolean().label('eproc-lable-450__')",
                        "useSnapshot": "joi.boolean().label('eproc-lable-454__')",
                        "view": "joi.boolean().label('eproc-lable-451__')",
                        "requireScopeValidation": "joi.boolean().label('eproc-lable-452__')",
                        "emailAddress": "joi.string().email().label('eproc-lable-453__')"
                      }
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/purchaseOrder/getAmendPODetails';
                http.post(url, 'getAmendPODetails', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        //TODO: Will add response schema later.
                        return callback(null, request, result);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Method Name : isAmendPurchaseOrderWorkflowRequired
    * @Description : To check whether amend PO required workflow or not
    * @return object / Throw Error
    */
    isAmendPurchaseOrderWorkflowRequired(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required().label('eproc-lable-70__')",
                        "amendedGrossTotalAmount": "joi.number().required().label('eproc-lable-324__')",
                        "amendedSupplierCurrency": "joi.string().required().label('eproc-lable-182__')"
                      };
            validationUtility.addInternalSchema(schema);
            const requestData = super.lodash.merge(request.body, {"purchaseOrderId": request.params.purchaseorder_Id });
            const result = validationUtility.validate(requestData);          
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/purchaseOrder/isAmendPurchaseOrderWorkflowRequired';
                    
                http.post(url, 'isAmendPurchaseOrderWorkflowRequired', requestData, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        //TODO: Will add response schema later.
                        return callback(null, request, result);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };


    /**
    * @Method Name : doAmendPurchaseOrderDetails
    * @Description : Amend purchase order details
    * @return object / Throw Error
    */
    doAmendPurchaseOrderDetails(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderDetails": "joi.object().required().label('eproc-lable-455__')",
                        "amend": "joi.boolean().label('eproc-lable-439__')",
                        "submit": "joi.boolean().label('eproc-lable-396__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/purchaseOrder/doAmendPurchaseOrderDetails';
                http.post(url, 'doAmendPurchaseOrderDetails', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        //TODO: Will add response schema later.
                        return callback(null, request, result);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Method Name : removeEntitySnapshot
    * @Description : Remove entity snapshot
    * @return object / Throw Error
    */
    removeEntitySnapshot(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "entityId": "joi.string().required().label('eproc-lable-448__')",
                        "entityType": "joi.string().required().label('eproc-lable-447__')",
                      };
                validationUtility.addInternalSchema(schema);
                const requestData = {"entityId":request.query.entityId,"entityType":request.query.entityType};
                const result = validationUtility.validate(requestData);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/purchaseOrder/removeEntitySnapshot';
                http.post(url, 'removeEntitySnapshot', requestData, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        //TODO: Will add response schema later.
                        return callback(null, request, result);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    /**
    * @Method Name : addReqItemsToPOAmendment
    * @Description : Add requisition item to PO amendment
    * @return object / Throw Error
    */
    addReqItemsToPOAmendment(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "emailAddress": "joi.string().email().label('eproc-lable-453__')",
                        "groupId": "joi.string().allow('', null).label('eproc-lable-456__')",
                        "requisitionId": "joi.string().required().label('eproc-lable-6__')"
                      };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/purchaseOrder/addReqItemsToPOAmendment';
                http.post(url, 'addReqItemsToPOAmendment', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        //TODO: Will add response schema later.
                        return callback(null, request, result);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };     
    }
    return PurchaseOrder;
}