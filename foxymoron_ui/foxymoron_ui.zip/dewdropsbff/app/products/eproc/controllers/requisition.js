"use strict";
/**
 * Requisition Controller
 *
 * @description :: Provides Requisition related operations
 */

module.exports = (parentClass) => {
  class Requisition extends parentClass {

    //Get the requisition list
    getList(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request);
        validationUtility.addCommonSchema('pagination');
        validationUtility.addCommonSchema('sort');
        validationUtility.addCommonSchema('criteriaGroup');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else {
          const eprocHook = new (super.eprocHook({ request: request }))();
          eprocHook.getrequisitionList(request, input, (error, request, response) => {
            if (error) {
              return callback(error, null);
            } else if (response) {
              return callback(null, request, response);
            }
          });
        }
      } catch (error) {
        callback(error, null);
      }
    }

    //Get the requisition list with open requisition list
    openprCount(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request);
        validationUtility.addCommonSchema('pagination');
        validationUtility.addCommonSchema('sort');
        validationUtility.addCommonSchema('criteriaGroup');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else {
          const finalResult = {},
            eprocHook = new (super.eprocHook({ request: request }))();
          super.async.parallel([
            (callback1) => {
              eprocHook.getrequisitionList(request, input, (error, request, response) => {
                if (error) {
                  return callback(error, null);
                } else if (response) {
                  if (response.data.records.length > 0) {
                    finalResult.prLists = response.data;
                  } else {
                    finalResult.prLists = {};
                    finalResult.prLists.records = [];
                  }
                  callback1(null, finalResult);
                }
              });
            },
            (callback1) => {
              request.body.criteriaGroup = request.body.criteriaGroup || {};
              request.body.criteriaGroup.logicalOperator = request.body.criteriaGroup.logicalOperator || "OR";
              request.body.criteriaGroup.criteria = request.body.criteriaGroup.criteria || [];
              request.body.criteriaGroup.criteria.push({
                "fieldName": "allStatus",
                "operation": "IN",
                "multivalue": ["GROUP_STATUS_APPROVED", "GROUP_STATUS_PARKED", "STATUS_ORDER_PARTIAL"]
              });
              eprocHook.getrequisitionList(request, input, (error, request, response) => {
                if (error) {
                  return callback(error, null);
                } else {
                  if (response.data.totalRecords > 0) {
                    finalResult.openprCount = response.data.totalRecords;
                  } else {
                    finalResult.openprCount = 0;
                  }
                  callback1(null, finalResult);
                }
              });
            }
          ],
            (err, results) => {
              if (err) return callback(err, null);
              return callback(null, request, { data: finalResult });
            });
        }
      } catch (error) {
        callback(error, null);
      }
    }

    getDetails(request, input, callback) {
      try {
        const http = new (super.httpService)(request),
          eProcURL = request.productsURL.eProc["soa"],
          url = `${eProcURL}/requisition/requsitionDetails/${request.params.requisition_Id}`;

        /*http.get(url, 'requsitionDetails', (error, requisitionDetails) => {
          const schema = {"type":"object","properties":{"action":{"type":"string"},"role":{"type":"string"},"submit":{"type":"boolean"},"checkedItemIds":{"type":"array"},"beforeApproval":{"type":"boolean"},"forkingRequired":{"type":"boolean"},"changedGroupId":{"type":"string"},"guidedRequisitions":{"type":"array","properties":{"guidedRequisitionId":{"type":"string"},"categoryEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"categoryCode":{"type":"string"},"itemId":{"type":"string"},"itemQuantity":{"type":"number"},"status":{"type":"number"},"quickSourceId":{"type":"string"},"quickSourceItemId":{"type":"string"}}},"guidedSuppliers":{"type":"object","properties":{"supplierId":{"type":"string"},"supplierType":{"type":"number"},"name":{"type":"string"},"location":{"type":"string"},"addressDetails":{"type":"string"},"contactPerson":{"type":"string"},"contactPersonType":{"type":"number"},"email":{"type":"string"},"phone":{"type":"string"},"fax":{"type":"string"},"website":{"type":"string"},"description":{"type":"string"},"contractOrderId":{"type":"string"},"contractOrderNumber":{"type":"string"},"contractOrderType":{"type":"number"},"referenceId":{"type":"string"}}},"requisition":{"type":"object","properties":{"requisitionId":{"type":"string"},"parentRequisitionId":{"type":"string"},"referenceRequisitionId":{"type":"string"},"requisitionNo":{"type":"string"},"name":{"type":"string"},"urgent":{"type":"boolean"},"behalfUserId":{"type":"string"},"department":{"type":"string"},"buyingJustification":{"type":"string"},"supplierComments":{"type":"string"},"companyCode":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"baseCurrency":{"type":"string"},"baseExchangeRate":{"type":"number"},"baseTotal":{"type":"number"},"guided":{"type":"boolean"},"purchaseTypeString":{"type":"string"},"purchaseTypeCode":{"type":"string"},"submittedOn":{"type":"number"},"approvedOn":{"type":"number"},"receivedOn":{"type":"number"},"closedOn":{"type":"number"},"resubmitionCount":{"type":"number"},"avgOrderTime":{"type":"number"},"totalItems":{"type":"number"},"currency":{"type":"string"},"totalAmount":{"type":"number"},"sendPOToSupplier":{"type":"boolean"},"approvedAmount":{"type":"number"},"buyerAmount":{"type":"number"},"amountToBeApproved":{"type":"number"},"workflowId":{"type":"string"},"workflowInstanceId":{"type":"string"},"rejectedItemCount":{"type":"number"},"processEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"flexibleAccountingFormId":{"type":"string"},"flexibleAccountingInstanceId":{"type":"string"},"flexibleAccountingVersion":{"type":"string"},"shipToCodeType":{"type":"number"},"shipToCode":{"type":"string"},"billToCode":{"type":"string"},"invoiceToCode":{"type":"string"},"deliverToType":{"type":"number"},"deliverTo":{"type":"string"},"deliveryOn":{"type":"number"},"paymentMethod":{"type":"number"},"paymentTransactionId":{"type":"string"},"paymentId":{"type":"string"},"canResubmit":{"type":"boolean"},"splitCostingLevel":{"type":"number"},"splitCostingType":{"type":"number"},"requesterAction":{"type":"number"},"orderStatus":{"type":"number"},"receiptStatus":{"type":"number"},"invoiceStatus":{"type":"number"},"retrospectivePurchase":{"type":"boolean"},"utilizeBudget":{"type":"boolean"},"budgetSettingsMap":{"type":"object","properties":{}},"attachmentIds":{"type":"array"},"statusBuyerNegotiated":{"type":"number"},"statusRequesterNegotiated":{"type":"number"},"statusBudgetary":{"type":"number"},"statusNeedAQuote":{"type":"number"},"requisitionType":{"type":"number"},"inventory":{"type":"boolean"},"assignedBuyerType":{"type":"number"},"assignedBuyer":{"type":"string"},"assignedBuyers":{"type":"array","properties":{"assignedBuyer":{"type":"string"},"assignedBuyerType":{"type":"number"},"assignedBuyerName":{"type":"string"}}},"linkedPurchaseOrderId":{"type":"string"},"linkedPurchaseOrderNo":{"type":"string"},"assignedOn":{"type":"number"},"origin":{"type":"number"},"externalId":{"type":"string"},"assignProject":{"type":"boolean"},"projectSettingStatus":{"type":"string"},"purchaseTypeSetting":{"type":"boolean"},"ptGLAccountSetting":{"type":"boolean"},"erpId":{"type":"string"},"sendToReadyForApproval":{"type":"boolean"},"hasBuyerItem":{"type":"boolean"},"sourcingStatusSettingMap":{"type":"object","properties":{"QUOTED_BY_SUPPLIER":{"type":"string"},"ESTIMATED_PRICE":{"type":"string"},"NEED_A_QUOTE":{"type":"string"}}},"updatedOn":{"type":"number"},"assetCodeSetting":{"type":"boolean"},"utilizeContract":{"type":"string"},"transferredTo":{"type":"string"},"retrospectiveSendPOSupplier":{"type":"boolean"},"retrospectiveLetUserDecide":{"type":"boolean"},"requisitionToExistingPOSetting":{"type":"boolean"},"purchaseTypeAtLineLevel":{"type":"boolean"},"allowedBackdateDays":{"type":"number"},"allowedSuggestedSupplier":{"type":"boolean"},"approvalIntegrationStatus":{"type":"number"},"externalIntegrationStatus":{"type":"number"},"totalTaxAmount":{"type":"number"},"grossTotalAmount":{"type":"number"},"buyerReviewSettingStatus":{"type":"boolean"},"reopenedRequisition":{"type":"boolean"},"groupStatus":{"type":"number"},"groupOrderStatus":{"type":"number"},"groupInvoiceStatus":{"type":"number"},"groupReceiptStatus":{"type":"number"},"projectVisibilityRule":{"type":"string"}}},"requisitionItemGroups":{"type":"array","properties":{"requisitionId":{"type":"string"},"groupId":{"type":"number"},"totalItems":{"type":"number"},"approvedAmount":{"type":"number"},"buyerAmount":{"type":"number"},"forkingCriteria":{"type":"string"},"requisitionType":{"type":"number"},"requesterAction":{"type":"number"},"workflowId":{"type":"string"},"linkedPurchaseOrderId":{"type":"string"},"linkedPurchaseOrderNo":{"type":"string"},"sendToReadyForApproval":{"type":"boolean"},"amountToBeApproved":{"type":"number"},"requisitionItems":{"type":"array","properties":{"requisitionId":{"type":"string"},"groupId":{"type":"number"},"requisitionNo":{"type":"string"},"itemId":{"type":"string"},"itemQuantity":{"type":"number"},"itemPrice":{"type":"number"},"currency":{"type":"string"},"sourcingStatus":{"type":"number"},"sourceType":{"type":"number"},"itemTotalPrice":{"type":"number"},"internalComment":{"type":"string"},"supplierComment":{"type":"string"},"splitDelivery":{"type":"boolean"},"splitCostingType":{"type":"number"},"attachmentIds":["string"],"approvedQuantity":{"type":"number"},"quickSourceId":{"type":"string"},"quickSourceItemId":{"type":"string"},"contractNo":{"type":"string"},"contractId":{"type":"string"},"contractType":{"type":"number"},"orderable":{"type":"boolean"},"approvalStatus":{"type":"number"},"buyerAdded":{"type":"boolean"},"replacingItemId":{"type":"string"},"originalReplacedItemId":{"type":"string"},"definitionId":{"type":"string"},"assetCode":{"type":"string"},"assetCodeType":{"type":"number"},"processEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"dynamicInstanceVersion":{"type":"number"},"flexibleAccountingFormId":{"type":"string"},"flexibleAccountingInstanceId":{"type":"string"},"flexibleAccountingVersion":{"type":"number"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"lineNo":{"type":"number"},"assetNumberRequired":{"type":"boolean"},"assignedBuyers":{"type":"array","properties":{"assignedBuyer":{"type":"string"},"assignedBuyerName":{"type":"string"}}},"assignedOn":{"type":"number"},"supplierPreferenceType":{"type":"number"},"itemTaxes":{"type":"array","properties":{"type":{"type":"string"},"name":{"type":"string"},"rate":{"type":"number"},"compound":{"type":"boolean"}}},"taxAmount":{"type":"number"},"status":{"type":"number"},"sendToReadyForApproval":{"type":"boolean"},"orderStatus":{"type":"number"},"receiptStatus":{"type":"number"},"invoiceStatus":{"type":"number"},"linkedPurchaseOrderId":{"type":"string"},"linkedPurchaseOrderNo":{"type":"string"},"receiptType":{"type":"number"},"requestedItemPrice":{"type":"number"}}}}},"requisitionDeliveries":{"type":"array","properties":{"itemId":{"type":"string"},"purchaseOrderId":{"type":"string"},"requisitionId":{"type":"string"},"lineItemId":{"type":"string"},"itemQuantity":{"type":"number"},"approvedQuantity":{"type":"number"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"deliverToType":{"type":"number"},"deliverTo":{"type":"string"},"deliveryOn":{"type":"number"},"deliveryUpto":{"type":"number"},"shipToCodeType":{"type":"number"},"shipToCode":{"type":"string"},"orderedQuantity":{"type":"number"},"receivedQuantity":{"type":"number"},"invoicedQuantity":{"type":"number"},"assetNumbers":{"type":"array","properties":{"serialNumber":{"type":"number"},"assetNumber":{"type":"string"},"manufacturerSerialNumber":{"type":"string"},"notes":{"type":"string"}}}}},"requisitionCostings":{"type":"object","properties":{"requisitionId":{"type":"string"},"itemId":{"type":"string"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"value":{"type":"number"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"budgetBaseValue":{"type":"number"},"projectCode":{"type":"string"},"splitValue":{"type":"number"}}},"requisitionAccountings":{"type":"array","properties":{"requisitionId":{"type":"string"},"itemId":{"type":"string"},"accountTypeCode":{"type":"string"},"generalLedgerCode":{"type":"string"},"value":{"type":"number"}}},"items":{"type":"array","properties":{"itemId":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"uom":{"type":"string"},"currency":{"type":"string"},"price":{"type":"number"},"marketPrice":{"type":"number"},"supplierId":{"type":"string"},"supplierPartId":{"type":"string"},"manufacturerName":{"type":"string"},"manufacturerProductURL":{"type":"string"},"manufacturerPartId":{"type":"string"},"imageURL":{"type":"string"},"thumbnailURL":{"type":"string"},"supplierProductURL":{"type":"string"},"leadTime":{"type":"number"},
          "sourceRefNo":{"type":"string"},"attachments":["none"],"itemAttributes":{"type":"object","properties":{}},"supplierAddressId":{"type":"string"},"supplierAddress":{"type":"string"},"supplierContact":{"type":"string"},"supplierPhone":{"type":"string"},"supplierOtherDetails":{"type":"string"},"supplierContactType":{"type":"string"},"supplierEmail":{"type":"string"},"supplierName":{"type":"string"},"categoryName":{"type":"string"},"categoryCode":{"type":"string"},"unsspscCode":{"type":"string"},"unsspscName":{"type":"string"},"greenItem":{"type":"boolean"},"preferredItem":{"type":"boolean"},"scopeId":{"type":"string"},"catalogId":{"type":"string"},"catalogVersion":{"type":"number"},"catalogItemId":{"type":"number"},"contractNo":{"type":"string"},"contractId":{"type":"string"},"itemType":{"type":"number"},"sourceType":{"type":"number"},"receiptType":{"type":"number"},"contractType":{"type":"number"}}},"supportObjects":{"type":"object","properties":{}},"attachmentsDetails":{"type":"array","properties":{"attachmentId":{"type":"string"},"comments":{"type":"string"},"visibility":{"type":"string"},"name":{"type":"string"},"size":{"type":"string"}}}}}
          error ? callback(error, null) : callback(null, request, (new(super.responseHandler)(request, requisitionDetails, schema)).execute());
        });*/
        http.get(url, 'requsitionDetails', (error, result) => {
          if (error) {
            return callback(error, null);
          } else {
            const responseSchema = {
              "type": "object", "properties": {
                "action": { "type": "string" }, "role": { "type": "string" }, "submit": { "type": "boolean" }, "checkedItemIds": { "type": "array" }, "beforeApproval": { "type": "boolean" }, "forkingRequired": { "type": "boolean" }, "changedGroupId": { "type": "string" }, "guidedRequisitions": { "type": "array", "properties": { "guidedRequisitionId": { "type": "string" }, "categoryEformId": { "type": "string" }, "dynamicFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "categoryCode": { "type": "string" }, "itemId": { "type": "string" }, "itemQuantity": { "type": "number" }, "status": { "type": "number" }, "quickSourceId": { "type": "string" }, "quickSourceItemId": { "type": "string" } } }, "guidedSuppliers": { "type": "object", "properties": { "supplierId": { "type": "string" }, "supplierType": { "type": "number" }, "name": { "type": "string" }, "location": { "type": "string" }, "addressDetails": { "type": "string" }, "contactPerson": { "type": "string" }, "contactPersonType": { "type": "number" }, "email": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "website": { "type": "string" }, "description": { "type": "string" }, "contractOrderId": { "type": "string" }, "contractOrderNumber": { "type": "string" }, "contractOrderType": { "type": "number" }, "referenceId": { "type": "string" } } }, "requisition": { "type": "object", "properties": { "requisitionId": { "type": "string" }, "parentRequisitionId": { "type": "string" }, "referenceRequisitionId": { "type": "string" }, "requisitionNo": { "type": "string" }, "name": { "type": "string" }, "urgent": { "type": "boolean" }, "behalfUserId": { "type": "string" }, "department": { "type": "string" }, "buyingJustification": { "type": "string" }, "supplierComments": { "type": "string" }, "companyCode": { "type": "string" }, "businessUnitCode": { "type": "string" }, "locationCode": { "type": "string" }, "baseCurrency": { "type": "string" }, "baseExchangeRate": { "type": "number" }, "baseTotal": { "type": "number" }, "guided": { "type": "boolean" }, "purchaseTypeString": { "type": "string" }, "purchaseTypeCode": { "type": "string" }, "submittedOn": { "type": "number" }, "approvedOn": { "type": "number" }, "receivedOn": { "type": "number" }, "closedOn": { "type": "number" }, "resubmitionCount": { "type": "number" }, "avgOrderTime": { "type": "number" }, "totalItems": { "type": "number" }, "currency": { "type": "string" }, "totalAmount": { "type": "number" }, "sendPOToSupplier": { "type": "boolean" }, "approvedAmount": { "type": "number" }, "buyerAmount": { "type": "number" }, "amountToBeApproved": { "type": "number" }, "workflowId": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "rejectedItemCount": { "type": "number" }, "processEformId": { "type": "string" }, "dynamicFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "flexibleAccountingFormId": { "type": "string" }, "flexibleAccountingInstanceId": { "type": "string" }, "flexibleAccountingVersion": { "type": "string" }, "shipToCodeType": { "type": "number" }, "shipToCode": { "type": "string" }, "billToCode": { "type": "string" }, "invoiceToCode": { "type": "string" }, "deliverToType": { "type": "number" }, "deliverTo": { "type": "string" }, "deliveryOn": { "type": "number" }, "paymentMethod": { "type": "number" }, "paymentTransactionId": { "type": "string" }, "paymentId": { "type": "string" }, "canResubmit": { "type": "boolean" }, "splitCostingLevel": { "type": "number" }, "splitCostingType": { "type": "number" }, "requesterAction": { "type": "number" }, "orderStatus": { "type": "number" }, "receiptStatus": { "type": "number" }, "invoiceStatus": { "type": "number" }, "retrospectivePurchase": { "type": "boolean" }, "utilizeBudget": { "type": "boolean" }, "budgetSettingsMap": { "type": "object", "properties": {} }, "attachmentIds": { "type": "array" }, "statusBuyerNegotiated": { "type": "number" }, "statusRequesterNegotiated": { "type": "number" }, "statusBudgetary": { "type": "number" }, "statusNeedAQuote": { "type": "number" }, "requisitionType": { "type": "number" }, "inventory": { "type": "boolean" }, "assignedBuyerType": { "type": "number" }, "assignedBuyer": { "type": "string" }, "assignedBuyers": { "type": "array", "properties": { "assignedBuyer": { "type": "string" }, "assignedBuyerType": { "type": "number" }, "assignedBuyerName": { "type": "string" } } }, "linkedPurchaseOrderId": { "type": "string" }, "linkedPurchaseOrderNo": { "type": "string" }, "assignedOn": { "type": "number" }, "origin": { "type": "number" }, "externalId": { "type": "string" }, "assignProject": { "type": "boolean" }, "projectSettingStatus": { "type": "string" }, "purchaseTypeSetting": { "type": "boolean" }, "ptGLAccountSetting": { "type": "boolean" }, "erpId": { "type": "string" }, "sendToReadyForApproval": { "type": "boolean" }, "hasBuyerItem": { "type": "boolean" }, "sourcingStatusSettingMap": { "type": "object", "properties": { "QUOTED_BY_SUPPLIER": { "type": "string" }, "ESTIMATED_PRICE": { "type": "string" }, "NEED_A_QUOTE": { "type": "string" } } }, "updatedOn": { "type": "number" }, "assetCodeSetting": { "type": "boolean" }, "utilizeContract": { "type": "string" }, "transferredTo": { "type": "string" }, "retrospectiveSendPOSupplier": { "type": "boolean" }, "retrospectiveLetUserDecide": { "type": "boolean" }, "requisitionToExistingPOSetting": { "type": "boolean" }, "purchaseTypeAtLineLevel": { "type": "boolean" }, "allowedBackdateDays": { "type": "number" }, "allowedSuggestedSupplier": { "type": "boolean" }, "approvalIntegrationStatus": { "type": "number" }, "externalIntegrationStatus": { "type": "number" }, "totalTaxAmount": { "type": "number" }, "grossTotalAmount": { "type": "number" }, "buyerReviewSettingStatus": { "type": "boolean" }, "reopenedRequisition": { "type": "boolean" }, "groupStatus": { "type": "number" }, "groupOrderStatus": { "type": "number" }, "groupInvoiceStatus": { "type": "number" }, "groupReceiptStatus": { "type": "number" }, "projectVisibilityRule": { "type": "string" } } }, "requisitionItemGroups": { "type": "array", "properties": { "requisitionId": { "type": "string" }, "groupId": { "type": "string" }, "totalItems": { "type": "number" }, "approvedAmount": { "type": "number" }, "buyerAmount": { "type": "number" }, "forkingCriteria": { "type": "string" }, "requisitionType": { "type": "number" }, "requesterAction": { "type": "number" }, "workflowId": { "type": "string" }, "linkedPurchaseOrderId": { "type": "string" }, "linkedPurchaseOrderNo": { "type": "string" }, "sendToReadyForApproval": { "type": "boolean" }, "amountToBeApproved": { "type": "number" }, "requisitionItems": { "type": "array", "properties": { "requisitionId": { "type": "string" }, "groupId": { "type": "string" }, "requisitionNo": { "type": "string" }, "itemId": { "type": "string" }, "itemQuantity": { "type": "number" }, "itemPrice": { "type": "number" }, "currency": { "type": "string" }, "sourcingStatus": { "type": "number" }, "sourceType": { "type": "number" }, "itemTotalPrice": { "type": "number" }, "internalComment": { "type": "string" }, "supplierComment": { "type": "string" }, "splitDelivery": { "type": "boolean" }, "splitCostingType": { "type": "number" }, "attachmentIds": ["string"], "approvedQuantity": { "type": "number" }, "quickSourceId": { "type": "string" }, "quickSourceItemId": { "type": "string" }, "contractNo": { "type": "string" }, "contractId": { "type": "string" }, "contractType": { "type": "number" }, "orderable": { "type": "boolean" }, "approvalStatus": { "type": "number" }, "buyerAdded": { "type": "boolean" }, "replacingItemId": { "type": "string" }, "originalReplacedItemId": { "type": "string" }, "definitionId": { "type": "string" }, "assetCode": { "type": "string" }, "assetCodeType": { "type": "number" }, "processEformId": { "type": "string" }, "dynamicFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "dynamicInstanceVersion": { "type": "number" }, "flexibleAccountingFormId": { "type": "string" }, "flexibleAccountingInstanceId": { "type": "string" }, "flexibleAccountingVersion": { "type": "number" }, "purchaseType": { "type": "string" }, "purchaseTypeCode": { "type": "string" }, "lineNo": { "type": "number" }, "assetNumberRequired": { "type": "boolean" }, "assignedBuyers": { "type": "array", "properties": { "assignedBuyer": { "type": "string" }, "assignedBuyerName": { "type": "string" } } }, "assignedOn": { "type": "number" }, "supplierPreferenceType": { "type": "number" }, "itemTaxes": { "type": "array", "properties": { "type": { "type": "string" }, "name": { "type": "string" }, "rate": { "type": "number" }, "compound": { "type": "boolean" } } }, "taxAmount": { "type": "number" }, "status": { "type": "number" }, "sendToReadyForApproval": { "type": "boolean" }, "orderStatus": { "type": "number" }, "receiptStatus": { "type": "number" }, "invoiceStatus": { "type": "number" }, "linkedPurchaseOrderId": { "type": "string" }, "linkedPurchaseOrderNo": { "type": "string" }, "receiptType": { "type": "number" }, "requestedItemPrice": { "type": "number" } } } } }, "requisitionDeliveries": { "type": "array", "properties": { "itemId": { "type": "string" }, "purchaseOrderId": { "type": "string" }, "requisitionId": { "type": "string" }, "lineItemId": { "type": "string" }, "itemQuantity": { "type": "number" }, "approvedQuantity": { "type": "number" }, "businessUnitCode": { "type": "string" }, "locationCode": { "type": "string" }, "deliverToType": { "type": "number" }, "deliverTo": { "type": "string" }, "deliveryOn": { "type": "number" }, "deliveryUpto": { "type": "number" }, "shipToCodeType": { "type": "number" }, "shipToCode": { "type": "string" }, "orderedQuantity": { "type": "number" }, "receivedQuantity": { "type": "number" }, "invoicedQuantity": { "type": "number" }, "assetNumbers": { "type": "array", "properties": { "serialNumber": { "type": "number" }, "assetNumber": { "type": "string" }, "manufacturerSerialNumber": { "type": "string" }, "notes": { "type": "string" } } } } }, "requisitionCostings": { "type": "object", "properties": { "requisitionId": { "type": "string" }, "itemId": { "type": "string" }, "businessUnitCode": { "type": "string" }, "costCenterCode": { "type": "string" }, "value": { "type": "number" }, "budgetId": { "type": "string" }, "budgetLineId": { "type": "string" }, "budgetLineTransactionId": { "type": "string" }, "budgetBaseValue": { "type": "number" }, "projectCode": { "type": "string" }, "splitValue": { "type": "number" } } }, "requisitionAccountings": { "type": "array", "properties": { "requisitionId": { "type": "string" }, "itemId": { "type": "string" }, "accountTypeCode": { "type": "string" }, "generalLedgerCode": { "type": "string" }, "value": { "type": "number" } } }, "items": {
                  "type": "array", "properties": {
                    "itemId": { "type": "string" }, "name": { "type": "string" }, "description": { "type": "string" }, "uom": { "type": "string" }, "currency": { "type": "string" }, "price": { "type": "number" }, "marketPrice": { "type": "number" }, "supplierId": { "type": "string" }, "supplierPartId": { "type": "string" }, "manufacturerName": { "type": "string" }, "manufacturerProductURL": { "type": "string" }, "manufacturerPartId": { "type": "string" }, "imageURL": { "type": "string" }, "thumbnailURL": { "type": "string" }, "supplierProductURL": { "type": "string" }, "leadTime": { "type": "number" },
                    "sourceRefNo": { "type": "string" }, "attachments": ["none"], "itemAttributes": { "type": "object", "properties": {} }, "supplierAddressId": { "type": "string" }, "supplierAddress": { "type": "string" }, "supplierContact": { "type": "string" }, "supplierPhone": { "type": "string" }, "supplierOtherDetails": { "type": "string" }, "supplierContactType": { "type": "string" }, "supplierEmail": { "type": "string" }, "supplierName": { "type": "string" }, "categoryName": { "type": "string" }, "categoryCode": { "type": "string" }, "unsspscCode": { "type": "string" }, "unsspscName": { "type": "string" }, "greenItem": { "type": "boolean" }, "preferredItem": { "type": "boolean" }, "scopeId": { "type": "string" }, "catalogId": { "type": "string" }, "catalogVersion": { "type": "number" }, "catalogItemId": { "type": "number" }, "contractNo": { "type": "string" }, "contractId": { "type": "string" }, "itemType": { "type": "number" }, "sourceType": { "type": "number" }, "receiptType": { "type": "number" }, "contractType": { "type": "number" }
                  }
                }, "supportObjects": { "type": "object", "properties": {} }, "attachmentsDetails": { "type": "array", "properties": { "attachmentId": { "type": "string" }, "comments": { "type": "string" }, "visibility": { "type": "string" }, "name": { "type": "string" }, "size": { "type": "string" } } }
              }
            },
              output = (new (super.responseHandler)(request, result, responseSchema));
            return callback(null, request, output.execute());
          }
        })
      } catch (error) {
        callback(error, null);
      }
    }

    /**
     * Function to fetch default requisition name
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    getDefaultName(request, input, callback) {
      try {
        const http = new (super.httpService)(request);
        const eProcURL = request.productsURL.eProc["soa"];
        const url = eProcURL + '/requisition/defaultname';
        http.get(url, 'requisition-getDefaultName', (error, result) => {
          if (error) {
            callback(error, null);
          } else if (result) {
            callback(null, request, result);
          }
        });
      } catch (error) {
        callback(error, null);
      }
    }

    /**
     * Function to update the requisition
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    update(request, input, callback) {
      try {
          const requisitionIds = {
            "requisition": {
              "requisitionId": request.params.requisition_Id
            },
            "requisitionItemGroups": [
              {
                "requisitionId": request.params.requisition_Id,
                "requisitionItems": [
                  {
                    "requisitionId": request.params.requisition_Id
                  }
                ]
              }
            ],
            "requisitionDeliveries": [
              {
                "requisitionId": request.params.requisition_Id
              }
            ],
            "requisitionCostings": [
              {
                "requisitionId": request.params.requisition_Id
              }
            ],
            "requisitionAccountings": [
              {
                "requisitionId": request.params.requisition_Id
              }
            ]
          };
          const eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/update',
            http = new (super.httpService)(request),
            requestData = super.lodash.merge(request.body, requisitionIds);
          http.post(url, 'updateRequisition', requestData, (error, result) => {
            if (error) {
              return callback(error, null);
          } else {
            const message = { description: "eproc-msg-16" };
            if (!super.lodash.isEmpty(result.data.id)) {
              result.message = [message];
            }
              return callback(null, request, result);
          }
          });
      }
      catch (error) {
        callback(error, null);
      }
    };

    /**
     * Function to create the requisition
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */

    create(request, input, callback) {
      try {
          const eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/update',
            http = new (super.httpService)(request);
          //requestData = super.lodash.merge(defaultRequestData, request.body);
          http.post(url, 'createRequisition', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
          } else {
            const message = { description: "eproc-msg-16" };
            if (!super.lodash.isEmpty(result.data.id)) {
              result.message = [message];
            }
              return callback(null, request, result);
          }
          });
        }
      catch (error) {
        callback(error, null);
      }
    };

    /**
     * Function to check the doublicate requisition name
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    checkDuplicateName(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "requisitionName": "joi.string().required().label('eproc-lable-94__')",
            "requisitionId": "joi.string().allow('').required().label('eproc-lable-78__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/duplicateName';
          http.post(url, 'checkRequisitionsDuplicateName', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result) {
              const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "string" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "boolean", "key": "isDuplicate" } } },
                output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
      * @Method Name : guidedList
      * @Description : Search for guided requisition
      * @return object / Throw Error
      */
    guidedList(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request);
        validationUtility.addCommonSchema('sort');
        validationUtility.addCommonSchema('pagination');
        validationUtility.addCommonSchema('criteriaGroup');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/guidedRequisition/filter';
          http.post(url, 'guidedRequisitionList', request.body, (error, result) => {
            if (error) {
              callback(error, null);
            } else {
              const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "guidedRequisitionId": { "type": "string" }, "categoryEformId": { "type": "string" }, "dynamicFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "categoryCode": { "type": "string" }, "itemId": { "type": "string" }, "itemQuantity": { "type": "number" }, "status": { "type": "number" }, "quickSourceId": { "type": "string" }, "quickSourceItemId": { "type": "string" }, "buyerPreview": { "type": "boolean" }, "item": { "type": "object", "properties": {} } } } } },
                output = new (super.responseHandler)(request, result, responseSchema);
              output.addCommonSchema('pagination', output.responseSchema.properties);
              output.addCommonSchema('ecatalog-item', output.responseSchema.properties.records.properties.item.properties);
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
      * @Method Name : guidedDetails
      * @Description : Get Guided Requisition Details
      * @return object / Throw Error
      */
    guidedDetails(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "itemIds": "joi.array().items(joi.string().min(1).label('eproc-lable-15__')).min(1).unique().required().label('eproc-lable-15__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/guidedRequisition/details';
          http.post(url, 'guidedDetails', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = { "type": "array", "properties": { "itemId": { "type": "string" }, "guidedRequisition": { "type": "object", "properties": { "guidedRequisitionId": { "type": "string" }, "categoryEformId": { "type": "string" }, "dynamicFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "categoryCode": { "type": "string" }, "itemId": { "type": "string" }, "itemQuantity": { "type": "number" }, "status": { "type": "number" }, "quickSourceId": { "type": "string" }, "quickSourceItemId": { "type": "string" }, "buyerPreview": { "type": "boolean" } } }, "guidedRequisitionSuppliers": { "type": "array", "properties": { "supplierId": { "type": "string" }, "supplierType": { "type": "number" }, "name": { "type": "string" }, "location": { "type": "string" }, "addressDetails": { "type": "string" }, "contactPerson": { "type": "string" }, "contactPersonType": { "type": "number" }, "email": { "type": "string" }, "phone": { "type": "string" }, "description": { "type": "string" }, "contractOrderId": { "type": "string" }, "contractOrderNumber": { "type": "string" }, "contractOrderType": { "type": "number" }, "referenceId": { "type": "string" } } }, "supportObjects": { "type": "object", "properties": { "items": { "type": "object", "properties": {} }, "suppliers": { "type": "array", "properties": { "supplierId": { "type": "string" }, "globalSupplierId": { "type": "string" }, "name": { "type": "string" }, "contracted": { "type": "boolean" }, "preffered": { "type": "boolean" }, "status": { "type": "number" }, "mapAddressERPId": { "type": "none" }, "supplierAddress": { "type": "array", "properties": { "tenantId": { "type": "string" }, "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } } } }, "suggestedSuppliers": { "type": "array", "properties": { "suggestedSupplierId": { "type": "string" }, "categoryCode": { "type": "string" }, "name": { "type": "string" }, "location": { "type": "string" }, "addressDetails": { "type": "string" }, "contactPerson": { "type": "string" }, "contactPersonType": { "type": "number" }, "email": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "website": { "type": "string" }, "referenceType": { "type": "number" }, "referenceId": { "type": "string" }, "description": { "type": "string" }, "contractOrderId": { "type": "string" }, "contractOrderNumber": { "type": "string" }, "contractOrderType": { "type": "number" } } } } } } },
                output = new (super.responseHandler)(request, result, responseSchema);
              output.addCommonSchema('ecatalog-item', output.responseSchema.properties.supportObjects.properties.items.properties);
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    getItemsList(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request);
        validationUtility.addCommonSchema('pagination');
        validationUtility.addCommonSchema('sort');
        validationUtility.addCommonSchema('criteriaGroup');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/items/filter';
          http.post(url, 'getRequisitionItemList', request.body, (error, result) => {
            if (error) {
              callback(error, null);
            } else {
              const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": {} } } },
                output = (new (super.responseHandler)(request, result, responseSchema));
              // using fav-item schema as previously used and filter items have same schema
              output.addCommonSchema('favourite-item', output.responseSchema.properties.records.properties);
              output.addCommonSchema('pagination', output.responseSchema.properties);
              const schemaRes = output.execute();
              if (schemaRes.data) {
                schemaRes.data.facetResult = result.data.facetResult;
                schemaRes.data.statResult = result.data.statResult;
              }
              return callback(null, request, schemaRes);
            }
          });
        }
      } catch (error) {
        callback(error, null);
      }
    };

    /**
    * Function to recall requisition
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    recall(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "requisitionId": "joi.string().required().label('eproc-lable-78__')",
            "statusComments": "joi.string().required().label('eproc-lable-364__')",
            "groupId": "joi.string().allow('', null).label('eproc-lable-332__')",
            "roleType": "joi.string().allow('').required().label('eproc-lable-213__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/doTerminateRequisition';
          http.post(url, 'doTerminateRequisition', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result) {
              const responseSchema = { "type": "object", "properties": { "requisitionStatus": { "type": "number" } } };
              if (super.lodash.isEmpty(result.errors)) {
                result.message = "eproc-msg-26";
              }
              const output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * Function to cancel requisition
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    cancel(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "requisitionId": "joi.string().required().label('eproc-lable-78__')",
            "comments": "joi.string().required().label('eproc-lable-196__')",
            "groupId": "joi.string().allow('', null).label('eproc-lable-332__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/cancel';
          http.post(url, 'cancelRequisition', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result) {
              const  responseSchema  =  {  "type":  "object",  "properties": {  "id": {  "type":  "string"  },  "modifiedBy": {  "type":  "string"  },  "modifiedOn": {  "type":  "date"  } } };
              if (super.lodash.isEmpty(result.errors)) {
                result.message = "eproc-msg-25";
              }
              const output  =  (new  (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * @Name : destroy
    * @Description : This method is used to delete a requisition
    * @return : object
    */
    destroy(request, input, callback) {
      try {
        let validationUtility = super.utils.validationUtility(request);
        let schema = {
          "requisition_Id":  "joi.string().required().label('eproc-lable-6__')"
        };
        validationUtility.addInternalSchema(schema);
        let result = validationUtility.validate({ "requisition_Id": request.params.requisition_Id });
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request);
          const eProcURL = request.productsURL.eProc["soa"];
          const url = eProcURL + '/requisition/' + request.params.requisition_Id + '/deleteRequisition';
          http.delete(url, 'deleteRequisition', (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const message = { description: "eproc-msg-27" };
              if (!super.lodash.isEmpty(result.data.id)) {
                result.message = [message];
              }
              let responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" } } };
              const output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * Function to close requisition
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    close(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "requisitionId": "joi.string().required().label('eproc-lable-78__')",
            "comments": "joi.string().allow('', null).label('eproc-lable-196__')",
            "groupId": "joi.string().allow('', null).label('eproc-lable-332__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);

        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);

        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = `${eProcURL}/requisition/close`;

          http.post(url, 'closeRequisition', request.body, (error, result) => {
            if (error) {
              callback(error, null);
            } else if (result) {
              const  responseSchema  =  {  "type":  "object",  "properties": {  "id": {  "type":  "string"  },  "modifiedBy": {  "type":  "string"  },  "modifiedOn": {  "type":  "date"  } } };
              if (super.lodash.isEmpty(result.errors)) {
                result.message = "eproc-msg-25";
              }
              const output = (new  (super.responseHandler)(request, result, responseSchema));
              callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
     * Function to get requisition details
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
     getRequisitionDetails(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "entityType": "joi.string().required().label('eproc-lable-356__')",
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "version": "joi.number().required().label('eproc-lable-72__')",
            "useSnapshot": "joi.boolean().allow('', null).label('eproc-lable-373__')",
            "view": "joi.boolean().allow('', null).label('eproc-lable-374__')",
            "requireDependent": "joi.boolean().required().label('eproc-lable-375__')",
            "requireScopeValidation": "joi.boolean().required().label('eproc-lable-376__')",
            "validateByScopeOnly": "joi.boolean().allow('', null).label('eproc-lable-377__')",
            "buyerDesk": "joi.boolean().allow('', null).label('eproc-lable-378__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(super.lodash.merge(request.body, { "entityId": request.params.requisition_Id }));
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else {
          request.body.emailAddress = request.user.emailId;
          const http = new (super.httpService)(request);
          const eProcURL = request.productsURL.eProc["soa"];
          const url = eProcURL + '/requisition/details';
          http.post(url, 'getRequisitionDetails', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
                let responseSchema = {"type":"object","properties":{"action":{"type":"string"},"role":{"type":"string"},"submit":{"type":"boolean"},"checkedItemIds":{"type":"array"},"beforeApproval":{"type":"boolean"},"forkingRequired":{"type":"boolean"},"changedGroupId":{"type":"string"},"guidedRequisitions":{"type":"array","properties":{"guidedRequisitionId":{"type":"string"},"categoryEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"categoryCode":{"type":"string"},"itemId":{"type":"string"},"itemQuantity":{"type":"number"},"status":{"type":"number"},"quickSourceId":{"type":"string"},"quickSourceItemId":{"type":"string"}}},"guidedSuppliers":{"type":"object","properties":{"supplierId":{"type":"string"},"supplierType":{"type":"number"},"name":{"type":"string"},"location":{"type":"string"},"addressDetails":{"type":"string"},"contactPerson":{"type":"string"},"contactPersonType":{"type":"number"},"email":{"type":"string"},"phone":{"type":"string"},"fax":{"type":"string"},"website":{"type":"string"},"description":{"type":"string"},"contractOrderId":{"type":"string"},"contractOrderNumber":{"type":"string"},"contractOrderType":{"type":"number"},"referenceId":{"type":"string"}}},"requisition":{"type":"object","properties":{"modifiedOn":{"type":"none"},"['modifiedOn']":{"type":"none","key":"modifiedOnFormat"},"status":{"type":"number"},"createdBy":{"type":"string"},"version":{"type":"string"},"requisitionId":{"type":"string"},"parentRequisitionId":{"type":"string"},"referenceRequisitionId":{"type":"string"},"requisitionNo":{"type":"string"},"name":{"type":"string"},"urgent":{"type":"boolean"},"behalfUserId":{"type":"string"},"department":{"type":"string"},"buyingJustification":{"type":"string"},"supplierComments":{"type":"string"},"companyCode":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"baseCurrency":{"type":"string"},"baseExchangeRate":{"type":"number"},"baseTotal":{"type":"number"},"guided":{"type":"boolean"},"purchaseTypeString":{"type":"string"},"purchaseTypeCode":{"type":"string"},"submittedOn":{"type":"number"},"approvedOn":{"type":"number"},"receivedOn":{"type":"number"},"closedOn":{"type":"number"},"resubmitionCount":{"type":"number"},"avgOrderTime":{"type":"number"},"totalItems":{"type":"number"},"currency":{"type":"string"},"totalAmount":{"type":"number"},"sendPOToSupplier":{"type":"boolean"},"approvedAmount":{"type":"number"},"buyerAmount":{"type":"number"},"amountToBeApproved":{"type":"number"},"workflowId":{"type":"string"},"workflowInstanceId":{"type":"string"},"rejectedItemCount":{"type":"number"},"processEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"flexibleAccountingFormId":{"type":"string"},"flexibleAccountingInstanceId":{"type":"string"},"flexibleAccountingVersion":{"type":"string"},"shipToCodeType":{"type":"number"},"shipToCode":{"type":"string"},"billToCode":{"type":"string"},"invoiceToCode":{"type":"string"},"deliverToType":{"type":"number"},"deliverTo":{"type":"string"},"deliveryOn":{"type":"none"},"paymentMethod":{"type":"number"},"paymentTransactionId":{"type":"string"},"paymentId":{"type":"string"},"canResubmit":{"type":"boolean"},"splitCostingLevel":{"type":"number"},"splitCostingType":{"type":"number"},"requesterAction":{"type":"number"},"orderStatus":{"type":"number"},"receiptStatus":{"type":"number"},"invoiceStatus":{"type":"number"},"retrospectivePurchase":{"type":"boolean"},"utilizeBudget":{"type":"boolean"},"budgetSettingsMap":{"type":"object","properties":{}},"attachmentIds":{"type":"none"},"statusBuyerNegotiated":{"type":"number"},"statusRequesterNegotiated":{"type":"number"},"statusBudgetary":{"type":"number"},"statusNeedAQuote":{"type":"number"},"requisitionType":{"type":"number"},"inventory":{"type":"boolean"},"assignedBuyerType":{"type":"number"},"assignedBuyer":{"type":"string"},"assignedBuyers":{"type":"array","properties":{"assignedBuyer":{"type":"string"},"assignedBuyerType":{"type":"number"},"assignedBuyerName":{"type":"string"}}},"linkedPurchaseOrderId":{"type":"string"},"linkedPurchaseOrderNo":{"type":"string"},"assignedOn":{"type":"number"},"origin":{"type":"number"},"externalId":{"type":"string"},"assignProject":{"type":"boolean"},"projectSettingStatus":{"type":"string"},"purchaseTypeSetting":{"type":"boolean"},"ptGLAccountSetting":{"type":"boolean"},"erpId":{"type":"string"},"sendToReadyForApproval":{"type":"boolean"},"hasBuyerItem":{"type":"boolean"},"sourcingStatusSettingMap":{"type":"object","properties":{"QUOTED_BY_SUPPLIER":{"type":"string"},"ESTIMATED_PRICE":{"type":"string"},"NEED_A_QUOTE":{"type":"string"}}},"updatedOn":{"type":"number"},"assetCodeSetting":{"type":"boolean"},"utilizeContract":{"type":"string"},"transferredTo":{"type":"string"},"retrospectiveSendPOSupplier":{"type":"boolean"},"retrospectiveLetUserDecide":{"type":"boolean"},"requisitionToExistingPOSetting":{"type":"boolean"},"purchaseTypeAtLineLevel":{"type":"boolean"},"allowedBackdateDays":{"type":"number"},"allowedSuggestedSupplier":{"type":"boolean"},"approvalIntegrationStatus":{"type":"number"},"externalIntegrationStatus":{"type":"number"},"totalTaxAmount":{"type":"number"},"grossTotalAmount":{"type":"number"},"buyerReviewSettingStatus":{"type":"boolean"},"reopenedRequisition":{"type":"boolean"},"groupStatus":{"type":"number"},"groupOrderStatus":{"type":"number"},"groupInvoiceStatus":{"type":"number"},"groupReceiptStatus":{"type":"number"},"projectVisibilityRule":{"type":"string"}}},"requisitionItemGroups":{"type":"array","properties":{"requisitionId":{"type":"string"},"status":{"type":"number"},"groupId":{"type":"string"},"totalItems":{"type":"number"},"approvedAmount":{"type":"number"},"buyerAmount":{"type":"number"},"forkingCriteria":{"type":"string"},"requisitionType":{"type":"number"},"requesterAction":{"type":"number"},"workflowId":{"type":"string"},"workflowInstanceId":{"type":"string"},"linkedPurchaseOrderId":{"type":"string"},"linkedPurchaseOrderNo":{"type":"string"},"sendToReadyForApproval":{"type":"boolean"},"amountToBeApproved":{"type":"number"},"requisitionItems":{"type":"array","properties":{"requisitionId":{"type":"string"},"groupId":{"type":"string"},"supplierName":{"type":"string"},"requisitionNo":{"type":"string"},"workflowId":{"type":"string"},"workflowInstanceId":{"type":"string"},"itemId":{"type":"string"},"itemQuantity":{"type":"number"},"itemPrice":{"type":"number"},"currency":{"type":"string"},"sourcingStatus":{"type":"number"},"sourceType":{"type":"number"},"itemTotalPrice":{"type":"number"},"internalComment":{"type":"string"},"supplierComment":{"type":"string"},"splitDelivery":{"type":"boolean"},"splitCostingType":{"type":"number"},"attachmentIds":{"type":"none"},"approvedQuantity":{"type":"number"},"quickSourceId":{"type":"string"},"quickSourceItemId":{"type":"string"},"contractNo":{"type":"string"},"contractId":{"type":"string"},"contractType":{"type":"number"},"orderable":{"type":"boolean"},"approvalStatus":{"type":"number"},"buyerAdded":{"type":"boolean"},"replacingItemId":{"type":"string"},"originalReplacedItemId":{"type":"string"},"definitionId":{"type":"string"},"assetCode":{"type":"string"},"assetCodeType":{"type":"number"},"processEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"dynamicInstanceVersion":{"type":"number"},"flexibleAccountingFormId":{"type":"string"},"flexibleAccountingInstanceId":{"type":"string"},"flexibleAccountingVersion":{"type":"number"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"lineNo":{"type":"number"},"assetNumberRequired":{"type":"boolean"},"assignedBuyers":{"type":"array","properties":{"assignedBuyer":{"type":"string"},"assignedBuyerType":{"type":"number"},"assignedBuyerName":{"type":"string"}}},"assignedOn":{"type":"number"},"supplierPreferenceType":{"type":"number"},"itemTaxes":{"type":"array","properties":{"type":{"type":"string"},"name":{"type":"string"},"rate":{"type":"number"},"compound":{"type":"boolean"}}},"taxAmount":{"type":"number"},"status":{"type":"number"},"sendToReadyForApproval":{"type":"boolean"},"orderStatus":{"type":"number"},"receiptStatus":{"type":"number"},"invoiceStatus":{"type":"number"},"linkedPurchaseOrderId":{"type":"string"},"linkedPurchaseOrderNo":{"type":"string"},"receiptType":{"type":"number"},"requestedItemPrice":{"type":"number"},"purchaseOrderId":{"type":"string"},"uom":{"type":"string"},"itemType":{"type":"number"},"projectVisibilityRule":{"type":"string"},"supplierId":{"type":"string"},"description":{"type":"string"},"categoryCode":{"type":"string"},"itemName":{"type":"string"}}}}},"requisitionDeliveries":{"type":"array","properties":{"itemId":{"type":"string"},"requisitionId":{"type":"string"},"lineItemId":{"type":"string"},"itemQuantity":{"type":"number"},"approvedQuantity":{"type":"number"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"deliverToType":{"type":"number"},"deliverTo":{"type":"string"},"deliveryOn":{"type":"none"},"deliveryUpto":{"type":"number"},"shipToCodeType":{"type":"number"},"shipToCode":{"type":"string"},"orderedQuantity":{"type":"number"},"receivedQuantity":{"type":"number"},"invoicedQuantity":{"type":"number"},"purchaseOrderId":{"type":"string"},"assetNumbers":{"type":"array","properties":{"serialNumber":{"type":"number"},"assetNumber":{"type":"string"},"manufacturerSerialNumber":{"type":"string"},"notes":{"type":"string"}}}}},"requisitionCostings":{"type":"array","properties":{"requisitionId":{"type":"string"},"itemId":{"type":"string"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"value":{"type":"number"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"budgetBaseValue":{"type":"number"},"projectCode":{"type":"string"},"splitValue":{"type":"number"}}},"requisitionAccountings":{"type":"array","properties":{"requisitionId":{"type":"string"},"itemId":{"type":"string"},"accountTypeCode":{"type":"string"},"generalLedgerCode":{"type":"string"},"value":{"type":"number"}}},"items":{"type":"array","properties":{"itemId":{"type":"string"},"supplierPartId":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"uom":{"type":"string"},"currency":{"type":"string"},"price":{"type":"number"},"marketPrice":{"type":"number"},"supplierId":{"type":"string"},"manufacturerName":{"type":"string"},"manufacturerProductURL":{"type":"string"},"manufacturerPartId":{"type":"string"},"imageURL":{"type":"string"},"thumbnailURL":{"type":"string"},"supplierProductURL":{"type":"string"},"leadTime":{"type":"number"},"sourceRefNo":{"type":"string"},"attachments":{"type":"array","properties":{}},"itemAttributes":{"type":"none"},"supplierAddressId":{"type":"string"},"supplierAddress":{"type":"string"},"supplierContact":{"type":"string"},"supplierPhone":{"type":"string"},"supplierOtherDetails":{"type":"string"},"supplierContactType":{"type":"string"},"supplierEmail":{"type":"string"},"supplierName":{"type":"string"},"categoryName":{"type":"string"},"categoryCode":{"type":"string"},"unsspscCode":{"type":"string"},"unsspscName":{"type":"string"},"greenItem":{"type":"boolean"},"preferredItem":{"type":"boolean"},"scopeId":{"type":"string"},"catalogId":{"type":"string"},"catalogVersion":{"type":"number"},"catalogItemId":{"type":"number"},"contractNo":{"type":"string"},"contractId":{"type":"string"},"itemType":{"type":"number"},"sourceType":{"type":"number"},"receiptType":{"type":"number"},"contractType":{"type":"number"}}},"supportObjects":{"type":"object","properties":{"categories":{"type":"none"},"purchaseTypes":{"type":"none"},"guidedRequisitionSuppliers":{"type":"none"},"categoryDynamicFormInstances":{"type":"none"},"processDynamicFormInstance":{"type":"none"},"budgets":{"type":"none"},"budgetLines":{"type":"none"},"attachments":{"type":"array","properties":{}},"companies":{"type":"none"},"businessUnits":{"type":"none"},"addresses":{"type":"none"},"customAddresses":{"type":"none"},"locations":{"type":"none"},"costCenters":{"type":"none"},"projects":{"type":"none"},"accountTypes":{"type":"none"},"generalLedgers":{"type":"none"},"userGroups":{"type":"none"},"users":{"type":"none"},"assets":{"type":"none"},"parentRequisition":{"type":"none"},"itemOrderedStatuses":{"type":"none"}}},"attachmentsDetails":{"type":"array","properties":{"attachmentId":{"type":"string"},"comments":{"type":"string"},"visibility":{"type":"string"},"name":{"type":"string"},"size":{"type":"string"}}}}};
                const output = (new (super.responseHandler)(request, result, responseSchema));
                output.addCommonSchema('attachments', output.responseSchema.properties.supportObjects.properties.attachments.properties);
                output.addCommonSchema('attachments', output.responseSchema.properties.items.properties.attachments.properties);
                return callback(null, request, output.execute());   
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * Function to add AuditTrail Comment
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    addAuditTrailComment(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "entityType": "joi.string().required().label('eproc-lable-356__')",
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "version": "joi.number().required().label('eproc-lable-72__')",
            "parentAuditTrailId": "joi.string().allow('', null).label('eproc-lable-373__')",
            "event": "joi.string().required().label('eproc-lable-390__')",
            "comments": "joi.string().allow('', null).label('eproc-lable-196__')",
            "attachmentIds": "joi.array().label('eproc-lable-194__').unique().label('eproc-lable-194__')",
            "role": "joi.string().allow('', null).label('eproc-lable-213__')",
            "toUserId": "joi.array().label('eproc-lable-194__').unique().label('eproc-lable-391__')",
            "visibleTo": "joi.array().label('eproc-lable-194__').unique().label('eproc-lable-392__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/addAuditTrailComment';
          http.post(url, 'addAuditTrailComment', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "date" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * Function to get AuditTrail Detail
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    getAuditTrailDetail(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "entityType": "joi.string().required().label('eproc-lable-356__')",
            "entityId": "joi.string().required().label('eproc-lable-357__')",
            "entityVersion": "joi.number().required().label('eproc-lable-394__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.entityList),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/auditTrail/Details';
          http.post(url, 'getAuditTrailDetail', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "auditTrailId": { "type": "string" }, "parentAuditTrailId": { "type": "string" }, "entityType": { "type": "string" }, "entityId": { "type": "string" }, "version": { "type": "number" }, "event": { "type": "string" }, "comments": { "type": "string" }, "attachmentIds": { "type": "none" }, "role": { "type": "string" }, "auditVariables": { "type": "none" }, "attachmentsStr": { "type": "none" }, "auditVariablesStr": { "type": "none" } } },
                output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
     * Function to copy a requisition
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    copy(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "requisitionId": "joi.string().required().label('eproc-lable-357__')",
            "includeCartItems": "joi.boolean().label('eproc-lable-444__')",
            "requireDependent": "joi.boolean().label('eproc-lable-375__')"
          };
        validationUtility.addInternalSchema(schema);
        request.body = super.lodash.merge(request.body, { "requisitionId": request.params.requisition_Id });
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          request.body.emailAddress = request.user.emailId;
          const http = new (super.httpService)(request),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/copyRequisition';
          http.post(url, 'copyRequisition', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              return callback(null, request, result);
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    };

    /**
    * Function to validateRequisition details
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    validateRequisition(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "requisitionId": "joi.string().required().label('eproc-lable-6__')",
            "role": "joi.string().required().label('eproc-lable-213__')",
            "newItemIds": "joi.array().items(joi.string().min(1).label('eproc-lable-3__')).unique().label('eproc-lable-3__')"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/validateRequisitionDetails';
          http.post(url, 'validateRequisitionDetails', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const output = { "data": {} };
              if (result.data && result.data.error && result.data.errors) {
                output.data.errors = {};
                for (let key in result.data.errors) {
                  output.data[key] = result.data.errors[key];
                  output.data.errors[key] = super.utils.translate(request, key);
                }
                output.data.error = true;
              } else {
                output.data.error = false;
              }
              return callback(null, request, output);
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * Function to doValidateRequisitions
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
   doValidateRequisitions(request, input, callback) {
    try {
      const validationUtility = super.utils.validationUtility(request),
        schema = {
          "ids": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required().label('eproc-lable-15__')"
        };
      validationUtility.addInternalSchema(schema);
      const result = validationUtility.validate(request.body);
      if (result) {
        const errorMsg = new (super.customError)(result, 'ValidationError', 3);
        callback(errorMsg, null);
      } else {
        const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
          eProcURL = request.productsURL.eProc["soa"],
          url = eProcURL + '/requisition/doValidateRequisitions';
          
        http.post(url, 'doValidateRequisitions', request.body, (error, result) => {
          if (error) {
            return callback(error, null);
          } else {
            return callback(null, request, result);
          }
        });
      }
    } catch (error) {
      return callback(error, null);
    }
  }

    /**
    * @description : Function to validate Guided Requisition Contarct Items details
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    validateContractItems(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request);
        validationUtility.validObj = false;
        const schema = {
          "supplierId": "joi.string().required().label('eproc-lable-123__')",
          "contractId": "joi.string().required().label('eproc-lable-150__')",
          "contractNo": "joi.string().required().label('eproc-lable-149__')"
        };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntities, null),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/guidedRequisition/validateContractItems';
          http.post(url, 'validateGuidedRequisitionContractItems', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result.data && result.data.id) {
              const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "number" }, "modifiedBy": { "type": "string" }, "info1": { "type": "boolean", "key": "isValid" }, "info2": { "type": "string" } } },
                output = (new (super.responseHandler)(request, result, responseSchema));
              return callback(null, request, output.execute());
            } else {
              return callback(null, request, result);
            }
          });
        }

      } catch (error) {
        return callback(err, null);
      }
    }

    /**
    * @description : Function to validate Guided Requisition BPO Items details
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    validateBPOItems(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request);
        validationUtility.validObj = false;
        const schema = {
          "supplierPartId": "joi.string().allow(['',null]).label('eproc-lable-125__')",
          "price": "joi.number().label('eproc-lable-138__')",
          "taxAmount": "joi.number().label('eproc-lable-178__')",
          "categoryCode": "joi.string().allow(['',null]).label('eproc-lable-448__')",
          "currency": "joi.string().allow(['',null]).label('eproc-lable-48__')",
          "quantity": "joi.number().label('eproc-lable-1__')",
          "companyCode": "joi.string().allow(['',null]).label('eproc-lable-56__')",
          "businessUnitCode": "joi.string().allow(['',null]).label('eproc-lable-57__')",
          "locationCode": "joi.string().allow(['',null]).label('eproc-lable-58__')",
          "costCenterCodes": "joi.array().items(joi.string().label('eproc-lable-60__')).unique().label('eproc-lable-60__')",
          "itemType": "joi.number().label('eproc-lable-152__')",
          "receivedBy": "joi.number().label('eproc-lable-445__')",
          "purchaseOrderDetails": "joi.array().items(joi.object().keys({purchaseOrderId: joi.string().required().label('eproc-lable-70__'),purchaseOrderNumber: joi.string().label('eproc-lable-446__')})).unique().label('eproc-lable-447__')"
        };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntities, null),
            eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/guidedRequisition/validateBPOItems';
          http.post(url, 'validateGuidedRequisitionBPOItems', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              return callback(null, request, result);
            }
          });
        }
      } catch (error) {
        return callback(err, null);
      }
    }
 
    /**
     * @description : Function to assign buyer to requisition
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    doAssignBuyer(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "requisitionId": "joi.string().required()",
            "comments": "joi.string().allow('')",
            "modifiedOn": "joi.string().allow('')",
            "requisitionItemId": "joi.string()",
            "requisitionAssignedBuyers": "joi.array().items(joi.object())",
            "requisitionRemovedBuyers": "joi.array().items(joi.object())"
          };
        // requisitionAssignedBuyers and requisitionRemovedBuyers need to map more as per request body
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else{
          const eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/assignBuyer',
            http = new (super.httpService)(request);
          http.post(url, 'assignBuyer', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result) {
              const message = { description: "EPROC-50000" };
              if (!super.lodash.isEmpty(result.errors)) {
                result.message = [message];
              }
              return callback(null, request, result);
            }
          });
        }
      }
      catch (error) {
        callback(error, null);
      }
    };
    /**
     * @description : Function to returnRequisition
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    doReturnRequisition(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "requisitionId": "joi.string().required()",
            "returnComments": "joi.string().required()",
            "action": "joi.string().required()",
            "groupId": "joi.string()",
            "canResubmit": "joi.boolean()",
            "itemIds": "joi.array()"
          };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          callback(errorMsg, null);
        } else{
          const eProcURL = request.productsURL.eProc["soa"],
            url = eProcURL + '/requisition/returnRequisition',
            http = new (super.httpService)(request);
          http.post(url, 'returnRequisition', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result) {
              const message = { description: "EPROC-40186" };
              if (!super.lodash.isEmpty(result.errors)) {
                result.message = [message];
              }
              return callback(null, request, result);
            }
          });
        }
      }
      catch (error) {
        callback(error, null);
      }
    };


  }
  return Requisition;
};