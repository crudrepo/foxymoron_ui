/**
 * Buyer Controller
 *
 * @description :: Provides user and userGroup related search operation.
 */

module.exports = (parentClass)=> {
    
        class BuyerGroup extends parentClass {

            /**
            * @Method Name : getUsers
            *
            * @Description : get the buyer group users
            * @return object / Throw Error
            */

            getUsers(request, input, callback) {
                try {
                    const validationUtility = super.utils.validationUtility(request),
                        schema = {
                            "buyergroup_Id":  "joi.required().label('eproc-lable-371__')"
                        };
                    validationUtility.addInternalSchema(schema);
                    const result = validationUtility.validate({ "buyergroup_Id": request.params.buyergroup_Id });
                    if (result) {
                        const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                        return callback(errorMsg, null);
                    } else {
                        const http = new (super.httpService)(request,super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                            eProcURL = request.productsURL.eProc["soa"],
                            url = eProcURL + '/user/group/' + request.params.buyergroup_Id;
                        http.get(url, 'getAssignBuyerGroupUsers', (error, result) => {
                            if (error) {
                                return callback(error, null);
                            } else {
                                const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"userId":{"type":"boolean"},"type":{"type":"number"},"emailId":{"type":"string"},"displayName":{"type":"string"},"firstName":{"type":"string"},"lastName":{"type":"string"},"designation":{"type":"string"},"department":{"type":"string"},"currency":{"type":"string"},"numberFormat":{"type":"string"},"fomattedNumberFormat":{"type":"string"},"dateFormat":{"type":"string"},"timeFormat":{"type":"string"},"salutation":{"type":"string"},"locale":{"type":"string"},"timeZone":{"type":"string"},"decimalPrecision":{"type":"number"},"reportingManagerId":{"type":"string"},"active":{"type":"boolean"},"erpId":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                                return callback(null, request, output);
                            }
                        });
                    }
                } catch (error) {
                    return callback(error, null);
                }
            };
        }

    return BuyerGroup;    
};
    