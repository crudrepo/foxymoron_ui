"use strict";
module.exports = (parentClass) => {

    class Catalog extends parentClass { 

        getFavOrPUCatalogList(request, input, callback) {
            try {
                const eProcURL = request.productsURL.eProc["soa"],
                    http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    url = eProcURL + input.URL;
                http.post(url, 'getFavOrPUCatalogList', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else if (result) {
                        const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "createdOn": { "type": "date" }, "favourite": { "type": "boolean" }, "modifiedOn": { "type": "date" }, "releaseDate": { "type": "date" }, "publishedOn": { "type": "date" }, "supplierValidFrom": { "type": "date" }, "supplierValidTo": { "type": "date" }, "validFrom": { "type": "date" }, "validTo": { "type": "date" }, "submittedOn": { "type": "date" }, "status": { "type": "number" }, "version": { "type": "number" }, "contractType": { "type": "number" }, "totalCount": { "type": "number" }, "errorCount": { "type": "number" }, "addedCount": { "type": "number" }, "updatedCount": { "type": "number" }, "removedCount": { "type": "number" }, "supplierContactType": { "type": "number" }, "source": { "type": "number" }, "catalogType": { "type": "number" }, "itemMasterType": { "type": "number" }, "extendedVersion": { "type": "number" }, "supplierName": { "type": "string" }, "supplierId": { "type": "string" }, "supplierVersion": { "type": "string" }, "supplierCatalogName": { "type": "string" }, "supplierAddressId": { "type": "string" }, "supplierContact": { "type": "string" }, "supplierEmail": { "type": "string" }, "transactionId": { "type": "string" }, "contractNo": { "type": "string" }, "contractId": { "type": "string" }, "catalogId": { "type": "string" }, "warehouseCode": { "type": "string" }, "name": { "type": "string" }, "description": { "type": "string" }, "systemAttributesString": { "type": "string" }, "multipleSuppliers": { "type": "boolean" }, "updated": { "type": "boolean" }, "publishing": { "type": "boolean" }, "sendToReadyForApproval": { "type": "boolean" }, "approvalRequired": { "type": "boolean" }, "buyerAmend": { "type": "boolean" } } } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        output.addCommonSchema('pagination', output.responseSchema.properties);
                        return callback(null, request, output.execute());
                    }
                });


            } catch (error) {
                callback(error, null);
            }
        }
        getCatalogList(request, input, callback) {
            try {
                super.async.waterfall([
                    (methodCallback) => {
                        //1: retrive catalogs from ecatalog
                        const ecatalogHook = new (super.ecatalogHook({request: request}))();
                        ecatalogHook.getCatalogList(request, 'getCatalogList', (error, request, result) => {
                            if (error) {
                                return methodCallback(error, null);
                            }
                            else {
                                return methodCallback(null, request, result);
                            }
                        });
                    },
                    (request, response, methodCallback) => {
                        if (response.data.records.length > 0) {
                            const reqdata = {
                                "entityType": "CATALOG",
                                "entityIds": []
                            }
                            super.lodash.forEach(response.data.records, function (item) {
                                reqdata.entityIds.push(item.catalogId)
                            });
                            //2: retrive catalogs favourites from eproc
                            const eprocHook = new (super.eprocHook({request: request}))();
                            eprocHook.getfavoriteList(request, reqdata, (error, request, result) => {
                                if (error) {
                                    return methodCallback(error, null);
                                }
                                else {
                                    super.lodash.forEach(response.data.records, function (item) {
                                        if (result.data[item.catalogId]) {
                                            item.favourite = result.data[item.catalogId];
                                        } else {
                                            item.favourite = false;
                                        }
                                    });
                                    return methodCallback(null, request, response);
                                }
                            });
                        } else {
                            return methodCallback(null, request, schemaRes);
                        }
                    }
                ],
                    (error, request, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }

                    });
            } catch (error) {
                return callback(error, null);
            }
        }

        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "name": "joi.string().alphanum().min(3).max(30).label('eproc-lable-4__')"
                    };
                validationUtility.addCommonSchema('pagination');
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/catalogs/search',
                        requestData = {
                            maxRows: request.body.perPageRecords,
                            pageNumber: request.body.pageNo,
                            name: request.body.name
                        };
                    http.post(url, 'catalogs', requestData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else if (result) {
                            callback(null, request, result.catalogs);
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        getDataList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const schema = {
                    "isType": "joi.string().alphanum().min(3).max(30).label('eproc-lable-358__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    input = {}
                    if (!("isType" in request.body)) {
                        //property does not exists
                        request.body.isType = 'all';
                    }
                    // switch case
                    switch (request.body.isType.toLowerCase()) {
                        case 'previouslyused':
                            input.URL = '/previouslyUsed/catalog/filter'
                            this.getFavOrPUCatalogList(request, input, callback);
                            break;
                        case 'favourite':
                            input.URL = '/favourites/catalog/filter';
                            this.getFavOrPUCatalogList(request, input, callback);
                            break;
                        default:
                            this.getCatalogList(request, input, callback);
                            break;
                    }

                }
            } catch (error) {
                callback(error, null);
            }
        };
    }
    return Catalog;
};

