"use strict";
const rm = require('@service/require.module')();

class Authorization {

  constructor(){
    this.productName = null;
    this.accessControls = null;
  }

  authorize(request, callback) {
    try {
      if (this.productName != 'dd' && this.accessControls != null) {
        const access = request.user.access,
          filterProductList = rm.lodash.filter(access, (item) => { return item.productInfo.name.toLowerCase() === this.productName; }),
          productAccess = (filterProductList.length > 0) ? filterProductList[0] : [];
        if (!rm.lodash.isEmpty(productAccess)) {
          if (typeof productAccess != "undefined") {
            const activities = productAccess.activities;
            const roles = productAccess.roles;
            if (eval(this.accessControls)) {
              callback(null, true);
            } else {
              const errorMsg = new rm.customError("dd-error-8", 'AppError', 8);
              errorMsg.statusCode = 403;
              callback(errorMsg, request);
            }
          } else {
            const errorMsg = new rm.customError("dd-error-9", 'AppError', 9);
            errorMsg.statusCode = 403;
            callback(errorMsg, request);
          }
        } else {
          const errorMsg = new rm.customError("dd-error-9", 'AppError', 9);
          errorMsg.statusCode = 403;
          callback(errorMsg, request);
        }
      } else {
        callback(null, true);
      }
    } catch (error) {
      callback(error, null);
    }
  }

  containsAll(productAccess, userAccess) {
    if (rm.lodash.isArray(productAccess) && rm.lodash.isArray(userAccess)) {
      return rm.lodash.intersectionWith(productAccess, userAccess, rm.lodash.isEqual).length == userAccess.length
    } else {
      return false;
    }
  }

  containsAny(productAccess, userAccess) {
    if (rm.lodash.isArray(productAccess) && rm.lodash.isArray(userAccess)) {
      return rm.lodash.intersectionWith(productAccess, userAccess, rm.lodash.isEqual).length > 0
    } else {
      return false;
    }
  }

}

exports.Authorization = Authorization;
