"use strict";
const rm = require('@service/require.module')();

exports.isValid = (req, res, next) => {
  try {    
    if(!rm.lodash.isEmpty(req.tokenId)){
      const tms = new (rm.tmsHook({request: req}))();
      tms.validateToken(req, (error, result) => {
          if (error || rm.lodash.isEmpty(result)) {              
            const data = {"redirectUrl" : rm.uiConfig.TMS_Web.SMT_LOGIN_URL};
            //return invalid token error
            rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'tms-error-401'), "statusCode":401, "lang":req.getLocale(), "data":data});            
          }else {
            req.userEmail = require('querystring').unescape(result);
            next();
          }
      });       
    }else{
      const data = {"redirectUrl" : rm.uiConfig.TMS_Web.SMT_LOGIN_URL};
      //return invalid token error
      rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'tms-error-401'),"statusCode":401, "lang":req.getLocale(), "data":data});
    }    
  } catch (error) {
      next(error);
  }
}
