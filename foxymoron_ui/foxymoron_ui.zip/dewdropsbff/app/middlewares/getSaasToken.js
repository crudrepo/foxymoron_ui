"use strict";

 exports.getSaasTokenId = (req, res, next) => {  
   if(typeof req.headers.cookie !== "undefined"){        
      const tokenId = req.headers.cookie.match( /(; )?SAAS_COMMON_BASE_TOKEN_ID=([^;]*);?/ );
      if(typeof tokenId !== "undefined" && tokenId !== null && tokenId !== ""){
          req.tokenId = tokenId[2];
      }   
   }  
   req.tokenId =   req.query.tokenId || req.tokenId;
   next();
}
