/**
 * @name : SSO.Filter
 * @description : It validates the token and checks for IP and browser restruction if the user is enabled with the restrictionit redirects to login page 
 */


"use strict";
const rm = require('@service/require.module')();

exports.isValid = (req, res, next) => {
  try {
    const errorData = { "redirectUrl": rm.uiConfig.TMS_Web.SMT_LOGIN_URL };
    if (!rm.lodash.isEmpty(req.tokenId)) {
      const tms = new (rm.tmsHook({request: req}))();      
      tms.ssoFilter(req, null, (error, result) => {
        const decodeResult = decodeURIComponent(result.toString());
        req.userSSOString = decodeURIComponent(result.toString().replace(/\+/g, ' '));
        if (error || rm.lodash.isEmpty(result) || decodeResult.indexOf('com.zycus.management.sso.exception.InvalidSourceIPException') > -1) {
          rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'tms-error-401'), "statusCode":401, "lang":req.getLocale(), "data":errorData});          
        } else {
          const ssoData = rm.utils.tryParse(decodeResult);
          if (rm.lodash.isObject(ssoData) && !rm.lodash.isEmpty(ssoData)) {
            const keyName = (Object.keys(ssoData).length == 1) ? Object.keys(ssoData)[0] : null;
            if (keyName) {
              req.userSSODetails = ssoData[keyName];
              return next();
            }
            return rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'tms-error-401'), "statusCode":401, "lang":req.getLocale(), "data":errorData});
          }
          return rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'tms-error-401'), "statusCode":401, "lang":req.getLocale(), "data":errorData});
        }
      });
    } else {
      rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'tms-error-401'), "statusCode":401, "lang":req.getLocale(), "data":errorData});
    }
  } catch (error) {
    next(error);
  }
}
