"use strict";
const rm = require('@service/require.module')();

exports.notFoundAPIURL = (req, res, next) => {   
  rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'dd-error-404'), "statusCode":404, "lang":req.getLocale()});    
  next();
}
