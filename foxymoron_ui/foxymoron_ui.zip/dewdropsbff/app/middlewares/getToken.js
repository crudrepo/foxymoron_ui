"use strict";
const rm = require('@service/require.module')();

 exports.getTokenId = (req, res, next) => {
     try {
        const token = req.headers['tokenid'];
        if(!rm.lodash.isEmpty(token)){
            req.tokenId = token;
            const decryptValue = rm.utils.decrypt(token, rm.settingConfig.cryptoKey);
            if(!rm.lodash.isEmpty(decryptValue)){
                req.userEmail = decryptValue;
                next();
            }else{
                rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'dd-error-16'), "statusCode":401, "lang":req.getLocale()});
            }        
        }else{            
            rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'dd-error-16'), "statusCode":401, "lang":req.getLocale()});
        }  
     } catch (error) {
        next(error);
     }   
}
