"use strict";
const rm = require('@service/require.module')(),
  routeParser = require('@service/route.parser');
  
exports.handler = (req, res, next) => {
  try {
    const item = {url:req.path, method:req.method, body: req.body},
          dewDropsHandler = new routeParser({ "request": req }).parse(item);
          if (dewDropsHandler.success === false) throw dewDropsHandler;
          
          let output = dewDropsHandler.handle();
          output.then((result) => {
            rm.response(req, res, result);
          }, (result) => {
            rm.response(req, res, result);
          });
  } catch (error) {
    if (error.code === 'MODULE_NOT_FOUND') {
      next();
    } else {
      next(error);
    }
  }
}
