/**
   * Date Component
   * Provides the most comprehensive, yet simple and consistent toolset for manipulating dates in Node.js
*/

const moment = require('moment-timezone');

class DateUtility {

	constructor() {
		this.defaultFormat = "DD-MM-YYYY HH:mm:ss";
		this.lang = 'en_US';
		this.timeStandard = 'GMT';
		moment.tz.setDefault(this.timeStandard);
		this.timeZones = {"ACT":"Australia/Adelaide","AET":"Antarctica/DumontDUrville","AGT":"America/Araguaina","ART":"Asia/Amman","AST":"Etc/GMT+9","BET":"Brazil/East","BST":"Etc/GMT-6","CAT":"Africa/Cairo","CNT":"America/St_Johns","CTT":"Etc/GMT-8","EAT":"Etc/GMT-3","ECT":"Etc/GMT-1","IET":"EST","IST":"Asia/Calcutta","JST":"Pacific/Palau","MIT":"Pacific/Apia","NET":"Asia/Baku","NST":"Canada/Newfoundland","PLT":"Asia/Aqtau","PNT":"US/Arizona","PRT":"America/Anguilla","PST":"US/Pacific","EST":"US/Eastern","CST":"US/Central","PST8PDT":"US/Pacific","SST":"Asia/Magadan","SystemV/AST4":"America/Anguilla","SystemV/AST4ADT":"America/Anguilla","SystemV/CST6":"US/Central","SystemV/CST6CDT":"US/Central","SystemV/EST5":"US/Eastern","SystemV/EST5EDT":"US/Eastern","SystemV/HST10":"US/Aleutian","SystemV/MST7":"US/Arizona","SystemV/MST7MDT":"US/Arizona","SystemV/PST8":"US/Pacific","SystemV/PST8PDT":"US/Pacific","SystemV/YST9":"US/Alaska","SystemV/YST9YDT":"US/Alaska","VST":"Antarctica/Davis","Asia/Riyadh87":"Asia/Riyadh","Asia/Riyadh88":"Asia/Riyadh","Asia/Riyadh89":"Asia/Riyadh","Mideast/Riyadh87":"Asia/Riyadh","Mideast/Riyadh88":"Asia/Riyadh","Mideast/Riyadh89":"Asia/Riyadh","CST6CDT":"CST","Cuba":"America/Havana","EST5EDT":"US/Eastern","Egypt":"Africa/Cairo","Eire":"Europe/Dublin","GB-Eire":"Europe/Dublin","GMT0":"GMT","Greenwich":"GMT","HST-":"HST","Hongkong":"HKT","Iceland":"UTC","Iran":"IRST","Israel":"Asia/Jerusalem","Jamaica":"EST","Japan":"JST","Kwajalein":"Pacific/Kwajalein","Libya":"Africa/Tripoli","MST7MDT":"US/Arizona","NZ-CHAT":"Pacific/Chatham","Navajo":"MST","Poland":"Europe/Warsaw","Portugal":"Europe/Lisbon","Singapore":"Asia/Singapore","Turkey":"Asia/Istanbul","Universal":"UTC","Zulu":"GMT"};
	}

	/**
	* @Method Name : validation
	*
	* @Description : Validate the date and timestamps
	*
	* @param1 string val     Pass the Date / Timestamp
	* @param2 string type    Type of validation eg. Date / Timestamp
	* @param3 string pattern Pass the format of the Date
	* @return object / Throw Error
	*/

	validation(val,type,pattern) {

		try{
			let output = {status: true};

			if(typeof val !="undefined" && val !="" && val !=null){
				switch(type) {
					case 'timestamp':
						if(!Number.isInteger(parseInt(val))) {
							throw new Error("Timestamp is not a Valid.");
						}
					break;
					case 'date':
						if(pattern=="" || typeof pattern =="undefined" || pattern ==null)  {
							throw new Error("Date pattern is Required.");
						}else if(!moment(val, pattern,true).isValid()) {
							throw new Error("Date Pattern is Not Matched.");
						}
					break;
					case 'dateoffset':
						let splitOffset = val.split(/[\s,]+/);

						if(!Number.isInteger(parseInt(splitOffset[0])) || !splitOffset[1].match(/^(months|days|years)$/i)) {
							throw new Error("Date offset pattern is not Valid.");
						}
					break;
					case 'expression':
						if(!val.match(/^(>|>=|<=|<|==|===)$/)){
							throw new Error("Expression not a Valid.");
						}
					break;

					default:
						throw new Error("Date pattern is Required.");
					break;
				}
			}else{
				throw new Error("Value is Required.");
			}

			return output;

		} catch (err) {
           return {status: false, msg: err.message};
        }
	}

	/**
	* @Method Name dateToTimeStamp
	*
	* @Description Date to TimeStamp conversation
	*
	* @param1 string Date  Date field
	* @param2 string timeStandard  (Utc/Gmt)
	* @return Number
	*/

	dateToTimeStamp(date, timeStandard, dateFromat) {
		try {
			let validation,timeStampOutput;
			let format = dateFromat || this.defaultFormat;

			timeStandard = timeStandard || this.timeStandard;

			validation = this.validation(date,'date',format);

			if(validation.status) {
				timeStampOutput = moment(date, format).format('x');
			}else{
				throw validation.msg;
			}
			return timeStampOutput;
		}
		catch (err) {
		  return err;
		}
	}

	/**
	* @Method timestampToDate
	*
	* @Description Timestamp to date conversation
	*
	* @param1 string timeStamp  Passed the timeStamp as number format
	* @param2 string timeStandard (Utc/Gmt)
	* @param3 string language   Passed the internation language
	* @return string dateFromat date format
	*/

	timestampToDate(timeStamp, timeStandard, language, dateFromat) {
		try {
			let validation, dateOutput;

			validation = this.validation(timeStamp, 'timestamp');
			timeStandard = this.timeZones[timeStandard] || timeStandard || this.timeStandard;

			if (validation.status) {
				moment.locale(language || this.lang);
				timeStamp = parseInt(timeStamp);
				dateOutput = moment(timeStamp).tz(timeStandard).format(dateFromat || this.defaultFormat);
			} else {
				throw validation.msg;
			}

			return dateOutput;
		}
		catch (err) {
		  return err;
		}
	}

	/**
	* @Method changeDateFormat
	*
	* @Description Change the format of the dates
	*
	* @param1 string date  Start date
	* @param2 string datePattern   Date pattern
	* @param3 string changePattern  Change Date pattern
	* @param4 string lang  Change the lang  of date
	* @return Date
	*/

	changeDateFormat(date,datePattern,lang,changePattern) {
		try {
			let dateValidation, changeFormat,
				format = datePattern || this.defaultFormat;

			dateValidation = this.validation(date, 'date', format);

			if (!dateValidation.status) {
				throw dateValidation.msg;
			} else {
				moment.locale(lang || this.lang);
				changeFormat = moment(date, format).format(changePattern);
			}
			return changeFormat;
		}
		catch (err) {
		  return err;
		}
	}

	/**
	* @Method dateDiff
	*
	* @Description Date difference for two dates
	*
	* @param1 string startDate  Start date
	* @param2 string endDate    End Date
	* @param2 string pattern    Date pattern
	* @return Number
	*/

	dateDiff(startDate,endDate,pattern) {
		try {
			let startDateValidation,endDateValidation,startDateInMoment,endDateInMoment,diff;
			let format = pattern || this.defaultFormat;

			startDateValidation = this.validation(startDate,'date',format);
			endDateValidation = this.validation(endDate,'date',format);

			if(!startDateValidation.status) {
				throw startDateValidation.msg;
			}else if(!endDateValidation.status) {
				throw endDateValidation.msg;
			}else{
				startDateInMoment = moment(startDate,format);
				endDateInMoment = moment(endDate,format);
				diff =  {
					'days':endDateInMoment.diff(startDateInMoment, 'days'),
					'months':endDateInMoment.diff(startDateInMoment, 'months'),
					'years':endDateInMoment.diff(startDateInMoment, 'years'),
					'hours':endDateInMoment.diff(startDateInMoment, 'hours'),
					'miniutes':endDateInMoment.diff(startDateInMoment, 'minutes'),
					'seconds':endDateInMoment.diff(startDateInMoment, 'seconds'),
				}
			}
		   return diff;
		}
		catch (err) {
		  return err;
		}
	}

	/**
	* @Method Name plusToDate
	*
	* @Description Adding days from other date
	*
	* @param1 string date  		 Startdate
	* @param2 string dateoffset  Date Offset
	* @param2 string pattern 	 Date Pattern
	* @return string(Date)
	*/

	plusToDate(date,dateoffset,pattern) {
		try {
			let resultDate,validation,dateoffsetValidation,splitOffset;
			validation = this.validation(date,'date',pattern);
			dateoffsetValidation = this.validation(dateoffset,'dateoffset');
			let format = pattern || this.defaultFormat;

			if(!validation.status) {
				throw validation.msg ;
			}else if(!dateoffsetValidation.status) {
				throw dateoffsetValidation.msg ;
			}
			else {
				splitOffset = dateoffset.split(/[\s,]+/);
				resultDate = moment(date, format).add(splitOffset[0],splitOffset[1]).format(format);
			}
			return resultDate;
		}
		catch (err) {
		  return err;
		}
	}


	/**
	* @Method Name compareDates
	*
	* @Description Adding days from other date
	*
	* @param1 string date  Startdate
	* @param2 string date  End date
	* @param3 string pattern format
	* @param4 string expression expression like as (>,>=,<=,<,=)
	* @return string(Date)
	*/

	compareDates(startdate,enddate,expression,pattern) {
		try {
			let result,startdateValidation,enddateValidation,startMoment,endMoment,expressionValidation;

			pattern = pattern || this.defaultFormat;

			startdateValidation = this.validation(startdate,'date',pattern);
			enddateValidation = this.validation(enddate,'date',pattern);
			expressionValidation = this.validation(expression,'expression');

			if(!startdateValidation.status) {
				throw startdateValidation.msg ;
			}
			else if(!enddateValidation.status) {
				throw enddateValidation.msg;
			}else if(!expressionValidation.status) {
				throw expressionValidation.msg;
			}else {
				startMoment = moment(startdate,pattern);
				endMoment = moment(enddate,pattern);
				result  = eval(startMoment + expression + endMoment);
			}
			return result;
		}
		catch (err) {
		  return err;
		}
	}
}

module.exports = new DateUtility();
