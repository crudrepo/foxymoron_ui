"use strict";

class Configuration {

  constructor() {
    this.port = process.env.PORT || this.setting().port;
  }

  setting() {
    return require('@config/setting.json');
  }

  session() {
    return require('@config/session.json');
  }

  redis() {
    return require('@config/redis.json');
  }

  i18n() {
    return require('@config/i18n.json');
  }

  productSetting(productName) {
    return require('@product/' + productName + '/config/setting.json');
  }

  productConfig() {
    return require('@config/product.config.json');
  }

  uiConfig() {
    return require('@config/ui.config.json');
  }

  constantConfig() {
    return require('@config/app.constant.json');
  }

}

module.exports = new Configuration();
