"use strict";
const swaggerJSDoc = require('swagger-jsdoc'),
setting = require('@helper/configuration').setting();

// swagger definition
let swaggerDefinition = {
  info: {
    title: "Dewdrops BFF API Listing",
    version: "1.0.0",
    description: "Demonstrating to describe a RESTful API"
  },  
  basePath: "/api",
  swagger: "2.0",
  paths: { },
  definitions: { },
  responses: { },
  parameters: { },
  securityDefinitions: { }
};


// options for the swagger docs
let options = {
  // import swaggerDefinitions
  swaggerDefinition: swaggerDefinition,
  // path to the API docs
  apis: ['./app/products/**/*.js'],
};

// initialize swagger-jsdoc
exports.init = () =>{
  return swaggerJSDoc(options);
}
