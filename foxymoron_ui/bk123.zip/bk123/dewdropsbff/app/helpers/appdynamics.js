const appDynamics = require('appdynamics');
const ip = require('ip');
const os=require('os');
exports.enableAppDynamics = (setting) => {
  appDynamics.profile({
    controllerHostName: setting.controllerHostName,
    controllerPort: setting.controllerPort,
    // If SSL, be sure to enable the next line
    controllerSslEnabled: setting.controllerSslEnabled,
    accountName: setting.accountName,
    accountAccessKey: setting.accountAccessKey,
    applicationName: setting.applicationName,
    tierName: os.hostname(),
    nodeName: ip.address() // The controller will automatically append the node name with a unique number
  });
}
