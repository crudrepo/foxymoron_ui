/**
   * deliveryTerms Controller
   * Provides this controller to get the deliveryTerms list and details.
*/

"use strict";

module.exports = (parentClass) => {

  class DeliveryTerm extends parentClass {

    /**
    * @Method Name : getList
    *
    * @Description : Display the name, code lists
    * @return object / Throw Error
    */
    getList(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "name": "joi.string().max(30).label('cmd-lable-1__')",
            "code": "joi.string().max(30).label('cmd-lable-10__')"
          };
        validationUtility.addInternalSchema(schema);
        validationUtility.addCommonSchema('pagination');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
            cmdURL = request.productsURL.cmd,
            url = cmdURL + '/component/searchDeliveryTerms?tenantId=' + request.user.tenantId + '&locale=' + request.user.userSettings.locale+'&activeCondition='+true;
          http.post(url, 'searchDeliveryTerms', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = { "type": "object", "properties": { "totalCount": { "type": "number", "key": "totalRecords" }, "perPageRecords": { "type": "number" }, "pageNo": { "type": "number" }, "result": { "type": "array", "key": "records", "properties": { "code": { "type": "string" }, "name": { "type": "string" }, "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "id": { "type": "none" }, "description": { "type": "string" }, "erpId": { "type": "string" } } } } },
                output = (new (super.responseHandler)(request, result, responseSchema)).execute();
              return callback(null, request, output);
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }
  }
  return DeliveryTerm;
}