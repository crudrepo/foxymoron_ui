/**
   * Cost Center Controller
   * Provides this controller to search the cost center.
*/

"use strict";

module.exports = {

  /**
   * @swagger
   * /a/cmd/costcenters/list:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Search the cost centers
   *     operationId: searchCostCenters
   *     description: Search the cost centers
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the cost centers based on the name & pagination.
   *         in: body
   *         schema:
   *             properties:  
   *               name:
   *                 type: string
   *               code:
   *                 type: string
   *               codes:
   *                 type: array
   *                 items:
   *                   type: string
   *               isActive:
   *                 type: boolean
   *               perPageRecords:
   *                 type: integer
   *               pageNo:
   *                 type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList:{
    pre: null,
    process: "costcenter.getList",
    post: null,
    method: 'POST'
  },

  /**
   * @swagger
   * /a/cmd/costcenters/allowedList:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Search Allowed CostCenters
   *     operationId: searchAllowedCostCenters
   *     description: Search Allowed CostCenters
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the cost centers based on those inputs(pagination, sorting & filter).
   *         in: body
   *         schema:
   *             allOf:
   *                - $ref: '#/definitions/pagination'
   *                - $ref: '#/definitions/cmdSort'
   *                - type: object
   *                  properties:  
   *                    companyCode:
   *                      type: string
   *                      required: true
   *                    businessUnitCode:
   *                      type: string
   *                      required: true
   *                    code:
   *                      type: string
   *                    name:
   *                      type: string    
   *     responses:
   *       200:
   *         description: successful operation
   */

  allowedList:{
    pre: null,
    process: "costcenter.allowedList",
    post: null,
    method: 'POST'
  }
}