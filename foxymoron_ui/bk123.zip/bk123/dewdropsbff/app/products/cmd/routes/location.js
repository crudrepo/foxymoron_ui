"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/cmd/locations/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Location List
    *     operationId: getLocationList
    *     description: Get Location List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Location List(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties:  
    *               name:
    *                 type: string
    *               code:
    *                 type: string
    *               codes:
    *                 type: array
    *                 items:
    *                   type: string
    *               isActive:
    *                 type: boolean
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "location.getList",
        post: null,
        method: 'POST'
    },
    
     /**
     * @swagger
     * /a/cmd/locations/allowedList:
     *   post:
     *     tags:
     *       - CMD API
     *     summary: Search Allowed Location
     *     operationId: searchAllowedLocation
     *     description: Search Allowed Location
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Find the Location based on those inputs(pagination, sorting & filter).
     *         in: body
     *         schema:
     *             allOf:
     *                - $ref: '#/definitions/pagination'
     *                - $ref: '#/definitions/cmdSort'
     *                - type: object
     *                  properties:  
     *                    companyCode:
     *                      type: string
     *                    businessUnitCode:
     *                      type: string
     *                    name:
     *                      type: string    
     *                    userId:
     *                      type: string    
     *                  required: [companyCode, businessUnitCode]
     *     responses:
     *       200:
     *         description: successful operation
     */

    allowedList: {
        pre: null,
        process: "location.allowedList",
        post: null,
        method: 'POST'
    }
};