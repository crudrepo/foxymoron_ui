/**
   * Department Controller
   * It is used for handling department related operations.
*/

"use strict";

module.exports = {

  /**
   * @swagger
   * /a/cmd/departments/list:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Get Department List
   *     operationId: getDepartments
   *     description: Get the Department
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the department.
   *         in: body
   *         schema:
   *             allOf:
   *                - $ref: '#/definitions/pagination'
   *                - type: object
   *                  properties:
   *                    codes:
   *                      type: array
   *                      items:
   *                        type: string
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList: {
    pre: null,
    process: "department.getList",
    post: null,
    method: 'POST'
  }

}