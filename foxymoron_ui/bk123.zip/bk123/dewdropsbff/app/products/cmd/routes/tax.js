/**
   * @Name: TaxTypeController   
   * @Description : It is used for handling Tax Type related operations.
**/
"use strict";

    module.exports = { 

    /**
    * @swagger
    * /a/cmd/taxes/getTypes:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Tax Type
    *     operationId: getTaxTypes
    *     description: Get Tax Types
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch all Tax Type(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties:  
    *               name:
    *                 type: string
    *               isActive:
    *                 type: boolean
    *               isArchive:
    *                 type: boolean
    *               includeUseTax:
    *                 type: boolean
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */

    getTypes:{
        pre: null,
        process: "tax.getTypes",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/cmd/taxes/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Tax Rate
    *     operationId: getTaxRate
    *     description: Get Tax Rate
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch all Tax Rate(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties:  
    *               applicableFor:
    *                 type: number
    *               name:
    *                 type: string
    *               taxType:
    *                 type: string
    *               isActive:
    *                 type: boolean
    *               isArchive:
    *                 type: boolean
    *               useTaxType:
    *                 type: boolean
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */    
    getList: {
        pre: null,
        process: "tax.getList",
        post: null,
        method: 'POST'
    } 
    
}

