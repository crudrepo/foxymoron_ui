/**
   * Asset Controller
   * Provides this controller to search the asset master.
*/

"use strict";

module.exports = {

  /**
   * @swagger
   * /a/cmd/assets/list:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Search the Asset Codes
   *     operationId: searchAssetCodes
   *     description: Search the Asset Codes
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the asset based on the assetCode & code.
   *         in: body
   *         schema:
   *             properties:
   *               assetCode:
   *                 type: string
   *               codes:
   *                 type: array
   *                 items:
   *                   type: string
   *               isActive:
   *                 type: boolean
   *               perPageRecords:
   *                 type: integer
   *               pageNo:
   *                 type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList: {
    pre: null,
    process: "asset.getList",
    post: null,
    method: 'POST'
  },

  /**
   * @swagger
   * /a/cmd/assets/allowedList:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Search Allowed Asset
   *     operationId: searchAllowedAsset
   *     description: Search Allowed Asset
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the Asset based on those inputs(pagination, sorting & filter).
   *         in: body
   *         required: true
   *         schema:
   *             allOf:
   *                - $ref: '#/definitions/pagination'
   *                - $ref: '#/definitions/cmdSort'
   *                - type: object
   *                  required: true
   *                  properties:
   *                    name:
   *                      type: string
   *                    companyCode:
   *                      type: string
   *                      required: true
   *     responses:
   *       200:
   *         description: successful operation
   */
  allowedList: {
    pre: null,
    process: "asset.allowedList",
    post: null,
    method: 'POST'
  }
}