"use strict";

module.exports = { 
   
    /**
    * @swagger
    * /a/irequest/linkobjects/list:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the linked object list
    *     operationId: getLinkedObjList
    *     description: Fetch the linked object list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the linked object list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "Linkobject.getList",
        post: null,
        method: 'POST'
    }
      
};
