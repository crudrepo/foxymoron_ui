"use strict";

module.exports = { 
     
  /**
    * @swagger
    * /a/irequest/contacts/list:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the list of procurementTeam
    *     operationId: getprocurementTeam list
    *     description: Get the list of procurementTeam
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the list of procurementTeam ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "contact.getList",
        post: null,
        method: 'POST'
    }
};