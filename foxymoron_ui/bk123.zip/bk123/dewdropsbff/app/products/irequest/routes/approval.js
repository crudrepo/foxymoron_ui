"use strict";

module.exports = { 
     
  /**
    * @swagger
    * /a/irequest/approvals/list:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the list of approval requests 
    *     operationId: getApprovals
    *     description: Get the list of approval requests
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the list of approval requests ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "approval.getList",
        post: null,
        method: 'POST'
    },


     /**
    * @swagger
    * /a/irequest/approvals/action:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Approval Action
    *     operationId: approvalAction
    *     description: Approval Action
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide those fileds to apply/submit the apporval action.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               requestApprovalId:
    *                 type: string
    *               action:
    *                 type: integer
    *               requestComments:
    *                 type: string
    *               description:
    *                 type: string
    *               urgentRequirementDesc:
    *                 type: string
    *               requestName:
    *                 type: string
    *               urgentRequirement:
    *                 type: boolean
    *               assignedToTypeId:
    *                 type: integer
    *               assignedToUserId:
    *                 type: string
    *               behalfOfUserId:
    *                 type: string
    *               attachmentIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               requestId:
    *                 type: string
    *               eformId:
    *                 type: string
    *               formInstance:
    *                  type: string
    *               checkForSecurity:
    *                 type: boolean
    *               supplierRequestFlag:
    *                 type: boolean
    *               quickSave:
    *                  type: boolean
    *               requestMaster:
    *                  type: boolean
    *                  default: false
    *             required: [requestApprovalId, action, requestComments]
    *     responses:
    *       200:
    *         description: successful operation
    */
    action: {
        pre: null,
        process: "approval.action",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/approvals/{requestApprovalUserId}:
    *   get:
    *     tags:
    *       - iRequest API
    *     summary: View the approval request
    *     operationId: viewApprovalRequest
    *     description: View the approval request
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requestApprovalUserId
    *         description: Provide the User ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "approval.getDetails",
        post: null,
        method: 'GET'
    },

    /**
     * @swagger
     * /a/irequest/approvals/getCount:
     *   get:
     *     tags:
     *       - iRequest API
     *     summary: Count of the Approval.
     *     operationId: getApprovalCount
     *     description: Get the (total/pending) count value of the Approval.
     *     produces:
     *       - application/json
     *     responses:
     *       200:
     *         description: successful operation
     */
    getCount:{
        pre: null,
        process: "approval.getCount",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/irequest/approvals/delegateApprovers:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Delegate the request to user.
    *     operationId: delegateRequestToUser
    *     description: Delegate the request to user
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Delegate the request to user.
    *         type: string
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               displayName:
    *                 type: string
    *               requestId:
    *                 type: string
    *             required: [displayName, requestId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    delegateApprovers:{
        pre: null,
        process: "approval.delegateApprovers",
        post: null,
        method: 'POST'
    },

     /**
    * @swagger
    * /a/irequest/approvals/{approval_Id}/delegateAction:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Delegate Action
    *     operationId: delegateAction
    *     description: Delegate Action
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: approval_Id
    *         description: Provide an approval ID.
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: Provide those fileds to Delegate the apporval action.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               action:
    *                 type: integer
    *               requestComments:
    *                 type: string    
    *               delegateUserId:
    *                 type: string
    *               description:
    *                 type: string
    *               urgentRequirementDesc:
    *                 type: string
    *               requestName:
    *                 type: string
    *               urgentRequirement:
    *                 type: boolean
    *               assignedToTypeId:
    *                 type: integer
    *               assignedToUserId:
    *                 type: string
    *               behalfOfUserId:
    *                 type: string
    *               attachmentIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               requestId:
    *                 type: string
    *               eformId:
    *                 type: string
    *               formInstance:
    *                  type: string
    *               checkForSecurity:
    *                 type: boolean
    *               supplierRequestFlag:
    *                 type: boolean
    *               quickSave:
    *                  type: boolean
    *               requestMaster:
    *                  type: boolean
    *                  default: false
    *             required: [action, delegateUserId, requestComments]
    *     responses:
    *       200:
    *         description: successful operation
    */
   delegateAction: {
    pre: null,
    process: "approval.delegateAction",
    post: null,
    method: 'POST'
    }
    
};
