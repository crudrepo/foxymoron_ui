"use strict";

module.exports = { 
   
    /**
    * @swagger
    * /a/irequest/faqs/list:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the FAQ list
    *     operationId: getFAQList
    *     description: Fetch the FAQ list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the FAQ list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "faq.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/faqs/getTypes:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the list of faq Types
    *     operationId: getFaqTypes
    *     description: Get the list of faq types
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the list of faq types ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getTypes: {
        pre: null,
        process: "faq.getTypes",
        post: null,
        method: 'POST'
    }
      
};
