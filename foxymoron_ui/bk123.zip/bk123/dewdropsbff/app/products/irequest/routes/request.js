"use strict";

module.exports = { 
   /**
   * @swagger
   * /a/irequest/requests/getCount:
   *   get:
   *     tags:
   *       - iRequest API
   *     summary: Count of the Request.
   *     operationId: getRequestCount
   *     description: Get the (total/pending) count value of the Request.
   *     produces:
   *       - application/json
   *     responses:
   *       200:
   *         description: successful operation
   */

  getCount:{
    pre: null,
    process: "request.getCount",
    post: null,
    method: 'GET'
  },    

  /**
    * @swagger
    * /a/irequest/requests/getDefinition:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Request Definition List
    *     operationId: getRequestDefinitionList
    *     description: Get the Request Definition List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Request Definition list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDefinition: {
        pre: null,
        process: "request.getDefinition",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/requests/list:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the request list
    *     operationId: getRequestList
    *     description: Fetch the request list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the request list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "request.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/requests/{request_Id}:
    *   delete:
    *     tags:
    *       - iRequest API
    *     summary: Delete a request
    *     operationId: deleteRequest
    *     description: Delete a request
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: request_Id
    *         description: Provide a request ID to delete
    *         required: true
    *         type: string
    *         in: path
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "request.destroy",
        post: null,
        method: 'DELETE'
    },

    /**
     * @swagger
     * definitions:
     *   createRequest:
     *     properties:
     *       requestName:
     *         type: string
     *       urgentRequirement:
     *         type: boolean
     *       urgentRequirementDesc:
     *         type: string
     *       description:
     *         type: string
     *       requestComments:
     *         type: string
     *       eformInstanceId:
     *         type: string
     *       submittedToWorkflow:
     *         type: boolean
     *       behalfOfUserId:
     *         type: string
     *       assignedToTypeId:
     *         type: number
     *       assignedToUserId:
     *         type: string
     *       requestDefinitionId:
     *         type: string
     *       attachmentIds:
     *         type: array
     *         items:
     *           type: string 
     *       eformId:
     *         type: string 
     *       formInstance:
     *         type: string
     *       supplierRequestFlag:
     *         type: boolean
     *       createdBySCId:
     *         type: string
     *       supplierDBId:
     *         type: string
     *       buyerTenantId:
     *         type: string
     *       supplierName:
     *         type: string
     *       cwfIntegration:
     *         type: boolean
     *     required: [requestName,requestDefinitionId]
     */

    /**
    * @swagger
    * /a/irequest/requests:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Create Request
    *     operationId: createRequest
    *     description: Create Request
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create Request
    *         in: body
    *         schema:    
    *           $ref: '#/definitions/createRequest'
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "request.create",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * definitions:
     *   status:
     *     properties:
     *       statusDraft:
     *         type: boolean
     */

    /**
    * @swagger
    * /a/irequest/requests/{request_Id}:
    *   put:
    *     tags:
    *       - iRequest API
    *     summary: Update Request
    *     operationId: updateRequest
    *     description: Update Request
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: request_Id
    *         description: provide requestId
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: update request
    *         in: body
    *         schema:    
    *           allOf:
    *             - $ref: '#/definitions/createRequest'
    *             - $ref: '#/definitions/status'
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "request.update",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/irequest/requests/{requestDefinition_Id}/getParams:
    *   get:
    *     tags:
    *       - iRequest API
    *     summary: Get the request creation details
    *     operationId: requestCreationDetails
    *     description: Fetch the request creation details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requestDefinition_Id
    *         description: Provide a requestDefinition ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getParams:{
        pre: null,
        process: "request.getParams",
        post: null,
        method: 'GET'
      },

    /**
    * @swagger
    * /a/irequest/requests/{request_Id}/getViewDetails:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: View request
    *     operationId: viewRequest
    *     description: View request
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: request_Id
    *         description: Provide a request ID.
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: View request
    *         in: body
    *         schema:
    *             properties:
    *               version:
    *                 type: integer
    *               userActivity:
    *                 type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getViewDetails: {
        pre: null,
        process: "request.getViewDetails",
        post: null,
        method: 'POST'
    },
      
    
    /**
    * @swagger
    * /a/irequest/requests/assignTo:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Assign the request to user/userGroup
    *     operationId: assignRequestToUser
    *     description: Assign the request to user/userGroup
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Assign the request to user/userGroup.
    *         type: string
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               displayName:
    *                 type: string
    *               userType:
    *                 type: integer
    *               requestDefinitionId:
    *                 type: string
    *               buyerTenantId:
    *                 type: string
    *             required: [displayName, userType]
    *     responses:
    *       200:
    *         description: successful operation
    */

    assignTo:{
        pre: null,
        process: "request.assignTo",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/requests/{request_Id}/printPreview:
    *   get:
    *     tags:
    *       - iRequest API
    *     summary: Get the request print preview
    *     operationId: requestprintPreview
    *     description: Get the request print preview
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: request_Id
    *         description: Provide a request ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    printPreview:{
        pre: null,
        process: "request.printPreview",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/irequest/requests/{request_Id}/pdfFormat:
    *   get:
    *     tags:
    *       - iRequest API
    *     summary: View the PDF format
    *     operationId: viewPDF
    *     description: View the PDF format
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: request_Id
    *         description: Provide a request ID to view the PDF format.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    pdfFormat: {
        pre: null,
        process: "request.pdfFormat",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/irequest/requests/getAdhocApprovalUser:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Fetch approver user/userGroup
    *     operationId: assignRequestToUser
    *     description: Fetch approver user/userGroup
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch approver user/userGroup.
    *         type: string
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               displayName:
    *                 type: string
    *             required: [displayName]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAdhocApprovalUser:{
        pre: null,
        process: "request.getAdhocApprovalUser",
        post: null,
        method: 'POST',
    },

    /**
    * @swagger
    * definitions:
    *   adhocJson:
    *     properties:
    *       workflowNodeId:
    *        type: string
    *       parentNodeId:
    *        type: string
    *       parentUserId:
    *        type: string
    *       approverUserId:
    *        type: string
    *       approverType:
    *        type: string
    *       nodeId:
    *        type: string      
    *     required: [workflowNodeId, parentNodeId, parentUserId, approverUserId, approverType, nodeId]
    */

    /**
    * @swagger
    * /a/irequest/requests/submitAdhocRequest:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Create Request with Addhoc approver
    *     operationId: submitAdhocRequest
    *     description: Create Request with Addhoc approver
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create Request with Addhoc approver
    *         in: body
    *         schema:
    *             properties:
    *               adhocUsers:
    *                 type: array
    *                 items:
    *                   type: object
    *                   $ref: '#/definitions/adhocJson'    
    *               requestId:
    *                 type: string
    *             required: [adhocUsers, requestId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    submitAdhocRequest: {
        pre: null,
        process: "request.submitAdhocRequest",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/requests/getRequestTypes:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Request Type List
    *     operationId: getRequestTypeList
    *     description: Get the Request Type List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Request Type list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getRequestTypes: {
        pre: null,
        process: "request.getRequestTypes",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/requests/getAllRequests:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the request list which is with RM
    *     operationId: getRequestListWithRM
    *     description: Fetch the request list which is with RM
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the request list which is with RM( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   getAllRequests: {
        pre: null,
        process: "request.getAllRequests",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/irequest/requests/getRequest:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: View request
    *     operationId: viewRequest
    *     description: View FlexiForm Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch Request as Approver from All Request.
    *         type: string
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               requestApprovalUserId:
    *                 type: string
    *               requestApprovalId:
    *                 type: string
    *             required: [requestApprovalId]
    *     responses:
    *       200:
    *         description: successful operation
    */
   getRequest: {
    pre: null,
    process: "request.getRequest",
    post: null,
    method: 'POST'
},

/**
    * @swagger
    * /a/irequest/requests/{request_Id}/getDynamicForms:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: View FlexiForm
    *     operationId: viewRequest
    *     description: View request
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: request_Id
    *         description: Provide a request ID.
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: View FlexiForm based on the version
    *         in: body
    *         schema:
    *             properties:
    *               version:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDynamicForms: {
        pre: null,
        process: "request.getDynamicForms",
        post: null,
        method: 'POST'
    },
      
};
