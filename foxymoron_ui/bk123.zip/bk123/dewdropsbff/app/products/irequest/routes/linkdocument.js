"use strict";

module.exports = { 

    /**
    * @swagger
    * /a/irequest/linkdocuments/getDetails:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the linked document
    *     operationId: getLinkDoc
    *     description: Get the linked document
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the linked document( Based on requestId & activity ).
    *         in: body
    *         schema:
    *          properties:
    *            requestId:
    *             type: string
    *            activity:
    *             type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "Linkdocument.getDetails",
        post: null,
        method: 'POST'
    }
      
};
