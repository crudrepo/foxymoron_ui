"use strict";

module.exports = { 

    /**
    * @swagger
    * /a/irequest/banners/list:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Get the banner list
    *     operationId: getBannerList
    *     description: Fetch the banner list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the banner list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "banner.getList",
        post: null,
        method: 'POST'
    }
      
};
