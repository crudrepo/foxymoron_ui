"use strict";

module.exports = {     
    /**
    * @swagger
    * /a/irequest/reports/createIssue:
    *   post:
    *     tags:
    *       - iRequest API
    *     summary: Report an Issue
    *     operationId: reportIssue
    *     description:  Report an Issue
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Report an Issue
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               module:
    *                 type: string
    *               subject:
    *                 type: string
    *               messageType:
    *                 type: string
    *               priority:
    *                 type: string
    *               message:
    *                 type: string
    *               attachments:
    *                  type: array
    *                  items:
    *                       type: object
    *                       properties:
    *                           id:
    *                               type: string
    *                           name:
    *                               type: string
    *                           path:
    *                               type: string
    *                           size:
    *                               type: integer
    *                           type:
    *                               type: string
    *               browser:
    *                 type: object
    *                 properties:
    *                   currentUrl:
    *                       type: string
    *                   name:
    *                       type: string
    *                   version:
    *                       type: string
    *                   agent:
    *                       type: string
    *                   screenResolution:
    *                       type: string
    *                   flashVersion:
    *                       type: string
    *             required: [module, subject, messageType, priority, message]
    *     responses:
    *       200:
    *         description: successful operation
    */
    createIssue: {
        pre: null,
        process: "report.createIssue",
        post: null,
        method: 'POST'
    }
};
