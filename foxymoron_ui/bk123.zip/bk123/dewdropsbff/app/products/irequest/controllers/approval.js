/**
* Approval Controller
*
* @description :: Provides Approval related curd operations
*/

"use strict";
module.exports = (parentClass) => {
    class Approval extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used to get the Approval requests list
        * @return : object
        */
        getList(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const iRequestURL = request.productsURL.iRequest;
                    let url = iRequestURL + '/approval/filter';

                    http.post(url, 'getApprovalsList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "createdBy": { "type": "string" }, "allowApproverEdit": { "type": "boolean" }, "urgentRequirementDesc": { "type": "string" }, "recievedOnDate": { "type": "none" }, "requestId": { "type": "string" }, "requestName": { "type": "string" }, "urgentRequirement": { "type": "boolean" }, "requestNumber": { "type": "number" }, "requestApprovalId": { "type": "string" }, "requestType": { "type": "string" }, "requestDefinitionName": { "type": "string" }, "submittedToWorkflowDate": { "type": "none" }, "requestApprovalUserId": { "type": "string" }, "action": { "type": "number" }, "description": { "type": "string" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name : Action
        * @Description : It is used to apply/submit the apporval action
        * @return : object
        */
        action(request, input, callback) {
            try {

                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "requestApprovalId": "joi.string().required().label('irequest-lable-49__')",
                    "action": "joi.number().integer().required().label('irequest-lable-50__')",
                    "requestComments": "joi.string().required().label('irequest-lable-4__')",
                    "description": "joi.string().allow('', null).label('irequest-lable-3__')",
                    "requestName": "joi.string().when('quickSave', { is: false, then: joi.required(), otherwise : joi.optional()}).label('irequest-lable-1__')",
                    "urgentRequirement": "joi.boolean().label('irequest-lable-2__')",
                    "assignedToTypeId": "joi.number().integer().label('irequest-lable-8__')",
                    "urgentRequirementDesc": "joi.string().empty('').max(500).label('irequest-lable-56__')",
                    "assignedToUserId": "joi.string().allow('').label('irequest-lable-9__')",
                    "behalfOfUserId": "joi.string().label('irequest-lable-7__')",
                    "attachmentIds": "joi.array().items(joi.string().min(1).label('irequest-lable-25__')).min(1).unique().label('irequest-lable-11__')",
                    "requestId": "joi.string().label('irequest-lable-20__')",
                    "eformId": "joi.string().label('irequest-lable-12__')",
                    "formInstance": "joi.string().label('irequest-lable-13__')",
                    "checkForSecurity": "joi.boolean().label('irequest-lable-51__')",
                    "supplierRequestFlag": "joi.boolean().label('irequest-lable-52__')",
                    "quickSave": "joi.boolean().label('irequest-lable-53__')",
                    "requestMaster": "joi.boolean().label('irequest-lable-62__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/approval/action';

                    http.post(url, 'approvalAction', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            if (!super.lodash.isEmpty(result.data.requestApprovalId)) {
                                result.message = [{ description: "irequest-msg-5" }];
                            }
                            const responseSchema = { "type": "object", "properties": { "action": { "type": "number" }, "requestApprovalId": { "type": "string" }, "requestComments": { "type": "string" }, "quickSave": { "type": "boolean" } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : getDetails
        * @Description : This method is used to view the approval request
        * @return : object
        */
        getDetails(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                    "requestApprovalUserId":  "joi.string().required().label('irequest-lable-54__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({ "requestApprovalUserId": request.params.approval_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/approval/view/' + request.params.approval_Id;

                    http.get(url, 'getApprovalsRequest', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = {"type":"object","properties":{"actionTaken":{"type":"number"},"allowApproverEdit":{"type":"boolean"},"assignedToTypeId":{"type":"number"},"assignedToUser":{"type":"string"},"behalfOfUser":{"type":"string"},"createdByType":{"type":"string"},"urgentRequirementDesc":{"type":"string"},"reqManagerAutoComplete":{"type":"boolean"},"requestComments":{"type":"string"},"requestId":{"type":"string"},"assignedToUserId":{"type":"string"},"status":{"type":"number"},"behalfOfUserId":{"type":"string"},"submittedToWorkflow":{"type":"boolean"},"createdBySCId":{"type":"string"},"supplierDBId":{"type":"string"},"requestName":{"type":"string"},"requestDefinitionId":{"type":"string"},"urgentRequirement":{"type":"boolean"},"supplierName":{"type":"string"},"eformInstanceId":{"type":"string"},"attachments":{"type":"array","properties":{"fileSize":{"type":"number"},"attachmentId":{"type":"string"},"createdById":{"type":"string"},"tenantId":{"type":"string"},"createdDate":{"type":"none"},"status":{"type":"number"},"name":{"type":"string"},"type":{"type":"number"},"path":{"type":"filePathEncode"},"encoding":{"type":"string"}}},"eformDefinitionId":{"type":"string"},"linkedObjectId":{"type":"string"},"requestNumber":{"type":"string"},"requestType":{"type":"string"},"requestDefinitionName":{"type":"string"},"version":{"type":"string"},"description":{"type":"string"},"audits":{"type":"array","properties":{"createdBy":{"type":"string"},"createdById":{"type":"string"},"createdDate":{"type":"none"},"comments":{"type":"string"},"requestAuditId":{"type":"string"},"version":{"type":"number"},"action":{"type":"number"}}}}};
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }


        /**
         * Get the approval count 
        */
        getCount(request, input, callback) {
            try {                
                const http = new (super.httpService)(request),
                      iRequestURL = request.productsURL.iRequest,
                      url = iRequestURL + '/approval/count';
                http.get(url, 'approvalCount', (error, result) => {
                    if (error) {
                        callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "total": { "type": "number" }, "pending": { "type": "number" } } },
                              output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                        return callback(null, request, output);
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        }

        /**
        * @Name : DelegateAction
        * @Description : This method is used to delegate the request
        * @return : object
        */
       delegateAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "requestApprovalId": "joi.string().required().label('irequest-lable-49__')",
                    "action": "joi.number().integer().required().label('irequest-lable-50__')",
                    "requestComments": "joi.string().required().label('irequest-lable-4__')",
                    "delegateUserId": "joi.string().required().label('irequest-lable-60__')",
                    "description": "joi.string().allow('', null).label('irequest-lable-3__')",
                    "requestName": "joi.string().when('quickSave', { is: false, then: joi.required(), otherwise : joi.optional()}).label('irequest-lable-1__')",
                    "urgentRequirement": "joi.boolean().label('irequest-lable-2__')",
                    "assignedToTypeId": "joi.number().integer().label('irequest-lable-8__')",
                    "urgentRequirementDesc": "joi.string().empty('').max(500).label('irequest-lable-2__')",
                    "assignedToUserId": "joi.string().allow('').label('irequest-lable-9__')",
                    "behalfOfUserId": "joi.string().label('irequest-lable-7__')",
                    "attachmentIds": "joi.array().items(joi.string().min(1).label('irequest-lable-25__')).min(1).unique().label('irequest-lable-11__')",
                    "requestId": "joi.string().label('irequest-lable-20__')",
                    "eformId": "joi.string().label('irequest-lable-12__')",
                    "formInstance": "joi.string().label('irequest-lable-13__')",
                    "checkForSecurity": "joi.boolean().label('irequest-lable-51__')",
                    "supplierRequestFlag": "joi.boolean().label('irequest-lable-52__')",
                    "quickSave": "joi.boolean().label('irequest-lable-53__')",
                    "requestMaster": "joi.boolean().label('irequest-lable-62__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, {"requestApprovalId": request.params.approval_Id}));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/approval/delegate';

                    http.post(url, 'delegate', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            if (!super.lodash.isEmpty(result.data.requestApprovalId)) {
                                result.message = [{ description: "irequest-msg-6" }];
                            }
                            const responseSchema = { "type": "object", "properties": { "action": { "type": "number" }, "requestApprovalId": { "type": "string" }, "requestComments": { "type": "string" }, "quickSave": { "type": "boolean" } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }



        /**
        * @Name : delegateApprovers
        * @Description : It is used to delegate the request to user.
        * @return : object / Throw Error
        */
        delegateApprovers(request, input, callback) {
            try {                               
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "displayName" : "joi.string().required().label('irequest-lable-47__')",
                    "requestId" : "joi.string().required().label('irequest-lable-21__')"
                };                      
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const requestData = {
                        displayName: request.body.displayName,
                        requestId: request.body.requestId
                    };
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity, super.appConstant.resHandler.entityList);
                    const iRequestURL = request.productsURL.iRequest;
                    const url = iRequestURL + '/approval/delegateApprovers';                   
                    http.post(url, 'delegateRequestTo', requestData, (error, result)=>{                       
                        if (error) {
                            return callback(error, null);
                        } else{                             
                            let responseSchema = {"type":"array","properties":{"emailId":{"type":"string"},"id":{"type":"string"},"displayName":{"type":"string"}}};
                            let output =  (new (super.responseHandler)(request, result, responseSchema));                         
                            return callback(null, request, output.execute());                                    
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

    };

    
    return Approval;
};
