/**
* Search Controller
*
* @description :: Search Requests on Lisiting page.
*/

"use strict";
module.exports = (parentClass) => {
    class Entity extends parentClass {

        /**
          * @Name : getList
          * @Description : It is used to sarch request in listing pages.
          * @return : array
        */
       getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "type": "joi.string().required().label('irequest-lable-63__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');                

                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let subURL;
                    switch (request.body.type) {
                        case "request":
                            subURL = '/request/searchReqByPattern';
                            break;
                        case "allrequest":
                            subURL = '/allRequests/searchAllRequestByPattern';
                            break;
                        case "workbench":
                            subURL = '/workbench/searchForWorkbench';
                            break;
                        case "allworkbench":
                            subURL = '/workbench/searchForAllWorkbench';
                            break;
                        case "approval":
                            subURL = '/approval/searchReqApprovalByPattern';
                            break;
                        default:
                            break;
                    }

                    delete request.body.type; 

                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),                        
                        url = request.productsURL.iRequest + subURL;

                    http.post(url, 'getRequestListBySearch', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "requestNumber": { "type": "string" }, "requestName": { "type": "string" }, "requestDefinitionName": { "type": "string" }, "requestType": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });

                }
            } catch (error) {
                return callback(error, null);
            }
        }
        
    };

    return Entity;
};        