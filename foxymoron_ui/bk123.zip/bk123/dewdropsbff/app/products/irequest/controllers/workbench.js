/**
* Workbench Controller
*
* @description :: Provides Workbench related curd operations
*/

"use strict";
module.exports = (parentClass) => {
    class Workbench extends parentClass {

        /**
         * post total count of requests which is with RM 
        */
        getCount(request, input, callback) {
            try {                
                
                    let validationUtility = super.utils.validationUtility(request),                    
                        schema = {
                                    "rmType": "joi.string().alphanum().min(2).max(30).label('irequest-lable-64__')"
                        };
                        
                    validationUtility.addInternalSchema(schema);    
                    let result = validationUtility.validate(request.body);  
                    if (result) {
                                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                                    callback(errorMsg, null);
                    }else { 
                        const subURL = (request.body.rmType=='RM')?'/workbench/requestCountWithRM':'/workbench/requestCountWithSuperRM',
                              http =   new (super.httpService)(request),                             
                              url = request.productsURL.iRequest + subURL;   
                        http.get(url, 'myWorkbenchCount', (error, result) => {
                            if (error) {
                                callback(error, null);
                            } else {
                                const responseSchema = { "type": "object", "properties": { "total": { "type": "number" }, "pending": { "type": "number" } } },
                                    output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                                return callback(null, request, output);
                            }
                        });
                }                         
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : getList
        * @Description : It is used to get the request list which is with RM
        * @return : array
        */    
        getList(request, input, callback) {
            try {

                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const schema = {
                    "rmType": "joi.string().alphanum().min(2).max(30).label('irequest-lable-64__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate(request.body);
               
                const   methodName = (request.body.rmType=='RM')?'getRequestListwithRM':'getRequestListwithSuperRM'; 
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const subURL = (request.body.rmType=='RM')?'/workbench/requestWithRM':'/workbench/requestWithSuperRM',
                          http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),                                     
                          url = request.productsURL.iRequest + subURL;
                          delete request.body.rmType;
                    http.post(url, methodName, request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "createdBy": { "type": "string" }, "allowApproverEdit": { "type": "boolean" }, "urgentRequirementDesc": { "type": "string" }, "recievedOnDate": { "type": "none" }, "requestId": { "type": "string" }, "requestName": { "type": "string" }, "urgentRequirement": { "type": "boolean" }, "requestNumber": { "type": "number" }, "requestApprovalId": { "type": "string" }, "requestType": { "type": "string" }, "requestDefinitionName": { "type": "string" }, "submittedToWorkflowDate": { "type": "none" }, "requestApprovalUserId": { "type": "string" }, "action": { "type": "number" }, "description": { "type": "string" }, "status":{"type":"number"},"assignedTo":{"type":"string"},"createActivityURL":{"type":"string"},"completelyInProcess":{"type":"boolean"},"requestEndPointName":{"type":"string"},"allowReqManagerEdit":{"type":"boolean"} } } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });          
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name : getDetails for RM
        * @Description : It is used to view the request
        * @return : object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                    "requestId" : "joi.string().allow('').required().label('irequest-lable-20__')",
                    "rmType": "joi.string().alphanum().min(2).max(30).label('irequest-lable-64__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                        let subURL = (request.body.rmType == 'RM')?'/workbench/viewWorkbenchRequestById/':'/workbench/viewAllWorkbenchRequestById/';
                        const http = new (super.httpService)(request),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + subURL + request.body.requestId;
                    http.get(url, 'getRequestManagerRequest', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = {"type":"object","properties":{"behalfOfUser":{"type":"string"},"reqManagerAutoComplete":{"type":"boolean"}," ":{"type":"string"},"assignedToUser":{"type":"string"},"linkedObjectId":{"type":"string"},"availableFor":{"type":"string"},"allowedAssignmentType":{"type":"string"},"flagForDeactivatedRM":{"type":"number"},"assignmentAllowed":{"type":"boolean"},"createdByType":{"type":"string"},"urgentRequirementDesc":{"type":"string"},"createdById":{"type":"string"},"requestId":{"type":"string"},"assignedToUserId":{"type":"string"},"assignedToTypeId":{"type":"number"},"eformDefinitionId":{"type":"string"},"behalfOfUserId":{"type":"string"},"submittedToWorkflow":{"type":"boolean"},"createdBySCId":{"type":"string"},"supplierDBId":{"type":"string"},"requestName":{"type":"string"},"requestDefinitionId":{"type":"string"},"urgentRequirement":{"type":"boolean"},"supplierName":{"type":"string"},"eformInstanceId":{"type":"string"},"requestNumber":{"type":"number"},"requestType":{"type":"string"},"requestDefinitionName":{"type":"string"},"attachments":{"type":"array","properties":{"attachmentId":{"type":"string"},"fileSize":{"type":"number"},"createdById":{"type":"string"},"tenantId":{"type":"string"},"createdDate":{"type":"none"},"status":{"type":"number"},"name":{"type":"string"},"type":{"type":"number"},"path":{"type":"filePathEncode"},"encoding":{"type":"string"}}},"workflowDefinitionId":{"type":"string"},"nonEditableByRequester":{"type":"boolean"},"requiredForSubmission":{"type":"boolean"},"completelyInProcess":{"type":"boolean"},"requestEndpoint":{"type":"string"},"linkedObjectDefinitionId":{"type":"string"},"linkedObjectObjectInstanceId":{"type":"string"},"audits":{"type":"array","properties":{"createdBy":{"type":"string"},"createdById":{"type":"string"},"createdDate":{"type":"none"},"comments":{"type":"string"},"requestAuditId":{"type":"string"},"version":{"type":"number"},"action":{"type":"number"}}},"version":{"type":"number"},"description":{"type":"string"},"status":{"type":"number"}}};
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });              
                }
            } catch (error) {
                return callback(error, null);
            }
        }


        /**
         * markComplete requests which is with RM 
        */
       markComplete(request, input, callback) {
       
        try {                
            const validationUtility = super.utils.validationUtility(request);
            const schema = {
                "requestDefinitionId": "joi.string().label('irequest-lable-10__')",
                "submittedToWorkflow": "joi.boolean().label('irequest-lable-6__')",
                "eformInstanceId": "joi.string().label('irequest-lable-5__')",
                "requestComments": "joi.string().required().label('irequest-lable-4__')",
                "description": "joi.string().allow('', null).label('irequest-lable-3__')",
                "requestName": "joi.string().when('quickSave', { is: false, then: joi.required(), otherwise : joi.optional()}).label('irequest-lable-1__')",
                "urgentRequirement": "joi.boolean().label('irequest-lable-2__')",
                "assignedToTypeId": "joi.number().integer().label('irequest-lable-8__')",
                "urgentRequirementDesc": "joi.string().empty('').max(500).label('irequest-lable-56__')",
                "assignedToUserId": "joi.string().allow('').label('irequest-lable-9__')",
                "behalfOfUserId": "joi.string().label('irequest-lable-7__')",
                "attachmentIds": "joi.array().items(joi.string().min(1).label('irequest-lable-25__')).min(1).unique().label('irequest-lable-11__')",
                "requestId": "joi.string().label('irequest-lable-20__')",
                "eformId": "joi.string().label('irequest-lable-12__')",
                "formInstance": "joi.string().label('irequest-lable-13__')",
                "checkForSecurity": "joi.boolean().label('irequest-lable-51__')",
                "supplierRequestFlag": "joi.boolean().label('irequest-lable-52__')",
                "quickSave": "joi.boolean().label('irequest-lable-53__')",
                "requestMaster": "joi.boolean().label('irequest-lable-62__')",
            };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            } else {
                  const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                  iRequestURL = request.productsURL.iRequest,
                  url = iRequestURL + '/workbench/markRequestCompleted';
                  http.post(url, 'markRequestCompleted', request.body, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    const responseSchema = { "type": "object", "properties": { "action": { "type": "number" }, "requestApprovalId": { "type": "string" }, "requestComments": { "type": "string" }, "quickSave": { "type": "boolean" } } };
                    const output = (new (super.responseHandler)(request, result, responseSchema));
                    return callback(null, request, output.execute());
                }
            });

        } }catch (error) {
            callback(error, null);
        }
    }; 
    
    
        /**
         * markComplete requests which is with RM 
        */
       markRequestReturned(request, input, callback) {
       
        try {  
            
            const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "requestDefinitionId": "joi.string().label('irequest-lable-10__')",
                    "submittedToWorkflow": "joi.boolean().label('irequest-lable-6__')",
                    "eformInstanceId": "joi.string().label('irequest-lable-5__')",
                    "requestComments": "joi.string().required().label('irequest-lable-4__')",
                    "description": "joi.string().allow('', null).label('irequest-lable-3__')",
                    "requestName": "joi.string().when('quickSave', { is: false, then: joi.required(), otherwise : joi.optional()}).label('irequest-lable-1__')",
                    "urgentRequirement": "joi.boolean().label('irequest-lable-2__')",
                    "assignedToTypeId": "joi.number().integer().label('irequest-lable-8__')",
                    "urgentRequirementDesc": "joi.string().empty('').max(500).label('irequest-lable-56__')",
                    "assignedToUserId": "joi.string().allow('').label('irequest-lable-9__')",
                    "behalfOfUserId": "joi.string().label('irequest-lable-7__')",
                    "attachmentIds": "joi.array().items(joi.string().min(1).label('irequest-lable-25__')).min(1).unique().label('irequest-lable-11__')",
                    "requestId": "joi.string().label('irequest-lable-20__')",
                    "eformId": "joi.string().label('irequest-lable-12__')",
                    "formInstance": "joi.string().label('irequest-lable-13__')",
                    "checkForSecurity": "joi.boolean().label('irequest-lable-51__')",
                    "supplierRequestFlag": "joi.boolean().label('irequest-lable-52__')",
                    "quickSave": "joi.boolean().label('irequest-lable-53__')",
                    "requestMaster": "joi.boolean().label('irequest-lable-62__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                  iRequestURL = request.productsURL.iRequest,
                  url = iRequestURL + '/workbench/markRequestReturned';
                  http.post(url, 'markRequestReturned', request.body, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    const responseSchema = { "type": "object", "properties": { "action": { "type": "number" }, "requestApprovalId": { "type": "string" }, "requestComments": { "type": "string" }, "quickSave": { "type": "boolean" } } };
                    const output = (new (super.responseHandler)(request, result, responseSchema));
                    return callback(null, request, output.execute());
                }
            });

        } }catch (error) {
            callback(error, null);
        }
    }; 
           
     
    /**
        * @Name : save
        * @Description : It is used to apply/submit the workbench save
        * @return : object
        */
       save(request, input, callback) {
        try {

            const validationUtility = super.utils.validationUtility(request);
            const schema = {
                "requestApprovalId": "joi.string().label('irequest-lable-49__')",
                "submittedToWorkflow": "joi.boolean().label('irequest-lable-6__')",              
                "requestDefinitionId": "joi.string().label('irequest-lable-49__')",
                "action": "joi.number().integer().label('irequest-lable-50__')",
                "requestComments": "joi.string().label('irequest-lable-4__')",
                "description": "joi.string().label('irequest-lable-3__')",
                "requestName": "joi.string().when('quickSave', { is: false, then: joi.required(), otherwise : joi.optional()}).label('irequest-lable-1__')",
                "urgentRequirement": "joi.boolean().label('irequest-lable-2__')",
                "assignedToTypeId": "joi.number().integer().label('irequest-lable-8__')",
                "urgentRequirementDesc": "joi.string().empty('').max(500).label('irequest-lable-56__')",
                "assignedToUserId": "joi.string().allow('').label('irequest-lable-9__')",
                "behalfOfUserId": "joi.string().label('irequest-lable-7__')",
                "attachmentIds": "joi.array().items(joi.string().min(1).label('irequest-lable-25__')).min(1).unique().label('irequest-lable-11__')",
                "requestId": "joi.string().label('irequest-lable-20__')",
                "eformId": "joi.string().label('irequest-lable-12__')",
                "formInstance": "joi.string().label('irequest-lable-13__')",
                "checkForSecurity": "joi.boolean().label('irequest-lable-51__')",
                "supplierRequestFlag": "joi.boolean().label('irequest-lable-52__')",
                "quickSave": "joi.boolean().label('irequest-lable-53__')",
                "eformInstanceId": "joi.string().label('irequest-lable-5__')",
                "requestMaster": "joi.boolean().label('irequest-lable-62__')"
            }; 
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                    iRequestURL = request.productsURL.iRequest,
                    url = iRequestURL + '/workbench/requestModifiedByRM';

                http.post(url, 'workbenchSave', request.body, (error, result) => {
                    if (error) {
                        callback(error, null);
                    } else {
                        if (!super.lodash.isEmpty(result.data.requestApprovalId)) {
                            result.message = [{ description: "irequest-msg-5" }];
                        }
                        const responseSchema = { "type": "object", "properties": { "action": { "type": "number" }, "requestApprovalId": { "type": "string" }, "requestComments": { "type": "string" }, "quickSave": { "type": "boolean" } } };
                        const output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            }
        } catch (error) {
            callback(error, null);
        }
    };
      
    };
   
    return Workbench;
};        