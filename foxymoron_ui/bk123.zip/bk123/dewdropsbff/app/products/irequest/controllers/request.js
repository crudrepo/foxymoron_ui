/**
 * Request Controller
 *
 * @description :: Provides Request related curd operations
 */

module.exports = (parentClass) => {

    class Request extends parentClass {

        /**
         * Get the request count details
        */
        getCount(request, input, callback) {
            try {
                const input = {
                    "onlyTenantSpecific": false,
                    "draftDataRequired": true,
                    "supplierRequestFlag": false
                };
                const http = new (super.httpService)(request);
                const iRequestURL = request.productsURL.iRequest;
                const url = iRequestURL + '/request/count';
                http.post(url, 'requestCount', input, (error, result) => {
                    if (error) {
                        callback(error, null);
                    } else if (result) {
                        const responseSchema = { "type": "object", "properties": { "total": { "type": "number" }, "pending": { "type": "number" } } };
                        const output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                        return callback(null, request, output);
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        }


        /**
        * @Name : getDefinition
        * @Description : It is used to get the request definition list
        * @return : Array List
        */
        getDefinition(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const iRequestURL = request.productsURL.iRequest;
                    const url = iRequestURL + '/requestDefinition/filter';
                    http.post(url, 'getRequestDefinitionList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "createdBy": { "type": "string" }, "statusText": { "type": "i18n" }, "endPoint": { "type": "string" }, "tenantId": { "type": "string" }, "createdById": { "type": "string" }, "requestType": { "type": "string" }, "requestDefinitionId": { "type": "string" }, "requestDefinitionName": { "type": "string" }, "createdDate": { "type": "none" }, "updatedDate": { "type": "none" }, "availableFor": { "type": "string" }, "helpText": { "type": "string" }, "version": { "type": "number" }, "status": { "type": "number" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Name : getList
        * @Description : It is used to get the request list
        * @return : array
        */
        getList(request, input, callback) {
            try {
                let data = super.lodash.merge({ "criteriaGroup": { "logicalOperator": "AND", "criteria": [] } }, request.body);
                let isTenantSpecific = super.lodash.find(data.criteriaGroup.criteria, function (criteriaObj) {
                    return criteriaObj['fieldName'] === 'onlyTenantSpecific';
                });
                if (!isTenantSpecific) {
                    data.criteriaGroup.criteria.push({ "fieldName": "onlyTenantSpecific", "operation": "EQUALS", "value": "false" });
                }

                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(data);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const iRequestURL = request.productsURL.iRequest;
                    const url = iRequestURL + '/request/filter';
                    http.post(url, 'getRequestList', data, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "statusText": { "type": "i18n" }, "version": { "type": "number" }, "description": { "type": "string" }, "urgentRequirementDesc": { "type": "string" }, "createdBy": { "type": "string" }, "status": { "type": "number" }, "assignedToTypeId": { "type": "number" }, "requestDefinitionId": { "type": "string" }, "requestDefinitionName": { "type": "string" }, "requestName": { "type": "string" }, "requestType": { "type": "string" }, "createdById": { "type": "string" }, "tenantId": { "type": "string" }, "requestNumber": { "type": "number" }, "requestId": { "type": "string" }, "assignedTo": { "type": "string" }, "endPoint": { "type": "string" }, "supplierDBId": { "type": "string" }, "urgentRequirement": { "type": "boolean" }, "submittedToWorkflowDate": { "type": "none" }, "linkedToEntities": { "type": "object" }, "progressPercentage": { "type": "number" }, "createdOn": { "type": "none" }, "supplierName": { "type": "string" }, "updatedDate": { "type": "none" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Name : destroy
        * @Description : This method is used to delete a request
        * @return : object
        */
        destroy(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                    "request_Id":  "joi.string().required().label('irequest-lable-22__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({ "request_Id": request.params.request_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request);
                    const iRequestURL = request.productsURL.iRequest;
                    const url = iRequestURL + '/request/delete';
                    const requestData = {
                        "requestId": request.params.request_Id,
                        "supplierRequestFlag": false,
                        "buyerTenantId": ""
                    };
                    http.post(url, 'deleteRequest', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const message = { description: "irequest-msg-3" };
                            if (!super.lodash.isEmpty(result.data.id)) {
                                result.message = [message];
                            }
                            let responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "requestName": "joi.string().required().max(100).label('irequest-lable-1__')",
                    "urgentRequirement": "joi.boolean().label('irequest-lable-2__')",
                    "description": "joi.string().empty('').max(500).label('irequest-lable-3__')",
                    "urgentRequirementDesc": "joi.string().empty('').max(500).label('irequest-lable-56__')",
                    "requestComments": "joi.string().empty('').label('irequest-lable-4__')",
                    "eformInstanceId": "joi.string().empty('').label('irequest-lable-5__')",
                    "submittedToWorkflow": "joi.boolean().label('irequest-lable-6__')",
                    "behalfOfUserId": "joi.string().empty('').label('irequest-lable-7__')",
                    "assignedToTypeId": "joi.number().empty('').label('irequest-lable-8__')",
                    "assignedToUserId": "joi.string().empty('').label('irequest-lable-9__')",
                    "requestDefinitionId": "joi.string().empty('').required().label('irequest-lable-10__')",
                    "attachmentIds":  "joi.array().items(joi.string().min(1).label('irequest-lable-11__')).min(1).unique().label('irequest-lable-11__')",
                    "eformId": "joi.string().empty('').label('irequest-lable-12__')",
                    "formInstance": "joi.string().empty('').label('irequest-lable-13__')",
                    "supplierRequestFlag": "joi.boolean().label('irequest-lable-14__')",
                    "createdBySCId": "joi.string().empty('').label('irequest-lable-15__')",
                    "supplierDBId": "joi.string().empty('').label('irequest-lable-16__')",
                    "buyerTenantId": "joi.string().empty('').label('irequest-lable-17__')",
                    "supplierName": "joi.string().empty('').label('irequest-lable-18__')",
                    "cwfIntegration": "joi.boolean().optional().label('irequest-lable-66__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = request.body;
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/request/create';
                    http.post(url, 'createBasket', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const message = { description: "irequest-msg-1" };
                            if (!super.lodash.isEmpty(result.data.id)) {
                                result.message = [message];
                            }
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        update(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "requestId": "joi.string().required().label('irequest-lable-19__')",
                    "requestName": "joi.string().required().max(100).label('irequest-lable-1__')",
                    "urgentRequirement": "joi.boolean().label('irequest-lable-2__')",
                    "urgentRequirementDesc": "joi.string().empty('').max(500).label('irequest-lable-56__')",
                    "description": "joi.string().empty('').max(500).label('irequest-lable-3__')",
                    "requestComments": "joi.string().empty('').label('irequest-lable-4__')",
                    "eformInstanceId": "joi.string().empty('').label('irequest-lable-5__')",
                    "submittedToWorkflow": "joi.boolean().label('irequest-lable-6__')",
                    "behalfOfUserId": "joi.string().empty('').label('irequest-lable-7__')",
                    "assignedToTypeId": "joi.number().empty('').label('irequest-lable-8__')",
                    "assignedToUserId": "joi.string().empty('').label('irequest-lable-9__')",
                    "requestDefinitionId": "joi.string().empty('').required().label('irequest-lable-10__')",
                    "attachmentIds":  "joi.array().items(joi.string().min(1).label('irequest-lable-11__')).min(1).unique().label('irequest-lable-11__')",
                    "eformId": "joi.string().empty('').label('irequest-lable-12__')",
                    "formInstance": "joi.string().empty('').label('irequest-lable-13__')",
                    "supplierRequestFlag": "joi.boolean().label('irequest-lable-14__')",
                    "createdBySCId": "joi.string().empty('').label('irequest-lable-15__')",
                    "supplierDBId": "joi.string().empty('').label('irequest-lable-16__')",
                    "buyerTenantId": "joi.string().empty('').label('irequest-lable-17__')",
                    "supplierName": "joi.string().empty('').label('irequest-lable-18__')",
                    "statusDraft": "joi.boolean().empty('').label('irequest-lable-20__')",
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "requestId": request.params.request_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = super.lodash.merge(request.body, { "requestId": request.params.request_Id }),
                        http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/request/update';

                    http.post(url, 'updateBasket', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const message = { description: "irequest-msg-2" };
                            if (!super.lodash.isEmpty(result.data.id)) {
                                result.message = [message];
                            }
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };


        /**
        * @Name : getParams
        * @Description : It is used to get the request creation details
        * @return : object / Throw Error
        */
        getParams(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "requestDefinitionId": "joi.required().label('irequest-lable-21__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "requestDefinitionId": request.params.request_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request);
                    const iRequestURL = request.productsURL.iRequest;
                    const url = iRequestURL + '/request/params/' + request.params.request_Id;
                    http.get(url, 'requestCreationDetails', (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else if (result) {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }


        /**
        * @Name : getViewDetails
        * @Description : It is used to view the request
        * @return : object / Throw Error
        */
        getViewDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "requestId": "joi.required().label('irequest-lable-20__')",
                        "version": "joi.number().integer().label('irequest-lable-36__')",
                        "userActivity": "joi.string().label('irequest-lable-67__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "requestId": request.params.request_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const requestData = {
                        requestId: request.params.request_Id,
                        version: request.body.version,
                        activity: request.body.userActivity,
                        supplierRequestFlag: false
                    },
                        http = new (super.httpService)(request),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/request';

                    http.post(url, 'viewRequest', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = { "type": "object", "properties": { "behalfOfUser": { "type": "string" }, "reqManagerAutoComplete": { "type": "boolean" }, "createActivityURL": { "type": "string" }, "assignedToUser": { "type": "string" }, "linkedObjectId": { "type": "string" }, "availableFor": { "type": "string" }, "allowedAssignmentType": { "type": "string" }, "flagForDeactivatedRM": { "type": "number" }, "assignmentAllowed": { "type": "boolean" }, "createdByType": { "type": "string" }, "urgentRequirementDesc": { "type": "string" }, "createdById": { "type": "string" }, "requestId": { "type": "string" }, "assignedToUserId": { "type": "string" }, "assignedToTypeId": { "type": "number" }, "eformDefinitionId": { "type": "string" }, "behalfOfUserId": { "type": "string" }, "submittedToWorkflow": { "type": "boolean" }, "createdBySCId": { "type": "string" }, "supplierDBId": { "type": "string" }, "requestName": { "type": "string" }, "requestDefinitionId": { "type": "string" }, "urgentRequirement": { "type": "boolean" }, "supplierName": { "type": "string" }, "eformInstanceId": { "type": "string" }, "requestNumber": { "type": "number" }, "requestType": { "type": "string" }, "requestDefinitionName": { "type": "string" }, "attachments": { "type": "array", "properties": { "attachmentId": { "type": "string" }, "fileSize": { "type": "number" }, "createdById": { "type": "string" }, "tenantId": { "type": "string" }, "createdDate": { "type": "none" }, "status": { "type": "number" }, "name": { "type": "string" }, "type": { "type": "number" }, "path": { "type": "filePathEncode" }, "encoding": { "type": "string" } } }, "workflowDefinitionId": { "type": "string" }, "nonEditableByRequester": { "type": "boolean" }, "requiredForSubmission": { "type": "boolean" }, "completelyInProcess": { "type": "boolean" }, "requestEndpoint": { "type": "string" }, "linkedObjectDefinitionId": { "type": "string" }, "linkedObjectObjectInstanceId": { "type": "string" }, "audits": { "type": "array", "properties": { "createdBy": { "type": "string" }, "createdById": { "type": "string" }, "createdDate": { "type": "none" }, "comments": { "type": "string" }, "requestAuditId": { "type": "string" }, "version": { "type": "number" }, "action": { "type": "number" } } }, "version": { "type": "number" }, "description": { "type": "string" }, "status": { "type": "number" }, "allowRequesterToAddAdhocUser": { "type": "boolean" } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }


        /**
        * @Name : assignTo
        * @Description : It is used to assign the request to user/userGroup
        * @return : object / Throw Error
        */
        assignTo(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "displayName": "joi.string().required().label('irequest-lable-47__')",
                    "userType": "joi.number().integer().required().label('irequest-lable-48__')",
                    "requestDefinitionId": "joi.string().empty('').label('irequest-lable-21__')",
                    "buyerTenantId": "joi.string().empty('').label('irequest-lable-17__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const requestData = {
                        displayName: request.body.displayName,
                        userType: request.body.userType,
                        requestDefinitionId: request.body.requestDefinitionId,
                        buyerTenantId: request.body.buyerTenantId,
                        supplierRequestFlag: false
                    };
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity, super.appConstant.resHandler.entityList);
                    const iRequestURL = request.productsURL.iRequest;
                    const url = iRequestURL + '/request/assignTo';
                    http.post(url, 'assignRequestTo', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = { "type": "array", "properties": { "emailId": { "type": "string" }, "id": { "type": "string" }, "displayName": { "type": "string" } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }


        /**
        * @Name : printPreview
        * @Description : It is used to get the request print preview
        * @return : object / Throw Error
        */
        printPreview(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "requestId": "joi.required().label('irequest-lable-22__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "requestId": request.params.request_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const requestData = {
                        requestId: request.params.request_Id
                    },
                        http = new (super.httpService)(request),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/request/printPreview';
                    http.post(url, 'getPrintPreview', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            return callback(null, request, { "data": { "content-type": result.data["contentType"], "file-data": result.data["content"] } });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Name : pdfFormat
        * @Description : It is used to view the Pdf
        * @return : object / Throw Error
        */
        pdfFormat(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "requestId": "joi.required().label('irequest-lable-22__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "requestId": request.params.request_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const requestData = {
                        requestId: request.params.request_Id,
                        activity: '',
                        supplierRequestFlag: false,
                        buyerTenantId: null
                    },
                        http = new (super.httpService)(request),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/request/pdfFormat';

                    http.post(url, 'ViewPdf', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return  callback(null, request, { "data": { "content-type": result.data["contentType"], "fileName": result.data["fileName"], "file-data": result.data["content"] } });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }


        /**
        * @Name : getAdhocApprovalUser
        * @Description : It is used to get the all the eligible Approvers
        * @return : object / Throw Error
        */
        getAdhocApprovalUser(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "displayName": "joi.string().required().label('irequest-lable-47__')",
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const requestData = {
                        displayName: request.body.displayName,
                    };
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity, super.appConstant.resHandler.entityList);
                    const iRequestURL = request.productsURL.iRequest;
                    const url = iRequestURL + '/request/getAdhocApprovalUser';
                    http.post(url, 'assignRequestTo', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = { "type": "array", "properties": { "emailId": { "type": "string" }, "id": { "type": "string" }, "displayName": { "type": "string" }, "userType": { "type": "string" } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Name : submitAdhocRequest
        * @Description : It is used to submit the request with added adhooc approvers 
        * @return : object / Throw Error
        */
        submitAdhocRequest(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "adhocUsers": "joi.array().items(joi.object().keys({workflowNodeId: joi.string().required().label('irequest-lable-57__'),parentNodeId: joi.string().required().label('irequest-lable-58__'),parentUserId: joi.string().required().label('irequest-lable-59__'),approverUserId: joi.string().required().label('irequest-lable-54__'),approverType: joi.string().required().label('irequest-lable-48__'),nodeId: joi.string().required().label('irequest-lable-56__'),displayName: joi.string().required().label('irequest-lable-47__') }))",
                    "requestId": "joi.string().required().label('irequest-lable-20__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = request.body;
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/request/createRequestForAdhocUser';
                    http.post(url, 'createAdhocRequest', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const message = { description: "irequest-msg-1" };
                            if (!super.lodash.isEmpty(result.data.id)) {
                                result.message = [message];
                            }
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }


        /**
        * @Name : getRequestTypes
        * @Description : It is used to get the request Type list
        * @return : Array List
        */
        getRequestTypes(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const iRequestURL = request.productsURL.iRequest;
                    const url = iRequestURL + '/requestType/filter';
                    http.post(url, 'getRequestTypeList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "requestType": { "type": "string" }, "statusText": { "type": "i18n" }, "requestEndPointId": { "type": "number" }, "tenantId": { "type": "string" }, "requestEndPoint": { "type": "string" }, "requestTypeId": { "type": "string" }, } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Name : getAllRequest
        * @Description : It is used to get all the request list which is with RM
        * @return : array
        */
        getAllRequests(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const iRequestURL = request.productsURL.iRequest;
                    let url = iRequestURL + '/allRequests/getAllRecordsForRequestMaster';

                    http.post(url, 'getRequestListwithRequestMaster', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "status": { "type": "number" }, "requestNumber": { "type": "string" }, "requestName": { "type": "string" }, "requesterName": { "type": "string" }, "requestDefinitionName": { "type": "string" }, "requestTypeName": { "type": "string" }, "createdDate": { "type": "none" }, "updatedDate": { "type": "none" }, "assignedToUserId": { "type": "string" }, "assignedToUserGroupId": { "type": "string" }, "assignedToTypeId": { "type": "number" }, "urgentRequirementDesc": { "type": "string" }, "requestApprovalId": { "type": "string" }, "requestId": { "type": "string" }, "workflowApproverName": { "type": "string" }, "assignedToUserName": { "type": "string" }, "createActivityURL": { "type": "string" }, "assignedToUserStatus": { "type": "number" }, "assignedToGroupStatus": { "type": "string" }, "assignedToGroupName": { "type": "string" }, "assignedUserStatus": { "type": "boolean" }, "eformInstanceId": { "type": "string" }, "requestApprovalUserId": { "type": "string" }, "requestEndPointProductName": { "type": "string" }, "groupApprovalUserCount": { "type": "number" }, "allowApproverEdit": { "type": "boolean" }, "allowReqManagerEdit": { "type": "boolean" }, "reqManagerAutoComplete": { "type": "boolean" }, "statusText": { "type": "string" }, "urgentRequirement": { "type": "boolean" }, "workflowApproverList": { "type": "none" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }

        }

    /**
    * @Name : get Request Details in All Request page with status in approval.
    * @Description : It is used to view the request
    * @return : object / Throw Error
    */
    getRequest(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "requestApprovalId" : "joi.string().required().label('irequest-lable-49__')",
                    "requestApprovalUserId" : "joi.string().allow('').label('irequest-lable-54__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const approvalUserId = (request.body.requestApprovalUserId!=undefined) ? request.body.requestApprovalUserId : '',
                    http = new (super.httpService)(request),
                    iRequestURL = request.productsURL.iRequest,
                    url = iRequestURL + '/allRequests/masterApproval?requestApprovalId=' + request.body.requestApprovalId + '&requestApprovalUserId='+ approvalUserId;
                
                http.get(url, 'getRequest', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = {"type":"object","properties":{"behalfOfUser":{"type":"string"},"reqManagerAutoComplete":{"type":"boolean"},"createActivityURL":{"type":"string"},"assignedToUser":{"type":"string"},"linkedObjectId":{"type":"string"},"availableFor":{"type":"string"},"allowedAssignmentType":{"type":"string"},"flagForDeactivatedRM":{"type":"number"},"assignmentAllowed":{"type":"boolean"},"createdByType":{"type":"string"},"urgentRequirementDesc":{"type":"string"},"createdById":{"type":"string"},"requestId":{"type":"string"},"assignedToUserId":{"type":"string"},"assignedToTypeId":{"type":"number"},"eformDefinitionId":{"type":"string"},"behalfOfUserId":{"type":"string"},"submittedToWorkflow":{"type":"boolean"},"createdBySCId":{"type":"string"},"supplierDBId":{"type":"string"},"requestName":{"type":"string"},"requestDefinitionId":{"type":"string"},"urgentRequirement":{"type":"boolean"},"supplierName":{"type":"string"},"eformInstanceId":{"type":"string"},"requestNumber":{"type":"number"},"requestType":{"type":"string"},"requestDefinitionName":{"type":"string"},"attachments":{"type":"array","properties":{"attachmentId":{"type":"string"},"fileSize":{"type":"number"},"createdById":{"type":"string"},"tenantId":{"type":"string"},"createdDate":{"type":"none"},"status":{"type":"number"},"name":{"type":"string"},"type":{"type":"number"},"path":{"type":"filePathEncode"},"encoding":{"type":"string"}}},"workflowDefinitionId":{"type":"string"},"nonEditableByRequester":{"type":"boolean"},"requiredForSubmission":{"type":"boolean"},"completelyInProcess":{"type":"boolean"},"requestEndpoint":{"type":"string"},"linkedObjectDefinitionId":{"type":"string"},"linkedObjectObjectInstanceId":{"type":"string"},"audits":{"type":"array","properties":{"createdBy":{"type":"string"},"createdById":{"type":"string"},"createdDate":{"type":"none"},"comments":{"type":"string"},"requestAuditId":{"type":"string"},"version":{"type":"number"},"action":{"type":"number"}}},"version":{"type":"number"},"description":{"type":"string"},"status":{"type":"number"},"actionTaken":{"type":"number"}}};
                        const output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
        * @Name : getDynamicForms
        * @Description : It is used to view the request
        * @return : object / Throw Error
        */
        getDynamicForms(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "requestId": "joi.required().label('irequest-lable-20__')",
                        "version": "joi.number().required().integer().label('irequest-lable-36__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "requestId": request.params.request_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const requestData = {
                        requestId: request.params.request_Id,
                        version: request.body.version,
                    },
                        http = new (super.httpService)(request),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/request/eFormVersion';

                    http.post(url, 'getDynamicForms', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = { "type": "object", "properties": { "dynamicForm": { "type": "string" }, "dynamicInstance": { "type": "string" } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }


    };
    return Request;
};