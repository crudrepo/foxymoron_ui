/**
 * Linkobject Controller
 *
 * @description :: Provides to get the linked object list
 */

module.exports = (parentClass) => {

    class LinkObject extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used to get the linked object list
        * @return : object
        */    
        getList(request, input, callback) {
            try {         
                const validationUtility = super.utils.validationUtility(request); 
                validationUtility.addCommonSchema('pagination');            
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const http =  new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                          iRequestURL = request.productsURL.iRequest,
                          url = iRequestURL + '/request/linkedObjectList';
                    http.post(url, 'getlinkedObjList', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else if(result) {
                            const responseSchema = { "type": "object", "properties": {"records":{"type":"array","properties":{"tableDefinition": { "type": "string" }, "tableInstance": { "type": "string" }}} }},
                            output =  (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);                          
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        };

    };

    return LinkObject;
};