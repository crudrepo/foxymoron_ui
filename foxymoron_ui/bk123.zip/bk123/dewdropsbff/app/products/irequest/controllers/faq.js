/**
 * FAQ Controller
 *
 * @description :: Provides FAQ related curd operations
 */

"use strict";
module.exports = (parentClass) => {

    class Faq extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used to get the FAQ list
        * @return : array
        */    
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request); 
                validationUtility.addCommonSchema('pagination'); 
                validationUtility.addCommonSchema('sort');              
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const http =  new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                          iRequestURL = request.productsURL.iRequest,
                          url = iRequestURL + '/faq/filter';
                    http.post(url, 'getFAQList', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else if(result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"createdBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"actorType":{"type":"string"},"emailAddress":{"type":"string"}}},"createdOn":{"type":"none"},"modifiedBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"emailAddress":{"type":"string"},"active":{"type":"boolean"},"actorType":{"type":"string"}}},"modifiedOn":{"type":"none"},"status":{"type":"number"},"answer":{"type":"string"},"faqId":{"type":"string"},"deleted":{"type":"boolean"},"name":{"type":"string"},"tenantId":{"type":"string"},"statusText":{"type":"i18n"},"faqType":{"type":"object","properties":{"deleted":{"type":"boolean"},"faqTypeId":{"type":"string"},"faqTypeName":{"type":"string"},"tenantId":{"type":"string"},"createdBy":{"type":"string"}}}}}}},
                            output =  (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);                          
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name : getTypes
        * @Description : It is used to get the FAQ Type list
        * @return : object
        */
        getTypes(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                         iRequestURL = request.productsURL.iRequest,
                         url = iRequestURL + '/faq/type/filter';
                    http.post(url, 'getFaqTypeList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"faqTypeName":{"type":"string"},"faqTypeId":{"type":"string"},"deleted":{"type":"boolean"},"tenantId":{"type":"string"},"createdBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"actorType":{"type":"string"},"userRoles":{"type":"none"},"emailAddress":{"type":"string"}}}}}}},
                                  output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    };

    return Faq;
};