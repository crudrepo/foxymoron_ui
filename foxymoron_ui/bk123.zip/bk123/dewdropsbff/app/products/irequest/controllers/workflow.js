/**
 * Workflow Controller
 *
 * @description :: Provides Workflow related curd operations
 */

module.exports = (parentClass) => {

    class Workflow extends parentClass {
        /**
        * Predict the Workflow
        */
        predict(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "requestId": "joi.string().optional().label('irequest-lable-20__')",
                    "requestName": "joi.string().optional().allow('').label('irequest-lable-1__')",
                    "urgentRequirement": "joi.boolean().optional().label('irequest-lable-2__')",
                    "description": "joi.string().optional().label('irequest-lable-3__')",
                    "eformInstanceId": "joi.string().optional().label('irequest-lable-5__')",
                    "submitToWorkflow": "joi.boolean().optional().label('irequest-lable-24__')",
                    "behalfOfUserId": "joi.string().optional().label('irequest-lable-7__')",
                    "assignedToUserId": "joi.string().optional().label('irequest-lable-9__')",
                    "assignedToTypeId": "joi.number().optional().label('irequest-lable-8__')",
                    "requestDefinitionId": "joi.string().optional().label('irequest-lable-10__')",
                    "attachmentIds": "joi.array().items(joi.string().min(1).label('irequest-lable-25__')).min(1).unique().label('irequest-lable-11__')",
                    "draft": "joi.boolean().optional().label('irequest-lable-26__')",
                    "mode": "joi.boolean().when('requestId', { is: joi.exist(), then: joi.required(), otherwise : joi.optional()}).label('irequest-lable-27__')",
                    "buyerTenantId": "joi.string().optional().label('irequest-lable-17__')",
                    "supplierRequestFlag": "joi.boolean().optional().label('irequest-lable-14__')",
                    "formInstance": "joi.string().optional().label('irequest-lable-13__')",
                    "editMode": "joi.boolean().optional().label('irequest-lable-65__')",
                    "cwfIntegration": "joi.boolean().optional().label('irequest-lable-66__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                          iRequestURL = request.productsURL.iRequest,
                          url = iRequestURL + '/workflow/predictWorkflow';
                    http.post(url, 'predictWorkflow', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "userName": { "type": "string" }, "displayName": { "type": "string" }, "actionOn": { "type": "none" }, "approvedOn": { "type": "none" }, "recievedOn": { "type": "none" }, "modifiedOn": { "type": "none" }, "comment": { "type": "string" }, "userNames": { "type": "none" }, "node": { "type": "string" }, "userType": { "type": "string" }, "status": { "type": "number" }, "nodeId": { "type": "string" }, "workflowNodeId": { "type": "string" }, "userId": { "type": "string" } ,"delegatedUserList": {"type": "array","properties": {"userId": {"type": "string"},"displayName": {"type": "string"},"userName": {"type": "string"},"comments": {"type": "string"},"delegateVersion": {"type": "number"},"action": {"type": "number"}}},"delegated": {"type": "boolean"},"userMap":{"type":"none"} } };
                            const output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                            return callback(null, request, output);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
    }

    return Workflow;
}