"use strict";
const rm = require('@service/require.module')();

/**
 * IRequest Hook
 *
 * @description :: Create common methods & used it throught out application.
 */
class IRequest {

    /*
     * Get Email Config Method
     * This method to get the email configuration details(to, cc email).
    */    
    getEmailConfig(request, input, callback) {
        try {
            const http = new (rm.httpService)(request);            
            const iRequestURL = request.productsURL.iRequest;
            const url = iRequestURL + '/config/email';
            http.get(url, 'getEmailConfig', (error, result) => {
                if (error) {
                    return callback(error, null);
                } else if (result) {
                    return callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }    

    /*
     * Add Attachment Method
     * This method to create an entry into the attachment table.
    */    
    addAttachment(request, input, callback) {
        try {
            const http = new (rm.httpService)(request);            
            const iRequestURL = request.productsURL.iRequest;
            const url = iRequestURL+'/attachment/add';
            http.post(url, 'addAttachment', input, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else if (result) {
                    return callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }    

    /*
     * Delete Attachment Method
     * This method to delete an entry from attachment table.
    */    
    deleteAttachment(request, input, callback) {
        try {
            const http = new (rm.httpService)(request),            
                  iRequestURL = request.productsURL.iRequest,
                  url = iRequestURL + '/attachment/delete/' + input.attachmentId;
            http.delete(url, 'deleteAttachment', (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    } 
}

module.exports = IRequest;