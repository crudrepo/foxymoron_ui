"use strict";
module.exports = (parentClass) => {
    class Phase extends parentClass {

        /**
       * @Method Name : getList
       * @Description : Search for Phase list
       * @return object / Throw Error
       */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        iManageUrl = request.productsURL.iManage,
                        url = iManageUrl + '/projectstage/filter';
                    http.post(url, 'searchphase', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"projectStageID":{"type":"number"},"projectStageTitle":{"type":"string"},"projectStageDescription":{"type":"string"},"stagePlannedStartDate":{"type":"string"},"stagePlannedEndDate":{"type":"string"},"stageActualStartDate":{"type":"string"},"stageActualEndDate":{"type":"string"},"stageCompletionPercentage":{"type":"number"},"stageStatusId":{"type":"number"},"stageStatusName":{"type":"string"},"projectTitle":{"type":"string"},"customerProjectID":{"type":"string"},"projectPriorityName":{"type":"string"},"projectOwnerName":{"type":"string"}}}}},
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


    };
    return Phase;
};
