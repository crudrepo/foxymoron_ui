"use strict";

module.exports = {   

    /**
    * @swagger
    * /a/imanage/projects/list:
    *   post:
    *     tags:
    *       - iManage API
    *     summary: Search projects
    *     operationId: searchProjects
    *     description: Search projects
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search for projects ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   getList: {
        pre: null,
        process: "project.getList",
        post: null,
        method: 'POST'
    }

};    
