"use strict";

module.exports = {   

    /**
    * @swagger
    * /a/imanage/phases/list:
    *   post:
    *     tags:
    *       - iManage API
    *     summary: Search phases
    *     operationId: searchPhases
    *     description: Search phases
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search for phases ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   getList: {
        pre: null,
        process: "phase.getList",
        post: null,
        method: 'POST'
    }

};    
