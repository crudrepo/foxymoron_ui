/**
 * Invoice Template Controller
 *
 * @description :: Provides invoice template related CRUD operation.
 */

module.exports = (parentClass) => 
{
    class InvoiceTemplate extends parentClass 
    {
        getList(request, input, callback) 
        {
            try 
            {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);

                if (result) 
                {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }
                else 
                {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    einvoiceURL = request.productsURL.eInvoice,
                    url = einvoiceURL + '/invoiceTemplate/filter';
                    http.post(url, 'invoiceTemplateFilterList', request.body, (error, result) => 
                    {
                        if (error) 
                        {
                            callback(error, null);
                        }
                        else 
                        {
                                const utils = super.utils,
                                lodash = super.lodash,
                                output = {},
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'].records : [],
                                pagination = (!super.lodash.isEmpty(result['data'])) ? result['data'].pagination : {},
                                
                                // TODO : We need to change this.
                                responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"templateId":{"type":"string"},"requester":{"type":"string"},"autoInvoiceNo":{"type":"string"},"description":{"type":"string"},"lastExecutionTime":{"type":"none"},"nextExecutionTime":{"type":"none"},"supplierName":{"type":"string"},"supplierId":{"type":"string"},"docType":{"type":"none"},"referenceValue":{"type":"string"},"origin":{"type":"none"},"templateName":{"type":"string"},"status":{"type":"none"},"invoicedAmount":{"type":"number"},"countractNumber":{"type":"string"},"version":{"type":"none"},"requesterEmail":{"type":"string"},"designation":{"type":"string"},"suppCurrency":{"type":"string"},"supplieName":{"type":"string"},"comments":{"type":"string"},"grossTotalAmount":{"type":"number"},"postedOn":{"type":"none"},"approvedOn":{"type":"none"},"companyCode":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"createdOn":{"type":"none"},"createdBy":{"type":"string"},"neverExpire":{"type":"boolean"}}}}};
                                let companyCodes = [],
                                businessUnitCodes = [],
                                locationCodes = [];
                                if(!lodash.isEmpty(records) && lodash.isArray(records)) 
                                {  
                                    records.forEach(item => 
                                    {
                                        if(item.companyCode) companyCodes.push(item.companyCode);
                                        if(item.businessUnitCode) businessUnitCodes.push( item.businessUnitCode);
                                        if(item.locationCode) locationCodes.push( item.locationCode);
                                    });
                                    companyCodes = lodash.uniq(companyCodes);
                                    businessUnitCodes = lodash.uniq(businessUnitCodes);
                                    locationCodes = lodash.uniq(locationCodes);
                                }
                                else 
                                {
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }
                                
                                const cmd = new (super.cmdHook({request: request}))(),
                                tasks = [
                                    (methodCallback) => {
                                        if (lodash.isEmpty(companyCodes)) 
                                        {
                                            const output = (new (super.responseHandler)(request, result, responseSchema));
                                            output.addCommonSchema('pagination', output.responseSchema.properties);
                                            return callback(null, request, output.execute());
                                            //return methodCallback(request, {});
                                        }
                                        //Step 1 : Fetch company details 
                                        const reqData = { "codes": companyCodes, "pageNo":1 , "perPageRecords":companyCodes.length };
                                        cmd.getCompany(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.companyDetails = input.data.result || [];
                                        if (lodash.isEmpty(businessUnitCodes)) 
                                        {
                                            
                                            const output = (new (super.responseHandler)(request, result, responseSchema));
                                            output.addCommonSchema('pagination', output.responseSchema.properties);
                                            return callback(null, request, output.execute());
                                            //return methodCallback(request, {});
                                        }
                                        //Step 2 : Fetch BusinessUnit details 
                                        const reqData = { "codes": businessUnitCodes,"pageNo":1 , "perPageRecords":businessUnitCodes.length  };
                                        cmd.getBusinessUnit(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.businessUnitDetails = input.data.result || [];
                                        if (lodash.isEmpty(locationCodes)) 
                                        {
                                            const output = (new (super.responseHandler)(request, result, responseSchema));
                                            output.addCommonSchema('pagination', output.responseSchema.properties);
                                            return callback(null, request, output.execute());
                                            //return methodCallback(request, {});
                                        }
                                        //Step 3 : Fetch Location details 
                                        const reqData = { "codes": locationCodes, "pageNo":1 , "perPageRecords":locationCodes.length  };
                                        cmd.getLocation(request, reqData, methodCallback);
                                    },                                    
                                    (request, input, methodCallback) => {
                                        output.locationDetails = input.data.result || [];    
                                        output.records = [];
                                        output.pagination = pagination;
                                        //Step 4 : Merge OU details to the response       
                                        //a) Company
                                        if (!lodash.isEmpty(output.companyDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.companyDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(records, extractProps, ["companyCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //b) Business Unit
                                         if (!lodash.isEmpty(output.businessUnitDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.businessUnitDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["businessUnitCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //c) Location
                                        if (!lodash.isEmpty(output.locationDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.locationDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["locationCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        return methodCallback(null, request, {"data": output});
                                    }, 
                                ];

                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {                                  
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }        
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

       /**
        * @name :: updateAction
        *
        * @description :: It Updates the Invoice based on actionName with Comments
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback response details
        */
        updateAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "actionName": "joi.string().required().valid('deleteInvoiceTemplate','activateInvoiceTemplate','deActivateInvoiceTemplate','recallInvoiceTemplate').label('einvoice-lable-12__')",
                        "comments": "joi.string().when('actionName', { is: joi.string().valid('deleteInvoiceTemplate','activateInvoiceTemplate','deActivateInvoiceTemplate','recallInvoiceTemplate'), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-13__')",
                        "invoiceTemplateId": "joi.string().required().label('EINVOICE_BFF_INVOICE_TEMPLATE_ID__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceTemplateId": request.params.invoiceTemplate_Id}));
                
                if (result) 
                {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }
                else 
                {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        actionName = request.body.actionName,
                        url = einvoiceURL + '/invoiceTemplate/' +  request.params.invoiceTemplate_Id + '/action/' + actionName,
                        requestBody = {comments: request.body.comments};                     
                    http.post(url, 'invoiceTemplateAction', requestBody, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        


        /**
        * @Name :: getInvoiceTemplateReleaseDetails
        *
        * @Description :: Fetch/Get a Invoice Release Details of a recurring template
        * 
        * @return/object/Throw Error
        */
       getInvoiceTemplateReleaseDetails(request, input, callback){
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {                        
                    "invoiceTemplateId": "joi.string().required().label('EINVOICE_BFF_INVOICE_TEMPLATE_ID__')",
                    "version": "joi.number().integer().label('einvoice-lable-18__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceTemplateId": request.params.invoiceTemplate_Id}));              
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),                   
                    einvoiceURL = request.productsURL.eInvoice,
                    version = request.body.version,
                    url = einvoiceURL + '/invoiceTemplate/' + request.params.invoiceTemplate_Id + '/' + version + '/releaseDetails';

                http.get(url, 'invoiceTemplateReleaseDetails', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const utils = super.utils,
                            lodash = super.lodash,
                            records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [],
                            // TODO : We need to change the Schema
                            responseSchema = {"type":"array","properties":{"tenantId":{"type":"string"},"invoiceNo":{"type":"string"},"status":{"type":"number"},"invoiceAmount":{"type":"number"},"paidAmount":{"type":"number"},"issuedOn":{"type":"none"},"currancy":{"type":"string"}}}
                        let userDetails = [];
                        if (!lodash.isEmpty(records)) 
                        {
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        } 
                        else 
                        {
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };
    

        /**
        * @Name :: getInvoiceTemplateDetails
        *
        * @Description :: Fetch/Get a Invoice Details
        * 
        * @return/object/Throw Error
        */
        getInvoiceTemplateDetails(request, input, callback){
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {                        
                        "invoiceTemplateId": "joi.string().required().label('EINVOICE_BFF_INVOICE_TEMPLATE_ID__')",
                        "version": "joi.number().integer().label('einvoice-lable-18__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceTemplateId": request.params.invoiceTemplate_Id}));              
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),                   
                        einvoiceURL = request.productsURL.eInvoice,
                        version = request.body.version,
                        url = einvoiceURL + '/invoiceTemplate/' + request.params.invoiceTemplate_Id + '/' + version;

                    http.get(url, 'invoiceTemplateDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [],
                                
                                responseSchema = {"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"none"},"createdOn":{"type":"none"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"none"},"modifiedBy":{"type":"none"},"modifiedOn":{"type":"none"},"version":{"type":"number"},"templateId":{"type":"string"},"templateUniqueId":{"type":"string"},"templateOwner":{"type":"none"},"templateName":{"type":"string"},"buyer":{"type":"none"},"requester":{"type":"none"},"autoInvoiceNo":{"type":"string"},"sequence":{"type":"number"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"visibilityRule":{"type":"string"},"visibilityRuleStatus":{"type":"boolean"},"description":{"type":"string"},"notes":{"type":"string"},"releaseScheduleId":{"type":"string"},"lastExecutionTime":{"type":"none"},"nextExecutionTime":{"type":"none"},"templateDate":{"type":"none"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"suppAddressId":{"type":"string"},"suppRemitToAddressId":{"type":"string"},"suppCurrency":{"type":"string"},"suppContact":{"type":"string"},"suppAddress":{"type":"string"},"supplierAddress":{"type":"none"},"supplierAddressRemit":{"type":"none"},"suppAddressRemit":{"type":"string"},"customerReferenceId":{"type":"string"},"extraCharges":{"type":"number"},"freightCharges":{"type":"number"},"insuranceCharges":{"type":"number"},"exciseDuties":{"type":"number"},"totalAmount":{"type":"number"},"grossTotalAmount":{"type":"number"},"taxAmount":{"type":"number"},"invoicedAmount":{"type":"number"},"submittedOn":{"type":"none"},"approvedOn":{"type":"none"},"closedOn":{"type":"none"},"baseCurrency":{"type":"string"},"baseExchangeRate":{"type":"number"},"baseTotal":{"type":"number"},"docType":{"type":"number"},"companyCode":{"type":"string"},"referenceValue":{"type":"string"},"referenceType":{"type":"number"},"splitCostingLevel":{"type":"number"},"splitCostingType":{"type":"number"},"origin":{"type":"number"},"suppErpid":{"type":"string"},"suppAddrErpid":{"type":"string"},"workflowId":{"type":"string"},"externalId":{"type":"string"},"erpId":{"type":"string"},"workflowInstanceId":{"type":"string"},"projectSettingStatus":{"type":"string"},"contractId":{"type":"string"},"contractNumber":{"type":"string"},"contractType":{"type":"number"},"suppPaymentTermId":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"billToCode":{"type":"string"},"invoiceToCode":{"type":"string"},"supplierRemitAddErpId":{"type":"string"},"shipToCodeType":{"type":"number"},"shipToCode":{"type":"string"},"shipToLocation":{"type":"string"},"purchaseTypeSetting":{"type":"boolean"},"ptGLAccountSetting":{"type":"boolean"},"assignProject":{"type":"boolean"},"supplierTaxExempt":{"type":"string"},"discountLevel":{"type":"number"},"discountType":{"type":"number"},"discountValue":{"type":"number"},"applyNoTaxes":{"type":"boolean"},"processEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"attachments":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"none"},"attachmentId":{"type":"string"},"referenceAttachmentId":{"type":"string"},"name":{"type":"string"},"encoding":{"type":"string"},"fileSize":{"type":"number"},"path":{"type":"string"},"type":{"type":"number"},"visibility":{"type":"string"},"comments":{"type":"string"},"displayName":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"consumerId":{"type":"string"},"origin":{"type":"number"},"alreadyInvoiced":{"type":"boolean"},"ocrParsedContent":{"type":"string"},"ocrDocumentJson":{"type":"string"},"ocrExtractedFieldsJson":{"type":"string"},"statusDetails":{"type":"number"},"checksum":{"type":"string"},"data":{"type":"string"},"version":{"type":"string"},"additionalInfo":{"type":"string"},"productid":{"type":"string"},"refId":{"type":"string"},"serviceCode":{"type":"string"},"serviceProviderCode":{"type":"string"},"callBackEndPoints":{"type":"string"},"tpiDoc":{"type":"string"},"tpiStatusComments":{"type":"string"},"serviceRequestTrackingId":{"type":"string"},"requestAccepted":{"type":"boolean"},"tpiResponse":{"type":"string"},"isExtract":{"type":"string"},"kofaxResponse":{"type":"string"},"attachmentErpId":{"type":"string"},"errorReasonsStr":{"type":"string"}}},"taxes":{"type":"array","properties":{"templateId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"taxType":{"type":"string"},"taxName":{"type":"string"},"taxRate":{"type":"number"},"compound":{"type":"boolean"},"applicableFor":{"type":"number"},"taxableAmount":{"type":"number"},"taxAmount":{"type":"number"},"useTax":{"type":"boolean"},"borneByBuyerTaxAmount":{"type":"number"}}},"costings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"budgetBaseValue":{"type":"number"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"costingValue":{"type":"number"},"projectCode":{"type":"string"},"splitValue":{"type":"number"},"unique":{"type":"string"}}},"items":{"type":"array","properties":{"lineItemId":{"type":"string"},"templateId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"lineNo":{"type":"string"},"splitCostingType":{"type":"number"},"itemId":{"type":"string"},"invoicedQuantity":{"type":"number"},"marketPrice":{"type":"number"},"discountType":{"type":"number"},"discountValue":{"type":"number"},"discountedPrice":{"type":"number"},"discountAmount":{"type":"number"},"applyNoTaxes":{"type":"boolean"},"itemPrice":{"type":"number"},"itemTaxPrice":{"type":"number"},"itemTotalPrice":{"type":"number"},"attachments":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"string"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"none"},"attachmentId":{"type":"string"},"referenceAttachmentId":{"type":"string"},"name":{"type":"string"},"encoding":{"type":"string"},"fileSize":{"type":"number"},"path":{"type":"string"},"type":{"type":"number"},"visibility":{"type":"string"},"comments":{"type":"string"},"displayName":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"consumerId":{"type":"string"},"origin":{"type":"number"},"alreadyInvoiced":{"type":"boolean"},"ocrParsedContent":{"type":"string"},"ocrDocumentJson":{"type":"string"},"ocrExtractedFieldsJson":{"type":"string"},"documentMappings":{"type":"array","properties":{"tenantId":{"type":"string"},"attachmentId":{"type":"string"},"documentId":{"type":"string"},"docType":{"type":"number"},"status":{"type":"string"}}},"statusDetails":{"type":"number"},"checksum":{"type":"string"},"data":{"type":"string"},"version":{"type":"string"},"additionalInfo":{"type":"string"},"productid":{"type":"string"},"refId":{"type":"string"},"serviceCode":{"type":"string"},"serviceProviderCode":{"type":"string"},"callBackEndPoints":{"type":"string"},"tpiDoc":{"type":"string"},"tpiStatusComments":{"type":"string"},"serviceRequestTrackingId":{"type":"string"},"requestAccepted":{"type":"boolean"},"tpiResponse":{"type":"string"},"isExtract":{"type":"string"},"kofaxResponse":{"type":"string"},"attachmentErpId":{"type":"string"},"errorReasonsStr":{"type":"string"}}},"comments":{"type":"string"},"contractNo":{"type":"string"},"contractId":{"type":"string"},"contractType":{"type":"number"},"chargedLineAmount":{"type":"number"},"chargedLineTaxAmount":{"type":"number"},"chargedQuantity":{"type":"number"},"assetCode":{"type":"string"},"adjustedQuantity":{"type":"number"},"assetCodeType":{"type":"number"},"requesterId":{"type":"string"},"requesterName":{"type":"string"},"shipToCodeType":{"type":"number"},"shipToCode":{"type":"string"},"shipToLocation":{"type":"string"},"deliverToType":{"type":"number"},"deliverTo":{"type":"string"},"deliveryUpto":{"type":"string"},"deliveryOn":{"type":"string"},"catlogItem":{"properties":{"scopeId":{"type":"string"},"catalogId":{"type":"string"},"catalogItemId":{"type":"number"},"catalogVersion":{"type":"number"},"itemId":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"supplierPartId":{"type":"string"},"supplierAuxPartId":{"type":"string"},"supplierAddressId":{"type":"string"},"supplierAddress":{"type":"string"},"manufacturerPartId":{"type":"string"},"manufacturerName":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"uom":{"type":"string"},"currency":{"type":"string"},"price":{"type":"number"},"marketPrice":{"type":"number"},"leadTime":{"type":"number"},"categoryCode":{"type":"string"},"categoryName":{"type":"string"},"unsspscCode":{"type":"string"},"unsspscName":{"type":"string"},"supplierProductURL":{"type":"string"},"manufacturerProductURL":{"type":"string"},"imageURL":{"type":"string"},"thumbnailURL":{"type":"string"},"sourceRefNo":{"type":"string"},"contractNo":{"type":"string"},"contractId":{"type":"string"},"sourceType":{"type":"number"},"itemType":{"type":"number"},"receiptType":{"type":"number"},"contractType":{"type":"number"},"error":{"type":"boolean"},"active":{"type":"boolean"},"hidden":{"type":"boolean"},"activity":{"type":"number"},"greenItem":{"type":"boolean"},"preferredItem":{"type":"boolean"},"validFrom":{"type":"string"},"validTo":{"type":"string"},"publishedOn":{"type":"string"},"attachments":{"type":"array","items":{"type":"string"}},"outOfStock":{"type":"boolean"},"systemAttributes":{"type":"none"},"itemAttributes":{"type":"none"},"itemErrors":{"type":"none"},"sourcingStatus":{"type":"number"},"externalId":{"type":"string"},"origin":{"type":"number"}}},"taxes":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"taxType":{"type":"string"},"taxName":{"type":"string"},"taxRate":{"type":"number"},"compound":{"type":"boolean"},"taxableAmount":{"type":"number"},"taxAmount":{"type":"number"},"useTax":{"type":"boolean"}}},"accountings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"accountTypeCode":{"type":"string"},"generalLedgerCode":{"type":"string"},"accountingValue":{"type":"number"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"purchaseTypeTemp":{"type":"string"},"visibilityRule":{"type":"string"},"visibilityRuleStatus":{"type":"boolean"}}},"costings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"budgetBaseValue":{"type":"numebr"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"costingValue":{"type":"numebr"},"projectCode":{"type":"string"},"splitValue":{"type":"number"},"unique":{"type":"string"}}},"attachmentIds":{"type":"array"},"itemQuantity":{"type":"number"},"processEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"dynamicInstanceVersion":{"type":"numebr"},"coaflexiFormId":{"type":"string"},"coaflexiFormInstanceVersion":{"type":"number"},"coaflexiFormInstanceId":{"type":"string"},"attachmentsStr":{"type":"string"}}}},"recurringSchedule":{"properties":{"schedulerId":{"type":"string"},"templateId":{"type":"string"},"frequencyBy":{"type":"string"},"recurrancesOn":{"type":"number"},"interval":{"type":"number"},"startFrom":{"type":"string"},"endTo":{"type":"string"},"neverExpire":{"type":"boolean"},"previousFireTime":{"type":"string"},"nextFireTime":{"type":"string"},"finalFireTime":{"type":"string"},"recurranceMonthForYear":{"type":"number"},"activeFrom":{"type":"string"},"activeTill":{"type":"string"}}},"attachmentIds":{"type":"array"},"neverExpire":{"type":"boolean"},"selfAssessedAmt":{"type":"number"},"useTaxApplicable":{"type":"boolean"},"supplierBankId":{"type":"string"},"suppBankingDetails":{"type":"string"},"supplierBankingDetails":{"type":"none"},"newGrossTotalAmount":{"type":"number"},"applyTaxOnGrossTotal":{"type":"boolean"},"newTotalTaxAmount":{"type":"number"},"entitySettings":{"type":"none"},"grossContractTotalAmount":{"type":"number"},"result":{"properties":{"errorList":{"type":"array","properties":{"fieldName":{"type":"string"},"errorCode":{"type":"string"},"errorMessage":{"type":"string"},"errorParameters":{"type":"array"}}},"warningList":{"type":"array","properties":{"fieldName":{"type":"string"},"errorCode":{"type":"string"},"errorMessage":{"type":"string"},"errorParameters":{"type":"array"}}}}},"invoiceAccountings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"accountTypeCode":{"type":"string"},"generalLedgerCode":{"type":"string"},"accountingValue":{"type":"number"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"purchaseTypeTemp":{"type":"string"},"visibilityRule":{"type":"string"},"visibilityRuleStatus":{"type":"boolean"}}},"allTemplateCostings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"budgetBaseValue":{"type":"number"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"costingValue":{"type":"number"},"projectCode":{"type":"string"},"splitValue":{"type":"number"},"unique":{"type":"string"}}},"validationResults":{"type":"string"},"attachmentsStr":{"type":"string"},"errorReasonsStr":{"type":"string"}};
                            let userDetails = [];
                            if (!lodash.isEmpty(records)) 
                            {
                                if(records.buyer) userDetails.push(records.buyer);
                                if(records.requester) userDetails.push(records.requester);
                                if(records.createdBy) userDetails.push(records.createdBy);
                                if(records.templateOwner) userDetails.push(records.templateOwner);
                                if(records.modifiedBy) userDetails.push(records.modifiedBy);
                                                            
                                if(records.attachments && records.attachments)
                                {
                                    records.attachments.forEach(item =>{
                                        userDetails.push(item.createdBy);
                                    });
                                }
                                userDetails = lodash.uniq(userDetails);
                            } 
                            else 
                            {
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                return callback(null, request, output.execute());
                            }

                            if (lodash.isEmpty(userDetails)) 
                            {
                                let output1 = [];
                                output1.push(records);
                                const output = (new (super.responseHandler)(request, { "data": output1 }, responseSchema));
                                return callback(null, request, output.execute());
                            }

                            const tms = new (super.tmsHook({ request: request }))(),
                                tasks = [                                                                       
                                    (methodCallback) => {
                                        if (lodash.isEmpty(userDetails)) return methodCallback(request, {});
                                        const reqData = { "ids": userDetails };
                                        tms.getUsersDetails(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        let data = [];
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]);
                                            utils.mergeObject(records, extractProps, ["buyer", "id"]);
                                            utils.mergeObject(records, extractProps, ["requester", "id"]);
                                            utils.mergeObject(records, extractProps, ["templateOwner", "id"]);
                                            utils.mergeObject(records, extractProps, ["createdBy", "id"]);
                                            utils.mergeArray(records.attachments, extractProps, ["createdBy", "id"]);
                                            data.push(records);                                            
                                        }
                                        return methodCallback(null, request, { data });
                                    }
                                ];
                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    // TODO : (HARSHAL) Are we populating the support object here ?
                                    //output.addCommonSchema('attachments', //output.responseSchema.properties.supportObjects.properties.attachments.properties);
                                    return callback(null, request, output.execute());
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: check if Invoice template Number Exists
        *
        * @Description :: Check if Invoice template Number Exists
        * 
        * @return/object/Throw Error
        */
        isExistsInvoiceTemplateNumber(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "recurringTemplateName": "joi.string().required().label('EINVOICE_BFF_TEMPLATE_NAME__')",
                        "supplierId": "joi.string().required().label('einvoice-lable-19__')",
                        "templateId": "joi.string().label('EINVOICE_BFF_INVOICE_TEMPLATE_ID__')",
                        "autoInvoiceNumber": "joi.string().label('einvoice-lable-14__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoiceTemplate/' + 'isExistsInvoiceTemplateNumber';
                    http.post(url, 'isInvoiceTemplateNumberExists', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Audit Trail By Id and Type
        *
        * @Description :: Audit Trail By Id and Type
        * 
        * @return/object/Throw Error
        */
        auditTrail(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "Id": "joi.string().required().label('einvoice-lable-66__')",
                        "entityType": "joi.string().required().label('einvoice-lable-67__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "Id": request.params.invoiceTemplate_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        entityType = request.body.entityType,
                        url = einvoiceURL + '/invoiceTemplate/' + request.params.invoiceTemplate_Id + '/auditTrail/' + entityType;
                    http.get(url, 'auditTrail', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "autoId": { "type": "number" }, "auditTrailId": { "type": "string" }, "parentAuditTrailId":{"type":"string"}, "entityType":{"type":"string"}, "entityId":{"type":"string"}, "version":{"type":"number"}, "event":{"type":"string"}, "comments":{"type":"string"}, "attachmentIds":{"type":"none"}, "role":{"type":"string"}, "auditVariables":{"type":"none"}, "auditVariablesStr":{"type":"string"}, "attachmentsStr":{"type":"string"} } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return InvoiceTemplate;
};