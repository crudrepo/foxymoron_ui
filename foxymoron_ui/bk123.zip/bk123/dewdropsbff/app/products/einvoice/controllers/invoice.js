/**
 * Invoice Controller
 *
 * @description :: Provides invoice related CRUD operation.
 */

module.exports = (parentClass) => {

    class Invoice extends parentClass {

        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/filter';
                    http.post(url, 'invoiceFilterList', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                output = {},
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'].records : [],
                                pagination = (!super.lodash.isEmpty(result['data'])) ? result['data'].pagination : {},
                                responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"}, "paymentInApproval":{"type":"number"}, "adjustedAmount":{"type":"number"}, "approvedGrossTotalAmount":{"type":"number"}, "useTaxApplicable":{"type":"boolean"}, "selfAssessedAmt":{"type":"number"}, "useTaxAdjustedAmount":{"type":"number"}, "bbAdjustedAmount":{"type":"number"}, "statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"status":{"type":"number"},"version":{"type":"number"},"invoiceId":{"type":"string"},"invoiceUniqueId":{"type":"string"},"comments":{"type":"string"},"invoiceNumber":{"type":"string"},"invoiceDate":{"type":"none"},"description":{"type":"string"}, "docType":{"type":"none"},"docTypeDesc":{"type":"string"}, "purchaseType":{"type":"string"},"purchaseOrderNumber":{"type":"string","key":"orderNumber"},"buyer":{"type":"string"},"attachmentsStr":{"type":"array"},"grossTotalAmount":{"type":"none"},"paymentTermId":{"type":"string"},"invoiceType":{"type":"number"},"requester":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"newGrossTotalAmount":{"type":"none","key":"invoiceAmount"},"requestEdit":{"type":"boolean"},"supplierCurrency":{"type":"string","key":"invoiceCurrency"},"origin":{"type":"string","key":"invoiceOrigin"},"submittedOn":{"type":"none"},"approvedOn":{"type":"none"},"closedOn":{"type":"none"},"resubmitionCount":{"type":"number"},"attachmentIds":{"type":"none"},"companyCode":{"type":"none","key":"company"},"businessUnitCode":{"type":"none","key":"businessUnit"},"locationCode":{"type":"none","key":"location"},"epDiscountDueDate":{"type":"none","key":"discountDueDate"},"epDiscountedAmount":{"type":"none","key":"discountAmount"},"transactionId":{"type":"string"},"zsnInvoiceCreator":{"type":"string"},"zsnInvoiceCreatorEmailId":{"type":"string"},"dueDate":{"type":"none","key":"invoiceDueDate"},"paidAmount":{"type":"none"},"matchedOn":{"type":"none"},"paidOn":{"type":"none"},"paymentApprovedOn":{"type":"none"},"confirmStatus":{"type":"number"},"paymentStatus":{"type":"number"},"autoMatched":{"type":"boolean"},"onHold":{"type":"boolean"}}}}};
                            let companyCodes = [],
                                businessUnitCodes = [],
                                locationCodes = [];
                            if(!lodash.isEmpty(records) && lodash.isArray(records)) {  
                                records.forEach(item => {
                                    if(item.companyCode) companyCodes.push(item.companyCode);
                                    if(item.businessUnitCode) businessUnitCodes.push( item.businessUnitCode);
                                    if(item.locationCode) locationCodes.push( item.locationCode);
                                });
                                companyCodes = lodash.uniq(companyCodes);
                                businessUnitCodes = lodash.uniq(businessUnitCodes);
                                locationCodes = lodash.uniq(locationCodes);
                            }
                            else{
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('pagination', output.responseSchema.properties);
                                return callback(null, request, output.execute());
                            }
                            const cmd = new (super.cmdHook({request: request}))(),
                                tasks = [
                                    (methodCallback) => {
                                        if (lodash.isEmpty(companyCodes)) return methodCallback(request, {});
                                        //Step 1 : Fetch company details 
                                        const reqData = { "codes": companyCodes, "pageNo":1 , "perPageRecords":companyCodes.length };
                                        cmd.getCompany(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.companyDetails = input.data.result || [];
                                        if (lodash.isEmpty(businessUnitCodes)) return methodCallback(request, {});
                                        //Step 2 : Fetch BusinessUnit details 
                                        const reqData = { "codes": businessUnitCodes,"pageNo":1 , "perPageRecords":businessUnitCodes.length  };
                                        cmd.getBusinessUnit(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.businessUnitDetails = input.data.result || [];
                                        if (lodash.isEmpty(locationCodes)) return methodCallback(request, {});
                                        //Step 3 : Fetch Location details 
                                        const reqData = { "codes": locationCodes, "pageNo":1 , "perPageRecords":locationCodes.length  };
                                        cmd.getLocation(request, reqData, methodCallback);
                                    },                                    
                                    (request, input, methodCallback) => {
                                        output.locationDetails = input.data.result || [];    
                                        output.records = [];
                                        output.pagination = pagination;
                                        //Step 4 : Merge OU details to the response       
                                        //a) Company
                                        if (!lodash.isEmpty(output.companyDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.companyDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(records, extractProps, ["companyCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //b) Business Unit
                                         if (!lodash.isEmpty(output.businessUnitDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.businessUnitDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["businessUnitCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //c) Location
                                        if (!lodash.isEmpty(output.locationDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.locationDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["locationCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        return methodCallback(null, request, {"data": output});
                                    }, 
                                ];

                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {                                  
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }        
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

       /**
        * @name :: updateAction
        *
        * @description :: It Updates the Invoice based on actionName with Comments
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback response details
        */
        updateAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "actionName": "joi.string().required().valid('voidInvoice','closeInvoice','returnInvoice','recallInvoice','remindPendingReceipt','confirmAndMatch','releaseHold','restrictPayment').label('einvoice-lable-12__')",
                        "comments": "joi.string().when('actionName', { is: joi.string().valid('voidInvoice', 'releaseHold', 'closeInvoice', 'returnInvoice', 'restrictPayment'), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-13__')",
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "approvedAmount": "joi.string().when('actionName', { is: joi.string().valid('restrictPayment'), then: joi.required(), otherwise : joi.optional().allow('')}).label('einvoice-lable-65__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id}));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        actionName = request.body.actionName,
                        url = einvoiceURL + '/invoice/' +  request.params.invoice_Id + '/action/' + actionName,
                        requestBody = {comments: request.body.comments};                     
                    http.post(url, 'invoiceAction', requestBody, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: getDetails
        *
        * @Description :: Fetch/Get a Invoice Details
        * 
        * @return/object/Throw Error
        */
        getInvoiceDetails(request, input, callback){
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {                        
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "version": "joi.number().integer().label('einvoice-lable-18__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id}));              
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),                   
                        einvoiceURL = request.productsURL.eInvoice,
                        version = request.body.version,
                        url = einvoiceURL + '/invoice/' + request.params.invoice_Id + '/' + version;

                    http.get(url, 'invoiceDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [],
                                responseSchema = {"type":"array","properties":{"invoice":{"type":"object","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"status":{"type":"number"},"paymentStatus":{"type":"number"},"approvedGrossTotalAmount":{"type":"number"},"useTaxApplicable":{"type":"boolean"},"selfAssessedAmt":{"type":"number"},"useTaxAdjustedAmount":{"type":"number"},"bbAdjustedAmount":{"type":"number"},"integrationStatus":{"type":"number"},"paymentInApproval":{"type":"number"},"cmAdjusted":{"type":"boolean"},"submitForCodingUserId":{"type":"none","key":"submitForCodingUserInfo"},"purchaseType":{"type":"string"},"epDiscountDueDate":{"type":"number"},"epDiscountedAmount":{"type":"number"},"invoiceDate":{"type":"none"},"dueDate":{"type":"none"},"version":{"type":"number"},"invoiceId":{"type":"string"},"invoiceUniqueId":{"type":"string"},"erpId":{"type":"string"},"workflowId":{"type":"string"},"workflowInstanceId":{"type":"string"},"attachmentIds":{"type":"none"},"supplierCurrency":{"type":"string"},"discountValue":{"type":"number"},"extraCharges":{"type":"number"},"insuranceCharges":{"type":"number"},"totalAmount":{"type":"number"},"grossTotalAmount":{"type":"number"},"discountLevel":{"type":"number"},"exciseDuties":{"type":"number"},"companyCode":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"billToCode":{"type":"string"},"invoiceToCode":{"type":"string"},"freightCharges":{"type":"number"},"splitCostingLevel":{"type":"number"},"splitCostingType":{"type":"number"},"origin":{"type":"number"},"newGrossTotalAmount":{"type":"number"},"assignProject":{"type":"boolean"},"supplierId":{"type":"string"},"baseCurrency":{"type":"string"},"baseExchangeRate":{"type":"number"},"customerReferenceId":{"type":"string"},"supplierContact":{"type":"string"},"supplierAddressId":{"type":"string"},"supplierAddressIdRemit":{"type":"string"},"invoiceTaxes":{"type":"string"},"supplierERPId":{"type":"string"},"paymentTermId":{"type":"string"},"supplierTaxExampt":{"type":"string"},"supplierName":{"type":"string"},"suppAddress":{"type":"object","properties":{"tenantId":{"type":"string"},"addressId":{"type":"string"},"street1":{"type":"string"},"street2":{"type":"string"},"street3":{"type":"string"},"city":{"type":"string"},"state":{"type":"string"},"country":{"type":"string"},"zip":{"type":"string"},"poBox":{"type":"string"},"phone":{"type":"string"},"fax":{"type":"string"},"headQuarter":{"type":"boolean"},"order":{"type":"boolean"},"remitt":{"type":"boolean"},"addressAccountGroupId":{"type":"string"}}},"suppAddressRemit":{"type":"object","properties":{"tenantId":{"type":"string"},"addressId":{"type":"string"},"street1":{"type":"string"},"street2":{"type":"string"},"street3":{"type":"string"},"city":{"type":"string"},"state":{"type":"string"},"country":{"type":"string"},"zip":{"type":"string"},"poBox":{"type":"string"},"phone":{"type":"string"},"fax":{"type":"string"},"headQuarter":{"type":"boolean"},"order":{"type":"boolean"},"remitt":{"type":"boolean"},"addressAccountGroupId":{"type":"string"}}},"purchaseOrderNumber":{"type":"string"},"submittedOn":{"type":"number"},"supplierBankingDetails":{"type":"object","properties":{"bankRecordLabel":{"type":"string"},"bankDescription":{"type":"string"},"bankRecordERPId":{"type":"string"},"bankCountry":{"type":"string"},"bankName":{"type":"string"},"bankId":{"type":"string"},"branchName":{"type":"string"},"bankBranchId":{"type":"string"},"bankAccountType":{"type":"string"},"bankAccountNo":{"type":"string"},"bankAccountSeqNumber":{"type":"string"},"bankBeneficiaryName":{"type":"string"},"bankSwiftQualifierCode":{"type":"string"},"bankSwiftCode":{"type":"string"},"bankSortCode":{"type":"string"},"bankIBANNo":{"type":"string"},"bankIdQualifier":{"type":"string"},"bankRoutingNo":{"type":"string"},"bankRoutingKey":{"type":"string"}}},"comments":{"type":"string"},"description":{"type":"string"},"invoiceNumber":{"type":"string"},"buyer":{"type":"none","key":"buyerInfo"},"requester":{"type":"none","key":"requesterInfo"}}},"invoiceItems":{"type":"array","properties":{"lineItemId":{"type":"string"},"invoiceId":{"type":"string"},"itemId":{"type":"string"},"attachmentIds":{"type":"none"},"lineNo":{"type":"string"},"itemTaxes":{"type":"array","properties":{"tenantId":{"type":"string"},"compound":{"type":"boolean"},"useTax":{"type":"boolean"},"type":{"type":"string"},"name":{"type":"string"},"rate":{"type":"number"},"taxAmount":{"type":"number"},"taxableAmount":{"type":"number"}}},"marketPrice":{"type":"number"},"itemQuantity":{"type":"number"},"splitCostingType":{"type":"number"},"assetCodeType":{"type":"number"},"assetCode":{"type":"string"},"itemComment":{"type":"string"},"purchaseOrderId":{"type":"none"},"contractNo":{"type":"string"},"contractType":{"type":"number"},"discountType":{"type":"number"},"discountValue":{"type":"number"},"coaflexiFormId":{"type":"string"},"coaflexiFormInstanceId":{"type":"string"},"coaflexiFormInstanceVersion":{"type":"number"},"itemTotalPrice":{"type":"number"}}},"invoiceTaxes":{"type":"array","properties":{"tenantId":{"type":"string"},"invoiceId":{"type":"string"},"type":{"type":"string"},"name":{"type":"string"},"rate":{"type":"number"},"taxableAmount":{"type":"number"},"taxAmount":{"type":"number"},"applicableFor":{"type":"number"},"compound":{"type":"boolean"},"useTax":{"type":"boolean"},"borneByBuyerTaxAmount":{"type":"number"}}},"invoiceCostings":{"type":"array","properties":{"lineItemId":{"type":"string"},"invoiceId":{"type":"string"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"projectCode":{"type":"string"},"splitValue":{"type":"number"},"value":{"type":"number"}}},"invoiceAccountings":{"type":"array","properties":{"generalLedgerCode":{"type":"string"},"tenantId":{"type":"string"},"lineItemId":{"type":"string"},"invoiceId":{"type":"string"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"value":{"type":"number"},"visibilityRule":{"type":"none"},"accountTypeCode":{"type":"string"}}},"invoiceMatchResult":{"type":"none"},"supportObjects":{"type":"object","properties":{"paymentAndCredits":{"type":"array","properties":{"tenantId":{"type":"string"},"invoiceId":{"type":"string"},"transactionId":{"type":"string"},"paidAmount":{"type":"number"},"referenceNumber":{"type":"string"},"paymentDate":{"type":"number"},"transactionType":{"type":"number"},"paymentStatus":{"type":"number"}}},"attachments":{"type":"array","properties":{}},"items":{"type":"none"},"ocrAttachmentId":{"type":"string"},"supplier":{"type":"none"}}}}};
                            let userDetails = [];
                            if (!lodash.isEmpty(records)) {
                                if(records.invoice){
                                    if(records.invoice.buyer) userDetails.push(records.invoice.buyer);
                                    if(records.invoice.requester) userDetails.push(records.invoice.requester);
                                    if(records.invoice.submitForCodingUserId) userDetails.push(records.invoice.submitForCodingUserId);                       
                                }
                                if(records.supportObjects && records.supportObjects.attachments){
                                    records.supportObjects.attachments.forEach(item =>{
                                        userDetails.push(item.createdBy);
                                    });
                                }
                                userDetails = lodash.uniq(userDetails);
                            } else {
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                return callback(null, request, output.execute());
                            }
                            if (lodash.isEmpty(userDetails)) {
                                let output1 = [];
                                output1.push(records);
                                const output = (new (super.responseHandler)(request, { "data": output1 }, responseSchema));
                                return callback(null, request, output.execute());
                            }

                            const tms = new (super.tmsHook({ request: request }))(),
                                tasks = [                                                                       
                                    (methodCallback) => {
                                        if (lodash.isEmpty(userDetails)) return methodCallback(request, {});
                                        const reqData = { "ids": userDetails };
                                        tms.getUsersDetails(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        let data = [];
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]);
                                            utils.mergeObject(records.invoice, extractProps, ["buyer", "id"]);
                                            utils.mergeObject(records.invoice, extractProps, ["requester", "id"]);
                                            utils.mergeObject(records.invoice, extractProps, ["submitForCodingUserId", "id"]);
                                            utils.mergeArray(records.supportObjects.attachments, extractProps, ["createdBy", "id"]);
                                            data.push(records);                                            
                                        }
                                        return methodCallback(null, request, { data });
                                    }
                                ];
                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('attachments', output.responseSchema.properties.supportObjects.properties.attachments.properties);
                                    return callback(null, request, output.execute());
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: get Invoice Details if Invoice Number Exists
        *
        * @Description :: Fetch/Get Invoice Details if Invoice Number Exists
        * 
        * @return/object/Throw Error
        */
        isExistsInvoiceNumber(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "invoiceNumber": "joi.string().required().label('einvoice-lable-23__')",
                        "supplierId": "joi.string().required().label('einvoice-lable-19__')",
                        "invoiceId": "joi.string().label('einvoice-lable-14__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/' + 'isExistsInvoiceNumber';
                    http.post(url, 'isInvoiceNumberExists', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Invoice Adjust Credit Memo by Id and Amount
        *
        * @Description :: Invoice Adjust Credit Memo by Id and Amount
        * 
        * @return/object/Throw Error
        */
        adjustCreditMemo(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {  
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "approvedAmount": "joi.string().required().label('einvoice-lable-65__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id}));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/' + 'creditMemoAdjustmentDetails';
                    http.post(url, 'adjustCredit', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "ToBeApportionedCMList": { "type": "none" }, "BB_TAX": { "type": "number" }, "TOTAL_TAX": { "type": "string" }, "prevAdjustedAmount": { "type": "number" }, "NEGATIVE_TAX": { "type": "number" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));                        
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Audit Trail By Id and Type
        *
        * @Description :: Audit Trail By Id and Type
        * 
        * @return/object/Throw Error
        */
        auditTrail(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "Id": "joi.string().required().label('einvoice-lable-66__')",
                        "entityType": "joi.string().required().label('einvoice-lable-67__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "Id": request.params.invoice_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        entityType = request.body.entityType,
                        url = einvoiceURL + '/invoice/' + request.params.invoice_Id + '/auditTrail/' + entityType;
                    http.get(url, 'auditTrail', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "autoId": { "type": "number" }, "auditTrailId": { "type": "string" }, "parentAuditTrailId":{"type":"string"}, "entityType":{"type":"string"}, "entityId":{"type":"string"}, "version":{"type":"number"}, "event":{"type":"string"}, "comments":{"type":"string"}, "attachmentIds":{"type":"none"}, "role":{"type":"string"}, "auditVariables":{"type":"none"}, "auditVariablesStr":{"type":"string"}, "attachmentsStr":{"type":"string"} } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        
        /**
        * @Name :: Submit For Coding By Invoice Id and User Id
        *
        * @Description :: Submit For Coding By Invoice Id and User Id
        * 
        * @return/object/Throw Error
        */
        submitForCoding(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "version": "joi.number().required().label('einvoice-lable-18__')",
                        "reAssignUserId": "joi.string().required().label('einvoice-lable-68__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/' + request.params.invoice_Id + '/action/submitForCoding/' + request.body.reAssignUserId,
                        reqBody = {};
                        reqBody.version = request.body.version;
                    http.post(url, 'SubmitForCoding', reqBody, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Adjust Credit, Against Invoice
        *
        * @Description :: Adjust Credit, Against Invoice
        * 
        * @return/object/Throw Error
        */
        adjustCredit(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "comments": "joi.string().required().label('einvoice-lable-13__')",
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')",
                        "creditMemoIds": "joi.array().items(joi.string().min(1).required().label('einvoice-lable-15__')).unique().label('einvoice-lable-15__')",
                        "apportionedAmount": "joi.array().items(joi.string().allow('').label('einvoice-lable-69__')).label('einvoice-lable-69__')",
                        "adjustedAmount": "joi.string().required().label('einvoice-lable-70__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceId": request.params.invoice_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/' + request.params.invoice_Id + '/action/creditMemoAdjustmentAgainstInvoice/adjustCredit',
                        requestBody = {};
                    requestBody.comments = request.body.comments;
                    requestBody.creditMemoId = request.body.creditMemoIds;
                    requestBody.apportionedAmount = request.body.apportionedAmount;
                    requestBody.adjustedAmount = request.body.adjustedAmount;
                    http.post(url, 'adjustCredit', requestBody, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

            /**
        * @Name :: Create
        *
        * @Description :: Create & Validate Invoice
        * 
        * @return/object/Throw Error
        */
        
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request); 
                    request.body.invoiceType = request.body.invoice.invoiceType;
                const schema = {
                    "actionType": "joi.string().valid('create','validate').required().label('einvoice-lable-86__')",
                    "invoiceType": "joi.number().label('einvoice-lable-55__')",
                    "actionName": "joi.string().valid('draft','submit','submitForCoding').required().label('einvoice-lable-12__')",                
                    "invoice": `joi.object().keys({
                        invoiceType: joi.number().valid(1, 2).required().label('einvoice-lable-55__'),
                        purchaseOrderNumber: joi.string().when('invoiceType', { is: joi.number().valid(2, 3), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-234__'),
                        referenceValue: joi.string().when('invoiceType', { is: joi.number().valid(2, 3), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-99__'),
                        createdBy: joi.string().required().label('einvoice-lable-227__'),
                        createdOn: joi.number().required().label('einvoice-lable-228__'),
                        tenantId: joi.string().required().label('einvoice-lable-229__'),
                        invoiceId: joi.string().label('einvoice-lable-14__'),
                        externalId: joi.string().label('einvoice-lable-230__'),
                        uniqueId: joi.string().label('einvoice-lable-231__'),
                        invoiceNumber: joi.string().required().label('einvoice-lable-23__'),
                        invoiceDate: joi.number().required().label('einvoice-lable-232__'),
                        supplierId: joi.string().required().label('einvoice-lable-19__'),
                        supplierName: joi.string().required().label('einvoice-lable-236__'),
                        supplierAddressId: joi.string().required().label('einvoice-lable-237__'),
                        supplierAddressIdRemit: joi.string().required().label('einvoice-lable-238__'),
                        supplierCurrency: joi.string().required().label('einvoice-lable-239__'),
                        discountLevel: joi.number().required().label('einvoice-lable-87__'),
                        discountType: joi.number().required().label('einvoice-lable-88__'),
                        baseCurrency: joi.string().required().label('einvoice-lable-95__'),
                        baseExchangeRate: joi.number().required().label('einvoice-lable-96__'),
                        baseTotal: joi.number().required().label('einvoice-lable-97__'),
                        companyCode: joi.string().required().label('einvoice-lable-34__'),
                        splitCostingLevel: joi.number().required().label('einvoice-lable-101__'),
                        splitCostingType: joi.number().required().label('einvoice-lable-102__'),
                        referenceType: joi.number().required().label('einvoice-lable-51__'),
                        origin: joi.number().required().label('einvoice-lable-103__'),
                        businessUnitCode: joi.string().required().label('einvoice-lable-35__'),
                        locationCode: joi.string().required().label('einvoice-lable-20__'),
                        billToCode: joi.string().required().label('einvoice-lable-135__'),
                        invoiceToCode: joi.string().required().label('einvoice-lable-112__'),
                        newGrossTotalAmount: joi.number().required().label('einvoice-lable-118__'),
                        newTotalTaxAmount: joi.number().required().label('einvoice-lable-119__'),
                        purchaseType: joi.string().label('einvoice-lable-49__'),
                        paymentTermId: joi.string().label('einvoice-lable-110__'),
                        epDiscDueDate: joi.number().label('einvoice-lable-122__'),
                        coaFlexiFormId: joi.string().label('einvoice-lable-44__'),
                        coaFlexiFormInstanceId: joi.string().label('einvoice-lable-43__'),
                        entitySetting: joi.string().label('einvoice-lable-125__'),
                        coaFlexiFormInstanceVersion: joi.number().label('einvoice-lable-123__'),
                        shouldSubmit: joi.boolean().label('einvoice-lable-98__'),
                        statusComments: joi.string().label('einvoice-lable-226__'),
                        comments: joi.string().label('einvoice-lable-13__'),
                        description: joi.string().allow('').label('einvoice-lable-233__'),
                        buyer: joi.string().label('einvoice-lable-235__'),
                        supplierContact: joi.string().label('einvoice-lable-240__'),
                        discountValue: joi.number().label('einvoice-lable-89__'),
                        extraCharges: joi.number().label('einvoice-lable-90__'),
                        freightCharges: joi.number().label('einvoice-lable-91__'),
                        insuranceCharges: joi.number().label('einvoice-lable-92__'),
                        exciseDuties: joi.number().label('einvoice-lable-93__'),
                        submittedOn: joi.number().label('einvoice-lable-94__'),
                        supplierErpId: joi.string().label('einvoice-lable-104__'),
                        supplierAddressERPId: joi.string().label('einvoice-lable-105__'),
                        erpId: joi.string().label('einvoice-lable-106__'),
                        workflowId: joi.string().label('einvoice-lable-28__'),
                        workflowInstanceId: joi.string().label('einvoice-lable-29__'),
                        processEformId: joi.string().label('einvoice-lable-107__'),
                        dynamicFormId: joi.string().label('einvoice-lable-108__'),
                        dynamicInstanceId: joi.string().label('einvoice-lable-109__'),
                        invoiceDateGMT: joi.number().label('einvoice-lable-113__'),
                        supplierRemitAddressERPId: joi.string().label('einvoice-lable-114__'),
                        shipToCodeType: joi.number().label('einvoice-lable-115__'),
                        shipToCode: joi.string().label('einvoice-lable-116__'),
                        shipToLocation: joi.string().label('einvoice-lable-117__'),
                        supplierBankingDetailsId: joi.string().allow('').label('einvoice-lable-120__'),
                        visibilityRule: joi.string().allow('').label('einvoice-lable-121__'),
                        customerReferenceId: joi.string().allow('').label('einvoice-lable-124__'),
                        requester: joi.string().label('einvoice-lable-132__'),
                        dueDate: joi.number().label('einvoice-lable-126__'),
                        matchStatus: joi.number().label('einvoice-lable-127__'),
                        matchedOn: joi.number().label('einvoice-lable-128__'),
                        sendToReadyForApproval: joi.boolean().label('einvoice-lable-129__'),
                        deliverTo: joi.string().label('einvoice-lable-130__'),
                        submitForCodingUserId: joi.string().label('einvoice-lable-131__'),
                        originId: joi.string().label('einvoice-lable-133__'),
                        originType: joi.string().label('einvoice-lable-134__'),
                        attachmentIds: joi.array().items(
                            joi.string().label('einvoice-lable-27__')
                        ).label('einvoice-lable-113__'),
                    }).label('einvoice-lable-225__')`,             
                    "costings": `joi.array().items(
                        joi.object().keys({
                            lineItemId: joi.string().label('einvoice-lable-35__'),
                            businessUnitCode: joi.string().label('einvoice-lable-35__'),
                            costCenterCode: joi.string().label('einvoice-lable-203__'),
                            projectCode: joi.string().label('einvoice-lable-204__'),
                            value: joi.number().label('einvoice-lable-205__'),
                            splitValue: joi.number().label('einvoice-lable-206__'),
                        }).label('einvoice-lable-201__')
                    ).label('einvoice-lable-201__')`,             
                    "headerTaxes": `joi.array().items(
                        joi.object().keys({
                            type: joi.string().required().label('einvoice-lable-193__'),
                            compound: joi.boolean().required().label('einvoice-lable-209__'), 
                            useTax: joi.boolean().required().label('einvoice-lable-196__'),
                            name: joi.string().required().label('einvoice-lable-159__'),
                            rate: joi.number().required().label('einvoice-lable-194__'),
                            taxAmount: joi.number().required().label('einvoice-lable-195__'),                     
                            taxableAmount: joi.number().required().label('einvoice-lable-197__'),
                            applicableFor: joi.number().required().label('einvoice-lable-210__'),                                            
                        }).label('einvoice-lable-207__')
                    ).label('einvoice-lable-207__')`,          
                    "accountings": `joi.array().items(
                        joi.object().keys({    
                            accountTypeCode: joi.string().required().label('einvoice-lable-47__'),
                            generalLedgerCode: joi.string().required().label('einvoice-lable-214__'),
                            value: joi.number().label('einvoice-lable-205__'),
                            purchaseType: joi.string().label('einvoice-lable-49__'),
                            purchaseTypeCode: joi.string().label('einvoice-lable-215__'),
                            visibilityRule: joi.string().allow('').label('einvoice-lable-121__'),
                        }).label('einvoice-lable-211__')
                    ).label('einvoice-lable-211__')`,           
                    "items": `joi.array().items(
                        joi.object().keys({     
                            purchaseOrderId: joi.string().label('einvoice-lable-21__'),
                            poLineNo: joi.string().allow('').label('einvoice-lable-140__'),
                            coaFlexiFormId: joi.string().label('einvoice-lable-44__'),
                            coaFlexiFormInstanceId: joi.string().label('einvoice-lable-43__'),                   
                            coaFlexiFormInstanceVersion: joi.number().label('einvoice-lable-123__'),
                            lineItemId: joi.string().label('einvoice-lable-138__'),
                            requisitionId: joi.string().label('einvoice-lable-50__'),
                            deliveryOn: joi.number().label('einvoice-lable-184__'),
                            deliveryUpto: joi.number().label('einvoice-lable-185__'),
                            chargedLineAmount: joi.number().label('einvoice-lable-186__'),
                            chargedLineTaxAmount: joi.number().label('einvoice-lable-187__'),
                            chargedQuantity: joi.number().label('einvoice-lable-188__'),
                            adjustedQuantity: joi.number().label('einvoice-lable-189__'),
                            requesterId: joi.string().label('einvoice-lable-54__'),
                            deliverToType: joi.number().label('einvoice-lable-190__'),
                            lineNo: joi.string().required().label('einvoice-lable-139__'),                            
                            itemQuantity: joi.number().required().label('einvoice-lable-141__'),                            
                            marketPrice: joi.number().required().label('einvoice-lable-142__'),                            
                            discountType: joi.number().required().label('einvoice-lable-88__'),                            
                            discountValue: joi.number().label('einvoice-lable-89__'),                            
                            itemPrice: joi.number().required().label('einvoice-lable-143__'),                            
                            itemTaxPrice: joi.number().required().label('einvoice-lable-144__'),                            
                            applyNoTaxes: joi.boolean().label('einvoice-lable-145__'),                            
                            itemTotalPrice: joi.number().required().label('einvoice-lable-198__'),                            
                            splitCostingType: joi.number().required().label('einvoice-lable-102__'),                             
                            itemComment: joi.string().label('einvoice-lable-146__'),                            
                            attachmentIds: joi.array().items(
                                joi.string().label('einvoice-lable-185__')
                            ).label('einvoice-lable-100__'),                            
                            contractNo: joi.string().label('einvoice-lable-147__'), 
                            contractId: joi.string().label('einvoice-lable-22__'), 
                            contractType: joi.number().label('einvoice-lable-148__'), 
                            assetCode: joi.string().label('einvoice-lable-149__'), 
                            assetCodeType: joi.number().label('einvoice-lable-150__'), 
                            shipToCodeType: joi.number().label('einvoice-lable-115__'), 
                            shipToCode: joi.string().label('einvoice-lable-116__'), 
                            shipToLocation: joi.string().label('einvoice-lable-117__'), 
                            processEformId: joi.string().label('einvoice-lable-107__'), 
                            dynamicFormId: joi.string().label('einvoice-lable-108__'), 
                            dynamicInstanceId: joi.string().label('einvoice-lable-109__'), 
                            dynamicInstanceVersion: joi.number().label('einvoice-lable-151__'), 
                            selfAssessedTaxAmt: joi.number().required().label('einvoice-lable-152__'),  
                            catalogItem: joi.object().keys({
                                itemId: joi.string().label('einvoice-lable-155__'),
                                name: joi.string().required().label('einvoice-lable-159__'),
                                uom: joi.string().required().label('einvoice-lable-160__'),
                                categoryCode: joi.string().required().label('einvoice-lable-161__'),
                                unsspscCode: joi.string().required().label('einvoice-lable-163__'),
                                sourceType: joi.number().required().label('einvoice-lable-171__'),
                                receiptType: joi.number().required().label('einvoice-lable-173__'),
                                catalogId: joi.string().label('einvoice-lable-154__'),
                                supplierPartId: joi.string().allow('').label('einvoice-lable-156__'),
                                manufacturerPartId: joi.string().allow('').label('einvoice-lable-157__'),
                                manufacturerName: joi.string().allow('').label('einvoice-lable-158__'),
                                description: joi.string().allow('').label('einvoice-lable-233__'),
                                leadTime: joi.number().label('einvoice-lable-167__'),
                                categoryName: joi.string().label('einvoice-lable-162__'),
                                unsspscName: joi.string().label('einvoice-lable-164__'),
                                supplierProductURL: joi.string().label('einvoice-lable-165__'),
                                manufacturerProductURL: joi.string().label('einvoice-lable-166__'),
                                imageURL: joi.string().label('einvoice-lable-168__'),
                                thumbnailURL: joi.string().label('einvoice-lable-169__'),
                                sourceRefNo: joi.string().allow('').label('einvoice-lable-170__'),
                                contractNo: joi.string().label('einvoice-lable-147__'),
                                contractId: joi.string().label('einvoice-lable-22__'),
                                itemType: joi.number().label('einvoice-lable-172__'),
                                contractType: joi.number().label('einvoice-lable-164__'),
                                active: joi.boolean().label('einvoice-lable-174__'),
                                hidden: joi.boolean().label('einvoice-lable-175__'),
                                activity: joi.number().label('einvoice-lable-176__'),
                                greenItem: joi.boolean().label('einvoice-lable-177__'),
                                preferredItem: joi.boolean().label('einvoice-lable-178__'),
                                validFrom: joi.number().label('einvoice-lable-179__'),
                                validTo: joi.number().label('einvoice-lable-180__'),
                                publishedOn: joi.number().label('einvoice-lable-181__'),
                                attachments: joi.array().items(
                                    joi.string().label('einvoice-lable-174__')
                                ).label('einvoice-lable-199__'),
                                outOfStock: joi.boolean().label('einvoice-lable-182__'),
                                sourcingStatus: joi.number().label('einvoice-lable-183__'),                            
                            }),                       
                            itemTaxes: joi.array().items(
                                joi.object().keys({
                                    type: joi.string().required().label('einvoice-lable-193__'),
                                    name: joi.string().required().label('einvoice-lable-159__'),
                                    rate: joi.number().required().label('einvoice-lable-194__'),
                                    taxAmount: joi.number().required().label('einvoice-lable-195__'),
                                    useTax: joi.boolean().required().label('einvoice-lable-196__'),
                                    taxableAmount: joi.number().required().label('einvoice-lable-197__'),
                                })
                            ).label('einvoice-lable-191__'),
                        })).label('einvoice-lable-136__')`
                    
                };    
                validationUtility.addInternalSchema(schema);               
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/invoice/${request.body.actionType}/${request.body.actionName}`;
                        delete request.body.actionName;
                        delete request.body.invoiceType;
                        delete request.body.actionType;
                        http.post(url, 'createInvoice', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "number" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute())
                           
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: basicDetails
        *
        * @Description :: Fetch/Get a Invoice Basic Details
        * 
        * @return/object/Throw Error
        */
        basicDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "invoiceId": "joi.string().required().label('einvoice-lable-14__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "invoiceId": request.params.invoice_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/invoice/${request.params.invoice_Id}/basicDetails`;
                    http.get(url, 'basicDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "paymentStatus": { "type": "number" }, "approvedGrossTotalAmount": { "type": "number" }, "useTaxApplicable": { "type": "boolean" }, "selfAssessedAmt": { "type": "number" }, "useTaxAdjustedAmount": { "type": "number" }, "bbAdjustedAmount": { "type": "number" }, "validCOAForm": { "type": "boolean" }, "refId": { "type": "none" }, "originId": { "type": "none" }, "originType": { "type": "none" }, "errorReasonsStr": { "type": "string" }, "poInvoiceExtractionMute": { "type": "boolean" }, "integrationErrorReasonsStr": { "type": "string" }, "systemAttributesStr": { "type": "string" }, "documentAmount": { "type": "none" }, "invoiceItems": { "type": "none" }, "budgetSettingsMapString": { "type": "string" }, "adjustedAmount": { "type": "number" }, "editedOn": { "type": "none" }, "editRequestedOn": { "type": "none" }, "integrationStatus": { "type": "number" }, "integrationErrorReasons": { "type": "none" }, "paymentInApproval": { "type": "number" }, "paidAmount": { "type": "number" }, "matchedOn": { "type": "none" }, "budgetSettingsMap": { "type": "none" }, "systemAttributes": { "type": "none" }, "autoMatched": { "type": "boolean" }, "onHold": { "type": "boolean" }, "utilizeBudget": { "type": "boolean" }, "invoiceType": { "type": "number" }, "paymentWorkflowId": { "type": "none" }, "paymentInstanceId": { "type": "none" }, "paidOn": { "type": "none" }, "paymentApprovedOn": { "type": "none" }, "confirmStatus": { "type": "number" }, "cmAdjusted": { "type": "boolean" }, "sendToReadyForApproval": { "type": "boolean" }, "epdApplyForPayment": { "type": "boolean" }, "ocrAttachmentId": { "type": "none" }, "deliverToType": { "type": "number" }, "deliverTo": { "type": "none" }, "invoiceClosingType": { "type": "number" }, "invoiceApprovalPendingWith": { "type": "string" }, "onHoldReleasedType": { "type": "number" }, "onHoldReleasedOn": { "type": "none" }, "submitForCodingUserId": { "type": "none" }, "purchaseType": { "type": "string" }, "purchaseTypeCode": { "type": "none" }, "pending": { "type": "boolean" }, "epDiscountDueDate": { "type": "number" }, "epDiscountedAmount": { "type": "number" }, "invoiceDate": { "type": "number" }, "dueDate": { "type": "number" }, "matchStatus": { "type": "number" }, "invoiceDateGMT": { "type": "none" }, "prePOAllowDays": { "type": "number" }, "suppLocationStr": { "type": "none" }, "defaultSupplierRemitTOAddress": { "type": "none" }, "version": { "type": "number" }, "invoiceId": { "type": "string" }, "invoiceUniqueId": { "type": "string" }, "erpId": { "type": "string" }, "externalId": { "type": "string" }, "workflowId": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "processEformId": { "type": "none" }, "dynamicFormId": { "type": "none" }, "dynamicInstanceId": { "type": "none" }, "attachmentIds": { "type": "none" }, "supplierCurrency": { "type": "string" }, "discountValue": { "type": "number" }, "extraCharges": { "type": "number" }, "insuranceCharges": { "type": "number" }, "totalAmount": { "type": "number" }, "grossTotalAmount": { "type": "number" }, "discountLevel": { "type": "number" }, "discountType": { "type": "number" }, "exciseDuties": { "type": "number" }, "referenceValue": { "type": "none" }, "companyCode": { "type": "string" }, "businessUnitCode": { "type": "string" }, "locationCode": { "type": "string" }, "billToCode": { "type": "string" }, "invoiceToCode": { "type": "string" }, "attachmentsStr": { "type": "string" }, "attachments": { "type": "none" }, "persistObject": { "type": "boolean" }, "coaflexiFormInstanceId": { "type": "none" }, "supplierAddressJSON": { "type": "string" }, "coaflexiFormInstanceVersion": { "type": "number" }, "supplierBankingDetailsJSON": { "type": "string" }, "supplierAddressRemitJSON": { "type": "string" }, "defaultSupplierRemitTOAddressJSON": { "type": "string" }, "coaflexiFormId": { "type": "none" }, "requestEdit": { "type": "boolean" }, "freightCharges": { "type": "number" }, "splitCostingLevel": { "type": "number" }, "splitCostingType": { "type": "number" }, "referenceType": { "type": "number" }, "paymentMethod": { "type": "number" }, "origin": { "type": "number" }, "purchaseTypeSetting": { "type": "boolean" }, "ptGLAccountSetting": { "type": "boolean" }, "newGrossTotalAmount": { "type": "number" }, "applyTaxOnGrossTotal": { "type": "boolean" }, "newTotalTaxAmount": { "type": "number" }, "supplierBankingDetailsId": { "type": "none" }, "assignProject": { "type": "boolean" }, "projectSettingStatus": { "type": "string" }, "supplierId": { "type": "string" }, "baseCurrency": { "type": "string" }, "baseExchangeRate": { "type": "number" }, "baseTotal": { "type": "number" }, "taxAmount": { "type": "number" }, "chargedAmount": { "type": "number" }, "chargedTaxAmount": { "type": "number" }, "batchProcessing": { "type": "boolean" }, "docType": { "type": "number" }, "docTypeDesc": { "type": "string" }, "customerReferenceId": { "type": "string" }, "contractNumber": { "type": "none" }, "contractId": { "type": "none" }, "contractType": { "type": "number" }, "supplierContact": { "type": "string" }, "supplierAddressId": { "type": "string" }, "supplierAddressIdRemit": { "type": "string" }, "invoiceTaxes": { "type": "none" }, "invoiceCostings": { "type": "none" }, "invoiceAccountings": { "type": "none" }, "invoiceCatLogItems": { "type": "none" }, "supplierERPId": { "type": "string" }, "supplierAddressERPId": { "type": "none" }, "paymentTermId": { "type": "string" }, "transactionId": { "type": "string" }, "zsnInvoiceCreator": { "type": "none" }, "zsnInvoiceCreatorEmailId": { "type": "none" }, "supplierRemitAddressERPId": { "type": "none" }, "supplierTaxExampt": { "type": "string" }, "shipToCodeType": { "type": "number" }, "shipToCode": { "type": "none" }, "shipToLocation": { "type": "none" }, "supplierName": { "type": "string" }, "suppAddress": { "type": "none" }, "suppAddressRemit": { "type": "none" }, "purchaseOrderNumber": { "type": "string" }, "submittedOn": { "type": "number" }, "approvedOn": { "type": "none" }, "closedOn": { "type": "none" }, "resubmitionCount": { "type": "number" }, "applyNoTaxes": { "type": "boolean" }, "supplierBankingDetails": { "type": "none" }, "visibilityRule": { "type": "none" }, "entitySettings": { "type": "none" }, "esignAttachment": { "type": "none" }, "templateId": { "type": "none" }, "recurringInvoiceDate": { "type": "none" }, "templateName": { "type": "none" }, "zsnInvalidData": { "type": "none" }, "comments": { "type": "string" }, "description": { "type": "string" }, "invoiceNumber": { "type": "string" }, "buyer": { "type": "none" }, "requester": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

    }

    return Invoice;
};
