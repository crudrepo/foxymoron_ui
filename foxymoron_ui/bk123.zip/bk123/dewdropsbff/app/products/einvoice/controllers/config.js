/**
 * Config Controller
 *
 * @description :: Provides config related CRUD operation.
 */

module.exports = (parentClass) => {

    class Config extends parentClass {

        getInvoiceConfig(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "configKeys": "joi.array().items(joi.string().label('einvoice-lable-1__')).unique().allow(null).label('einvoice-lable-1__')"
                    }
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/config/invoiceConfig';
                    http.post(url, 'getInvoiceConfig', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            /*
                            let responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{}}}},
                             output =  (new (super.responseHandler)(request, result, responseSchema)); 
                           // using fav-item as previously used and filter items have same schema
                            output.addCommonSchema('favourite-item', output.responseSchema.properties.records.properties);
                            output.addCommonSchema('pagination', output.responseSchema.properties);                               
                            let schemaRes = output.execute(); 
                            return callback(null, request, schemaRes);
                            */
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
* @Name :: getSystemConfig
*
* @Description :: Fetch system configuration details
* 
* @return/object/Throw Error
*/
        getSystemConfig(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "configKeys": "joi.array().items(joi.string().label('einvoice-lable-1__')).unique().allow(null).label('einvoice-lable-1__')"
                    }
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/config/systemConfig';
                    http.post(url, 'getSystemConfig', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return Config;
};
