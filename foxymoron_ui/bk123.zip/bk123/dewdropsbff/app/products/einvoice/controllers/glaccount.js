/**
   * @Name: GlAccountController   
   * @Description : It is used for handling the operations relate to Glaccount.
**/

module.exports = (parentClass) => {

    class Glaccount extends parentClass {
        /**
       * @name :: allowedList
       *
       * @description :: provides the allowed  list
       *
       * @param1 :: request object
       * @param2 :: input object
       * @return/callback companies details
       */
        allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/master/allowedGenaralLedgers/filter';
                    http.post(url, 'AllowedList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "code": { "type": "string" }, "name": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "accountTypeCode": { "type": "string" }, "parentGeneralLedgerCode": { "type": "string" }, "companyGeneralLedgerCode": { "type": "string" }, "companyCode": { "type": "string" }, "description": { "type": "string" }, "erpId": { "type": "string" }, "businessUnitCodes": { "type": "string" }, "scopeGroupCode": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    }
    return Glaccount;
}