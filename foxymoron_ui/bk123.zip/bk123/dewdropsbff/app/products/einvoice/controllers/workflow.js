/**
 * Workflow  Controller
 *
 * @description :: Provides Workflow related CRUD operation.
 */
module.exports = (parentClass) => {

    class Workflow extends parentClass {
        /**
        * @Name :: getWorkflowDetails
        *
        * @Description :: Fetch/Get workflow trail Details based on WorkflowID & workflowInstanceId
        * 
        * @return/object/Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "workflowId": "joi.string().required().label('einvoice-lable-28__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "workflowId": request.params.workflow_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/workflow/${request.params.workflow_Id}`;
                    http.get(url, 'getDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "version": { "type": "number" }, "workflowId": { "type": "string" }, "name": { "type": "string" }, "defaultWorkflow": { "type": "boolean" }, "description": { "type": "string" }, "processCode": { "type": "string" }, "definitionId": { "type": "string" }, "currency": { "type": "string" }, "updated": { "type": "boolean" }, "parentWorkflowId": { "type": "string" }, "preventMultiApprovals": { "type": "boolean" }, "defaultWorkflowKey": { "type": "string" }, "newWorkflow": { "type": "boolean" }, "definitionType": { "type": "number" }, "processKey": { "type": "string" }, "errorReasonsStr": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Name :: scopeDetails
        *
        * @Description :: Fetch the Scope Details of Workflow
        * 
        * @return/object/Throw Error
        */
        scopeDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "workflowId": "joi.string().required().label('einvoice-lable-28__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "workflowId": request.params.workflow_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/workflow/${request.params.workflow_Id}/scope`;
                    http.get(url, 'scopeDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "businessUnitLocations": { "type": "none" }, "regions": { "type": "none" }, "categories": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());

                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Name :: getWorkflowTrail
        *
        * @Description :: Fetch/Get workflow trail Details based on WorkflowID & workflowInstanceId
        * 
        * @return/object/Throw Error
        */
        workflowTrail(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "workflowInstanceId": "joi.string().required().label('einvoice-lable-29__')",
                        "workflowId": "joi.string().required().label('einvoice-lable-28__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "workflowId": request.params.workflow_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/workflow/${request.params.workflow_Id}/${request.body.workflowInstanceId}`;
                    http.get(url, 'workflowTrail', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "lastModifiedOn": { "type": "none" }, "workflowName": { "type": "string" }, "isNewWorkflow": { "type": "boolean" }, "instanceActivities": { "type": "array", "properties": { "tenantId": { "type": "string" }, "autoId": { "type": "number" }, "activityId": { "type": "string" }, "predictedActivityId": { "type": "string" }, "workflowNodeId": { "type": "string" }, "nodeId": { "type": "string" }, "userType": { "type": "string" }, "displayName": { "type": "string" }, "receivedOn": { "type": "none" }, "status": { "type": "number" }, "delegated": { "type": "boolean" }, "endCustomNode": { "type": "boolean" }, "activityType": { "type": "number" }, "activityValue": { "type": "string" }, "approvalId": { "type": "string" }, "comments": { "type": "string" }, "actionBy": { "type": "string" }, "actionOn": { "type": "none" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "customNode": { "type": "boolean" }, "instanceId": { "type": "string" }, "executionId": { "type": "string" }, "instanceActivityUsers": { "type": "string" }, "instanceActivityDelegates": { "type": "string" }, "subProcessInstanceIds": { "type": "string" }, "subInstanceActivities": { "type": "string" }, "multiSubInstanceActivities": { "type": "string" }, "multiSubProcessInstanceIds": { "type": "string" }, "forkMetaMap": { "type": "string" }, "userTypeStr": { "type": "string" }, "subProcessInstanceIdsStr": { "type": "string" }, "multiSubProcessInstanceIdsStr": { "type": "string" }, "forkMetaMapStr": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());

                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Name :: evaluateWorkflow
        *
        * @Description :: Evaluate the wokflow for the data passed
        * 
        * @return/object/Throw Error
        */
        evaluate(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "processCode": "joi.string().required().label('einvoice-lable-30__')",
                        "requestUserId": "joi.string().required().label('einvoice-lable-31__')",
                        "currency": "joi.string().required().label('einvoice-lable-32__')",
                        "itemSource": "joi.string().required().label('einvoice-lable-36__')",
                        "supplierId": "joi.string().required().label('einvoice-lable-19__')",
                        "noTaxAmount": "joi.boolean().label('einvoice-lable-37__')",
                        "neverExpires": "joi.boolean().label('einvoice-lable-64__')",
                        "selfAssessedAmt": "joi.boolean().label('einvoice-lable-38__')",
                        "shipToLocationDifference": "joi.boolean().label('einvoice-lable-39__')",
                        "headerCOAEnabled": "joi.boolean().label('einvoice-lable-40__')",
                        "hasNegativeTaxByByuer": "joi.boolean().label('einvoice-lable-41__')",
                        "hasNegativeTax": "joi.boolean().label('einvoice-lable-42__')",
                        "coaFlexiFormInstanceIds": "joi.array().items(joi.string().allow('').label('einvoice-lable-43__')).unique().required().label('einvoice-lable-43__')",
                        "costCenterUniqueCodes": "joi.array().items(joi.string().allow('').label('einvoice-lable-45__')).unique().required().label('einvoice-lable-45__')",
                        "glAccountCodes": "joi.array().items(joi.string().allow('').label('einvoice-lable-46__')).unique().required().label('einvoice-lable-46__')",
                        "accountTypeCodes": "joi.array().items(joi.string().allow('').label('einvoice-lable-47__')).unique().required().label('einvoice-lable-47__')",
                        "coaFlexiFormId": "joi.string().allow('').required().label('einvoice-lable-44__')",
                        "totalAmount": "joi.number().required().label('einvoice-lable-48__')",
                        "purchaseType": "joi.string().allow('').label('einvoice-lable-49__')",
                        "requisitionIds": "joi.array().items(joi.string().allow('').label('einvoice-lable-50__')).unique().required().label('einvoice-lable-50__')",
                        "referenceType": "joi.string().allow('').label('einvoice-lable-51__')",
                        "paymentTerms": "joi.string().allow('').required().label('einvoice-lable-52__')",
                        "buyerId": "joi.string().allow('').required().label('einvoice-lable-53__')",
                        "requesterId": "joi.string().allow('').required().label('einvoice-lable-54__')",
                        "invoiceId": "joi.string().allow('').required().label('einvoice-lable-14__')",
                        "invoiceType": "joi.string().allow('').required().label('einvoice-lable-55__')",
                        "paymentMethod": "joi.string().allow('').required().label('einvoice-lable-56__')",
                        "invoiceMatchingStatus": "joi.string().allow('').required().label('einvoice-lable-57__')",
                        "invoiceMatchResult": "joi.object().required().label('einvoice-lable-58__')",
                        "receiptRequiredForItemMap": "joi.object().label('einvoice-lable-59__')",
                        "requesterForItemsMap": "joi.object().label('einvoice-lable-60__')",
                        "templateId": "joi.string().allow('').required().label('einvoice-lable-61__')",
                        "contractOwner": "joi.string().allow('').required().label('einvoice-lable-62__')",
                        "invoiceTemplate": "joi.object().allow(null).required().label('einvoice-lable-63__')",
                        "cbl": "joi.object().keys({companyCode: joi.string().required().label('einvoice-lable-34__'),businessUnitCode:joi.string().required().label('einvoice-lable-35__'),locationCode:joi.string().required().label('einvoice-lable-20__')}).required().label('einvoice-lable-33__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/workflow/evaluateWorkflow`;
                    http.post(url, 'evaluateWorkflow', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "workflow": { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "object" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "version": { "type": "number" }, "workflowId": { "type": "string" }, "name": { "type": "string" }, "defaultWorkflow": { "type": "boolean" }, "description": { "type": "string" }, "processCode": { "type": "string" }, "definitionId": { "type": "string" }, "currency": { "type": "string" }, "updated": { "type": "boolean" }, "parentWorkflowId": { "type": "string" }, "preventMultiApprovals": { "type": "boolean" }, "defaultWorkflowKey": { "type": "string" }, "newWorkflow": { "type": "boolean" }, "definitionType": { "type": "number" }, "processKey": { "type": "string" }, "errorReasonsStr": { "type": "string" } } }, "instanceActivities": { "type": "array", "properties": { "tenantId": { "type": "string" }, "autoId": { "type": "number" }, "activityId": { "type": "string" }, "predictedActivityId": { "type": "string" }, "workflowNodeId": { "type": "string" }, "nodeId": { "type": "string" }, "userType": { "type": "string" }, "displayName": { "type": "string" }, "receivedOn": { "type": "none" }, "status": { "type": "number" }, "delegated": { "type": "booean" }, "endCustomNode": { "type": "booean" }, "activityType": { "type": "number" }, "activityValue": { "type": "string" }, "approvalId": { "type": "string" }, "comments": { "type": "string" }, "actionBy": { "type": "string" }, "actionOn": { "type": "none" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "customNode": { "type": "boolean" }, "instanceId": { "type": "string" }, "executionId": { "type": "string" }, "multiSubProcessInstanceIdsStr": { "type": "string" }, "forkMetaMapStr": { "type": "string" }, "userTypeStr": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Name :: remind Workflow Approval
        *
        * @Description :: To remind the workflow approval
        * 
        * @return/object/Throw Error
        */
        remindAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "workflowInstanceId": "joi.string().required().label('einvoice-lable-29__')",
                        "approvalLastModifiedOn": "joi.string().label('einvoice-lable-72__')",
                        "approvalId": "joi.string().required().label('einvoice-lable-71__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/workflowApproval/${request.body.approvalId}/remindWorkflowApproval`;
                    delete request.body.approvalId;
                    http.post(url, 'remindWorkflowApproval', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "string" }, "info2": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * Function to get getApprovals
        * @param {*} request 
        * @param {*} input 
        * @param {*} callback 
        */
        getApprovals(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "approvalId": "joi.string().required().label('einvoice-lable-71__')"
                    };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/workflowApproval/${request.body.approvalId}`;
                    http.get(url, 'getWorkflowApprovals', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "autoId": { "type": "number" }, "approvalId": { "type": "string" }, "receivedOn": { "type": "number" }, "status": { "type": "number" }, "entityId": { "type": "string" }, "version": { "type": "number" }, "entityNumber": { "type": "string" }, "entityName": { "type": "string" }, "entityCompanyCode": { "type": "string" }, "entityBusinessUnitCode": { "type": "string" }, "entityLocationCode": { "type": "string" }, "entityCreatedBy": { "type": "string" }, "entityInitiator": { "type": "string" }, "entityCurrency": { "type": "string" }, "entityAmount": { "type": "number" }, "entityApprovedAmount":{"type":"number"}, "approvedAmountRange":{"type":"string"}, "entityUrgent": { "type": "boolean" }, "approvalType": { "type": "number" }, "approvalValue": { "type": "string" }, "displayName": { "type": "string" }, "comments": { "type": "string" }, "actionBy": { "type": "string" }, "actionOn": { "type": "number" }, "workflowId": { "type": "string" }, "processCode": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "workflowExecutionId": { "type": "string" }, "delegated": { "type": "boolean" }, "adminAction": { "type": "boolean" }, "workflowApprovalUsers": { "type": "none" }, "workflowApprovalDelegates": { "type": "none" }, "modifiedOn": { "type": "number" }, "systemAction": { "type": "boolean" }, "processingStatus": { "type": "number" }, "processType": { "type": "string" }, "processKey": { "type": "string" }, "forkingAmount":{"type":"number"}, "autoAction": { "type": "boolean" }, "archive": { "type": "boolean" }, "origin":{"type":"number"}, "entityType":{"type":"number"}, "forkingValues":{"type":"string"}, "processTypeStr": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Name :: Get Workflow Approval List
        *
        * @Description :: Get the workflow Approval List
        * 
        * @return/object/Throw Error
        */
        approvalList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "pageName": "joi.string().required().label('einvoice-lable-2__')"
                    };
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.eInvoice}/workflowApproval/filter/${request.body.pageName}`;
                    delete request.body.pageName;
                    http.post(url, 'WorkflowApprovalList', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                output = {},
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'].records : [],
                                pagination = (!super.lodash.isEmpty(result['data'])) ? result['data'].pagination : {},
                                responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "autoId": { "type": "number" }, "approvalId": { "type": "string" }, "receivedOn": { "type": "number" }, "status": { "type": "number" }, "entityId": { "type": "string" }, "version": { "type": "number" }, "entityNumber": { "type": "string" }, "entityName": { "type": "string" }, "entityCompanyCode": { "type": "none", "key":"companyCodeInfo" }, "entityBusinessUnitCode": { "type": "none", "key":"businessCodeInfo" }, "entityLocationCode": { "type": "none", "key":"locationCodeInfo" }, "entityCreatedBy": { "type": "string" }, "entityInitiator": { "type": "none", "key":"entityInitiatorInfo" }, "entityCurrency": { "type": "string" }, "entityAmount": { "type": "number" }, "entityApprovedAmount": { "type": "number" }, "approvedAmountRange": { "type": "string" }, "entityUrgent": { "type": "boolean" }, "approvalType": { "type": "number" }, "approvalValue": { "type": "string" }, "displayName": { "type": "string" }, "comments": { "type": "string" }, "actionBy": { "type": "string" }, "actionOn": { "type": "number" }, "workflowId": { "type": "string" }, "processCode": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "workflowExecutionId": { "type": "string" }, "delegated": { "type": "boolean" }, "adminAction": { "type": "boolean" }, "workflowApprovalUsers": { "type": "none" }, "workflowApprovalDelegates": { "type": "none" }, "modifiedOn": { "type": "number" }, "systemAction": { "type": "boolean" }, "processingStatus": { "type": "number" }, "processType": { "type": "string" }, "processKey": { "type": "string" }, "forkingAmount": { "type": "number" }, "autoAction": { "type": "boolean" }, "archive": { "type": "boolean" }, "origin": { "type": "number" }, "entityType": { "type": "number" }, "forkingValues": { "type": "string" }, "processTypeStr": { "type": "string" } } } } };
                            let initiatorDetails = [],
                                companyCodes = [],
                                businessUnitCodes = [],
                                locationCodes = [];
                            if (!lodash.isEmpty(records) && lodash.isArray(records)) {
                                records.forEach(item => {
                                    if (item.entityInitiator) initiatorDetails.push(item.entityInitiator);
                                    if (item.entityCompanyCode) companyCodes.push(item.entityCompanyCode);
                                    if (item.entityBusinessUnitCode) businessUnitCodes.push(item.entityBusinessUnitCode);
                                    if (item.entityLocationCode) locationCodes.push(item.entityLocationCode);
                                });
                                initiatorDetails = lodash.uniq(initiatorDetails);
                                companyCodes = lodash.uniq(companyCodes);
                                businessUnitCodes = lodash.uniq(businessUnitCodes);
                                locationCodes = lodash.uniq(locationCodes);
                            } else {
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('pagination', output.responseSchema.properties);
                                return callback(null, request, output.execute());
                            }
                            const cmd = new (super.cmdHook({ request: request }))(),
                                tasks = [

                                    (methodCallback) => {
                                        if (lodash.isEmpty(companyCodes)) return methodCallback(request, {});
                                        //Step 1 : Fetch Company details 
                                        const reqData = { "codes": companyCodes, "pageNo": 1, "perPageRecords": companyCodes.length };
                                        cmd.getCompany(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.companyDetails = input.data.result || [];
                                        if (lodash.isEmpty(businessUnitCodes)) return methodCallback(request, {});
                                        //Step 2 : Fetch BusinessUnit details 
                                        const reqData = { "codes": businessUnitCodes, "pageNo": 1, "perPageRecords": businessUnitCodes.length };
                                        cmd.getBusinessUnit(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.businessUnitDetails = input.data.result || [];
                                        if (lodash.isEmpty(locationCodes)) return methodCallback(request, {});
                                        //Step 3 : Fetch Location details 
                                        const reqData = { "codes": locationCodes, "pageNo": 1, "perPageRecords": locationCodes.length };
                                        cmd.getLocation(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        const tms = new (super.tmsHook({ request: request }))();
                                        output.locationDetails = input.data.result || [];
                                        if (lodash.isEmpty(initiatorDetails)) return methodCallback(request, {});
                                        //step 4 : get the initiators details
                                        const reqData = { "ids": initiatorDetails };
                                        tms.getUsersDetails(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {

                                        output.records = [];
                                        output.pagination = pagination;
                                        //Step 5 : Merge all details to the response                                      
                                        //a) Company
                                        if (!lodash.isEmpty(output.companyDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.companyDetails, ["name", "code"]),
                                                utilsMerge = utils.mergeArray(records, extractProps, ["entityCompanyCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //b) Business Unit
                                        if (!lodash.isEmpty(output.businessUnitDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.businessUnitDetails, ["name", "code"]),
                                                utilsMerge = utils.mergeArray(output.records, extractProps, ["entityBusinessUnitCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //c) Location
                                        if (!lodash.isEmpty(output.locationDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.locationDetails, ["name", "code"]),
                                                utilsMerge = utils.mergeArray(output.records, extractProps, ["entityLocationCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //e) Initiator Details
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]),
                                                utilsMerge = utils.mergeArray(output.records, extractProps, ["entityInitiator", "id"]);
                                            output.records = utilsMerge;
                                        }
                                        return methodCallback(null, request, output);
                                    },
                                ];

                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    const output = (new (super.responseHandler)(request, { "data": result }, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: approve Workflow Approval
        *
        * @Description :: Fetch/Get workflow Approval Details based on approval Id
        * 
        * @return/object/Throw Error
        */
        approveAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                    validationUtility.validObj = false;
                const schema = {
                    "adminRequestedAction": "joi.string().label('einvoice-lable-74__')",
                    "roletype": "joi.string().label('einvoice-lable-73__')",
                    "approvalLastModifiedOn": "joi.string().label('einvoice-lable-72__')",
                    "comments": "joi.string().label('einvoice-lable-13__')",
                    "approvedAmount": "joi.string().required().label('einvoice-lable-65__')",
                    "approvalId": "joi.string().required().label('einvoice-lable-71__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntities, null),
                        url = `${request.productsURL.eInvoice}/workflowApproval/approveWorkflowApprovals`; 
                    http.post(url, 'approveWorkflowApproval', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "string" }, "info2": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Name :: reject Workflow Approval
        *
        * @Description :: Fetch/Get workflow Approval Details based on Approval Id
        * 
        * @return/object/Throw Error
        */
        rejectAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                    validationUtility.validObj = false;
                const schema = {
                    "adminRequestedAction": "joi.string().label('einvoice-lable-74__')",
                    "roletype": "joi.string().label('einvoice-lable-73__')",
                    "approvalLastModifiedOn": "joi.string().label('einvoice-lable-72__')",
                    "comments": "joi.string().label('einvoice-lable-13__')",
                    "approvalId": "joi.string().required().label('einvoice-lable-71__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntities, null),
                        url = `${request.productsURL.eInvoice}/workflowApproval/rejectWorkflowApprovals`;
                    http.post(url, 'rejectWorkflowApproval', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "string" }, "info2": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: delegate Workflow Approval Action
        *
        * @Description :: Fetch/Get workflow Approval Details based on Approval Id, Delegated User Id. 
        * 
        * @return/object/Throw Error
        */
        delegateAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                    validationUtility.validObj = false;
                const schema = {
                    "adminRequestedAction": "joi.string().label('einvoice-lable-74__')",
                    "roletype": "joi.string().label('einvoice-lable-73__')",
                    "approvalLastModifiedOn": "joi.string().label('einvoice-lable-72__')",
                    "comments": "joi.string().label('einvoice-lable-13__')",
                    "delegatedUserId": "joi.string().required().label('einvoice-lable-75__')",
                    "approvalId": "joi.string().required().label('einvoice-lable-71__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntities, null),
                        url = `${request.productsURL.eInvoice}/workflowApproval/delegateWorkflowApprovals`;
                    http.post(url, 'delegateWorkflowApproval', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "string" }, "info2": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: validate dynamic Workflow Approval
        *
        * @Description :: Check if the workflow name already exists or not based on WorkflowID
        *
        * @return/object/Throw Error
        */
        validateDynamicApprover(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "newUserId": "joi.string().required().label('einvoice-lable-76__')",
                        "workflowId": "joi.string().required().label('einvoice-lable-28__')",
                        "workflowInstanceId": "joi.string().required().label('einvoice-lable-29__')",
                        "parentNodeId": "joi.string().required().label('einvoice-lable-77__')",
                        "action": "joi.string().required().label('einvoice-lable-78__')",
                        "entityId": "joi.string().required().label('einvoice-lable-79__')",
                        "activityId": "joi.string().label('einvoice-lable-80__')",
                        "processCode": "joi.string().required().label('einvoice-lable-30__')",
                        "lastModifiedLong": "joi.number().label('einvoice-lable-81__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/workflowApproval/validateDynamicApprover`;
                    http.post(url, 'validateDynamicApprover', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        	                /**
    * @Name :: update Workflow Instance
    *
    * @Description :: Update the workflow instance based on workflow Instance Id and approval Id
    * 
    * @return/object/Throw Error
    */
   updateWorkflowInstance(request, input, callback) {
    try {
        const validationUtility = super.utils.validationUtility(request),
            schema = {
                "workflowInstanceId": "joi.string().required().label('einvoice-lable-29__')",
                "workflowNodeId": "joi.string().required().label('einvoice-lable-82__')",
                "parentNodeId": "joi.string().required().label('einvoice-lable-77__')",
                "parentUserId": "joi.string().required().label('einvoice-lable-83__')",
                "approvalId": "joi.string().required().label('einvoice-lable-71__')",
                "nodeId": "joi.string().required().label('einvoice-lable-84__')",
                "approverUserId": "joi.string().required().label('einvoice-lable-85__')",
                "action": "joi.string().required().label('einvoice-lable-78__')",
                "entityId": "joi.string().required().label('einvoice-lable-79__')",
                "processCode": "joi.string().required().label('einvoice-lable-30__')",
                "roleType": "joi.string().required().label('einvoice-lable-73__')",
                "lastModifiedLong": "joi.number().label('einvoice-lable-81__')"
            };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate(super.lodash.merge(request.body, {"workflowInstanceId": request.params.workflow_Id}));
        if (result) {
            const errorMsg = new (super.customError)(result, 'ValidationError', 3);
            return callback(errorMsg, null);
        } else {
            const http = new (super.httpService)(request),
                url = `${request.productsURL.eInvoice}/workflowApproval/updateWorkflowInstance`,
                requestData = super.lodash.merge(request.body, {"workflowInstanceId": request.params.workflow_Id});
            http.post(url, 'updateWorkflowInstance', requestData, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                        output = (new (super.responseHandler)(request, result, responseSchema));
                    return callback(null, request, output.execute());
                }
            });
        }
    } catch (error) {
        return callback(error, null);
    }
};

    }
    return Workflow;
}