"use strict";

module.exports = {

    /**
    * @swagger
    * /a/einvoice/invoiceTemplate/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the invoice templates list
    *     operationId: invoiceTemplateList
    *     description: Get the invoice templates list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the invoice templates (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "invoicetemplate.getList",
        post: null,
        method: 'POST'
    },

    /**
  * @swagger
  * /a/einvoice/invoiceTemplate/{invoiceTemplate_Id}/callAction:
  *   put:
  *     tags:
  *       - eInvoice API
  *     summary: Update the Invoice template based on actionName
  *     operationId: updateInvoiceTemplateBasedOnAction
  *     description: Update the Invoice template based on actionName
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: invoiceTemlpate_Id
  *         description: Provide a Invoice template Id
  *         in: path
  *         required: true
  *         type: integer
  *       - name: body
  *         description: Update the invoice Template based on actionName (deleteInvoiceTemplate','activateInvoiceTemplate','deActivateInvoiceTemplate','recallInvoiceTemplate') with comments.
  *         type: string
  *         in: body
  *         required: true
  *         schema: 
  *             properties:
  *               actionName:
  *                 type: string
  *               comments:
  *                 type: string
  *               approvedAmount:
  *                 type: string
  *             required: [actionName ]
  *     responses:
  *       200:
  *         description: successful operation
  */
  callAction: {
      pre: null,
      process: "invoicetemplate.updateAction",
      post: null,
      method: 'PUT'
  },

  /**
  * @swagger
  * /a/einvoice/invoiceTemplate/{invoiceTemplate_Id}/getDetails:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Fetch/Get a Invoice Template Details
  *     operationId: getInvoiceDetails
  *     description: Fetch/Get a Invoice Template Details
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: invoiceTemplate_Id
  *         description: Provide a invoice Template ID.
  *         in: path
  *         required: true
  *         type: integer
  *       - name: body
  *         description: View Invoice Template Details.
  *         in: body
  *         schema: 
  *             properties:
  *               version:
  *                 type: integer
  *             required: [version]
  *     responses:
  *       200:
  *         description: successful operation
  */
  getDetails: {
      pre: null,
      process: "invoicetemplate.getInvoiceTemplateDetails",
      post: null,
      method: 'POST'
  },

  /**
  * @swagger
  * /a/einvoice/invoiceTemplate/{invoiceTemplate_Id}/getReleaseDetails:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Fetch/Get a Invoice Details
  *     operationId: getInvoiceTemplateReleaseDetails
  *     description: Fetch/Get a Invoice Details
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: invoiceTemplate_Id
  *         description: Provide a invoice ID.
  *         in: path
  *         required: true
  *         type: integer
  *       - name: body
  *         description: View Invoice Template Release Details.
  *         in: body
  *         schema: 
  *             properties:
  *               version:
  *                 type: integer
  *             required: [version]
  *     responses:
  *       200:
  *         description: successful operation
  */
 getReleaseDetails: {
    pre: null,
    process: "invoicetemplate.getInvoiceTemplateReleaseDetails",
    post: null,
    method: 'POST'
},

  /**
  * @swagger
  * /a/einvoice/invoiceTemplate/isExistsInvoiceTemplateNumber:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Fetch/Get a Invoice Details if Invoice Number Exists
  *     operationId: getInvoiceDetails if Invoice Number Exists
  *     description: Fetch/Get a Invoice Details if Invoice Number Exists
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: body
  *         description: View Invoice Details if Invoice Number Exists
  *         in: body
  *         required: true
  *         schema: 
  *             properties:
  *               invoiceNumber:
  *                 type: string
  *               supplierId:
  *                 type: string
  *               invoiceId:
  *                 type: string
  *             required: [invoiceNumber,supplierId]
  *     responses:
  *       200:
  *         description: successful operation
  */
  isExistsInvoiceTemplateNumber: {
      pre: null,
      process: "invoicetemplate.isExistsInvoiceTemplateNumber",
      post: null,
      method: 'POST'
  },

  /**
  * @swagger
  * /a/einvoice/invoiceTemplate/{id}/auditTrail:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Fetch/Get Audit Trail Details by Id and Type
  *     operationId: getAuditTrailDetails
  *     description: Fetch/Get Audit Trail Details by Id and Type
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: id
  *         description: Provide invoice template id
  *         in: path
  *         required: true
  *         type: string
  *       - name: body
  *         description: Get Audit Trail Details(pass the entityType as INVOICE_TEMPLATE with respetive Id).
  *         in: body
  *         required: true
  *         schema: 
  *             properties:
  *               entityType:
  *                 type: string
  *             required: [entityType ]
  *     responses:
  *       200:
  *         description: successful operation
  */
  auditTrail: {
      pre: null,
      process: "invoicetemplate.auditTrail",
      post: null,
      method: 'POST'
  }
}