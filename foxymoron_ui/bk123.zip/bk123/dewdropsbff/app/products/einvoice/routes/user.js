"use strict";
module.exports = {
  /**
 * @swagger
 * definitions:
 *   eInvoiceUserRole:
 *     properties:
 *       userRole:
 *         type: string
 *     required: [userRole]
 */

  /**
    * @swagger
    * /a/einvoice/users/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the buyer/requestor list
    *     operationId: buyer/requestorList
    *     description: Get the buyer/requestor list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the buyer/requestor list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/eInvoiceUserRole'
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
  getList: {
    pre: null,
    process: "user.getList",
    post: null,
    method: 'POST'
  },

  /**
    * @swagger
    * /a/einvoice/users/scopeList:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get User Scopes list
    *     operationId: UserScopesList
    *     description: Get User Scopes list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the User Scope list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    scopeList: {
      pre: null,
      process: "user.scopeList",
      post: null,
      method: 'POST'
    }

}