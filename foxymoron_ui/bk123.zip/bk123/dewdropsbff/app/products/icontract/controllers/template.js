/**
 * Templatel Controller 
 * @description :: Provides Template  Details.
 */
module.exports = (parentClass) => {
    class Template extends parentClass {
        /**
        * @Method Name : getLabels
        * @Description : Get UI Labels 
        * @return object / Throw Error
        */
        getLabels(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.iContract["soa"]}/template/screenlabels`;
                http.get(url, 'templateGetLabels', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "templateTitle": { "type": "string" }, "templateNumber": { "type": "string" }, "source": { "type": "string" }, "lastModifiedOn": { "type": "string" }, "type": { "type": "string" }, "Subtype": { "type": "string" }, "status": { "type": "string" }, "templateDescription": { "type": "string" }, "baseType": { "type": "string" }, "region": { "type": "string" }, "contractCategory": { "type": "string" }, "businessunits": { "type": "string" }, "templateFor": { "type": "string" }, "language": { "type": "string" }, "templateCreatedOn": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : getList
         *
         * @Description : Get the list of templates 
         * @return object / Throw Error
         */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/template/filter`;
                    http.post(url, 'getClauseList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "templateId": { "type": "string" }, "templateName": { "type": "string" }, "templateNo": { "type": "string" }, "source": { "type": "string" }, "sourceCode": { "type": "number" }, "lastModifiedOn": { "type": "none" }, "type": { "type": "string" }, "subType": { "type": "string" }, "status": { "type": "number" }, "statusCode": { "type": "boolean" }, "language": { "type": "string" }, "templateRegion": { "type": "none" }, "templateContractCategory": { "type": "none" }, "templateBusinessUnits": { "type": "none" }, "templateBaseTypes": { "type": "string" }, "templateCreatedOn": { "type": "none" }, "templateDescription": { "type": "string" }, "templateFor": { "type": "number" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        updateStatus(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "status": "joi.string().required().valid('Active','Inactive','Delete').insensitive().label('icontract-lable-6__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/template/update/status`;
                    http.post(url, 'updateStatus', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());

                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : downloadDocuments
        * @Description : Get the multiple Attachment for given contract id's
        * @return object / Throw Error
        */
        downloadDocuments(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/template/documents`;
                    http.post(url, 'downloadDocuments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(result.errors, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }
    return Template;
};