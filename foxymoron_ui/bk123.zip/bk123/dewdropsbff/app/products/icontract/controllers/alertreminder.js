/**
 * ScreenLabel Controller 
 * @description :: Provides Alert Remainder  Details.
 */
module.exports = (parentClass) => {
    class AlertReminder extends parentClass {
        /**
        * @Method Name : getAlertList
        * @param1 labelId 
        * @Description : Get Alert List
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getAlertList`;
                    http.post(url, 'getAlertList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "alertId": { "type": "string" }, "title": { "type": "string" }, "alertType": { "type": "string" }, "createdFor": { "type": "string" }, "alertTriggeredCondition": { "type": "string" }, "createdBy": { "type": "string" }, "priority": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getAlertDateCondition
        * @param1 labelId 
        * @Description : Get Alert Date Condition
        * @return object / Throw Error
        */
        getAlertDateCondition(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.alertReminder_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getAlertDateCondition/${request.params.alertReminder_Id}`;
                    http.get(url, 'getAlertList', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "metadata": { "type": "string" }, "screenLevel": { "type": "string" }, "date": { "type": "none" }, "formatdate": { "type": "string" }, "remainDays": { "type": "number" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : destroy
         *
         * @Description : Delete the alert
         * @return object / Throw Error
         */

        destroy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "alertId": "joi.string().required().label('icontract-lable-23__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "alertId": request.params.alertReminder_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/deleteAlert/${request.body.contractId}/${request.params.alertReminder_Id}`;
                    http.get(url, 'deletAlert', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : getAlertDateCondition
        * @param1 labelId 
        * @Description : Get Alert Date Condition
        * @return object / Throw Error
        */
        getAlertRecipients(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "alertId": "joi.string().required().label('icontract-lable-23__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "alertId": request.params.alertReminder_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getalertrecipients/${request.params.alertReminder_Id}`;
                    http.get(url, 'getAlertList', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "recipientType": { "type": "number" }, "recipientName": { "type": "string" }, "recipientEmail": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : Create
        * @param1 labelId 
        * @Description : Create Alert
        * @return object / Throw Error
        */
        saveAndUpdateAlert(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "contractValue": "joi.string().label('icontract-lable-49__')",
                        "alertId": "joi.string().allow('').label('icontract-lable-23__')",
                        "title": "joi.string().required().label('icontract-lable-26__')",
                        "description": "joi.string().label('icontract-lable-27__')",
                        "priority": "joi.string().required().label('icontract-lable-28__')",
                        "metadataScreenLabel": "joi.string().required().label('icontract-lable-29__')",
                        "metaData": "joi.string().required().label('icontract-lable-30__')",
                        "metadataDate": "joi.string().required().label('icontract-lable-31__')",
                        "alertOn": "joi.boolean().required().label('icontract-lable-32__')",
                        "selfAlert": "joi.boolean().required().label('icontract-lable-33__')",
                        "alertType": "joi.number().required().label('icontract-lable-34__')",
                        "alertOnDate": "joi.string().required().label('icontract-lable-35__')",
                        "repeatDuration": "joi.number().label('icontract-lable-36__')",
                        "alertBefore": "joi.number().label('icontract-lable-47__')",
                        "internalUsers": "joi.object().label('icontract-lable-48__')",
                        "internalUserList": `joi.array().items(
                            joi.object().keys({
                                externalUserEmailId: joi.string().email().label('icontract-lable-43__'),
                                externalUserName: joi.string().label('icontract-lable-44__'),
                                userID: joi.number().label('icontract-lable-39__'),
                                ownerID: joi.number().label('icontract-lable-40__')
                            }).label('icontract-lable-38__')
                        ).label('icontract-lable-37__')`,
                        "externalUsers": `joi.array().items(
                            joi.object().keys({
                                externalUserEmailId: joi.string().email().label('icontract-lable-43__'),
                                externalUserName: joi.string().label('icontract-lable-44__'),
                                userID: joi.number().label('icontract-lable-39__'),
                                ownerID: joi.number().label('icontract-lable-40__')
                            }).label('icontract-lable-42__')
                        ).label('icontract-lable-41__')`,
                        "quick": "joi.boolean().label('icontract-lable-45__')",
                        "isOutLookEventSend": "joi.boolean().required().label('icontract-lable-46__')",
                        "alertConditionDto": `joi.object().keys({
                            alertConditionId: joi.string().label('icontract-lable-51__'),
                            numberOfRepetitions: joi.number().label('icontract-lable-52__'),
                            numberOfRepetitionFixed: joi.number().label('icontract-lable-53__'),
                            utilizationValue: joi.number().label('icontract-lable-54__'),
                            lastTriggeredUtilizedValue: joi.number().label('icontract-lable-55__'),
                            firstTriggeredUtilizedValue: joi.number().label('icontract-lable-56__'),
                            repeatByUtilization: joi.number().label('icontract-lable-57__'),
                            repeatByDays: joi.number().label('icontract-lable-58__'),
                            alertConditionType: joi.string().label('icontract-lable-59__'),
                            metadataName: joi.string().label('icontract-lable-60__'),
                            utilizationUnit: joi.string().label('icontract-lable-61__'),
                            dateCondition: joi.string().label('icontract-lable-62__'),
                            alertDate: joi.string().label('icontract-lable-63__'),
                        }).label('icontract-lable-50__')`,
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/saveorupdatealert`;
                    http.post(url, 'saveOrUpdate', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        create(request, input, callback) {
            this.saveAndUpdateAlert(request, input, callback);
        };
        /**
        * @Method Name : update
        * @param1 labelId 
        * @Description : update Alert
        * @return object / Throw Error
        */
        update(request, input, callback) {
            this.saveAndUpdateAlert(request, input, callback);
        };

    }
    return AlertReminder;
};