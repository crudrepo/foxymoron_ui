/**
 * BU ScreenLabel Controller 
 * @description :: Provides ScreenLabel Labels Details.
 */
module.exports = (parentClass) => {
    class Bu extends parentClass {
        /**
        * @Method Name : getLabels
        * @param1 buId 
        * @Description : Get UI Labels for a type
        * @return object / Throw Error
        */
        getLabels(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractTypeId": "joi.string().required().label('icontract-lable-25__')"
                    };                    
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractTypeId": request.params.bu_Id});
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/businessUnits/screenLabels/${request.params.bu_Id}`;
                    http.get(url, 'getLabels', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "Business_Units": { "type": "string" }, "BU_ACTION": { "type": "string" }, "Status1": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
    }
    return Bu;
};