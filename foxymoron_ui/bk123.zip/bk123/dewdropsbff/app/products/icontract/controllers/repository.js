/**
 * repository.screenlabel Controller 
 * @description :: Provides Repository Labels Details.
 */
module.exports = (parentClass) => {
    class Repository extends parentClass {
        /**
        * @Method Name : getLabels
        * @Description : Get UI Labels 
        * @return object / Throw Error
        */
        getLabels(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.iContract["soa"]}/repository/screenlabels`;
                http.get(url, 'getLabels', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "region": { "type": "string" }, "contractTitleNo": { "type": "string" }, "status": { "type": "string" }, "contractStartDate": { "type": "string" }, "contractingParty": { "type": "string" }, "type": { "type": "string" }, "subtype": { "type": "string" }, "amendmentEffectiveDate": { "type": "string" }, "businessunits": { "type": "string" }, "hierarchyType": { "type": "string" }, "contractSignDate": { "type": "string" }, "contractCategory": { "type": "string" }, "isContractConfidential": { "type": "string" }, "contractModificationDate": { "type": "string" }, "folder": { "type": "string" }, "contractEndDate": { "type": "string" }, "id": { "type": "string" }, "templateType": { "type": "string" }, "signer": { "type": "string" }, "isContractSearchable": { "type": "string" }, "contractCreationDate": { "type": "string" }, "owner": { "type": "string" }, "contractTitle": { "type": "string" }, "contractValue": { "type": "string" }, "contractSource": { "type": "string" }, "contractNumber": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : getList
        *
        * @Description : Get the list of contract in respository module
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/repository/filter`;
                    http.post(url, 'getRespositoryContractList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "id": { "type": "string" }, "contractTitle": { "type": "string" }, "contractNumber": { "type": "string" }, "type": { "type": "string" }, "subtype": { "type": "string" }, "contractingParty": { "type": "none" }, "status": { "type": "string" }, "statusCode": { "type": "string" }, "contractValue": { "type": "string" }, "contractCategory": { "type": "string" }, "region": { "type": "string" }, "creationDate": { "type": "none" }, "modificationDate": { "type": "none" }, "startDate": { "type": "none" }, "endDate": { "type": "none" }, "contractSource": { "type": "string" }, "owner": { "type": "string" }, "templateType": { "type": "string" }, "contractSignDate": { "type": "none" }, "businessUnit": { "type": "string" }, "signer": { "type": "string" }, "isContractConfidential": { "type": "string" }, "isContractSearchable": { "type": "string" }, "hierarchyType": { "type": "string" }, "folder": { "type": "string" }, "redirectURL": { "type": "string" }, "showHierarchy": { "type": "boolean" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : getContractHierarchy
         * @Description : Fetch/Get a Contract Hierarchy Details
         * @return object / Throw Error
         */
        getContractHierarchy(request, input, callback) {
            try {
                const contractId = request.params.repository_Id,
                    validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contract_Id": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contract_Id": contractId });
                if (result) {
                    callback(new (super.customError)(result, 'ValidationError', 3), null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/repository/getcontracthierarchy/${contractId}`;
                    http.get(url, 'getContractHierarchy', (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contractId": { "type": "string" }, "subtypeId": { "type": "string" }, "contractNumber": { "type": "string" }, "contractTitle": { "type": "string" }, "hierarchyStatus": { "type": "string" }, "hierarchyStatusValue": { "type": "string" }, "value": { "type": "number" }, "currency": { "type": "string" }, "parentContractId": { "type": "string" }, "listOfChildren": { "type": "none" }, "hasAmendments": { "type": "number" }, "type": { "type": "string" }, "subType": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : downloadLineItem
        * @Description : Get the line items for given contract id
        * @return object / Throw Error
        */
        downloadLineItem(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contract/downloadlineitem`;
                    http.post(url, 'downloadDocuments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(result.errors, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "contractIds": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : downloadDocuments
        * @Description : Get the multiple Attachment for given contract id's
        * @return object / Throw Error
        */
        downloadDocuments(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')",
                        "module": "joi.string().required().valid('Authoring','Repository').insensitive().label('icontract-lable-8__')"

                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "module": "Repository" }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contract/downloaddocuments`;
                    http.post(url, 'downloadDocuments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(result.errors, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : canDelete
        * @Description : Check whether the contract is deletable or not
        * @return object / Throw Error
        */
        canDelete(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).unique().required().label('icontract-lable-2__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')",
                        "comment": "joi.string().label('icontract-lable-3__')"
                    };

                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, null),
                        url = `${request.productsURL.iContract["soa"]}/repository/candeletecontract`;

                    http.post(url, 'canDelete', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : deleteContract
         *
         * @Description : Delete the contract
         * @return object / Throw Error
         */
        deleteContract(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).unique().required().label('icontract-lable-2__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')",
                        "comment": "joi.string().label('icontract-lable-3__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/repository/deletecontract`;
                    http.post(url, 'DeleteContract', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const message = { description: "icontract-msg-1" };
                            if (!super.lodash.isEmpty(result.data.id)) {
                                result.message = [message];
                            }
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : getAllowedAction
        * @Description : Get the allowed action for given contract id
        * @return object / Throw Error
        */
        getAllowedAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/repository/getAllowedActionByContract`;
                    http.post(url, 'getAllowedAction', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : delegateAmendment
         *
         * @Description :  Apply Action For Delegating Amendment to selected users
         * @return object / Throw Error
         */
        delegateAmendment(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "delegateUsersEmailIds": "joi.array().items(joi.string().allow('').label('icontract-lable-5__')).allow(null).unique().label('icontract-lable-5__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/repository/delegateamendment`;
                    http.post(url, 'delegateAmendment', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {

                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : suggestedAction
        * @Description : Get the suggested action for given contract id's
        * @return object / Throw Error
        */
        suggestedAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/repository/suggestedaction`;
                    http.post(url, 'getSuggestedAction', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : foldersByConfidentiality
         *
         * @Description :  Get Folder Confidentiality
         * @return object / Throw Error
         */
        foldersByConfidentiality(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractTypeId": "joi.string().required().label('icontract-lable-25__')",
                        "contractCategoryId": "joi.string().allow('').required().label('icontract-lable-66__')",
                        "contractOwner": "joi.string().required().label('icontract-lable-67__')",
                        "searchable": "joi.boolean().required().label('icontract-lable-68__')",
                        "confidential": "joi.boolean().required().label('icontract-lable-69__')",

                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/repository/getfoldersbyconfidentiality`;
                    http.post(url, 'foldersByConfidentiality', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {

                            const responseSchema = { "type": "array", "properties": { "value": { "type": "string" }, "id": { "type": "string" }, "resourceKey": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };


    }
    return Repository;
};