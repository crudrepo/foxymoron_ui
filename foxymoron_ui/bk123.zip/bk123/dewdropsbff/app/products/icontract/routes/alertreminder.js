"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/alertReminders/list:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get alert Paginated List API
    *     operationId: alert List
    *     description: Get alert Paginated List API
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get alert Paginated List API
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "alertreminder.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/{contract_Id}/getAlertDateCondition:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Alert Date Condition
    *     operationId: getAlertDateCondition
    *     description: Get Alert Date Condition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contract_Id
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAlertDateCondition: {
        pre: null,
        process: "alertreminder.getAlertDateCondition",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/{alert_Id}:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete the Alert
    *     operationId: deleteAlert
    *     description: Delete the Alert
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: alert_Id
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: provide the contract ID and Alert ID to delete alert
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                            
    *     required: [contractId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "alertreminder.destroy",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/{alert_Id}/getAlertRecipients:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Alert Recipients by alert id 
    *     operationId: getAlertRecipients
    *     description: Get Alert Recipients by alert id 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: alert_Id
    *         description: Provide a alert ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAlertRecipients: {
        pre: null,
        process: "alertreminder.getAlertRecipients",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * definitions:
    *   saveAlert:
    *     properties:
    *       contractId:
    *         type: string                                            
    *       contractValue:
    *         type: string                                            
    *       alertId:
    *         type: string                                            
    *       title:
    *         type: string                                            
    *       description:
    *         type: string                                            
    *       priority:
    *         type: string                                            
    *       metadataScreenLabel:
    *         type: string                                            
    *       metaData:
    *         type: string                                            
    *       metadataDate:
    *         type: string                                            
    *       alertOn:
    *         type: boolean                                            
    *       selfAlert:
    *         type: boolean                                            
    *       alertType:
    *         type: number                                            
    *       alertBefore:
    *         type: number                                            
    *       alertOnDate:
    *         type: string                                            
    *       repeatDuration:
    *         type: number                                            
    *       quick:
    *         type: boolean                                            
    *       internalUsers:
    *         type: object                                            
    *       isOutLookEventSend:
    *         type: boolean                                            
    *       internalUserList:
    *         type: array                                            
    *         items:
    *             type: object
    *             properties:
    *               externalUserEmailId:
    *                   type: string
    *               externalUserName:
    *                   type: string
    *               userID:
    *                   type: number
    *               ownerID:
    *                   type: number
    *       externalUsers:
    *         type: array                                            
    *         items:
    *             type: object
    *             properties:
    *               externalUserEmailId:
    *                   type: string
    *               externalUserName:
    *                   type: string
    *               ownerID:
    *                   type: number
    *               userID:
    *                   type: number
    *       alertConditionDto:
    *         type: object                                            
    *         properties:
    *           alertConditionId:
    *               type: string
    *           numberOfRepetitions:
    *               type: number
    *           numberOfRepetitionFixed:
    *               type: number
    *           utilizationValue:
    *               type: number
    *           lastTriggeredUtilizedValue:
    *               type: number
    *           firstTriggeredUtilizedValue:
    *               type: number
    *           repeatByUtilization:
    *               type: number
    *           repeatByDays:
    *               type: number
    *           alertConditionType:
    *               type: string
    *           metadataName:
    *               type: string
    *           utilizationUnit:
    *               type: string
    *           dateCondition:
    *               type: string
    *           alertDate:
    *               type: string
    */
    /**
    * @swagger
    * /a/icontract/alertReminders:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: create Alert
    *     operationId: createAlert
    *     description: create Alert
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: create Alert
    *         in: body
    *         required: true
    *         schema:
    *             allOf:
    *               - $ref: '#/definitions/saveAlert' 
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "alertreminder.create",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders:
    *   put:
    *     tags:
    *       - IContract API
    *     summary: Update Alert
    *     operationId: UpdateAlert
    *     description: Update Alert
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update Alert
    *         in: body
    *         required: true
    *         schema:
    *             allOf:
    *               - $ref: '#/definitions/saveAlert' 
    *     responses:
    *       200:
    *         description: successful operation
    */
   update: {
        pre: null,
        process: "alertreminder.update",
        post: null,
        method: 'POST'
    }
};