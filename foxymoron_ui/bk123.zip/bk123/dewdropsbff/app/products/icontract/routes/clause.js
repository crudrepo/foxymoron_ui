"use strict";
module.exports = {
    /**
     * @swagger
     * /a/icontract/clauses/list:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get Clause Paginated List API
     *     operationId: Clause List
     *     description: Get Clause Paginated List API
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Get Clause Paginated List API
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    getList: {
        pre: null,
        process: "clause.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/clauses/updateStatus:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Change the status of contracts (For clause Listing)
    *     operationId: changeStatus
    *     description: Change the status of contracts (For clause Listing)
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Change the status of contracts - Allowed Value for status ('Active','Inactive')
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             status:
    *               type: string
    *           required: [ids,status]
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateStatus: {
        pre: null,
        process: "clause.updateStatus",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/clauses/downloadDocuments:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Download Documents (For clause Contract ID's)
    *     operationId: downloadDocuments
    *     description: Download Documents (For clause Contract ID's)
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Download Documents (For clause Contract ID's) - Allowed Value for mode ('Single','Bulk')
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadDocuments: {
        pre: null,
        process: "clause.downloadDocuments",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/clauses/suggestedAction:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Suggested Actions for Clause listing page
    *     operationId: suggestedAction
    *     description: Suggested Actions for Clause listing page
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Suggested Actions for Clause listing page
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
   suggestedAction: {
        pre: null,
        process: "clause.suggestedAction",
        post: null,
        method: 'POST'
    }
};