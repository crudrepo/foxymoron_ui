"use strict";

module.exports = (parentClass)=> {
  class GuidedForm extends parentClass {
      getList(request, input, callback){
          try {
            let validationUtility = super.utils.validationUtility(request);                    
            validationUtility.addCommonSchema('pagination'); 
            let schema = {
                "name" : "joi.string().alphanum().min(3).max(30).label('eproc-lable-4__')"
            };
            validationUtility.addInternalSchema(schema);    
            let result = validationUtility.validate(request.body);   
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            } else {   
            let http =  new (super.httpService)(request);
            const eProcURL = request.productsURL.eProc["soa"];
            let url = eProcURL+'/guidedRequisitions/search';
            const requestData = {
              maxRows: request.body.perPageRecords,  
              pageNumber: request.body.pageNo,
              name: request.body.name
            };
            http.post(url, 'guidedRequisitions', requestData, (error, result) => {
              if(error){
                callback(error, null);
              }else if(result){
                callback(null, request, result.guidedForms);
              }
            });
          }
        } catch (error) {
          callback(error, null);
        }
      }
  }
  return GuidedForm;
}