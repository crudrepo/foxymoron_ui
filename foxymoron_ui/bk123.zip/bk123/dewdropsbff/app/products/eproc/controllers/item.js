/**
 * Item Controller
 *
 * @description :: Get the Items list and particular item details.
 */
"use strict";
module.exports = (parentClass)=> {
  class Item extends parentClass { 
      /**
       * Get the list of items.
      */    
      getList(request, input, callback){
          try {
              const validationUtility = super.utils.validationUtility(request);                    
              validationUtility.addCommonSchema('pagination'); 
              const schema = {
                    "ids": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required()"
              };
              validationUtility.addInternalSchema(schema);    
              const result = validationUtility.validate(request.body);   
              if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
              } else {
                  const http =  new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.entityList);
                  const eProcURL = request.productsURL.eProc["soa"];
                  const url = eProcURL+'/items';
                  http.post(url, 'catalogItems', request.body, (error, result) => {
                    if(error){
                      callback(error, null);
                    }else if(result){
                      let responseSchema = {"type":"array","properties":{"enitity.name":{"type":"string","key":"name"},"enitity.supplierName":{"type":"string","key":"supplierName"},"enitity.description":{"type":"string","key":"description"},"enitity.price":{"type":"number","key":"price"},"enitity['price']":{"type":"currency","key":"priceFormat"},"enitity.imageURL":{"type":"string","key":"imageURL"},"enitity.createdOn":{"type":"none","key":"createdOn"},"enitity.modifiedOn":{"type":"none","key":"modifiedOn"},"quantity":{"type":"number"},"enitity.currency":{"type":"string","key":"currency"},"enitity.totalAmount":{"type":"number","key":"totalAmount"},"enitity['totalAmount']":{"type":"currency","key":"totalAmountFormat"},"enitity.taxAmount":{"type":"currency","key":"taxAmount"},"enitity['taxAmount']":{"type":"number","key":"taxAmountFormat"},"enitity.itemId":{"type":"string","key":"itemId"},"enitity.uom":{"type":"string","key":"uom"},"enitity.leadTime":{"type":"number","key":"leadTime"},"enitity.outOfStock":{"type":"string","key":"outOfStock"},"enitity.contractNo":{"type":"string","key":"contractNo"},"enitity.itemType":{"type":"string","key":"itemType"},"enitity.manufacturerName":{"type":"string","key":"manufacturerName"},"enitity.manufacturerPartId":{"type":"string","key":"manufacturerPartId"},"enitity.categoryName":{"type":"string","key":"categoryName"},"enitity.unsspscCode":{"type":"string","key":"unsspscCode"},"enitity.supplierContact":{"type":"string","key":"supplierContact"},"enitity.ERPPartId":{"type":"string","key":"supplierPartId"},"attachment":{"type":"array","properties":{"name":{"type":"string"},"path":{"type":"filePathEncode"},"fileSize":{"type":"string"},"comments":{"type":"string"}}}}};
                      let output =  (new (super.responseHandler)(request, result, responseSchema)).execute();
                      return callback(null, request,  output);
                    }
                  });
              }
          } catch (error) {
            callback(error, null);
          }
      }

      /**
       * Get the particular item details
      */    
      getDetails(request, input, callback) {
          try {
              let validationUtility = super.utils.validationUtility(request);                    
              validationUtility.addCommonSchema('pagination'); 
              let schema = {
                    "item_Id": "joi.string().required().label('eproc-lable-3__')"
              };
              validationUtility.addInternalSchema(schema);    
              let result = validationUtility.validate({"item_Id": request.params.item_Id});   
              if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
              } else {
                  let http =  new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.entityList);
                  const eProcURL = request.productsURL.eProc["soa"];
                  const url = eProcURL+'/items';
                  let requestData = {
                    "ids":[request.params.item_Id]
                  }
                  http.post(url, 'catalogItems', requestData, (error, result) => {
                    if(error){
                      callback(error, null);
                    }else {
                      result.data = (super.lodash.isEmpty(result.data)===false && super.lodash.isArray(result.data))?result.data[0]:{};                      
                      let responseSchema = {"type":"object","properties":{"enitity.name":{"type":"string","key":"name"},"enitity.supplierName":{"type":"string","key":"supplierName"},"enitity.description":{"type":"string","key":"description"},"enitity.price":{"type":"number","key":"price"},"enitity['price']":{"type":"currency","key":"priceFormat"},"enitity.imageURL":{"type":"string","key":"imageURL"},"enitity.createdOn":{"type":"none","key":"createdOn"},"enitity.modifiedOn":{"type":"none","key":"modifiedOn"},"quantity":{"type":"number"},"enitity.currency":{"type":"string","key":"currency"},"enitity.totalAmount":{"type":"number","key":"totalAmount"},"enitity['totalAmount']":{"type":"currency","key":"totalAmountFormat"},"enitity.taxAmount":{"type":"number","key":"taxAmount"},"enitity['taxAmount']":{"type":"currency","key":"taxAmountFormat"},"enitity.itemId":{"type":"string","key":"itemId"},"enitity.uom":{"type":"string","key":"uom"},"enitity.scopeId":{"type":"string","key":"scopeId"},"enitity.catalogId":{"type":"string","key":"catalogId"},"enitity.catalogVersion":{"type":"string","key":"catalogVersion"},"enitity.catalogItemId":{"type":"string","key":"catalogItemId"},"enitity.supplierId":{"type":"string","key":"supplierId"},"enitity.supplierPartId":{"type":"string","key":"supplierPartId"},"enitity.supplierAuxPartId":{"type":"string","key":"supplierAuxPartId"},"enitity.supplierAddressId":{"type":"string","key":"supplierAddressId"},"enitity.supplierAddress":{"type":"string","key":"supplierAddress"},"enitity.supplierContact":{"type":"string","key":"supplierContact"},"enitity.supplierEmail":{"type":"string","key":"supplierEmail"},"enitity.supplierContactType":{"type":"number","key":"supplierContactType"},"enitity.supplierPhone":{"type":"string","key":"supplierPhone"},"enitity.supplierOtherDetails":{"type":"string","key":"supplierOtherDetails"},"enitity.manufacturerPartId":{"type":"string","key":"manufacturerPartId"},"enitity.manufacturerName":{"type":"string","key":"manufacturerName"},"enitity.marketPrice":{"type":"number","key":"marketPrice"},"enitity['marketPrice']":{"type":"currency","key":"marketPriceFormat"},"enitity.leadTime":{"type":"number","key":"leadTime"},"enitity.categoryCode":{"type":"string","key":"categoryCode"},"enitity.categoryName":{"type":"string","key":"categoryName"},"enitity.unsspscCode":{"type":"string","key":"unsspscCode"},"enitity.unsspscName":{"type":"string","key":"unsspscName"},"enitity.supplierProductURL":{"type":"string","key":"supplierProductURL"},"enitity.manufacturerProductURL":{"type":"string","key":"manufacturerProductURL"},"enitity.thumbnailURL":{"type":"string","key":"thumbnailURL"},"enitity.sourceRefNo":{"type":"string","key":"sourceRefNo"},"enitity.contractNo":{"type":"string","key":"contractNo"},"enitity.contractId":{"type":"string","key":"contractId"},"enitity.sourceType":{"type":"number","key":"sourceType"},"enitity.itemType":{"type":"number","key":"itemType"},"enitity.receiptType":{"type":"number","key":"receiptType"},"enitity.contractType":{"type":"number","key":"contractType"},"enitity.error":{"type":"boolean","key":"error"},"enitity.warning":{"type":"boolean","key":"warning"},"enitity.active":{"type":"boolean","key":"active"},"enitity.hidden":{"type":"boolean","key":"hidden"},"enitity.activity":{"type":"number","key":"activity"},"enitity.greenItem":{"type":"boolean","key":"greenItem"},"enitity.preferredItem":{"type":"boolean","key":"preferredItem"},"enitity.validFrom":{"type":"string","key":"validFrom"},"enitity.validTo":{"type":"string","key":"validTo"},"enitity.publishedOn":{"type":"number","key":"publishedOn"},"enitity.attachments":{"type":"string","key":"attachments"},"enitity.outOfStock":{"type":"boolean","key":"outOfStock"},"enitity.systemAttributes":{"type":"string","key":"systemAttributes"},"enitity.itemAttributes":{"type":"none","key":"itemAttributes"},"enitity.itemErrors":{"type":"string","key":"itemErrors"},"enitity.sourcingStatus":{"type":"number","key":"sourcingStatus"},"enitity.externalId":{"type":"string","key":"externalId"},"enitity.origin":{"type":"number","key":"origin"},"enitity.contracted":{"type":"boolean","key":"contracted"},"enitity.parentItemId":{"type":"string","key":"parentItemId"},"enitity.updated":{"type":"boolean","key":"updated"},"enitity.assetNumberRequired":{"type":"boolean","key":"assetNumberRequired"},"enitity.itemTaxes":{"type":"none","key":"itemTaxes"},"enitity.warehouseCode":{"type":"string","key":"warehouseCode"},"enitity.parentCatalogItemId":{"type":"string","key":"parentCatalogItemId"},"enitity.supplierCurrency":{"type":"string","key":"supplierCurrency"},"enitity.supplierLeadTime":{"type":"number","key":"supplierLeadTime"},"enitity.supplierStatus":{"type":"string","key":"supplierStatus"},"enitity.supplierCount":{"type":"string","key":"supplierCount"},"enitity.priceValidFrom":{"type":"string","key":"priceValidFrom"},"enitity.priceValidTo":{"type":"string","key":"priceValidTo"},"enitity.attachmentsStr":{"type":"string","key":"attachmentsStr"},"enitity.itemAttributesStr":{"type":"string","key":"itemAttributesStr"},"enitity.systemAttributesStr":{"type":"string","key":"systemAttributesStr"},"attachments":{"type":"none"},"attachment":{"type":"array","properties":{}}}};
                      let output =  (new (super.responseHandler)(request, result, responseSchema));
                      output.addCommonSchema('attachments', output.responseSchema.properties.attachment.properties);
                      return callback(null, request,  output.execute());
                    }
                  });
              }
          } catch (error) {
            callback(error, null);
          }
      };

      /**
      * Description : This method will validate the items before addign into cart.
      */
      validate(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray'); 
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 6);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/items/validate';
                    http.post(url, 'validateItems', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"array","properties":{"itemId":{"type":"string"},"active":{"type":"boolean"}}},
                                  output =  (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request,  output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
      /**
        * @Method Name : getPreviouslyUsedList
        *
        * @Description : Filter the items in PreviouslyUsedList
        * @return object / Throw Error
        */
       getPreviouslyUsedList(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request);
            validationUtility.addCommonSchema('pagination');
            validationUtility.addCommonSchema('sort'); 
            validationUtility.addCommonSchema('criteriaGroup');
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/previouslyUsed/items/filter';
                http.post(url, 'favItemFilter', request.body, (error, result) => {
                    if (error) {
                        callback(error, null);
                    } else {
                        let responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{}}}},
                         output =  (new (super.responseHandler)(request, result, responseSchema)); 
                       // using fav-item as previously used and filter items have same schema
                        output.addCommonSchema('favourite-item', output.responseSchema.properties.records.properties);
                        output.addCommonSchema('pagination', output.responseSchema.properties);                               
                        let schemaRes = output.execute(); 
                        return callback(null, request, schemaRes);
                    }
                });
            }
        } catch (error) {
            callback(error, null);
        }
    };

      
  }
  return Item;
};

