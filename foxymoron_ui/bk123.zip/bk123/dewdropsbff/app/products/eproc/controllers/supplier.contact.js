/**
 * Supplier.Contact Controller
 *
 * @description :: Provides Supplier Contact related crud operations
 */

"use strict";
module.exports = (parentClass) => {
    class SupplierContact extends parentClass {
        /**
         * Get the particular Supplier Contact details
        */
        getList(request, input, callback) {
            try {
                request.body.supplierId = (request.params.supplier_Id) ? request.params.supplier_Id.toString() : null;
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "supplierId": "joi.string().required().label('eproc-lable-123__')",
                        "addressId": "joi.string().label('eproc-lable-127__')",
                        "referConfig": "joi.boolean().required().label('eproc-lable-355__')",
                        "contactType": "joi.string().label('eproc-lable-131__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity, super.appConstant.resHandler.entityList),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/supplier/contact/list';
                    http.post(url, 'getSupplierContactDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                                const responseSchema = { "type": "array", "properties": { "supplierContactId": { "type": "string" }, "supplierId": { "type": "string" }, "addressId": { "type": "string" }, "contactType": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "title": { "type": "string" }, "email": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "cell": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return SupplierContact;
}