/**
 * TenatConfig Controller
 *
 * @description :: Provides tenant config details
 */

module.exports = (parentClass) => {

    class Config extends parentClass {

        getDetailsByLevel(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);      
                const schema = {
                    "configKeys" : "joi.array().items(joi.string().label('eproc-lable-53__')).unique().allow(null).label('eproc-lable-53__')",
                    "configLevel": "joi.string().required().label('eproc-lable-54__')",
                    "regionCode": "joi.string().allow('').label('eproc-lable-55__')",
                    "companyCode": "joi.string().when('configLevel', { is: joi.string().valid('company', 'business unit', 'location').insensitive(), then: joi.required(), otherwise : joi.optional()}).label('eproc-lable-56__')",
                    "businessUnitCode": "joi.string().when('configLevel', {is: joi.string().valid('business unit', 'location').insensitive(), then: joi.required(), otherwise : joi.optional()}).label('eproc-lable-57__')",
                    "locationCode": "joi.string().when('configLevel', { is: joi.string().valid('location').insensitive(), then: joi.required(), otherwise : joi.optional()}).label('eproc-lable-58__')"
                };
                validationUtility.addInternalSchema(schema); 
                const result = validationUtility.validate(request.body);   
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const output = {};
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL + '/config/eprocConfigByLevel';
                    http.post(url, 'getDetailsByLevel', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            if(!super.lodash.isEmpty(result.data.eProcConfig)){
                                return callback(null, request, { "data": result.data.eProcConfig });
                            }else{
                                const errorMsg = new (super.customError)('dd-common-error-1', "AppError");               
                                output.errors = errorMsg;
                                output.data = {};
                                return callback(null, request, output);
                            }                
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        doEvaluateIntegrationProfile(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "entity": "joi.string().required().label('eproc-lable-440__')",
                        "companyCode": "joi.string().allow(['',null]).label('eproc-lable-56__')",
                        "businessUnitCode": "joi.string().allow(['',null]).label('eproc-lable-57__')",
                        "locationCode": "joi.string().allow(['',null]).label('eproc-lable-58__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/config/evaluateIntegrationProfile';
                    http.post(url, 'doEvaluateProfile', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"tenantId":{"type":"string"},"profileId":{"type":"string"},"companyCode":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"entity":{"type":"string"},"targetSystem":{"type":"string"},"toUrl":{"type":"string"}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    }
    return Config;
}