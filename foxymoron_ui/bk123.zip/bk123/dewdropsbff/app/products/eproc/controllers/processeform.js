/**
 * processeForm Controller
 *
 * @description :: It deals with processeForm related operations.
 */
"use strict";

module.exports = (parentClass) => {

    class Processform extends parentClass {

        /**
        * Evaluate the processeForm
        */
        evaluate(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "type": "joi.number().required().label('eproc-lable-81__')",
                        "processCode": "joi.string().required().label('eproc-lable-201__')",
                        "purchaseType": "joi.string().allow('').label('eproc-lable-199__')",
                        "purchaseTypeCode": "joi.string().allow('').label('eproc-lable-200__')",
                        "companyCode": "joi.string().required().label('eproc-lable-28__')",
                        "businessUnitCode": "joi.string().required().label('eproc-lable-29__')",
                        "locationCode": "joi.string().required().label('eproc-lable-30__')",
                        "regions":  "joi.array().items(joi.string().allow('').label('eproc-lable-198__')).unique().label('eproc-lable-198__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/processEform/evaluate';
                    http.post(url, 'evaluateprocessForm', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"array"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"version":{"type":"number"},"processEformId":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"processCodes":{"type":"array"},"type":{"type":"number"},"dynamicFormId":{"type":"string"},"updated":{"type":"boolean"},"parentProcessEformId":{"type":"string"},"errorReasonsStr":{"type":"string"}}},
                                  output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                            return callback(null, request, output);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
    }
    return Processform;
};