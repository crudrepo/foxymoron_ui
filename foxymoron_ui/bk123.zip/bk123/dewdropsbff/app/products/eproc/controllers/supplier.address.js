/**
 * Supplier.Address Controller
 *
 * @description :: Provides Supplier Address related crud operations
 */

"use strict";
module.exports = (parentClass) => {
    class SupplierAddress extends parentClass {
        /**
         * Get the particular Supplier address details
        */
        getRecords(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    supplier_Id = (request.params.supplier_Id) ? request.params.supplier_Id.toString() : null,
                    schema = {
                        "supplier_Id": "joi.string().required().label('eproc-lable-123__')"
                    };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({ "supplier_Id": supplier_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/supplier/addresses/' + request.params.supplier_Id;
                    http.get(url, 'getSupplierAddressDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return SupplierAddress;
}