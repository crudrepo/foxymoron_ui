/**
 * Punchout Controller
 *
 * @description :: Provides Punchout related operations
 */

"use strict";
module.exports = (parentClass)=> {
  class Punchout extends parentClass {
      /* Fetch the punchout items */
      getList(request, input, callback) {
            try {                
                const validationUtility = super.utils.validationUtility(request);         
                validationUtility.addCommonSchema('pagination'); 
                validationUtility.addCommonSchema('sort');              
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const eProcURL = request.productsURL.eProc["soa"];
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter); 
                    const url = eProcURL+'/punchouts/filter';       
                    http.post(url, 'getPunchout', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else if(result){  
                            let responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"enitity.createdOn":{"type":"none","key":"createdOn"},"enitity.favourite":{"type":"boolean","key":"favourite"},"enitity.modifiedOn":{"type":"none","key":"modifiedOn"},"enitity.supplierId":{"type":"number","key":"supplierId"},"enitity.supplierName":{"type":"string","key":"supplierName"},"enitity.punchoutId":{"type":"string","key":"punchoutId"},"enitity.name":{"type":"string","key":"name"},"enitity.statusText":{"type":"i18n","key":"statusText"},"attachment":{"type":"array","properties":{"name":{"type":"string"},"path":{"type":"filePathEncode"},"fileSize":{"type":"string"},"comments":{"type":"string"}}}}}}};
                            let output =  (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : addToCart
        *
        * @Description : Add punchOut items to card
        * @return object / Throw Error
        */

        addToCart(request, input, callback) {
            try { 
                const validationUtility = super.utils.validationUtility(request),               
                schema = {
                    "punchoutId": "joi.string().required().label('eproc-lable-379__')", 
                    "cartItems": "joi.array().items(joi.object().keys({item:joi.object().keys({itemId: joi.string().required().label('eproc-lable-2__'), price: joi.number().label('eproc-lable-138__') }).required().label('eproc-lable-208__'),quantity:joi.number().required().label('eproc-lable-1__'),assetNumberRequired:joi.boolean().label('eproc-lable-350__'),itemTaxes:joi.array().items(joi.object().keys({tenantId: joi.string().label('eproc-lable-382__'),type: joi.string().label('eproc-lable-81__'),name: joi.string().label('eproc-lable-4__'),rate: joi.number().required().label('eproc-lable-352__'),compound: joi.boolean().label('eproc-lable-353__')})).label('eproc-lable-177__'),internalComment:joi.string().label('eproc-lable-337__'),supplierComment:joi.string().label('eproc-lable-44__'),requiredByDate:joi.string().label('eproc-lable-381__'),attachmentIds:joi.array().label('eproc-lable-194__')})).unique().required().label('eproc-lable-380__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                        http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity), 
                        url = eProcURL+'/punchouts/items/addToCart';       
                    http.post(url, 'addPunchoutitemsToCart', request.body, (error, result) => {
                        if(error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "date" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output =  (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : setupRequest
        *
        * @Description : Setup punchOut request
        * @return object / Throw Error
        */

        setupRequest(request, input, callback) {
            try { 
                const validationUtility = super.utils.validationUtility(request),               
                schema = {
                    "punchoutId": "joi.string().required().label('eproc-lable-379__')", 
                    "updatePunchoutStatus": "joi.boolean().required().label('eproc-lable-383__')", 
                    "mode": "joi.string().required().label('eproc-lable-384__')", 
                    "returnURL": "joi.string().required().label('eproc-lable-385__')", 
                    "itemIds": "joi.array().label('eproc-lable-15__')", 
                    "quantity": "joi.array().label('eproc-lable-1__')", 
                    "emailAddress": "joi.string().label('eproc-lable-386__')", 
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                        http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity), 
                        url = eProcURL+'/punchouts/setup/request';       
                    http.post(url, 'setupPunchOutRequest', request.body, (error, result) => {
                        if(error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "httpUrl": { "type": "string" }, "httpMethod": { "type": "string" }, "httpRequestParam": { "type": "none" }, "httpRequestContent": { "type": "none" }, "httpResponseContent": { "type": "string" },"httpErrorCode": { "type": "none" },"resultObject": { "type": "none" },"resultErrorCode": { "type": "none" } } },
                                output =  (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : validateItems
        *
        * @Description : Validate a punchOut Item(s)
        * @return object / Throw Error
        */

        validateItems(request, input, callback) {
            try { 
                const validationUtility = super.utils.validationUtility(request),               
                schema = {
                    "punchoutId": "joi.string().required().label('eproc-lable-379__')", 
                    "itemIds": "joi.array().required().label('eproc-lable-15__')", 
                    "categoryCodes": "joi.array().required().label('eproc-lable-59__')" 
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                        http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity), 
                        url = eProcURL+'/punchouts/items/validate';       
                    http.post(url, 'validatePunchOutItems', request.body, (error, result) => {
                        if(error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "errors": { "type": "none" }, "error": { "type": "boolean" } }},
                            output =  (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : addItems
        *
        * @Description : Add PunchOut Item(s)
        * @return object / Throw Error
        */

        addItems(request, input, callback) {
            try { 
                const validationUtility = super.utils.validationUtility(request),               
                schema = {
                    "punchoutId": "joi.string().required().label('eproc-lable-379__')", 
                    "testPunchout": "joi.boolean().label('eproc-lable-387__')", 
                    "params": "joi.object().required().label('eproc-lable-388__')" 
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                        http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity), 
                        url = eProcURL+'/punchouts/items/add';       
                    http.post(url, 'addPunchOutItems', request.body, (error, result) => {
                        if(error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "boolean" },"createdOn": { "type": "string" },"totalAmount": { "type": "number" },"currency": { "type": "string" },"cartItems": { "type": "array","properties":{"item.name":{"type":"string","key":"name"},"item.supplierName":{"type":"string","key":"supplierName"},"item.description":{"type":"string","key":"description"},"item.price":{"type":"number","key":"price"},"item['price']":{"type":"currency","key":"priceFormat"},"item.imageURL":{"type":"string","key":"imageURL"},"item.createdOn":{"type":"none","key":"createdOn"},"item.modifiedOn":{"type":"none","key":"modifiedOn"},"quantity":{"type":"number"},"item.currency":{"type":"string","key":"currency"},"item.totalAmount":{"type":"number","key":"totalAmount"},"item['totalAmount']":{"type":"currency","key":"totalAmountFormat"},"item.taxAmount":{"type":"number","key":"taxAmount"},"item['taxAmount']":{"type":"currency","key":"taxAmountFormat"},"item.itemId":{"type":"string","key":"itemId"},"item.uom":{"type":"string","key":"uom"},"item.scopeId":{"type":"string","key":"scopeId"},"item.catalogId":{"type":"string","key":"catalogId"},"item.catalogVersion":{"type":"string","key":"catalogVersion"},"item.catalogItemId":{"type":"string","key":"catalogItemId"},"item.supplierId":{"type":"string","key":"supplierId"},"item.supplierPartId":{"type":"string","key":"supplierPartId"},"item.supplierAuxPartId":{"type":"string","key":"supplierAuxPartId"},"item.supplierAddressId":{"type":"string","key":"supplierAddressId"},"item.supplierAddress":{"type":"string","key":"supplierAddress"},"item.supplierContact":{"type":"string","key":"supplierContact"},"item.supplierEmail":{"type":"string","key":"supplierEmail"},"item.supplierContactType":{"type":"number","key":"supplierContactType"},"item.supplierPhone":{"type":"string","key":"supplierPhone"},"item.supplierOtherDetails":{"type":"string","key":"supplierOtherDetails"},"item.manufacturerPartId":{"type":"string","key":"manufacturerPartId"},"item.manufacturerName":{"type":"string","key":"manufacturerName"},"item.marketPrice":{"type":"number","key":"marketPrice"},"item['marketPrice']":{"type":"currency","key":"marketPriceFormat"},"item.leadTime":{"type":"number","key":"leadTime"},"item.categoryCode":{"type":"string","key":"categoryCode"},"item.categoryName":{"type":"string","key":"categoryName"},"item.unsspscCode":{"type":"string","key":"unsspscCode"},"item.unsspscName":{"type":"string","key":"unsspscName"},"item.supplierProductURL":{"type":"string","key":"supplierProductURL"},"item.manufacturerProductURL":{"type":"string","key":"manufacturerProductURL"},"item.thumbnailURL":{"type":"string","key":"thumbnailURL"},"item.sourceRefNo":{"type":"string","key":"sourceRefNo"},"item.contractNo":{"type":"string","key":"contractNo"},"item.contractId":{"type":"string","key":"contractId"},"item.sourceType":{"type":"number","key":"sourceType"},"item.itemType":{"type":"number","key":"itemType"},"item.receiptType":{"type":"number","key":"receiptType"},"item.contractType":{"type":"number","key":"contractType"},"item.error":{"type":"boolean","key":"error"},"item.warning":{"type":"boolean","key":"warning"},"item.active":{"type":"boolean","key":"active"},"item.hidden":{"type":"boolean","key":"hidden"},"item.activity":{"type":"number","key":"activity"},"item.greenItem":{"type":"boolean","key":"greenItem"},"item.preferredItem":{"type":"boolean","key":"preferredItem"},"item.validFrom":{"type":"string","key":"validFrom"},"item.validTo":{"type":"string","key":"validTo"},"item.publishedOn":{"type":"none","key":"publishedOn"},"item.attachments":{"type":"none","key":"attachments"},"item.outOfStock":{"type":"boolean","key":"outOfStock"},"item.systemAttributes":{"type":"none","key":"systemAttributes"},"item.itemAttributes":{"type":"none","key":"itemAttributes"},"item.itemErrors":{"type":"string","key":"itemErrors"},"item.sourcingStatus":{"type":"number","key":"sourcingStatus"},"item.externalId":{"type":"string","key":"externalId"},"item.origin":{"type":"number","key":"origin"},"item.contracted":{"type":"boolean","key":"contracted"},"item.parentItemId":{"type":"string","key":"parentItemId"},"item.updated":{"type":"boolean","key":"updated"},"item.assetNumberRequired":{"type":"boolean","key":"assetNumberRequired"},"itemTaxes":{"type":"number","key":"itemTaxes"},"item.warehouseCode":{"type":"string","key":"warehouseCode"},"item.parentCatalogItemId":{"type":"string","key":"parentCatalogItemId"},"item.supplierCurrency":{"type":"string","key":"supplierCurrency"},"item.supplierLeadTime":{"type":"number","key":"supplierLeadTime"},"item.supplierStatus":{"type":"string","key":"supplierStatus"},"item.supplierCount":{"type":"string","key":"supplierCount"},"item.priceValidFrom":{"type":"string","key":"priceValidFrom"},"item.priceValidTo":{"type":"string","key":"priceValidTo"},"item.attachmentsStr":{"type":"string","key":"attachmentsStr"},"item.itemAttributesStr":{"type":"string","key":"itemAttributesStr"},"item.systemAttributesStr":{"type":"string","key":"systemAttributesStr"},"internalComment":{"type":"string"},"supplierComment":{"type":"string"},"requiredByDate":{"type":"string"},"attachmentIds":{"type":"none"},"assetNumberRequired":{"type":"boolean"}} } }},
                            output =  (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : updateItemClassification
        *
        * @Description : Update Item Classification
        * @return object / Throw Error
        */

        updateItemClassification(request, input, callback) {
            try { 
                const validationUtility = super.utils.validationUtility(request),               
                schema = {
                    "punchoutId": "joi.string().required().label('eproc-lable-379__')", 
                    "itemId": "joi.string().required().label('eproc-lable-2__')", 
                    "catCode": "joi.string().required().label('eproc-lable-393__')" 
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, {"punchoutId": request.params.punchout_Id}));
                if(result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                        http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity), 
                        url = eProcURL+'/punchouts/items/updateClassification';       
                    http.post(url, 'updateItemClassification', request.body, (error, result) => {
                        if(error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": {"id": { "type": "string" },"modifiedBy": { "type": "string" },"modifiedOn": { "type": "date" },"info1": { "type": "string" },"info2": { "type": "string" }}},
                            output =  (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : returnFromPunchout
        *
        * @Description : Return from Supplier site to BFF
        * @return object / Throw Error
        */

        returnFromPunchout(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),               
                schema = {
                    "punchoutId": "joi.string().required().label('eproc-lable-379__')", 
                    "testPunchout": "joi.boolean().label('eproc-lable-387__')", 
                    "params": "joi.object().required().label('eproc-lable-388__')" 
                };
                validationUtility.addInternalSchema(schema);
                const requestData = {
                    "punchoutId": request.params.punchout_Id, 
                    "testPunchout": true
                };
                if(request.body['cxml-urlencoded']) {
                    requestData.params = {};
                    requestData.params['cxml-urlencoded'] = [request.body['cxml-urlencoded']];
                }else{
                     requestData.params = request.body;
                }
                const result = validationUtility.validate(requestData);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    super.lodash.templateSettings.interpolate = /{{([\s\S]+?)}}/g;                    
                    const eProcURL = request.productsURL.eProc["soa"],
                        http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity), 
                        url = eProcURL+'/punchouts/items/add',
                        responseData = {
                            'content-type': "redirect",
                            'URL': '',
                            'statusCode':303
                        }, 
                        webURL = super.utils.stripTrailingSlash(super.settingConfig.WEB_URL),
                        productConstant = super.productConstant(request),
                        redirectErrURL = webURL + productConstant.punchoutErrURL,
                        compileURL = super.lodash.template(webURL + productConstant.punchoutSuccessURL),                        
                        redirectSuccessURL = compileURL({ 'punchout_Id': request.params.punchout_Id });
                    http.post(url, 'addPunchOutItems', requestData, (error, result) => {
                        if(error) {
                            responseData.URL =  redirectErrURL;
                            return callback(null, request, { data: responseData });
                        } else {
                            const tasks = [
                               //Step 1: Store punchout data in redis
                                (methodCallback) => {
                                    super.redisClient.setRedisData(super.utils.prepareRedisKey(request,"punchoutDetails"+"_" + request.params.punchout_Id), result, 600, (err, resp) => {
                                        if(err) {
                                            return methodCallback(err, request, null);
                                        }else{
                                            return methodCallback(null, request, resp);
                                        }
                                    });
                                },
                                //Step 2: Pass the punchout data and mapped the content type
                                (request, input, methodCallback) => { 
                                   return methodCallback(null, request, input);
                                }
                            ];
                            
                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    responseData.URL =  redirectErrURL;
                                    return callback(null, request, { data: responseData });
                                } else {
                                    responseData.URL =  redirectSuccessURL;
                                    return callback(null, request, { data: responseData });
                                }        
                            });                
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : getItems
        *
        * @Description : Get/Fetch the punchout Details
        * @return object / Throw Error
        */

        getItems(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "punchout_Id": "joi.string().required().label('eproc-lable-379__')"
                },
                punchout_Id = request.params.punchout_Id;
                validationUtility.addInternalSchema(schema);    
                const result = validationUtility.validate({"punchout_Id": punchout_Id});  
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                            http = new (super.httpService)(request), 
                            url = eProcURL+'/punchouts/details/'+punchout_Id;
                    const tasks = [
                        //Step 1: call the get punchout details product API 
                        (methodCallback) => {                            
                            http.get(url, 'getPunchoutDetails', (error, result) => {
                                if (error) {
                                    return methodCallback(error, request, null);
                                } else {
                                    return methodCallback(null, request, result);
                                }
                            });
                        },
                        //Step 2: get the punchout data  in redis & merge the product response
                        (request, input, methodCallback) => {
                            super.redisClient.getRedisData(super.utils.prepareRedisKey(request,"punchoutDetails"+"_" + punchout_Id), (err, resp) => {
                                if(err) {
                                    const output = {},
                                    errorMsg = new (super.customError)('dd-common-error-1', "AppError");
                                    output.errors = errorMsg;
                                    output.data = {};
                                    return methodCallback(null, request, output);
                                }else{
                                    const result = JSON.parse(resp);
                                    result.data.details = input.data;
                                    return methodCallback(null, request, result);
                                }
                            });
                        }
                    ];

                    super.async.waterfall(tasks, (error, request, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "boolean" },"createdOn": { "type": "string" },"totalAmount": { "type": "number" },"currency": { "type": "string" },"cartItems": {"type": "none"},"details": {"type": "none"} }},
                            output =  (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
  }
  return Punchout;
};

