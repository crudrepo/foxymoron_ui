/**
 * Eform Controller
 *
 * @description :: Provides Eform related operations
 */

"use strict";
module.exports = (parentClass)=> {
  class Eform extends parentClass {
      /* Fetch the Eform items */
      getCategoryForms(request, input, callback) {
            try {                
                const validationUtility = super.utils.validationUtility(request);         
                validationUtility.addCommonSchema('pagination'); 
                validationUtility.addCommonSchema('sort');              
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const eProcURL = request.productsURL.eProc["soa"];
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter); 
                    const url = eProcURL+'/categoryEforms/filter';         
                    http.post(url, 'getEform', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else if(result){ 
                           
                            let responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"name":{"type":"string"},"favourite":{"type":"boolean"},"displayName":{"type":"string"},"categoryEformId":{"type":"string"},"parentCategoryEformId":{"type":"string"},"description":{"type":"string"},"statusText":{"type":"i18n"},"createdOn":{"type":"none"},"modifiedOn":{"type":"none"},"dynamicFormId":{"type":"string"}}}}};
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());                             
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }

  }
  return Eform;
};

