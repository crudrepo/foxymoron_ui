/**
 * Basket.item Controller
 *
 * @description :: Provides basketItem related crud operations
 */

"use strict";
module.exports = (parentClass)=> {
    class BasketItem extends parentClass {
    /**
        * @Name : update
        * @Description : It is used to update Basket Item
        * @param1 name 
        * @return : object / Throw Error
        */
        update(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "basketId" : "joi.required().label('eproc-lable-27__')",
                    "itemQuantityList" : "joi.array().items({itemId: joi.string().label('eproc-lable-25__'), itemQuantity: joi.number().label('eproc-lable-38__')}).required().label('eproc-lable-25__')",
                    "removingItemIDs" : "joi.array().items(joi.string().label('eproc-lable-25__')).required().unique().label('eproc-lable-25__')"
                }
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, {"basketId": request.params.basket_Id}));
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const requestData = super.lodash.merge(request.body, {"basketId": request.params.basket_Id});
                    const http =  new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL+'/basket/items/update';                
                    http.post(url, 'updateBasketItem', requestData, (error, result) => {                       
                        if(error){
                            return callback(error, null);
                        }else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } }; 
                            if(super.lodash.isEmpty(result.errors)){
                                result.message = "eproc-msg-13";
                            }
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        };
        
        /**
        * @Name : delBasketItems
        * @Description : This method is used to delete the basket items
        * @return : object
        */
        delBasketItems(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request); 
                let schema = {
                    "basket_Id": "joi.string().required().label('eproc-lable-22__')",
                    "itemIds": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required()"
                };
                validationUtility.addInternalSchema(schema);    
                //let result = validationUtility.validate({"basket_Id": request.params.basket_Id, "itemIds":request.body.itemIds});  
                let result = validationUtility.validate(super.lodash.merge(request.body, {"basket_Id": request.params.basket_Id}));
                if (result) {
                  const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                  return callback(errorMsg, null);
                }else{
                    const http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];   
                    const url = eProcURL + '/basket/items/delete';
                    let requestData = {
                        "basketId":request.params.basket_Id,
                        "itemIds":request.body.itemIds
                    };
                    http.post(url, 'deleteBasketItems', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedOn":{"type":"none"},"modifiedBy":{"type":"string"},"info1":{"type":"string"},"info2":{"type":"string"}}};
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());       
                        }
                    });
                }                
            } catch (error) {
              return callback(error, null);
            }
        }        

    }

    return BasketItem;
};