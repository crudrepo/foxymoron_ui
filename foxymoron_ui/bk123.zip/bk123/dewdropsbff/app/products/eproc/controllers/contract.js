"use strict";
module.exports = (parentClass) => {
    class Contract extends parentClass {
        /**
        * @Method Name : getList
        *
        * @Description : Filter the contract List
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "isMapUserInfo": "joi.boolean().label('eproc-lable-441__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/contract/filter';
                    http.post(url, 'contract', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"contractId":{"type":"string"},"contractNumber":{"type":"string"},"title":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"supplierContactId":{"type":"none"},"contractStatus":{"type":"string"},"currency":{"type":"string"},"contractCreatedOn":{"type":"none"},"contractRenewalDate":{"type":"none"},"active":{"type":"boolean"},"createdBy":{"type":"string","key":"createdBy"},"expiryDate":{"type":"none"},"totalAmount":{"type":"number"},"['totalAmount']":{"type":"currency","key":"totalAmountFormatted"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            if (!request.body.isMapUserInfo) {
                                return callback(null, request, output.execute());
                            }
                            const utils = super.utils,
                                lodash = super.lodash,
                                taskResult = { contractList: [], supplierList: [], userList: [], userIds: [], supplierIds: [] };
                            const tasks = [
                                (methodCallback) => {
                                    taskResult.contractList = output.execute();
                                    if (lodash.isArray(taskResult.contractList['data'].records)) {
                                        // Get the unique user ID(S)
                                        taskResult.userIds = taskResult.contractList['data'].records.map((user) => { return user.createdBy; }).filter((elem, index, self) => {
                                            return (elem && index === self.indexOf(elem));
                                        });
                                        taskResult.supplierIds = taskResult.contractList['data'].records.map((supplier) => { return supplier.supplierId; }).filter((elem, index, self) => {
                                            return (elem && index === self.indexOf(elem));
                                        });
                                    }
                                    // Pass the userIds and Collect the user datas
                                    if (!lodash.isEmpty(taskResult.userIds)) {
                                        const tms = new (super.tmsHook({request: request}))();
                                        tms.getUsers(request, taskResult.userIds, (tmsError, tmsResult)=>{
                                            if (tmsError) {
                                                return methodCallback(tmsError, null);
                                            } 
                                            else{
                                                taskResult.userList = tmsResult;
                                                return methodCallback(null, request, taskResult);
                                            }
                                        });
                                    } else {
                                        return methodCallback(null, request, taskResult);
                                    }
                                },
                                (request, input, methodCallback) => {
                                    //merge user details with contract list
                                    if (!lodash.isEmpty(input.userList) && !lodash.isEmpty(input.userIds)) {
                                        const extractProps = utils.extractObjPropsFromArray(input.userList, ["firstName", "lastName", "displayName", "userId"]),
                                            utilsMerge = utils.mergeArray(input.contractList['data'].records, extractProps, ['createdBy', 'userId']);
                                            input.contractList['data'].records = utilsMerge;
                                    }
                                    if (lodash.isEmpty(input.supplierIds)) {
                                        return methodCallback(null, request, input);
                                    }
                                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                                        eProcURL = request.productsURL.eProc["soa"],
                                        url = eProcURL + '/supplier/filter',
                                        requestData = { "perPageRecords": input.supplierIds.length, "pageNo": 1 , "criteriaGroup": { "logicalOperator": "AND", "criteria": [{ "fieldName": "supplierIds", "operation": "IN", "multivalue": input.supplierIds }] } };
                                    http.post(url, 'searchsupplier_mergeContract', requestData, (supplierError, supplierResult) => {
                                        if (supplierError) {
                                            return methodCallback(supplierError, null);
                                        } else {
                                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "supplierId": { "type": "string"}, "name": { "type": "string" } } } } },
                                                output = (new (super.responseHandler)(request, supplierResult, responseSchema));
                                            output.addCommonSchema('pagination', output.responseSchema.properties);
                                            input.supplierList = output.execute();
                                            return methodCallback(null, request, input);
                                        }
                                    });
                                },
                                // Merge the supplier details with contract list
                                (request, input, methodCallback) => {                                   
                                    if (!lodash.isEmpty(input.contractList) && !lodash.isEmpty(input.supplierIds)) {
                                        const extractProps = input.supplierList['data'].records,
                                            utilsMerge = utils.mergeArray(input.contractList['data'].records, extractProps, ['supplierId', 'supplierId']);
                                            input.contractList['data'].records = utilsMerge;
                                    }
                                    return methodCallback(null, request, input);
                                },

                            ];

                            super.async.waterfall(tasks, (waterfallError, request, waterfallResult) => {
                                if (waterfallError) {
                                    return callback(waterfallError, null);
                                } else {
                                    return callback(null, request, waterfallResult.contractList);
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }

        /**
         * @Method Name : getDetails
         * @Description : Filter the contract List
         * @return object / Throw Error
         */
        getDetails(request, input, callback) {
            try {
                const contractId = request.params.contract_Id,
                    validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contract_Id": "joi.required().label('eproc-lable-360__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({
                    "contract_Id": contractId
                });
                if (result) {
                    callback(new (super.customError)(result, 'ValidationError', 3), null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = `${eProcURL}/contract/details/${contractId}`;
                    http.get(url, 'getContractDetails', (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contract": { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "contractId": { "type": "string" }, "contractNumber": { "type": "string" }, "title": { "type": "string" }, "startDate": { "type": "none" }, "expiryDate": { "type": "none" }, "supplierId": { "type": "string" }, "supplierName": { "type": "string" }, "supplierContactId": { "type": "string" }, "category": { "type": "string" }, "businessUnit": { "type": "none" }, "version": { "type": "number" }, "viewUrl": { "type": "string" }, "totalAmount": { "type": "none" }, "['totalAmount']": { "type": "currency", "key": "totalAmountFormatted" }, "utilization": { "type": "number" }, "utilizedAmount": { "type": "none" }, "['utilizedAmount']": { "type": "currency", "key": "utilizedAmountFormatted" }, "reservedAmount": { "type": "none" }, "['reservedAmount']": { "type": "currency", "key": "reservedAmountFormatted" }, "currency": { "type": "string" }, "ownerId": { "type": "string" }, "ownerName": { "type": "string" }, "contractStatus": { "type": "string" }, "contractCreatedOn": { "type": "none" }, "contractRenewalDate": { "type": "none" }, "region": { "type": "string" }, "type": { "type": "string" }, "subType": { "type": "string" }, "heirarchyStatus": { "type": "string" }, "folder": { "type": "string" }, "confidential": { "type": "boolean" }, "searchable": { "type": "boolean" }, "autoRenewable": { "type": "boolean" }, "autoRenewalNoticeDays": { "type": "string" }, "autoRenewalNoticeMonths": { "type": "string" }, "autoRenewalLimitCount": { "type": "string" }, "paymentTerm": { "type": "string" }, "stageName": { "type": "string" }, "archived": { "type": "boolean" }, "checkedOut": { "type": "boolean" }, "active": { "type": "boolean" }, "errorReasonsStr": { "type": "string" } } }, "contractItems": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "itemId": { "type": "string" }, "contractID": { "type": "string" }, "contractNumber": { "type": "string" }, "lineItemNumber": { "type": "string" }, "itemNumber": { "type": "string" }, "cost": { "type": "number" }, "supplierId": { "type": "string" }, "supplierName": { "type": "string" }, "contractedQuantity": { "type": "number" }, "uom": { "type": "string" }, "currency": { "type": "string" }, "category": { "type": "string" }, "categoryName": { "type": "string" }, "catalogId": { "type": "string" }, "errorReasonsStr": { "type": "string" } } }, "contractDocuments": { "type": "array", "properties": { "contractId": { "type": "string" }, "documentName": { "type": "string" }, "documentType": { "type": "string" }, "description": { "type": "string" }, "fileName": { "type": "string" }, "uploadedBy": { "type": "string" }, "uploadedOn": { "type": "none" }, "fileId": { "type": "string" }, "downloadUrl": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }
    }

    return Contract;
}