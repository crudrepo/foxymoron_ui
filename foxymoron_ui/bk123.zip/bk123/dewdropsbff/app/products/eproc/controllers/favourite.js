"use strict";
module.exports = (parentClass)=> {
    class Favourite extends parentClass{ 

        /**
        * @Method Name : getList
        *
        * @Description : Filter the items in favourite
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort'); 
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                       eProcURL = request.productsURL.eProc["soa"],
                       url = eProcURL + '/favourites/items/filter';
                    http.post(url, 'favItemFilter', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            let responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{}}}},
                            output =  (new (super.responseHandler)(request, result, responseSchema)); 
                            output.addCommonSchema('favourite-item', output.responseSchema.properties.records.properties);
                            output.addCommonSchema('attachments', output.responseSchema.properties.records.properties.attachments.properties);
                            output.addCommonSchema('pagination', output.responseSchema.properties);                               
                            let schemaRes = output.execute(); 
                            return callback(null, request, schemaRes);
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

       /**
        * @Method Name : destroy
        *
        * @Description : Delete the items from favourite. \n [Note: Allowed values for the property entityType : BASKET, CATALOG, PUNCHOUT, CATEGORY_EFORM, CATALOG_ITEM, FREE_TEXT_ITEM] 
        * @return object / Throw Error
        */

        destroy(request, input, callback){
          try {
              const validationUtility = super.utils.validationUtility(request);
              const schema = {
                "entityType": "joi.string().required().label('eproc-lable-356__')",
                "entityIds" :  "joi.array().items(joi.string().required().label('eproc-lable-357__')).required().unique().label('eproc-lable-357__')"
            };
              validationUtility.addInternalSchema(schema);    
              const result = validationUtility.validate(request.body);   
              if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
              } else {
                  const http = new (super.httpService)(request);
                  const eProcURL = request.productsURL.eProc["soa"];
                  const url = eProcURL+'/favourites/remove';
                  http.post(url, 'DeleteFavouriteItems', request.body, (error, result) => {
                    if(error){
                      callback(error, null);
                    }else if(result){
                        const message = {description: "eproc-msg-14"};
                        if(!super.lodash.isEmpty(result.data.id)){
                            result.message = [message];              
                        }
                      let responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedOn":{"type":"none"},"modifiedBy":{"type":"string"},"info1":{"type":"string"},"info2":{"type":"string"}}};
                      const output = (new (super.responseHandler)(request, result, responseSchema));
                      return callback(null, request,  output.execute());
                    }
                  });
              }
          } catch (error) {
            callback(error, null);
          }
      }

      /**
        * @Name : create
        * @Description : It is used to add Items in favourite list.\n [Note: Allowed values for the property entityType : BASKET, CATALOG, PUNCHOUT, CATEGORY_EFORM, CATALOG_ITEM, FREE_TEXT_ITEM] 
        * @return : object / Throw Error
        */
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "entityType": "joi.string().required().label('eproc-lable-356__')",
                    "entityIds" :  "joi.array().items(joi.string().required().label('eproc-lable-357__')).required().unique().label('eproc-lable-357__')"
                }
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                   
                    const http = new (super.httpService)(request); 
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL+'/favourites/add';                
                    http.post(url, 'addFavouriteItem', request.body, (error, result) => {                       
                        if(error){
                            return callback(error, null);
                        }else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } }; 
                            if(super.lodash.isEmpty(result.data.id)){
                                result.message = "eproc-msg-12";
                            }
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        };

    };
    return Favourite;
};