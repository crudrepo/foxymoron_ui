/**
 * Budget Controller
 *
 * @description :: It's used to get the Budget list.
 */

"use strict";
module.exports = (parentClass) => {
    class Budget extends parentClass {
        /**
          * Get the Budget list.
        */
        getList(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const eProcURL = request.productsURL.eProc["soa"];
                    let url = eProcURL + '/budget/allowed/filter';

                    http.post(url, 'getBudgetList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "createdOn": { "type": "date" }, "modifiedOn": { "type": "date" }, "tenantId": { "type": "string" }, "budgetLineId": { "type": "string" }, "name": { "type": "string" }, "budgetId": { "type": "string" }, "code": { "type": "string" }, "ownerUserId": { "type": "string" }, "businessUnitCode": { "type": "string" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "plannedAmount": { "type": "currency" }, "reservedAmount": { "type": "currency" }, "costCenterCode": { "type": "string" }, "designationCode": { "type": "string" }, "departmentCode": { "type": "string" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                            return callback(null, request, output);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : getDetails
        * @Description : Fetch/Get Budget Details
        * @return object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "budgetId":  "joi.required().label('eproc-lable-197__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "budgetId": request.params.budget_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/budget/' + request.params.budget_Id;
                    http.get(url, 'budgetDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let utils = super.utils,
                            lodash = super.lodash,
                            userIds = [];
                            if(!lodash.isEmpty(result['data'])) {
                                userIds.push(result['data']['ownerUserId']);
                            }
                            const tasks = [
                                // Pass the userIds and Collect the user datas
                                (methodCallback) => {
                                    if(!lodash.isEmpty(userIds)) {
                                        const tms = new (super.tmsHook({request: request}))();
                                        tms.getUsers(request, userIds, methodCallback);
                                    }else{
                                        return methodCallback(null, request, []);
                                    }
                                },
                                // Merge the user datas and Product results
                                (request, input, methodCallback) => {
                                   if(!lodash.isEmpty(input)) {
                                        let extractProps = utils.extractObjPropsFromArray(input, ["firstName","lastName","displayName","userId"]);
                                        let mergeDatas = utils.mergeArray([result['data']], extractProps, ['ownerUserId','userId']);
                                        result['data'] = mergeDatas[0]; 
                                   }
                                   return methodCallback(null, request, result);
                                }
                            ];
                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    const responseSchema = {"type":"object","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"version":{"type":"number"},"budgetId":{"type":"string"},"budgetPeriodId":{"type":"string"},"companyCode":{"type":"string"},"currency":{"type":"string"},"ownerUserId":{"type":"object","key":"ownerUser","properties":{"firstName":{"type":"string"},"lastName":{"type":"string"},"displayName":{"type":"string"},"userId":{"type":"string","key":"ownerUserId"}}},"name":{"type":"string"},"description":{"type":"string"},"startDate":{"type":"none"},"endDate":{"type":"none"},"plannedAmount":{"type":"currency"},"reservedAmount":{"type":"currency"},"utilizedAmount":{"type":"currency"},"budgetDimensions":{"type":"none"},"settings":{"type":"object","properties":{"SHOW_APPROVER":{"type":"boolean","key":"approver"},"SHOW_REQUESTER":{"type":"boolean","key":"requester"},"TOLLERANCE_AMOUNT":{"type":"currency","key":"tolleranceAmount"}}},"statusText":{"type":"i18n"}}},
                                    output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                                    return callback(null, request, output);    
                                }        
                            });             
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : getOptimumBudgetLine
        * @Description : Fetch/Get the Optimum Budget Line
        * @return Array / Throw Error
        */
        getOptimumBudgetLine(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/budget/optimumBudgetLines/filter';

                    http.post(url, 'getOptimumBudgetLine', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": {"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"status":{"type":"number"},"statusComments":{"type":"none"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"none"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"version":{"type":"number"},"budgetLineId":{"type":"string"},"budgetId":{"type":"string"},"externalId":{"type":"string"},"code":{"type":"string"},"name":{"type":"string"},"ownerUserId":{"type":"string"},"plannedAmount":{"type":"currency"},"reservedAmount":{"type":"currency"},"utilizedAmount":{"type":"currency"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"costCenterCode":{"type":"string"},"designationCode":{"type":"string"},"departmentCode":{"type":"string"},"projectCode":{"type":"string"},"generalLedgerCode":{"type":"string"},"categoryCode":{"type":"string"},"settings":{"type":"none"},"settingsStr":{"type":"string"},"errorReasonsStr":{"type":"string"}} } } },
                            output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                            return callback(null, request, output);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    }
    return Budget;
};

