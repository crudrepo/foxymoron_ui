"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/eproc/users/getDeliveryUsers:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get DeliveryTo User List
    *     operationId: getDeliveryToUser
    *     description: Get DeliveryTo User List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the DeliveryTo User List(based on pagination and serach criteria).
    *         in: body
    *         required: true
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getDeliveryUsers: {
        pre: null,
        process: "user.getDeliveryUsers",
        post: null,
        method: 'POST'
    },

  /**
   * @swagger
   * /a/eproc/users/{id}:
   *   get:
   *     tags:
   *       - Eproc API
   *     summary: Get the deliveryTo user details
   *     operationId: getDeliveryToUserDetails
   *     description: Fetch the deliveryTo user details
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: id
   *         description: Provide a user ID.
   *         in: path
   *         required: true
   *         type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getDetails:{
    pre: null,
    process: "user.getDetails",
    post: null,
    method: 'GET'
  },

  /**
   * @swagger
   * /a/eproc/users/{id}/getScope:
   *   get:
   *     tags:
   *       - Eproc API
   *     summary: Get the user scope details
   *     operationId: getUserScope
   *     description: Fetch the user scope details
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: id
   *         description: Provide a request user ID.
   *         in: path
   *         required: true
   *         type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getScope:{
    pre: null,
    process: "user.getScope",
    post: null,
    method: 'GET'
  },


  /**
    * @swagger
    * /a/eproc/users/{id}/getBuyingUnit:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get Buying Unit Details
    *     operationId: getBuyingUnit
    *     description: Get Buying Unit Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: id
    *         description: Provide a request user ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getBuyingUnit: {
        pre: null,
        process: "user.getBuyingUnit",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/users/{id}/getDefaultAddress:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get Default Address
    *     operationId: defaultAddress
    *     description: Get user default address
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: id
    *         description: Provide a request user ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDefaultAddress:{
        pre: null,
        process: "user.getDefaultAddress",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/users/getBehalfUsers:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Behalf Users
    *     operationId: behalfuserList
    *     description: Get the Behalf User List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the behalf User List(based on pagination and serach criteria).
    *         in: body
    *         required: true
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getBehalfUsers: {
        pre: null,
        process: "user.getBehalfUsers",
        post: null,
        method: 'POST'
    },
    
   /**
   * @swagger
   * /a/eproc/users/getDetailsByIds:
   *   post:
   *     tags:
   *       - Eproc API
   *     summary: Get users details 
   *     operationId: getUsersDetails
   *     description: Fetch users details
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Fetch Users details(based on user id).
   *         in: body
   *         required: true
   *         schema:
   *            properties:
   *              userIds:
   *                type: array 
   *                items:
   *                  type: string
   *     responses:
   *       200:
   *         description: successful operation
   */

  getDetailsByIds:{
    pre: null,
    process: "user.getDetailsByIds",
    post: null,
    method: 'POST'
  },

  /**
    * @swagger
    * /a/eproc/users/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the users list
    *     operationId: getUsersList
    *     description: Get the users list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the users list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "user.getList",
        post: null,
        method: 'POST'
    },

  /**
    * @swagger
    * /a/eproc/users/selectableUser:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the selectableUser list
    *     operationId: getselectableUserList
    *     description: Get the selectableUser list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the selectableUser list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    selectableUser: {
        pre: null,
        process: "user.selectableUser",
        post: null,
        method: 'POST'
    },
    

    
  /**
    * @swagger
    * /a/eproc/users/getEprocUserConfig:
   *   post:
   *     tags:
   *       - Eproc API
   *     summary: Get User Config 
   *     operationId: getEprocUserConfig
   *     description: Fetch User Configuration
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Fetch Users Configuration.
   *         in: body
   *         required: true
   *         schema:
   *            properties:
   *              configUserId:
   *                 type: string
   *              configTenantId:
   *                 type: string
   *              configKeys:
   *                 type: array
   *                 items:
   *                  type: string
   *     responses:
   *       200:
   *         description: successful operation
    */
   getEprocUserConfig: {
    pre: null,
    process: "user.getEprocUserConfig",
    post: null,
    method: 'POST'
},

    
  /**
    * @swagger
    * /a/eproc/users/updateEprocUserConfig:
   *   post:
   *     tags:
   *       - Eproc API
   *     summary:  Update User Configuration 
   *     operationId: updateUsersConfiguration
   *     description:  Update User Configuration
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Update User Configuration.
   *         in: body
   *         required: true
   *         schema:
   *            properties:
   *              configTenantId:
   *                 type: string
   *              configUserId:
   *                  type: string
   *              reassignPending:
   *                  type : boolean
   *                  default: false
   *              EPROC_APPROVAL_DELEGATION:
   *                  type : string
   *           
   *     responses:
   *       200:
   *         description: successful operation
    */
   updateEprocUserConfig: {
    pre: null,
    process: "user.updateEprocUserConfig",
    post: null,
    method: 'POST'
}
};