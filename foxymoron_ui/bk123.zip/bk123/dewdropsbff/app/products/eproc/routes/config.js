"use strict";

module.exports = {

    /**
   * @swagger
   * /a/eproc/configs/getDetailsByLevel:
   *   post:
   *     tags:
   *       - Eproc API
   *     summary: Get configuration details by level
   *     operationId: getDetailsByLevel
   *     description: Fetch configuration details by level
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Get configuration details by level. Config Level is (1.Tenant, 2.Company, 3.Business_Unit, 4.Location )
   *         in: body
   *         required: true
   *         schema:
   *             properties:
   *               configKeys:
   *                 type: array
   *                 items:
   *                   type: string
   *               configLevel:
   *                 type: string
   *               regionCode:
   *                 type: string
   *               companyCode:
   *                 type: string
   *               businessUnitCode:
   *                 type: string
   *               locationCode:
   *                 type: string
   *             required: [configLevel]
   *     responses:
   *       200:
   *         description: successful operation
   */

    getDetailsByLevel: {
        pre: null,
        process: "config.getDetailsByLevel",
        post: null,
        method: 'POST'
    },

     /**
	* @swagger
	* /a/eproc/configs/doEvaluateIntegrationProfile:
	*   post:
	*     tags:
	*       - Eproc API
	*     summary: Get configuration details by evaluated integration profile
	*     operationId: evaluateIntegrationProfile
	*     description: Fetch configuration details by evaluated integration profile
	*     produces:
	*       - application/json
    *     parameters:
    *       - name: body
    *         description: Get configuration details by evaluated integration profile
	*         in: body
    *         required: true
    *         schema:
    *             properties:
    *               entity:
	*                 type: string
    *               companyCode:
	*                 type: string
    *               businessUnitCode:
	*                 type: string
    *               locationCode:
	*                 type: string
    *             required: [entity]
	*     responses:
	*       200:
	*         description: successful operation
    */
    
   doEvaluateIntegrationProfile: {
        pre: null,
        process: "config.doEvaluateIntegrationProfile",
        post: null,
        method: 'POST'
    }
}