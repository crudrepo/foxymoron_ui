"use strict";

module.exports = {

    /**
    * @swagger
    * definitions:
    *   createBasket:
    *     properties:
    *       name:
    *         type: string
    *     required: [name]
    */

    /**
    * @swagger
    * definitions:
    *   basketItems:
    *     properties:
    *       itemId:
    *         type: string
    *       itemQuantity:
    *          type: integer
    *     required: [itemId, itemQuantity]
    */

    /**
    * @swagger
    * definitions:
    *   createBasketDefinition:
    *     properties:
    *       basket:
    *         type: object
    *         $ref: '#/definitions/createBasket'
    *       basketItems:
    *           type: array
    *           items:
    *             type: object
    *             $ref: '#/definitions/basketItems'
    *     required: [basket]
    */

    /**
    * @swagger
    * /a/eproc/baskets:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Create a Basket
    *     operationId: createBasket
    *     description: Create a Basket
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create a Basket and add Items (optional)
    *         in: body
    *         required: true
    *         schema:
    *           type: object
    *           $ref: '#/definitions/createBasketDefinition'
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "basket.create",
        post: null,
        method: 'POST'
    },


    /**
     * @swagger
     * definitions:
     *   updateBasket:
     *     properties:
     *       name:
     *         type: string
     *       basketId:
     *          type: string
     *     required: [name , basketId]
     */

    /**
    * @swagger
    * definitions:
    *   updateBasketDefinition:
    *     properties:
    *       basket:
    *         type: object
    *         $ref: '#/definitions/updateBasket'
    *       basketItems:
    *           type: array
    *           items:
    *             type: object
    *             $ref: '#/definitions/basketItems'
    *     required: [basket]
    */

    /**
    * @swagger
    * /a/eproc/baskets:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update an existing Basket
    *     operationId: updateBasket
    *     description: Update an existing Basket
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update an existing Basket and add Items (optional)
    *         in: body
    *         required: true
    *         schema:
    *           type: object
    *           $ref: '#/definitions/updateBasketDefinition'
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "basket.update",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/eproc/baskets/{basket_Id}:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary: Delete Basket
    *     operationId: deleteBasket
    *     description: Delete Basket
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: basket_Id
    *         description: Provide the basketId to delete
    *         required: true
    *         type: integer
    *         in: path
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "basket.destroy",
        post: null,
        method: 'DELETE'
    },

    /**
    * @swagger
    * /a/eproc/baskets/share:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Share Basket
    *     operationId: shareBasket
    *     description: Share Basket
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Share a basket with items to the scope users.
    *         in: body
    *         schema:
    *             properties:
    *               basketId:
    *                 type: string
    *               scopeType:
    *                 type: integer
    *               companyCodes:
    *                 type: array
    *                 items:
    *                   type: string
    *               businessUnitCodes:
    *                 type: array
    *                 items:
    *                   type: string
    *               locationCodes:
    *                 type: array
    *                 items:
    *                   type: string
    *               regionCodes:
    *                 type: array
    *                 items:
    *                   type: string
    *               ouType:
    *                 type: array
    *                 items:
    *                   type: string
    *               deptCodes:
    *                 type: array
    *                 items:
    *                   type: string
    *               shared:
    *                 type: boolean
    *             required: [basketId,scopeType]
    *     responses:
    *       200:
    *         description: successful operation
    */
    share: {
        pre: null,
        process: "basket.share",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/baskets/{basket_Id}:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Fetch/Get a Basket Details
    *     operationId: getBasketDetails
    *     description: Fetch/Get a Basket Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: basket_Id
    *         description: Provide a basket ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */

    getDetails: {
        pre: null,
        process: "basket.getDetails",
        post: null,
        method: 'GET'
    },

    /**
      * @swagger
      * /a/eproc/baskets/list:
      *   post:
      *     tags:
      *       - Eproc API
      *     summary: Get the baskets list
      *     operationId: getBaskets
      *     description: Get the baskets list
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: body
      *         description: Fetch the baskets list ( Based on those options filter, sorting & pagination ).
      *         in: body
      *         schema:
      *           allOf:
      *             - $ref: '#/definitions/pagination'
      *             - $ref: '#/definitions/criteriaGroup'
      *             - $ref: '#/definitions/sort'
      *     responses:
      *       200:
      *         description: successful operation
      */
    getList: {
        pre: null,
        process: "basket.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/baskets/getOrganizationScope:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the basket Organization Scope
    *     operationId: getOrganizationScope
    *     description: Get the basket Organization Scope
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the basket Organization Scope.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               basketId:
    *                 type: string
    *               shareType:
    *                 type: integer
    *             required: [basketId, shareType]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getOrganizationScope: {
        pre: null,
        process: "basket.getOrganizationScope",
        post: null,
        method: 'POST'
    },


    /**
    * @swagger
    * /a/eproc/baskets/{basket_Id}/addToCart:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add a basket to cart
    *     operationId: addBasketToCart
    *     description: Add a Basket to cart
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: basket_Id
    *         description: Provide the basketId to add item(s) to cart
    *         required: true
    *         type: integer
    *         in: path
    *     responses:
    *       200:
    *         description: successful operation
    */
    addToCart: {
        pre: null,
        process: "basket.addToCart",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * definitions:
     *   basketItemsValues:
     *     schema:
     *       type: array     
     *       items:
     *         type: object
     *         properties:
     *           basketId:
     *             type: string
     *           itemId:
     *             type: string
     *           itemQuantity:
     *             type: integer
     *         required: [itemId, itemQuantity]
     */

    /**
     * @swagger
     * definitions:
     *   basketValues:
     *     required: [currency]
     *     properties:
     *       basketId:
     *          type: string 
     *       name:
     *          type: string
     *       currency:
     *          type: string
     */

    /**
    * @swagger
    * /a/eproc/baskets/addDetails:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add(virtual/item master) item to basket
    *     description: Add(virtual/item master) item to basket
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add(virtual/item master) item to basket.
    *         in: body
    *         required: true
    *         schema: 
    *           properties:
    *             item:
    *               schema:
    *                $ref: '#/definitions/otherItemDetails'
    *             basket:
    *               schema:
    *                $ref: '#/definitions/basketValues'
    *             basketItems:
    *               schema:
    *                $ref: '#/definitions/basketItemsValues'
    *     responses:
    *       200:
    *         description: successful operation
    */
    addDetails: {
        pre: null,
        process: "basket.addDetails",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * /a/eproc/baskets/getItemsList:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get Basket Items List
     *     operationId: getItemsList
     *     description: Get Basket Items List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch the Basket Items (based on those options filter, sorting & pagination)..
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    getItemsList: {
        pre: null,
        process: "basket.getItemsList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/baskets/{basket_Id}/addGuidedItemToBasket:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add a guided items basket to cart
    *     operationId: addGuidedItemToBasket
    *     description: Add guided items to a basket
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: basket_Id
    *         description: Provide the basketId to add Guided item(s) to it
    *         required: true
    *         type: integer
    *         in: path
    *       - name: body
    *         description: Add Guided Procurement items to the existing Basket
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/addGuidedItemsToCart'
    *     responses:
    *       200:
    *         description: successful operation
    */
    addGuidedItemToBasket: {
        pre: null,
        process: "basket.addGuidedItemToBasket",
        post: null,
        method: 'POST'
    },

};
