"use strict";

module.exports = { 

    /**
    * @swagger
    * /a/eproc/flexiforms/{dynamicForm_Id}/updateDynamicInstanceCOA:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update a dynamic Instance COA
    *     operationId: updateDynamicInstanceCOA
    *     description: Update a dynamic Instance COA
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: dynamicForm_Id
    *         description: Provide a Form ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Update a dynamic Instance COA
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           dynamicInstanceId:
    *            type: string
    *           processCode:
    *            type: string
    *           formInstance:
    *             type: object
    *           extraParams:
    *            type: object
    *            properties:
    *             quantity:
    *              type: integer
    *             totalAmount:
    *              type: number
    *              format: double
    *             purchaseType:
    *              type: string
    *             company:
    *              type: string
    *             businessUnit:
    *              type: string
    *             location:
    *              type: string 
    *             category:
    *              type: string 
    *             userId:
    *              type: string 
    *             scopeType:
    *              type: string 
    *             scopeId:
    *              type: string 
    *           skipValidation:
    *            type: boolean
    *            default: true
    *          required: [processCode,formInstance]
    *               
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateDynamicInstanceCOA: {
        pre: null,
        process: "flexiform.updateDynamicInstanceCOA",
        post: null,
        method: 'PUT'
    },

        /**
    * @swagger
    * /a/eproc/flexiforms/{dynamicForm_Id}/updateDynamicInstance:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update a dynamic Instance
    *     operationId: updateDynamicInstance
    *     description: Update a dynamic Instance
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: dynamicForm_Id
    *         description: Provide a Form ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Update a dynamic Instance
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           dynamicInstanceId:
    *            type: string
    *           processCode:
    *            type: string
    *           formInstance:
    *             type: object
    *          required: [processCode,formInstance]
    *               
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateDynamicInstance: {
        pre: null,
        process: "flexiform.updateDynamicInstance",
        post: null,
        method: 'PUT'
    }
    
};