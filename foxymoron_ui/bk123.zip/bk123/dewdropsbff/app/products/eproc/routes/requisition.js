"use strict";

module.exports = { 
    
  /**
    * @swagger
    * definitions:
    *   updateRequisition:
    *      properties:
	*         name:
	*           type: string
	*         behalfUserId:
    *           type: string
	*         supplierComments:
    *           type: string
	*         urgent:
	*           type: boolean
	*         retrospectivePurchase:
	*           type: boolean
	*         linkedPurchaseOrderNo:
    *           type: string
    *         currency:
    *           type: string
    *         modifiedOn:
    *           type: integer
    *         buyingJustification:
    *           type: string
    *         deliverTo:
    *           type: string
    *         shipToCodeType:
    *           type: integer
    *         shipToCode:
    *           type: string
    *         billToCode:
    *           type: string
    *         invoiceToCode:
    *           type: string
    *         companyCode:
    *           type: string
    *         businessUnitCode:
    *           type: string
    *         locationCode:
    *           type: string
    *         paymentId:
    *           type: string
    *         paymentMethod:
    *           type: integer
    */

    /**
    * @swagger
    * definitions:
    *   guidedRequisitions:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *         guidedRequisitionId:
    *           type: string
	*         categoryEformId:
    *           type: string
	*         dynamicFormId:
    *           type: string
	*         dynamicInstanceId:
    *           type: string
	*         categoryCode:
    *           type: string
	*         itemId:
    *           type: string
	*         itemQuantity:
    *           type: integer
	*         status:
    *           type: integer
	*         quickSourceId:
    *           type: string
	*         quickSourceItemId:
    *           type: string
    */

    /**
    * @swagger
    * definitions:
    *   guidedSuppliers:
    *     type: array
    *     items:
    *       type: object
    *       properties:
	*         supplierId:
	*           type: string
	*         supplierType:
    *           type: integer
	*         name:
    *           type: string
	*         location:
    *           type: string
	*         addressDetails:
    *           type: string
	*         contactPerson:
    *           type: string
	*         contactPersonType:
    *           type: integer
	*         email:
    *           type: string
	*         phone:
    *           type: string
	*         fax:
    *           type: string
	*         website:
    *           type: string
	*         description:
    *           type: string
	*         contractOrderId:
    *           type: string
	*         contractOrderNumber:
    *           type: string
	*         contractOrderType:
    *           type: integer
	*         referenceId:
    *           type: string
    */

    /**
    * @swagger
    * definitions:
    *   createRequisition:
    *      properties:
    *         requisitionId:
    *           type: string
    *         parentRequisitionId:
    *           type: string
    *         referenceRequisitionId:
    *           type: string
    *         requisitionNo:
    *           type: string
    *         name:
    *           type: string
    *         urgent:
    *           type: boolean
    *         behalfUserId:
    *           type: string
    *         department:
    *           type: string
    *         buyingJustification:
    *           type: string
    *         supplierComments:
    *           type: string
    *         companyCode:
    *           type: string
    *         businessUnitCode:
    *           type: string
    *         locationCode:
    *           type: string
    *         modifiedOn:
    *           type: integer
    *           format: int64
    *         baseCurrency:
    *           type: string
    *         baseExchangeRate:
    *           type: number
    *           format: double
    *         baseTotal:
    *           type: number
    *           format: double
    *         guided:
    *           type: boolean
	*         purchaseTypeString:
    *           type: string
    *         purchaseTypeCode:
    *           type: string
    *         submittedOn:
    *           type: integer
    *           format: int64
    *         approvedOn:
    *           type: integer
    *           format: int64
    *         receivedOn:
    *           type: integer
    *           format: int64
    *         closedOn:
    *           type: integer
    *           format: int64
    *         resubmitionCount:
    *           type: integer
    *         avgOrderTime:
    *           type: integer
    *           format: int64
    *         totalItems:
    *           type: integer
    *         currency:
    *           type: string
    *         totalAmount:
    *           type: number
    *           format: double
	*         sendPOToSupplier:
    *           type: boolean
    *         approvedAmount:
    *           type: number
    *           format: double
    *         buyerAmount:
    *           type: number
    *           format: double
    *         amountToBeApproved:
    *           type: number
    *           format: double
    *         workflowId:
    *             type: string
    *         workflowInstanceId:
    *             type: string
    *         rejectedItemCount:
    *             type: integer
    *         processEformId:
    *           type: string
    *         dynamicFormId:
    *           type: string
    *         dynamicInstanceId:
    *           type: string
    *         flexibleAccountingFormId:
    *           type: string
    *         flexibleAccountingInstanceId:
    *           type: string
    *         flexibleAccountingVersion:
    *           type: string
    *         shipToCodeType:
    *           type: integer
    *         shipToCode:
    *           type: string
    *         billToCode:
    *           type: string
    *         invoiceToCode:
    *           type: string
    *         deliverToType:
    *           type: integer
    *         deliverTo:
    *           type: string
    *         deliveryOn:
    *           type: integer
    *           format: int64
    *         paymentMethod:
    *           type: integer
    *         paymentTransactionId:
    *           type: string
    *         paymentId:
    *           type: string
    *         canResubmit:
    *           type: boolean
    *         splitCostingLevel:
    *           type: integer
    *         splitCostingType:
    *           type: integer
    *         requesterAction:
    *           type: integer
    *         orderStatus:
    *           type: integer
    *         receiptStatus:
    *           type: integer
    *         invoiceStatus:
    *           type: integer
    *         retrospectivePurchase:
    *           type: boolean
    *           default: false
    *         utilizeBudget:
    *           type: boolean
    *           default: false
    *         budgetSettingsMap:
    *           type: object
    *         attachmentIds:
    *            type: array
    *            items:
    *             type:string
	*         statusBuyerNegotiated:
    *           type: integer
	*         statusRequesterNegotiated:
    *           type: integer
	*         statusBudgetary:
    *           type: integer
	*         statusNeedAQuote:
    *           type: integer
    *         requisitionType:
    *           type: integer
    *         assignedBuyerType:
    *           type: integer
    *         assignedBuyer:
    *           type: string
    *         assignedBuyers:
    *           type: array
    *           items:
    *             type: object
    *             properties:
	*              assignedBuyer:
	*               type: string
	*              assignedBuyerType:
    *               type: integer
    *              assignedBuyerName:
    *               type: string
    *         linkedPurchaseOrderId:
    *             type: string
	*         linkedPurchaseOrderNo:
    *           type: string
	*         assignedOn:
    *           type: integer
    *           format: int64
	*         origin:
    *           type: integer
	*         externalId:
    *           type: string
    *         assignProject:
    *           type: boolean
    *           default: false
    *         projectSettingStatus:
    *           type: string
    *           default: PROJECT_USER_DECIDE
	*         purchaseTypeSetting:
    *           type: boolean
    *           default: false
	*         ptGLAccountSetting:
    *           type: boolean
    *           default: false
	*         erpId:
    *           type: string
    *         sendToReadyForApproval:
    *           type: boolean
    *           default: false
    *         hasBuyerItem:
    *           type: boolean
    *           default: false
    *         sourcingStatusSettingMap:
    *           type: object
    *           properties:
    *            QUOTED_BY_SUPPLIER:
    *             type: string
    *            ESTIMATED_PRICE:
    *             type: string
    *            NEED_A_QUOTE:
    *             type: string
	*         updatedOn:
    *           type: integer
    *           format: int64
    *         assetCodeSetting:
    *           type: boolean
	*         utilizeContract:
    *           type: string
    *           default: REQUISITION_SUBMIT
	*         transferredTo:
    *           type: string
    *         retrospectiveSendPOSupplier:
    *           type: boolean
    *         retrospectiveLetUserDecide:
    *           type: boolean
    *           default: false
    *         requisitionToExistingPOSetting:
    *           type: boolean
	*         purchaseTypeAtLineLevel:
    *           type: boolean
    *           default: false
    *         allowedBackdateDays:
    *           type: integer
	*         allowedSuggestedSupplier:
    *           type: boolean
    *         approvalIntegrationStatus:
    *           type: integer
    *         externalIntegrationStatus:
    *           type: integer
    *         totalTaxAmount:
    *           type: number
    *           format: double
    *         grossTotalAmount:
    *           type: number
    *           format: double
    *         buyerReviewSettingStatus:
    *           type: boolean
    *         reopenedRequisition:
    *           type: boolean
    *         groupStatus:
    *           type: integer
    *         groupOrderStatus:
    *           type: integer 
    *         groupInvoiceStatus:
    *           type: integer 
    *         groupReceiptStatus:
    *           type: integer 
    *         projectVisibilityRule:
    *           type: string
    *              
    */

	/**
    * @swagger
    * definitions:
    *   requisitionItemGroupsforUpdate:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *          groupId:
    *             type: integer
    *          totalItems:
    *             type: integer
    *          approvedAmount:
    *             type: integer
    *          buyerAmount:
    *             type: integer
    *          requisitionItems:
    *             type: array
    *             items:
    *               type: object
    *               $ref: '#/definitions/requisitionItemsforUpdate'
    */

    /**
    * @swagger
    * definitions:
    *   requisitionItemsforUpdate:
    *       properties:
	*         supplierId:
    *           type: string
	*         groupId:
    *           type: integer
	*         requisitionNo:
    *           type: string
	*         itemId:
    *           type: string
	*         itemQuantity:
    *           type: integer
	*         itemPrice:
    *           type: integer
	*         currency:
    *           type: string
    *         itemTotalPrice:
    *           type: integer
    *         internalComment:
    *           type: string
    *         supplierComment:
    *           type: string
    *         splitDelivery:
    *           type: boolean
    *         splitCostingType:
    *           type: integer
    *         approvedQuantity:
    *           type: integer
    *         assignedBuyers:
    *           type: array
    *           items:
    *             type: object
    *             properties:
	*              assignedBuyer:
	*               type: string
	*              assignedBuyerType:
    *               type: integer
    *              assignedBuyerName:
    *               type: string
    *         taxAmount:
    *           type: integer
    *         itemTaxes:
    *           type: array
    *           items:
    *             type: object
    *             properties:
	*              type:
	*               type: string
	*              name:
    *               type: string
    *              rate:
    *               type: integer
    *         attachmentIds:
    *           type: array
    *           items:
    *             type: string
    */

    	/**
    * @swagger
    * definitions:
    *   requisitionItemGroupsforCreate:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *          requisitionId:
    *             type: string
    *          groupId:
    *             type: integer
    *          totalItems:
    *             type: integer
    *          approvedAmount:
    *             type: integer
    *          buyerAmount:
    *             type: integer
    *          forkingCriteria:
    *             type: string
    *          requisitionType:
    *             type: integer
    *          requesterAction:
    *             type: integer
    *          workflowId:
    *             type: string
    *          linkedPurchaseOrderId:
    *             type: string
    *          linkedPurchaseOrderNo:
    *             type: string
    *          sendToReadyForApproval:
    *             type: boolean
    *          amountToBeApproved:
    *             type: integer
    *          requisitionItems:
    *             type: array
    *             items:
    *               type: object
    *               $ref: '#/definitions/requisitionItemsforCreate'
    */

    /**
    * @swagger
    * definitions:
    *   requisitionItemsforCreate:
    *       properties:
	*         requisitionId:
    *           type: string
	*         groupId:
    *           type: integer
	*         requisitionNo:
    *           type: string
	*         itemId:
    *           type: string
	*         itemQuantity:
    *           type: number
    *           format: double
	*         itemPrice:
    *           type: number
    *           format: double
	*         currency:
    *           type: string
    *         sourcingStatus:
    *           type: integer
    *         sourceType:
    *           type: integer
    *         itemTotalPrice:
    *           type: number
    *           format: double
    *         internalComment:
    *           type: string
    *         supplierComment:
    *           type: string
    *         splitDelivery:
    *           type: boolean
    *         splitCostingType:
    *           type: integer
    *         attachmentIds:
    *           type: array
    *           items:
    *             type: string
    *         approvedQuantity:
    *           type: number
    *           format: double
    *         quickSourceId:
    *           type: string
    *         quickSourceItemId:
    *           type: string
    *         contractNo:
    *           type: string
    *         contractId:
    *           type: string
    *         contractType:
    *           type: integer
    *         orderable:
    *           type: boolean
    *         approvalStatus:
    *           type: integer
    *         buyerAdded:
    *           type: boolean
    *         replacingItemId:
    *           type: string
    *         originalReplacedItemId:
    *           type: string
    *         definitionId:
    *           type: string
    *         assetCode:
    *           type: string
    *         assetCodeType:
    *           type: integer
    *         processEformId:
    *           type: string
    *         dynamicFormId:
    *           type: string
    *         dynamicInstanceId:
    *           type: string
    *         dynamicInstanceVersion:
    *           type: integer
    *         flexibleAccountingFormId:
    *           type: string
    *         flexibleAccountingInstanceId:
    *           type: string
    *         flexibleAccountingVersion:
    *           type: integer
    *         purchaseType:
    *           type: string
    *         purchaseTypeCode:
    *           type: string
    *         lineNo:
    *           type: integer
    *         assetNumberRequired:
    *           type: boolean
    *         assignedBuyers:
    *           type: array
    *           items:
    *             type: object
    *             properties:
	*              assignedBuyer:
	*               type: string
    *              assignedBuyerName:
    *               type: string
    *         assignedOn:
    *           type: integer
    *           format: int64
    *         supplierPreferenceType:
    *           type: integer
    *         itemTaxes:
    *           type: array
    *           items:
    *             type: object
    *             properties:
	*              type:
	*               type: string
	*              name:
    *               type: string
    *              rate:
    *               type: number
    *               format: double
    *              compound:
    *               type: boolean
    *               default: false
    *         taxAmount:
    *           type: number
    *           format: double
    *         status:
    *           type: integer
    *         sendToReadyForApproval:
    *           type: boolean
    *         orderStatus:
    *           type: integer
    *         receiptStatus:
    *           type: integer
    *         invoiceStatus:
    *           type: integer
    *         linkedPurchaseOrderId:
    *           type: string
    *         linkedPurchaseOrderNo:
    *           type: string
    *         receiptType:
    *           type: integer
    *         requestedItemPrice:
    *           type: number
    *           format: double
    */

    /**
    * @swagger
    * definitions:
    *   requisitionDeliveries:
    *     type: array
    *     items:
    *       type: object
    *       properties:
	*         itemId:
    *           type: string
	*         requisitionId:
	*           type: string
	*         lineItemId:
    *           type: string
	*         itemQuantity:
    *           type: number
    *           format: double
	*         approvedQuantity:
    *           type: number
    *           format: double
	*         businessUnitCode:
    *           type: string
	*         locationCode:
    *           type: string
	*         deliverToType:
    *           type: integer
	*         deliverTo:
    *           type: string
	*         deliveryOn:
    *           type: integer
    *           format: int64
    *         deliveryUpto:
    *           type: integer
    *           format: int64
    *         shipToCodeType:
    *           type: integer
    *         shipToCode:
    *           type: string
    *         orderedQuantity:
    *           type: number
    *           format: double
    *         receivedQuantity:
    *           type: number
    *           format: double
    *         invoicedQuantity:
    *           type: number
    *           format: double
    *         assetNumbers:
    *           type: array
    *           items:
    *             type: object
    *             properties:
	*              serialNumber:
    *                type: integer
    *              assetNumber:
    *                 type: string
    *              manufacturerSerialNumber:
    *                 type: string
    *              notes:
    *                 type: string
    */

    /**
    * @swagger
    * definitions:
    *   requisitionCostings:
    *     type: array
    *     items:
    *       type: object
    *       properties:
	*         requisitionId:
	*           type: string
	*         itemId:
	*           type: string
	*         businessUnitCode:
    *           type: string
	*         costCenterCode:
    *           type: string
	*         value:
    *           type: number
    *           format: double
	*         budgetId:
    *           type: string
	*         budgetLineId:
    *           type: string
	*         budgetLineTransactionId:
    *           type: string
	*         budgetBaseValue:
    *           type: number
    *           format: double
	*         projectCode:
	*           type: string
    *         splitValue:
    *           type: number
    *           format: double
    */

    /**
    * @swagger
    * definitions:
    *   requisitionAccountings:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *         requisitionId:
	*           type: string
	*         itemId:
	*           type: string
	*         accountTypeCode:
    *           type: string
	*         generalLedgerCode:
    *           type: string
	*         value:
    *           type: number
    *           format : double
    */

    /**
    * @swagger
    * definitions:
    *   AttachRequisition:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *          attachmentId:
    *             type: string
    *          comments:
    *             type: string
    *          visibility:
    *             type: string
    */

    /**
    * @swagger
    * definitions:
    *   items:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *          itemId:
    *             type: string
    *          name:
    *             type: string
    *          description:
    *             type: string
    *          uom:
    *             type: string
    *          currency:
    *             type: string
    *          price:
    *             type: number
    *             format: double
    *          marketPrice:
    *             type: number
    *             format: double
    *          supplierId:
    *             type: string
    *          supplierPartId:
    *             type: string
    *          manufacturerName:
    *             type: string
    *          manufacturerProductURL:
    *             type: string
    *          manufacturerPartId:
    *             type: string
    *          imageURL:
    *             type: string
    *          thumbnailURL:
    *             type: string
    *          supplierProductURL:
    *             type: string
    *          leadTime:
    *             type: integer
    *          sourceRefNo:
    *             type: string
    *          attachments:
    *             type: array
    *             items:
    *              type: string
    *          itemAttributes:
    *             type: object
    *          supplierAddressId:
    *             type: string
    *          supplierAddress:
    *             type: string
    *          supplierContact:
    *             type: string
    *          supplierPhone:
    *             type: string
    *          supplierOtherDetails:
    *             type: string
    *          supplierContactType:
    *             type: string
    *          supplierEmail:
    *             type: string
    *          supplierName:
    *             type: string
    *          categoryName:
    *             type: string
    *          categoryCode:
    *             type: string
    *          unsspscCode:
    *             type: string
    *          unsspscName:
    *             type: string
    *          greenItem:
    *             type: boolean
    *          preferredItem:
    *             type: boolean
    *          scopeId:
    *             type: string
    *          catalogId:
    *             type: string
    *          catalogVersion:
    *             type: integer
    *          catalogItemId:
    *             type: integer
    *          contractNo:
    *             type: string
    *          contractId:
    *             type: string
    *          itemType:
    *             type: integer
    *          sourceType:
    *             type: integer
    *          receiptType:
    *             type: integer
    *          contractType:
    *             type: integer
    */

    /**
     * @swagger
     * /a/eproc/requisitions/list:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get Requisitions
     *     operationId: getRequisitions
     *     description: Fetch all Requisitions List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch the requisition items(based on those options sorting & pagination).
     *         in: body
     *         required: true
     *         schema:
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort' 
     *     responses:
     *       200:
     *         description: successful operation
     */
    getList: {
        pre: null,
        process: "requisition.getList",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * /a/eproc/requisitions/openprCount:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get Requisitions List With Open PR List
     *     operationId: getOpenRequisitions
     *     description: Fetch all Requisitions List with open PR
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch the requisition items with open PR(based on those options sorting & pagination).
     *         in: body
     *         required: true
     *         schema:
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort' 
     *     responses:
     *       200:
     *         description: successful operation
     */
    openprCount: {
        pre: null,
        process: "requisition.openprCount",
        post: null,
        method: 'POST'
    },
    // /**
    //  * @swagger
    //  * /a/eproc/requisitions/getTableView:
    //  *   get:
    //  *     tags:
    //  *       - Eproc API
    //  *     summary: Get Table View
    //  *     operationId: getRequisitionTableView
    //  *     description: Fetch the Requisition table view setting
    //  *     produces:
    //  *       - application/json
    //  *     responses:
    //  *       200:
    //  *         description: successful operation
    //  */
    /*getTableView: {
        pre: null,
        process: "requisition.getTableView",
        post: null
    },*/
    /**
     * @swagger
     * definitions:
     *   tableViewDefinition:
     *     required: [name, key, isSelected, sequence]
     *     properties:
     *        name:
     *          type: string
     *        key:
     *           type: string
     *        isSelected:
     *           type: boolean
     *        sequence:
     *           type: integer
     */

    /**
     * @swagger
     * definitions:
     *   saveTableView:
     *     required: [columns, rows]
     *     properties:
     *       columns:
     *         schema:
     *           type: array
     *           items:
     *             type: object
     *             $ref: '#/definitions/tableViewDefinition'
     *       rows:
     *         schema:
     *           type: array
     *           items:
     *             type: object
     *             $ref: '#/definitions/tableViewDefinition'
     */
    // /**
    // * @swagger
    // * /a/eproc/requisitions/saveTableView:
    // *   post:
    // *     tags:
    // *       - Eproc API
    // *     summary: Save Table View
    // *     operationId: saveRequisitionTableView
    // *     description: Save the Requisition Table view setting
    // *     produces:
    // *       - application/json
    // *     parameters:
    // *       - name: body
    // *         description: Provide row & column details
    // *         in: body
    // *         required: true
    // *         schema:
    // *           $ref: '#/definitions/saveTableView'
    // *     responses:
    // *       200:
    // *         description: successful operation
    // */
    /*saveTableView: {
        pre: null,
        process: "requisition.saveTableView",
        post: null
    },*/
    // /**
    //  * @swagger
    //  * /a/eproc/requisitions/getFilterData:
    //  *   get:
    //  *     tags:
    //  *       - Eproc API
    //  *     summary: Get Filter Data
    //  *     operationId: getRequisitionFilterData
    //  *     description: Fetch the Requisition table filter data
    //  *     produces:
    //  *       - application/json
    //  *     responses:
    //  *       200:
    //  *         description: successful operation
    //  */   
    /*getFilterData: {
        pre: null,
        process: "requisition.getFilterData",
        post: null
    },*/
    /**
    * @swagger
    * /a/eproc/requisitions/{requisition_Id}:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get Requisition Details
    *     operationId: getRequisitionDetails
    *     description: Fetch a Requisition Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requisition_Id
    *         description: Find a Requisition Details.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "requisition.getDetails",
        post: null,
        method: 'GET'
    },
    
    /**
     * @swagger
     * /a/eproc/requisitions/getDefaultName:
     *   get:
     *     tags:
     *       - Eproc API
     *     summary: Get Requisition Default Name
     *     operationId: getRequisitionDefaultName
     *     description: Fetch the default Requisition Name
     *     produces:
     *       - application/json
     *     responses:
     *       200:
     *         description: successful operation
     */
    getDefaultName: {
        pre: null,
        process: "requisition.getDefaultName",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/{requisition_Id}:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update a requisition
    *     operationId: updateRequisitions
    *     description: Update a requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requisition_Id
    *         description: Provide a requisition ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Update a requisition
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           action:
    *            type: string
    *           role:
    *            type: string
    *            default: REQUESTER
    *           submit:
    *            type: boolean
    *           checkedItemIds:
    *            type: array
    *            items:
    *             type:string
    *           beforeApproval:
    *            type: boolean
    *           forkingRequired:
    *            type: boolean
    *            default: false
    *           changedGroupId:
    *            type: string
    *           guidedRequisitions:
    *             $ref: '#/definitions/guidedRequisitions'
    *           guidedSuppliers:
    *             $ref: '#/definitions/guidedSuppliers'
    *           requisition:
    *             $ref: '#/definitions/createRequisition'
    *           requisitionItemGroups:
    *             $ref: '#/definitions/requisitionItemGroupsforCreate'
    *           requisitionDeliveries:
    *             $ref: '#/definitions/requisitionDeliveries'
    *           requisitionCostings:
    *             $ref: '#/definitions/requisitionCostings'
    *           requisitionAccountings:
    *             $ref: '#/definitions/requisitionAccountings'
    *           items:
    *             $ref: '#/definitions/items'
    *           supportObjects:
    *             type: object
    *           attachmentsDetails:
    *             $ref: '#/definitions/AttachRequisition'
    *               
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "requisition.update",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/eproc/requisitions:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Create a requisition
    *     operationId: createRequisitions
    *     description: Create a requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create a requisition
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           action:
    *            type: string
    *           role:
    *            type: string
    *            default: REQUESTER
    *           submit:
    *            type: boolean
    *           checkedItemIds:
    *            type: array
    *            items:
    *             type:string
    *           beforeApproval:
    *            type: boolean
    *           forkingRequired:
    *            type: boolean
    *            default: false
    *           changedGroupId:
    *            type: string
    *           guidedRequisitions:
    *             $ref: '#/definitions/guidedRequisitions'
    *           guidedSuppliers:
    *             $ref: '#/definitions/guidedSuppliers'
    *           requisition:
    *             $ref: '#/definitions/createRequisition'
    *           requisitionItemGroups:
    *             $ref: '#/definitions/requisitionItemGroupsforCreate'
    *           requisitionDeliveries:
    *             $ref: '#/definitions/requisitionDeliveries'
    *           requisitionCostings:
    *             $ref: '#/definitions/requisitionCostings'
    *           requisitionAccountings:
    *             $ref: '#/definitions/requisitionAccountings'
    *           items:
    *             $ref: '#/definitions/items'
    *           supportObjects:
    *             type: object
    *           attachmentsDetails:
    *             $ref: '#/definitions/AttachRequisition'
    *               
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "requisition.create",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/checkDuplicateName:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: check a duplicate requisition name
    *     operationId: createDuplicateRequisitionName
    *     description: check a duplicate requisition name
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: check a duplicate requisition name
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           requisitionName:
    *            type: string
    *           requisitionId:
    *            type: string
    *          required: [requisitionName, requisitionId]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    checkDuplicateName: {
        pre: null,
        process: "requisition.checkDuplicateName",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/guidedList:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Search Guided Requisition
    *     operationId: searchGuidedRequisition
    *     description: Search Guided Requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search for Guided Requisition ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   guidedList: {
       pre: null,
       process: "requisition.guidedList",
       post: null,
       method: 'POST'
   },

   /**
    * @swagger
    * /a/eproc/requisitions/guidedDetails:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Guided Requisition Details
    *     operationId: guidedrequisitionDetails
    *     description: Get Guided Requisition Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Guided Requisition Details.
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               itemIds:
    *                 type: array
    *                 items:
    *                   type: string
    *           required: [itemIds]
    *     responses:
    *       200:
    *         description: successful operation
    */
    guidedDetails: {
        pre: null,
        process: "requisition.guidedDetails",
        post: null,
        method: 'POST'
    },
    
    /**
    * @swagger
    * /a/eproc/requisitions/getItemsList:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Past Requisitions Items List
    *     operationId:  getItemsList
    *     description:  Get Past Requisitions Items List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the  Past Requisitions items(based on those options filter, sorting & pagination)..
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */    
   getItemsList: {
        pre: null,
        process: "requisition.getItemsList",
        post: null,
        method: 'POST'
   },

    /**
    * @swagger
    *  /a/eproc/requisitions/recall:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: recall a requisition
    *     operationId: recallRequisition
    *     description: recall a requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: recall a requisition
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           requisitionId:
    *            type: string
    *           statusComments:
    *            type: string
    *           groupId:
    *            type: string
    *           roleType:
    *            type: string
    *          required: [requisitionId, statusComments, roleType]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    recall: {
        pre: null,
        process: "requisition.recall",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    *  /a/eproc/requisitions/cancel:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: cancel a requisition
    *     operationId: cancelRequisition
    *     description: cancel a requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: cancel a requisition
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           requisitionId:
    *            type: string
    *           comments:
    *            type: string
    *           groupId:
    *            type: string
    *          required: [requisitionId, comments]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    cancel: {
        pre: null,
        process: "requisition.cancel",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/{requisition_Id}:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary: Delete Requisition
    *     operationId: deleteRequisition
    *     description: Delete Requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requisition_Id
    *         description: Provide the requisitionId to delete
    *         required: true
    *         type: integer
    *         in: path
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy : {  
        pre: null,
        process : "requisition.destroy",
        post: null,
        method: 'DELETE'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/close:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Delete Requisition
    *     operationId: deleteRequisition
    *     description: Delete Requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: cancel a requisition
    *         in: body
    *         required: true
    *         schema:
    *           required: [requisitionId]     
    *           properties:
    *             requisitionId:
    *               type: string
    *             comments:
    *               type: string
    *             groupId:
    *               type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    close : {  
        pre: null,
        process : "requisition.close",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/{requisition_Id}/getRequisitionDetails:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Entity Version Details
    *     operationId: getEntityVersionDetails
    *     description: Get Entity Version Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requisition_Id
    *         description: Provide the requisitionId to get requisition details
    *         required: true
    *         type: integer
    *         in: path
    *       - name: body
    *         description: Get Requisition Details
    *         in: body
    *         required: true
    *         schema:
    *           required: [entityType, version, requireDependent, requireScopeValidation]
    *           properties:
    *             entityType:
    *               type: string
    *             version:
    *               type: string
    *             useSnapshot:
    *               type: boolean
    *             view:
    *               type: boolean
    *             requireDependent:
    *               type: boolean
    *             requireScopeValidation:
    *               type: boolean
    *             validateByScopeOnly:
    *               type: boolean
    *             buyerDesk:
    *               type: boolean
    *     responses:
    *       200:
    *         description: successful operation
    */
    getRequisitionDetails : {  
        pre: null,
        process : "requisition.getRequisitionDetails",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/addAuditTrailComment:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add Audit Trail Comment
    *     operationId: addAuditTrailComment
    *     description: Add Audit Trail Comment
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add Audit Trail Comment
    *         in: body
    *         required: true
    *         schema:
    *           required: [entityType, entityId, version, event]
    *           properties:
    *             entityType:
    *               type: string
    *             entityId:
    *               type: string
    *             parentAuditTrailId:
    *               type: string
    *             version:
    *               type: number
    *             event:
    *               type: string
    *             comments:
    *               type: string
    *             attachmentIds:
    *               type: array
    *               items:
    *                type: string
    *             role:
    *               type: string
    *             toUserId:
    *               type: array
    *               items:
    *                type: string
    *             visibleTo:
    *               type: array
    *               items:
    *                type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    addAuditTrailComment : {  
        pre: null,
        process : "requisition.addAuditTrailComment",
        post: null,
        method: 'POST'
    },

     /**
    * @swagger
    * /a/eproc/requisitions/getAuditTrailDetail:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Audit Trail Detail
    *     operationId: getAuditTrailDetail
    *     description: Get Audit Trail Detail
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Audit Trail Detail
    *         in: body
    *         required: true
    *         schema:
    *           required: [entityType, entityId, entityVersion]
    *           properties:
    *             entityType:
    *               type: string
    *             entityId:
    *               type: string
    *             entityVersion:
    *               type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAuditTrailDetail : {  
        pre: null,
        process : "requisition.getAuditTrailDetail",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/{requisition_Id}/copyRequisition:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Copy Requisition
    *     operationId: copyRequisition
    *     description: Copy Requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requisition_Id
    *         description: Provide the requisitionId to copy the requisition
    *         required: true
    *         type: integer
    *         in: path
    *       - name: body
    *         description: Copy a requisition
    *         in: body
    *         required: true
    *         schema:
    *           required: []     
    *           properties:
    *             includeCartItems:
    *               type: boolean
    *             requireDependent:
    *               type: boolean
    *     responses:
    *       200:
    *         description: successful operation
    */
    copyRequisition: {
        pre: null,
        process: "requisition.copy",
        post: null,
        method: 'POST'
    },

     /**
    * @swagger
    * /a/eproc/requisitions/validateRequisition:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Validate Requisition Details
    *     operationId: validateRequisition
    *     description: Validate Requisition Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Validate Requisition Details
    *         in: body
    *         required: true
    *         schema:
    *           required: [requisitionId, role]
    *           properties:
    *             requisitionId:
    *               type: string
    *             role:
    *               type: string
    *             newItemIds:
    *               type: array
    *               items:
    *                 type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    validateRequisition : {  
        pre: null,
        process : "requisition.validateRequisition",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/validateContractItems:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Validate guided requisitions contract items
    *     operationId: validateContractItems
    *     description: Validate Contract Items
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: validate guided requisitions contract items.
    *         in: body
    *         required: true  
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             properties:
    *               supplierId:
    *                 type: string
    *               contractId:
    *                 type: string
    *               contractNo:
    *                 type: string
    *             required: [supplierId, contractId, contractNo]
    *     responses:
    *       200:
    *         description: successful operation
    */

   validateContractItems: {
        pre: null,
        process: "requisition.validateContractItems",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/validateBPOItems:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: validate guided requisitions BPO items
    *     operationId: validateBPOItems
    *     description: Validate BPO Items
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: validate guided requisitions contract items.
    *         in: body
    *         required: true  
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             properties:
    *               supplierPartId:
    *                 type: string
    *               price:
    *                 type: number
    *               taxAmount:
    *                 type: number
    *               categoryCode:
    *                 type: string
    *               currency:
    *                  type: string
    *               quantity:
    *                 type: number
    *               companyCode:
    *                 type: string
    *               businessUnitCode:
    *                 type: string
    *               locationCode:
    *                 type: string
    *               costCenterCodes:
    *                 type: array  
    *                 items:
    *                   type: string
    *               itemType:
    *                 type: number                    
    *               receivedBy:
    *                 type: number
    *               purchaseOrderDetails:
    *                 type: array
    *                 items:
    *                   type: object
    *                   properties:
    *                     purchaseOrderId:
    *                       type: string
    *                     purchaseOrderNumber:
    *                       type: string
    *                   required: [purchaseOrderId]
    *     responses:
    *       200:
    *         description: successful operation
    */

   validateBPOItems: {
        pre: null,
        process: "requisition.validateBPOItems",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/requisitions/doAssignBuyer:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Update a requisition by assignBuyer
    *     operationId: assignBuyer
    *     description: Update a requisition by assignBuyer
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update a requisition by assignBuyer
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           requisitionId:
    *            type: string
    *           comments:
    *            type: string
    *           requisitionItemId:
    *            type: string
    *           requisitionAssignedBuyers:
    *            type: array
    *            items:
    *               type: object
    *               properties:
    *                 assignedBuyer:
    *                   type: string
    *                 assignedBuyerType:
    *                   type: string
    *                 assignedBuyerName:
    *                   type: string
    *           requisitionRemovedBuyers:
    *            type: array
    *            items:
    *               type: object
    *               properties:
    *                 assignedBuyer:
    *                   type: string
    *                 assignedBuyerType:
    *                   type: string
    *                 assignedBuyerName:
    *                   type: string         
    *     responses:
    *       200:
    *         description: successful operation
    */
   doAssignBuyer: {
        pre: null,
        process: "requisition.doAssignBuyer",
        post: null,
        method: 'POST'
    },
    /**
       * @swagger
       * /a/eproc/requisitions/doReturnRequisition:
       *   post:
       *     tags:
       *       - Eproc API
       *     summary: ReturnRequisition to requisition
       *     operationId: returnRequisition
       *     description: ReturnRequisition to requisition
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: body
       *         description: ReturnRequisition to requisition
       *         in: body
       *         required: true
       *         schema:
       *          properties:
       *           requisitionId:
       *            type: string
       *           returnComments:
       *            type: string
       *           canResubmit:
       *            type: boolean
       *           action:
       *            type: string
       *           groupId:
       *            type: string
       *           itemIds:
       *            type: array
       *            items:
       *             type: string
       *          required: [requisitionId, returnComments, canResubmit]
       *     responses:
       *       200:
       *         description: successful operation
       */
    doReturnRequisition: {
        pre: null,
        process: "requisition.doReturnRequisition",
        post: null,
        method: 'POST'
    },   

   /**
    * @swagger
    * /a/eproc/requisition/doValidateRequisitions:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Validate Requisitions
    *     operationId: doValidateRequisitions
    *     description: Validate Requistions
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: This api is use to validate requisitions
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *           required: [ids]
    *     responses:
    *       200:
    *         description: successful operation
    */
   doValidateRequisitions : {  
        pre: null,
        process : "requisition.doValidateRequisitions",
        post: null,
        method: 'POST'
    },

           /**
    * @swagger
    * /a/eproc/requisition/doForkRequisition:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Fork Requisition
    *     operationId: doForkRequisition
    *     description: Fork Requisition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: This api is use to validate requisitions
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             requisitionDetails	:
    *                 type: object
    *                 properties:
    *                   requisition:
    *                     $ref: '#/definitions/createRequisition'
    *                   requisitionItemGroupsforCreate:
    *                     $ref: '#/definitions/requisitionItemGroupsforCreate'
    *                   requisitionItemGroups:
    *                     $ref: '#/definitions/requisitionItemsforCreate'
    *                   requisitionDeliveries:
    *                     $ref: '#/definitions/requisitionDeliveries'
    *                   requisitionCostings:
    *                     $ref: '#/definitions/requisitionCostings'
    *                   requisitionAccountings:
    *                     $ref: '#/definitions/requisitionAccountings'
    *                   supportObject:
    *                     type: object
    *                   guidedItems:
    *                     type: array
    *                     items:
    *                        type: string
    *             requisitionId	:	
    *              type: string
    *             onChange 	: 	
    *              type: boolean
    *              default: false
    *             roleType	:
    *              type : string 
    *           required: [requisitionId,onChange]  
    *     responses:
    *       200:
    *         description: successful operation
    */
   doForkRequisition : {  
    pre: null,
    process : "requisition.doForkRequisition",
    post: null,
    method: 'POST'
}
};