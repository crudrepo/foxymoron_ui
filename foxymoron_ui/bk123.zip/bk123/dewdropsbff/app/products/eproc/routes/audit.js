"use strict";
module.exports = {
    /**
        * @swagger
        * /a/eproc/audits/list:
        *   post:
        *     tags:
        *       - Eproc API
        *     summary: Get the audits List
        *     operationId: getList
        *     description: Get the audits List
        *     produces:
        *       - application/json
        *     parameters:
        *       - name: body
        *         description: Fetch the audits list ( Based on entityType & entityId ).
        *         in: body
        *         required: true
        *         schema:
        *           properties:
        *               entityType:
        *                   type: string
        *               entityId:
        *                   type: string
        *               entityVersion: 
        *                   type: string
        *           required: [entityType, entityId, entityVersion]
        *     responses:
        *       200:
        *         description: successful operation
    */
    getList: {
        pre: null,
        process: "audit.getList",
        post: null,
        method: 'POST'
    },

    /**
        * @swagger
        * /a/eproc/audits/createComment:
        *   post:
        *     tags:
        *       - Eproc API
        *     summary: Create new conversation
        *     operationId: createComment
        *     description: Create new conversation
        *     produces:
        *       - application/json
        *     parameters:
        *       - name: body
        *         description: Create new conversation .
        *         in: body
        *         required: true
        *         schema:
        *           properties:
        *               entityType:
        *                   type: string
        *               entityId:
        *                   type: string
        *               version: 
        *                   type: number 
        *               comments: 
        *                   type: string 
        *               role: 
        *                   type: string 
        *               attachmentIds: 
        *                   type: array 
        *                   items:
        *                       type:string
        *               toUserId: 
        *                   type: array 
        *                   items:
        *                       type:string
        *               visibleTo: 
        *                   type: array 
        *                   items:
        *                       type:string
        *           required: [entityType, entityId, version, comments, role, attachmentIds, toUserId, visibleTo]
        *     responses:
        *       200:
        *         description: successful operation
    */
    createComment: {
        pre: null,
        process: "audit.createComment",
        post: null,
        method: 'POST'
    },
    /**
        * @swagger
        * /a/eproc/audits/createReply:
        *   post:
        *     tags:
        *       - Eproc API
        *     summary: Creat reply
        *     operationId: createReply
        *     description: Creat reply
        *     produces:
        *       - application/json
        *     parameters:
        *       - name: body
        *         description: Creat reply.
        *         in: body
        *         required: true
        *         schema:
        *           properties:
        *               entityType:
        *                   type: string
        *               entityId:
        *                   type: string
        *               parentAuditTrailId: 
        *                   type: string
        *               version: 
        *                   type: number 
        *               comments: 
        *                   type: string 
        *               role: 
        *                   type: string 
        *               attachmentIds: 
        *                   type: array 
        *                   items:
        *                       type:string
        *           required: [entityType, entityId, version, comments, role, attachmentIds, parentAuditTrailId]
        *     responses:
        *       200:
        *         description: successful operation
    */
    createReply: {
        pre: null,
        process: "audit.createReply",
        post: null,
        method: 'POST'
    }
};