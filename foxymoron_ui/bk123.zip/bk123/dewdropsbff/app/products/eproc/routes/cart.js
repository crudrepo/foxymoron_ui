"use strict";

module.exports = {    
    /**
     * @swagger
     * definitions:
     *   addItemToCart:
     *     properties:
     *       price:
     *         type: integer
     *       quantity:
     *         type: integer
     *       updateCartItem:
     *         type: boolean
     *       itemId:
     *          type: string
     *       sourceType:
     *          type: number
     *     required: [quantity, itemId, sourceType, price]
     */

    /**
    * @swagger
    * /a/eproc/carts:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add Item(s) to Cart
    *     operationId: addItemToCart
    *     description: Add Item(s) to Cart
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add item(s) to cart
    *         in: body
    *         required: true
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             $ref: '#/definitions/addItemToCart'
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "cart.addItemToCart",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * definitions:
     *   updateItemsInCart:
     *     properties:
     *       price:
     *         type: integer
     *       quantity:
     *         type: integer
     *       updateCartItem:
     *         type: boolean
     *       itemId:
     *          type: string
     *       sourceType:
     *          type: number
     *     required: [quantity, itemId, sourceType]
     */

    /**
    * @swagger
    * /a/eproc/carts:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update Item in Cart
    *     operationId: updateItemsInCart
    *     description: Update items in cart
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update items in cart
    *         in: body
    *         required: true
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             $ref: '#/definitions/updateItemsInCart'
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "cart.updateCartItem",
        post: null,
        method: 'PUT'
    },
	
    /**
	* @swagger
	* /a/eproc/carts/removeItems:
	*   delete:
	*     tags:
	*       - Eproc API
	*     summary: Remove Cart Item(s)
	*     operationId: removeItems
	*     description: Delete item(s) from cart.
	*     produces:
	*       - application/json
	*     parameters:
	*       - name: body
    *         description: Provide item id(s) to remove it from cart.
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *           required: [ids]
	*     responses:
	*       200:
	*         description: successful operation
	*/
	removeItems: {
        pre: null,
        process: "cart.removeItems",
        post: null,
        method: 'DELETE'
    },
	
	/**
	* @swagger
	* /a/eproc/carts/list:
	*   post:
	*     tags:
	*       - Eproc API
	*     summary: Get Cart Items
	*     operationId: eprocCartList
	*     description: Fetch all Cart Items
	*     produces:
	*       - application/json
	*     parameters:
	*       - name: body
	*         description: Provide pageNo & perPageRecords value to get the cart items.
	*         in: body
	*         schema:
	*           properties:
	*               pageNo:
	*                   type: integer
	*               perPageRecords:
	*                   type: integer
	*     responses:
	*       200:
	*         description: successful operation
	*/
	getList: {
        pre: null,
        process: "cart.getItemList",
        post: null,
        method: 'POST'
    },

    /**
	* @swagger
	* /a/eproc/carts:
	*   get:
	*     tags:
	*       - Eproc API
	*     summary: Get Cart Items
	*     operationId: get_eprocCartList
	*     description: Fetch all Cart Items
	*     produces:
	*       - application/json
	*     responses:
	*       200:
	*         description: successful operation
    */
    
    getRecords: {
        pre: null,
        process: "cart.getRecords",
        post: null,
        method: 'GET'
    },
	
	/**
	* @swagger
	* /a/eproc/carts/clear:
	*   delete:
	*     tags:
	*       - Eproc API
	*     summary: Delete All Items
	*     operationId: deleteAllCartItem
	*     description: Delete all items from cart.
	*     produces:
	*       - application/json
	*     responses:
	*       200:
	*         description: successful operation
	*/
	clear: {
        pre: null,
        process: "cart.clearCartItem",
        post: null,
        method: 'DELETE'
    },

    /**
	* @swagger
	* /a/eproc/carts/getLatestItems:
	*   post:
	*     tags:
	*       - Eproc API
	*     summary: Get Latest Cart Item(s)
	*     operationId: getLatestCartItems
	*     description: Get latest cart item(s).
	*     produces:
	*       - application/json
	*     parameters:
	*       - name: body
    *         description: Provide item id(s) to get latest cart items.
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
	*     responses:
	*       200:
	*         description: successful operation
	*/
	getLatestItems: {
        pre: null,
        process: "cart.getLatestItems",
        post: null,
        method: 'POST'
    },

    /**
	* @swagger
	* /a/eproc/carts/validateItems:
	*   post:
	*     tags:
	*       - Eproc API
	*     summary: Validate Cart Item(s)
	*     operationId: validateCartItems
	*     description: Validate cart item(s).
	*     produces:
	*       - application/json
	*     parameters:
	*       - name: body
    *         description: Validate cart items.
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
	*     responses:
	*       200:
	*         description: successful operation
	*/
	validateItems: {
        pre: null,
        process: "cart.validateItems",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * definitions:
     *   otherItemDetails:
     *     required: [itemId,imageURL,itemId,itemType,leadTime,name,sourcingStatus,price,receiptType,marketPrice,currency]
     *     properties:
     *       attachments:
     *          schema:
     *           $ref: '#/definitions/stringArray'
     *       currency:
     *          type: string 
     *       description:
     *          type: string
     *       imageURL:
     *          type: string
     *       isGreen:
     *          type: boolean
     *       isPreferred:
     *          type: boolean
     *       itemId:
     *          type: string
     *       itemType:
     *          type: integer  
     *       leadTime:
     *          type: integer 
     *       name:
     *          type: string  
     *       parametricData:
     *          schema:
     *           $ref: '#/definitions/stringArray'
     *       sourcingStatus:
     *          type: integer
     *       parametricName:
     *          schema:
     *           $ref: '#/definitions/stringArray'
     *       price:
     *          type: integer
     *       receiptType:
     *          type: integer  
     *       scopeId:
     *          type: string
     *       sourceRefNo:
     *          type: string
     *       manufacturerName:
     *          type: string
     *       manufacturerProductURL:
     *          type: string
     *       manufacturerPartId:
     *          type: string
     *       supplierId:
     *          type: integer
     *       supplierName:
     *          type: string   
     *       supplierPartId:
     *          type: string
     *       supplierProductURL:
     *          type: string
     *       marketPrice:
     *          type: integer
     *       uom:
     *          type: string
     *       quantity:
     *          type: integer
     *       supplierContact:
     *          type: string                   
     */

    /**
    * @swagger
    * /a/eproc/carts/addDetails:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add (virtual/item master) item to cart
    *     description: Add (virtual/item master) item to cart
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add (virtual/item master) item to cart.
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/otherItemDetails'
    *     responses:
    *       200:
    *         description: successful operation
    */
    addDetails: {
        pre: null,
        process: "cart.addDetails",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * definitions:
     *   itemMasterInventryItem:
     *     type: object
     *     required: [itemId]
     *     properties:
     *       scopeId: 
     *         type: string
     *       catalogId: 
     *         type: string
     *       catalogVersion:
     *         type: number
     *       catalogItemId: 
     *         type: number
     *       itemId:
     *         type: string
     *       supplierId: 
     *         type: string
     *       supplierName: 
     *         type: string
     *       supplierPartId: 
     *         type: string
     *       supplierAuxPartId: 
     *         type: string
     *       supplierAddressId: 
     *         type: string
     *       supplierAddress: 
     *         type: string
     *       supplierContact: 
     *         type: string
     *       supplierEmail: 
     *         type: string
     *       supplierContactType: 
     *         type: number
     *       supplierPhone: 
     *         type: string
     *       supplierOtherDetails: 
     *         type: string
     *       manufacturerPartId:
     *         type: string
     *       manufacturerName: 
     *         type: string
     *       name: 
     *         type: string
     *       description: 
     *         type: string
     *       uom: 
     *         type: string
     *       currency: 
     *         type: string
     *       price: 
     *         type: number
     *       marketPrice:
     *         type: number
     *       leadTime:
     *         type: number
     *       categoryCode:
     *         type: string
     *       categoryName:
     *         type: string
     *       unsspscCode:
     *         type: string
     *       unsspscName:
     *         type: string
     *       supplierProductURL:
     *         type: string
     *       manufacturerProductURL:
     *         type: string
     *       imageURL:
     *         type: string
     *       thumbnailURL:
     *         type: string
     *       sourceRefNo:
     *         type: string
     *       contractNo:
     *         type: string
     *       contractId:
     *         type: string
     *       sourceType:
     *         type: number
     *       itemType:
     *         type: number
     *       receiptType:
     *         type: number
     *       contractType:
     *         type: number
     *       error:
     *         type: boolean
     *       warning:
     *         type: boolean
     *       active:
     *         type: boolean
     *       hidden:
     *         type: boolean
     *       activity:
     *         type: number
     *       greenItem:
     *         type: boolean
     *       preferredItem: 
     *         type: boolean
     *       validFrom: 
     *         type: string
     *       validTo: 
     *         type: string
     *       publishedOn: 
     *         type: string
     *       attachments:
     *         type: array
     *         items: 
     *           type: string
     *       outOfStock: 
     *           type: boolean
     *       itemAttributes:
     *           type: object
     *       sourcingStatus:
     *           type: number
     *       externalId:
     *           type: string
     *       origin:
     *           type: number
     *       contracted:
     *           type: boolean
     *       parentItemId:
     *           type: string
     *       updated:
     *           type: boolean
     *       assetNumberRequired:
     *           type: boolean
     *       warehouseCode:
     *           type: string
     *       parentCatalogItemId:
     *           type: string
     *       supplierCurrency:
     *           type: string
     *       supplierLeadTime:
     *           type: number
     *       supplierStatus:
     *           type: object
     *       supplierCount:
     *           type: number
     *       priceValidFrom:
     *           type: date
     *       priceValidTo:
     *           type: string
     *       createdOn:
     *           type: string
     *       modifiedOn:
     *           type: string
     *       attachmentsStr:
     *           type: array
     *           items:
     *             type: string
     *       itemAttributesStr:
     *           type: string
     *       systemAttributesStr:
     *           type: string
     *       parametricName:
     *           type: array
     *           items:
     *             type: string
     *       parametricData:
     *           type: array
     *           items:
     *             type: string
     *       quantity:
     *           type: number
     *       requiredByDate:
     *           type: string
     *       internalComments:
     *           type: string
     *       supplierComments:
     *           type: string
     *       attachmentIds:
     *           type: array
     *           items:
     *             type: string
     */

    /**
     * @swagger
     * definitions:
     *   itemTax:
     *     type: object
     *     properties:
     *       tenantId:
     *         type: string
     *       type:
     *         type: string
     *       name:
     *         type: string
     *       rate:
     *         type: number
     *       compound:
     *         type: boolean
     */

    /**
     * @swagger
     * definitions:
     *   catalogItems:
     *     type: array
     *     items: 
     *       type: object
     *       required: [quantity]
     *       properties:
     *         item:
     *           type: object
     *           required: [itemId, sourceType]
     *           properties:
     *             itemId:
     *               type: string
     *             sourceType:
     *               type: number
     *         quantity:
     *           type: number
     *         assetNumberRequired:
     *           type: boolean
     *         itemTaxes:
     *           type: array
     *           items: 
     *              - $ref: '#/definitions/itemTax'
     *         price:
     *           type: number
     *         requiredByDate:
     *           type: string
     *         updateCartItem:
     *           type: boolean
     *         internalComments:
     *           type: string
     *         supplierComments:
     *           type: string
     *         attachmentIds:
     *           type: array
     *           items:
     *             type: string
     */
    
    /**
     * @swagger
     * definitions:
     *   guidedRequistion:
     *     type: object
     *     required: [itemQuantity, buyerPreview]
     *     properties:
     *       guidedRequisitionId:
     *         type: string
     *       categoryEformId:
     *         type: string
     *       dynamicFormId:
     *         type: string
     *       dynamicInstanceId:
     *         type: string
     *       categoryCode:
     *         type: string
     *       itemId:
     *         type: string
     *       itemQuantity: 
     *         type: string
     *       status:
     *         type: number
     *       quickSourceId:
     *         type: string
     *       quickSourceItemId:
     *         type: string
     *       buyerPreview:
     *         type: boolean
     */
    
    /**
     * @swagger
     * definitions:
     *   guidedRequisitionSupplierItem:
     *     type: object
     *     required: [supplierType]
     *     properties:
     *       supplierId: 
     *         type: string
     *       supplierType: 
     *         type: number
     *       name:
     *         type: string
     *       location:
     *         type: string
     *       addressDetails:
     *         type: string
     *       contactPerson:
     *         type: string
     *       contactPersonType:
     *         type: number
     *       email:
     *         type: string
     *       phone:
     *         type: string
     *       fax:
     *         type: string
     *       website:
     *         type: string
     *       description:
     *         type: string
     *       contractOrderId:
     *         type: string
     *       contractOrderNumber:
     *         type: string
     *       contractOrderType:
     *         type: number
     *       referenceId:
     *         type: string
     */

    /**
     * @swagger
     * definitions:
     *   guidedItemDefinition:
     *     type: object
     *     required: [active]
     *     properties:
     *       scopeId:
     *         type: string
     *       catalogId:
     *         type: string
     *       catalogVersion:
     *         type: number
     *       catalogItemId:
     *         type: number
     *       itemId:
     *         type: string
     *       supplierId:
     *         type: string
     *       supplierName:
     *         type: string
     *       supplierPartId:
     *         type: string
     *       supplierAuxPartId:
     *         type: string
     *       supplierAddressId:
     *         type: string
     *       supplierAddress:
     *         type: string
     *       supplierContact:
     *         type: string
     *       supplierEmail:
     *         type: string
     *       supplierContactType:
     *         type: number
     *       supplierPhone:
     *         type: string
     *       supplierOtherDetails:
     *         type: string
     *       manufacturerPartId:
     *         type: string
     *       manufacturerName:
     *         type: string
     *       name:
     *         type: string
     *       description:
     *         type: string
     *       uom:
     *         type: string
     *       currency:
     *         type: string
     *       price:
     *         type: number
     *       marketPrice:
     *         type: number
     *       leadTime:
     *         type: number
     *       categoryCode:
     *         type: string
     *       categoryName:
     *         type: string
     *       unsspscCode:
     *         type: string
     *       unsspscName:
     *         type: string
     *       supplierProductURL:
     *         type: string
     *       manufacturerProductURL:
     *         type: string
     *       imageURL:
     *         type: string
     *       thumbnailURL:
     *         type: string
     *       sourceRefNo:
     *         type: string
     *       contractNo:
     *         type: string
     *       contractId:
     *         type: string
     *       sourceType:
     *         type: number
     *       itemType:
     *         type: number
     *       receiptType:
     *         type: number
     *       contractType:
     *         type: number
     *       error:
     *         type: boolean
     *       warning:
     *         type: boolean
     *       active:
     *         type: boolean
     *       hidden:
     *         type: boolean
     *       activity:
     *         type: number
     *       greenItem:
     *         type: boolean
     *       preferredItem:
     *         type: boolean
     *       validFrom:
     *         type: string
     *       validTo:
     *         type: string
     *       publishedOn:
     *         type: string
     *       attachments: 
     *         type: array
     *         items: 
     *           type: string
     *       outOfStock:
     *         type: boolean
     *       systemAttributes:
     *         type: object
     *       itemAttributes:
     *         type: object
     *       sourcingStatus:
     *         type: number
     *       externalId:
     *         type: string
     *       origin:
     *         type: number
     *       contracted:
     *         type: boolean
     *       parentItemId:
     *         type: string
     *       updated:
     *         type: boolean
     *       assetNumberRequired:
     *         type: boolean
     *       warehouseCode:
     *         type: string
     *       parentCatalogItemId:
     *         type: string
     *       supplierCurrency:
     *         type: string
     *       supplierLeadTime:
     *         type: number
     *       supplierStatus:
     *         type: object
     *       supplierCount:
     *         type: number
     *       priceValidFrom:
     *         type: string
     *       priceValidTo:
     *         type: string
     *       createdOn:
     *         type: string
     *       modifiedOn:
     *         type: string
     *       attachmentsStr:
     *         type: array
     *         items: 
     *           type: string
     *       itemAttributesStr:
     *         type: string
     *       systemAttributesStr:
     *         type: string
     *       parametricName:
     *         type: array
     *         items: 
     *           type: string
     *       parametricData:
     *         type: array
     *         items: 
     *           type: string
     *       quantity:
     *         type: number
     */

    /**
     * @swagger
     * definitions:
     *   addGuidedItemsToCart:
     *     type: object
     *     properties:
     *       catalogItems:
     *         type: object
     *         $ref: '#/definitions/catalogItems'
     *       itemMasterInventryItems:
     *         type: array
     *         items: 
     *            - $ref: '#/definitions/itemMasterInventryItem'
     *       guidedRequisitionItems:
     *         type: array
     *         items:
     *           type: object
     *           properties:
     *              guidedRequisition:
     *                type: object
     *                $ref: '#/definitions/guidedRequistion'
     *              guidedRequisitionSupplier:
     *                type: array
     *                items:
     *                  type: object
     *                  $ref: '#/definitions/guidedRequisitionSupplierItem'
     *              guidedItem:
     *                type: object
     *                $ref: '#/definitions/guidedItemDefinition'
     *              requiredByDate:
     *                type: string
     *              internalComments:
     *                type: strnig
     *              supplierComments:
     *                type: strnig
     *              attachmentIds:
     *                type: array
     *                items:
     *                  type: string
     */
    
    /**
    * @swagger
    * /a/eproc/carts/addItems:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add Guided Procurement Item(s) to Cart
    *     operationId: addItems
    *     description: Add Guided Procurement Item(s) to Cart
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add Guided Procurement item(s) to cart
    *         in: body
    *         required: true
    *         schema:
    *             type: object
    *             $ref: '#/definitions/addGuidedItemsToCart'              
    *     responses:
    *       200:
    *         description: successful operation
    */
    addItems: {
        pre: null,
        process: "cart.addItems",
        post: null,
        method: 'POST'
    } 
};