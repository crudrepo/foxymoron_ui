"use strict";

module.exports = {

    // /**
    //  * @swagger
    //  * definitions:
    //  *   findRecord:
    //  *     properties:
    //  *       name:
    //  *         type: string
    //  *       pageNo:
    //  *         type: integer
    //  *       perPageRecords:
    //  *         type: integer
    //  *     required: [name]
    //  */

    // /**
    //  * @swagger
    //  * definitions:
    //  *   itemIds:
    //  *     required: [ids]
    //  *     properties:
    //  *       ids:
    //  *          schema:
    //  *            type: array
    //  *            items:
    //  *              type: string
    //  *              
    //  */

    // /**
    //  * @swagger
    //  * /a/eproc/catalogs/list:
    //  *   post:
    //  *     tags:
    //  *       - Eproc API
    //  *     summary: Get Catalogs
    //  *     operationId: getCatalogs
    //  *     description: Fetch all Catalog List
    //  *     produces:
    //  *       - application/json
    //  *     parameters:
    //  *       - name: body
    //  *         description: Find name or Provide page no to get records.
    //  *         in: body
    //  *         schema:
    //  *           $ref: '#/definitions/findRecord'
    //  *     responses:
    //  *       200:
    //  *         description: successful operation
    //  */
    // getList: {
    //     pre: null,
    //     process: "catalog.getList",
    //     post: null
    // },


    /**
     * @swagger
     * /a/eproc/catalogs/list:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get the  PreviouslyUsed/favourites/All catalog list
     *     operationId: list
     *     description: Get the  PreviouslyUsed/favourites/All catalog list
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch all PreviouslyUsed/favourites/All catalog list ( Based on those options filter, sorting & pagination ).
     *         in: body
     *         schema:
     *           allOf:
     *             - type: object
     *               properties:
     *                 isType:
     *                   type: string
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    getList: {
        pre: null,
        process: "catalog.getDataList",
        post: null,
        method: 'POST'
    }


};