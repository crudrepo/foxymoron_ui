"use strict";

module.exports = { 

    /**
    * @swagger
    * /a/eproc/processeforms/evaluate:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Evaluate process eForm
    *     operationId: evaluateprocesseForm
    *     description: Evaluate process eForm
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Evaluate process eform.
    *         in: body
    *         schema:
    *           properties:
    *             type:
    *               type: number
    *             processCode:
    *               type: string
    *             purchaseType:
    *               type: string
    *             purchaseTypeCode:
    *               type: string
    *             companyCode:
    *               type: string
    *             regions:
    *               type: array
    *               items:
    *                 type: string
    *             businessUnitCode:
    *               type: string
    *             locationCode:
    *               type: string
    *           required: [type, processCode, companyCode, businessUnitCode, locationCode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    evaluate: {
        pre: null,
        process: "processeform.evaluate",
        post: null,
        method: 'POST'
    }

}