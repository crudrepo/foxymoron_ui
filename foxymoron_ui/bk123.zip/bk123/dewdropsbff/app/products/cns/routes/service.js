"use strict";

module.exports = {    
   
   
   /**
    * @swagger
    * /a/cns/services/notificationRequest:
    *   post:
    *     tags:
    *       - CNS API
    *     summary: Get & Close notification
    *     operationId: Get&CloseNotification
    *     description: Get & Close notification
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get & Close notification.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               productName:
    *                 type: string
    *               type:
    *                 type: integer
    *             required: [productName, type]
    *     responses:
    *       200:
    *         description: successful operation
    */
    notificationRequest: {
        pre: null,
        process: "service.notificationRequest",
        post: null,
        method: 'POST'
    }

};