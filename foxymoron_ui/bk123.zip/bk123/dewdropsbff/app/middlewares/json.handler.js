"use strict";
const errorMsg = require('@helper/error.message'),
    rm = require('@service/require.module')()

/*
* Provide the middleware to handled the bad JSON data from request input.
*/
exports.jsonError = (error, req, res, next) => {
    if (error instanceof SyntaxError && error.status === 400 && 'body' in error) {               
        errorMsg.errorFormat({"request":req, "response":res, "errorMsg":"Invalid JSON Data", "errorType":"AppError", "statusCode":400, "lang":rm.i18nConfig.defaultLocale});        
    }else{
      next();
    }
};
