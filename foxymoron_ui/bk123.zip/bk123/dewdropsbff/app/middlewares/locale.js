"use strict";

exports.setLocale = (req, res, next) => {
  try {
    if (req.user) {
      req.setLocale(req.user.lang);
      next();
    } else {
      next();
    }
  } catch (error) {
    next(error);
  }
}